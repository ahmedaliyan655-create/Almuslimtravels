-- Al Muslim Travel CRM - CLEAN DATABASE SCHEMA
-- Generated for MariaDB 10.4+ / MySQL 8+
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE TABLE `agents` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `agent_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `pin_hash` varchar(255) NOT NULL,
  `role` enum('manager','admin','teamlead','agent') NOT NULL DEFAULT 'agent',
  `commission_pct` decimal(5,2) NOT NULL DEFAULT 5.00,
  `team_id` int(10) UNSIGNED DEFAULT NULL,
  `team_lead_id` int(10) UNSIGNED DEFAULT NULL,
  `default_project_id` int(10) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `login_status` enum('Online','Offline') DEFAULT 'Offline',
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `agent_projects` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `bonus_claims` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) UNSIGNED NOT NULL,
  `bonus_type` enum('call30','sameday','saturday','sunday','followup','review','videoreview','weekly3','weekly4','weekly5','monthly12','special','custom') NOT NULL,
  `booking_ref` varchar(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `proof_note` text DEFAULT NULL,
  `proof_file` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `admin_note` text DEFAULT NULL,
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `bookings` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(20) NOT NULL,
  `invoice_prefix` varchar(20) DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `gds_pnr` varchar(20) DEFAULT NULL,
  `airline_pnr` varchar(30) DEFAULT NULL,
  `travel_date` date DEFAULT NULL,
  `status` enum('New','Confirmed','Departed','In Makkah','In Madinah','Returning','Completed','Cancelled') NOT NULL DEFAULT 'New',
  `booking_source` enum('Manual','Sabre PNR','Package Parser','Import') NOT NULL DEFAULT 'Manual',
  `booking_type` varchar(100) DEFAULT NULL,
  `client_name` varchar(150) NOT NULL,
  `client_mobile` varchar(30) DEFAULT NULL,
  `client_email` varchar(150) DEFAULT NULL,
  `destination` varchar(200) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `agent_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `atol_charges` decimal(10,2) NOT NULL DEFAULT 0.00,
  `safi_charges` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(10) NOT NULL DEFAULT 'GBP',
  `gross_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_received` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance_due` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_cost_rows` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `age_category` enum('ADULT','CHILD','YOUTH','INFANT','MAK HOTEL','MED HOTEL','VISA','TRANSPORT','OTHER') NOT NULL,
  `category_type` enum('ADULT','CHILD','INFANT','HOTEL','TRANSPORT','VISA','INSURANCE','OTHER') DEFAULT 'ADULT',
  `quantity` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `base_fare` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `selling_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `net_cost` decimal(10,2) GENERATED ALWAYS AS (`base_fare` + `tax`) STORED,
  `total_net` decimal(10,2) GENERATED ALWAYS AS ((`base_fare` + `tax`) * `quantity`) STORED,
  `selling_total` decimal(10,2) GENERATED ALWAYS AS (`selling_price` * `quantity`) STORED,
  `margin` decimal(10,2) GENERATED ALWAYS AS (`selling_price` * `quantity` - (`base_fare` + `tax`) * `quantity`) STORED,
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_flights` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `airline_code` varchar(3) NOT NULL,
  `booking_class` varchar(50) DEFAULT NULL,
  `flight_no` varchar(10) NOT NULL,
  `dept_date` date NOT NULL,
  `origin` char(3) NOT NULL,
  `destination` char(3) NOT NULL,
  `terminal` varchar(50) DEFAULT NULL,
  `dept_time` time DEFAULT NULL,
  `arr_time` time DEFAULT NULL,
  `baggage` varchar(50) DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `ticket_no` varchar(100) DEFAULT NULL,
  `flight_status` enum('Pending','Booked','Ticketed','Cancelled') DEFAULT 'Pending',
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_hotels` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `hotel_name` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `room_type` varchar(100) DEFAULT NULL,
  `rooms` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `meal_basis` enum('R/O','B/B','H/B','F/B') NOT NULL DEFAULT 'R/O',
  `room_view` varchar(50) DEFAULT NULL,
  `check_in` date NOT NULL,
  `nights` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `check_out` date NOT NULL,
  `reservation_no` varchar(50) DEFAULT NULL,
  `hotel_status` enum('Pending','Reserved','Tentative','Definitive','Cancelled') DEFAULT 'Pending',
  `expiry_date` date DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `hotel_supplier` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_logs` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `agent_id` int(10) UNSIGNED NOT NULL,
  `module` varchar(50) DEFAULT 'Booking',
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_passengers` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `title` enum('MR','MRS','MS','MISS','CHILD','DR','PROF','MST','INFANT') NOT NULL DEFAULT 'MR',
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `dob` date DEFAULT NULL,
  `passport_no` varchar(100) DEFAULT NULL,
  `passport_expiry` date DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `visa_status` enum('Pending','Applied','Approved','Rejected','Issued') DEFAULT 'Pending',
  `visa_number` varchar(100) DEFAULT NULL,
  `visa_issue_date` date DEFAULT NULL,
  `visa_expiry_date` date DEFAULT NULL,
  `visa_notes` text DEFAULT NULL,
  `visa_supplier` varchar(255) DEFAULT NULL,
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_payments` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `receipt_id` varchar(50) DEFAULT NULL,
  `profile_id` varchar(100) DEFAULT NULL,
  `payer_name` varchar(150) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `method` enum('Natwest Bank','HBL Pakistan','E Payment','London Office Card Merchant','Cash - London Office','barclays Bank','Revolut Bank') NOT NULL DEFAULT 'Natwest Bank',
  `credit_debit` enum('CREDIT','DEBIT') NOT NULL DEFAULT 'DEBIT',
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('Pending','Received','Refunded') DEFAULT 'Received',
  `reference_no` varchar(100) DEFAULT NULL,
  `received_by` int(11) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(150) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_products` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_transports` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `vehicle` varchar(100) NOT NULL,
  `journey` text NOT NULL,
  `vehicles_qty` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `pickup_date` date DEFAULT NULL,
  `pickup_time` time DEFAULT NULL,
  `transport_status` enum('Pending','Confirmed','Completed','Cancelled') DEFAULT 'Pending',
  `driver_name` varchar(255) DEFAULT NULL,
  `driver_mobile` varchar(30) DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `confirmation_no` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `integration_logs` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `source` enum('meta_webhook','website_form','zapier','json_import','csv_import','url_param') NOT NULL,
  `raw_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`raw_payload`)),
  `lead_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('success','failed','duplicate') NOT NULL DEFAULT 'success',
  `error_msg` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `leads` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(15) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `whatsapp` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `service_type` enum('Umrah','Hajj','Holiday Package','Flights Only','Hotel Only','Visa Only') NOT NULL DEFAULT 'Umrah',
  `source` enum('Facebook Ads','Instagram Ads','Website Form','Google Ads','WhatsApp','Direct Call','Referral','Walk-in','Existing Customer') NOT NULL DEFAULT 'Facebook Ads',
  `campaign` varchar(200) DEFAULT NULL,
  `travel_month` varchar(50) DEFAULT NULL,
  `adults` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `youth` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `children` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `infants` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `budget` decimal(10,2) DEFAULT NULL,
  `priority` enum('Hot','Warm','Cold') NOT NULL DEFAULT 'Warm',
  `status` enum('New Lead','Attempted Contact','No Answer','Wrong Number','Invalid Lead','Interested','Wants Cheapest Package','Wants Family Package','Follow-up Later','Call Tomorrow','Not Ready Yet','Booked','Lost Lead','Duplicate') NOT NULL DEFAULT 'New Lead',
  `assigned_to` int(10) UNSIGNED DEFAULT NULL,
  `follow_up_date` date DEFAULT NULL,
  `message` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `enquiry_date` date NOT NULL,
  `converted_booking_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `lead_activity_log` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `log_text` text NOT NULL,
  `log_type` enum('call','note','status','assign','visit','booked','email','whatsapp') NOT NULL DEFAULT 'note',
  `logged_by` int(10) UNSIGNED DEFAULT NULL,
  `logged_by_name` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `projects` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_name` varchar(150) NOT NULL,
  `project_code` varchar(50) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `monthly_target` decimal(12,2) DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1,
  `logo` varchar(255) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `project_invoice_sequences` (

  `project_id` int(10) UNSIGNED NOT NULL,
  `last_number` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `sessions` (

  `id` varchar(128) NOT NULL,
  `agent_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `teams` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `team_lead_id` int(10) UNSIGNED NOT NULL,
  `monthly_target` int(11) NOT NULL DEFAULT 20,
  `created_by` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `work_type` enum('followup','booking','both') DEFAULT 'both'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `team_bonus_awards` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `team_id` int(10) UNSIGNED NOT NULL,
  `period_month` date NOT NULL,
  `bookings_count` int(11) NOT NULL DEFAULT 0,
  `tier_level` enum('tier1','tier2','tier3') DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `approved_by` int(10) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `team_members` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `team_id` int(10) UNSIGNED NOT NULL,
  `agent_id` int(10) UNSIGNED NOT NULL,
  `assigned_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_delete_requests` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `requester_id` int(10) UNSIGNED NOT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_edit_requests` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `requester_id` int(10) UNSIGNED NOT NULL,
  `status` enum('Pending','Approved','Rejected','Used') NOT NULL DEFAULT 'Pending',
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `used_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `booking_alerts` (

  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) UNSIGNED NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `alert_date` date NOT NULL,
  `seen_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'system',
  `category` varchar(50) NOT NULL DEFAULT 'system',
  `title` varchar(180) NOT NULL,
  `message` text NOT NULL,
  `priority` enum('low','normal','high','critical') NOT NULL DEFAULT 'normal',
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `action_url` varchar(500) DEFAULT NULL,
  `dedupe_key` varchar(191) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notifications_dedupe` (`dedupe_key`),
  KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`),
  KEY `idx_notifications_category` (`user_id`,`category`,`created_at`),
  KEY `idx_notifications_entity` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Indexes
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_agents_code` (`agent_code`),
  ADD UNIQUE KEY `uq_agents_email` (`email`),
  ADD KEY `idx_agents_role` (`role`),
  ADD KEY `idx_agents_team` (`team_id`),
  ADD KEY `idx_agents_default_project` (`default_project_id`);

ALTER TABLE `agent_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_agent_project` (`agent_id`,`project_id`),
  ADD KEY `idx_agent_projects_project` (`project_id`);

ALTER TABLE `bonus_claims`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_bonus_reviewed_by` (`reviewed_by`),
  ADD KEY `idx_bonus_agent` (`agent_id`),
  ADD KEY `idx_bonus_status` (`status`);

ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_bookings_invoice` (`invoice_no`),
  ADD KEY `idx_bookings_agent` (`agent_id`),
  ADD KEY `idx_bookings_status` (`status`),
  ADD KEY `idx_bookings_date` (`travel_date`),
  ADD KEY `idx_bookings_project` (`project_id`);

ALTER TABLE `booking_cost_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cost_booking` (`booking_id`);

ALTER TABLE `booking_flights`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_flights_booking` (`booking_id`);

ALTER TABLE `booking_hotels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_hotels_booking` (`booking_id`);

ALTER TABLE `booking_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_booking_logs_booking` (`booking_id`),
  ADD KEY `idx_booking_logs_agent` (`agent_id`);

ALTER TABLE `booking_passengers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pax_booking` (`booking_id`);

ALTER TABLE `booking_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payments_booking` (`booking_id`),
  ADD KEY `idx_payments_date` (`payment_date`),
  ADD KEY `idx_payments_status` (`payment_status`),
  ADD KEY `idx_payments_transaction` (`transaction_id`);

ALTER TABLE `booking_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_products_booking` (`booking_id`);

ALTER TABLE `booking_transports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transport_booking` (`booking_id`);

ALTER TABLE `integration_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_integration_lead` (`lead_id`),
  ADD KEY `idx_intlog_source` (`source`),
  ADD KEY `idx_intlog_created` (`created_at`);

ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_leads_lead_id` (`lead_id`),
  ADD KEY `idx_leads_converted_booking` (`converted_booking_id`),
  ADD KEY `idx_leads_status` (`status`),
  ADD KEY `idx_leads_source` (`source`),
  ADD KEY `idx_leads_priority` (`priority`),
  ADD KEY `idx_leads_assigned` (`assigned_to`),
  ADD KEY `idx_leads_followup` (`follow_up_date`),
  ADD KEY `idx_leads_date` (`enquiry_date`),
  ADD KEY `idx_leads_updated` (`updated_at`);

ALTER TABLE `lead_activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_lead_activity_logged_by` (`logged_by`),
  ADD KEY `idx_lead_activity_lead` (`lead_id`);

ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_project_code` (`project_code`);

ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_session_agent` (`agent_id`),
  ADD KEY `idx_session_expires` (`expires_at`);

ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_teams_teamlead` (`team_lead_id`),
  ADD KEY `idx_teams_createdby` (`created_by`);

ALTER TABLE `team_bonus_awards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_team_month` (`team_id`,`period_month`),
  ADD KEY `idx_team_bonus_approved_by` (`approved_by`);

ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_team_agent` (`team_id`,`agent_id`),
  ADD KEY `idx_team_members_agent` (`agent_id`);

ALTER TABLE `booking_delete_requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_pending_delete` (`booking_id`,`requester_id`,`status`),
  ADD KEY `idx_delete_status` (`status`),
  ADD KEY `idx_delete_booking` (`booking_id`),
  ADD KEY `idx_delete_requester` (`requester_id`);

ALTER TABLE `booking_edit_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_edit_request_status` (`status`),
  ADD KEY `idx_edit_request_booking` (`booking_id`),
  ADD KEY `idx_edit_request_requester` (`requester_id`);

ALTER TABLE `booking_alerts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_booking_alert_date` (`alert_date`,`seen_at`),
  ADD KEY `idx_booking_alert_booking` (`booking_id`),
  ADD KEY `idx_booking_alert_creator` (`created_by`);

ALTER TABLE `leads` ADD FULLTEXT KEY `ft_leads_search` (`name`,`phone`,`email`);

-- Foreign keys
ALTER TABLE `agents`
  ADD CONSTRAINT `fk_agent_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_agents_default_project` FOREIGN KEY (`default_project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `agent_projects`
  ADD CONSTRAINT `fk_agent_projects_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_agent_projects_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

ALTER TABLE `bonus_claims`
  ADD CONSTRAINT `fk_bonus_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_bonus_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `agents` (`id`) ON DELETE SET NULL;

ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_booking_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`),
  ADD CONSTRAINT `fk_booking_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON UPDATE CASCADE;

ALTER TABLE `booking_cost_rows`
  ADD CONSTRAINT `fk_cost_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_flights`
  ADD CONSTRAINT `fk_flight_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_hotels`
  ADD CONSTRAINT `fk_hotel_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_logs`
  ADD CONSTRAINT `fk_booking_log_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_passengers`
  ADD CONSTRAINT `fk_passenger_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_payments`
  ADD CONSTRAINT `fk_payment_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_products`
  ADD CONSTRAINT `fk_product_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_transports`
  ADD CONSTRAINT `fk_transport_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

ALTER TABLE `integration_logs`
  ADD CONSTRAINT `fk_integration_log_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL;

ALTER TABLE `leads`
  ADD CONSTRAINT `fk_lead_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `agents` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_lead_converted_booking` FOREIGN KEY (`converted_booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL;

ALTER TABLE `lead_activity_log`
  ADD CONSTRAINT `fk_lead_activity_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_lead_activity_agent` FOREIGN KEY (`logged_by`) REFERENCES `agents` (`id`) ON DELETE SET NULL;

ALTER TABLE `sessions`
  ADD CONSTRAINT `fk_session_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE;

ALTER TABLE `teams`
  ADD CONSTRAINT `fk_team_created_by` FOREIGN KEY (`created_by`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_team_lead` FOREIGN KEY (`team_lead_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE;

ALTER TABLE `team_bonus_awards`
  ADD CONSTRAINT `fk_team_bonus_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_team_bonus_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `agents` (`id`) ON DELETE SET NULL;

ALTER TABLE `team_members`
  ADD CONSTRAINT `fk_team_member_agent` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_team_member_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;

ALTER TABLE `booking_delete_requests`
  ADD CONSTRAINT `fk_delete_request_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_delete_request_requester` FOREIGN KEY (`requester_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_delete_request_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `agents` (`id`) ON DELETE SET NULL;

ALTER TABLE `booking_edit_requests`
  ADD CONSTRAINT `fk_edit_request_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_edit_request_requester` FOREIGN KEY (`requester_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_edit_request_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `agents` (`id`) ON DELETE SET NULL;

ALTER TABLE `booking_alerts`
  ADD CONSTRAINT `fk_booking_alert_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_booking_alert_creator` FOREIGN KEY (`created_by`) REFERENCES `agents` (`id`) ON DELETE CASCADE;

COMMIT;
