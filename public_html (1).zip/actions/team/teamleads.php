<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try{

    /*
    |--------------------------------------------------------------------------
    | Only Admin & Manager
    |--------------------------------------------------------------------------
    */

    if(
        $_SESSION['role'] != "admin" &&
        $_SESSION['role'] != "manager"
    ){

        jsonResponse(false,"Permission denied.");

    }

    $rows = Database::select(

        "SELECT

            id,
            name

        FROM agents

        WHERE role='teamlead'

        AND is_active=1

        ORDER BY name"

    );

    jsonResponse(

        true,

        "",

        $rows

    );

}catch(Exception $e){

    jsonResponse(

        false,

        $e->getMessage()

    );

}