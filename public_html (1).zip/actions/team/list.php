<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    $loginId   = $_SESSION['agent_id'];
    $loginRole = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Base Query
    |--------------------------------------------------------------------------
    */

    $sql = "

       SELECT

            t.id,
            t.name,
            t.monthly_target,
            t.work_type,
            t.team_lead_id,
            t.created_by,
            t.created_at,

            tl.name AS team_lead,
            tl.profile_image AS team_lead_image,

            COUNT(DISTINCT tm.agent_id) AS total_members

        FROM teams t

        LEFT JOIN agents tl
            ON tl.id = t.team_lead_id

        LEFT JOIN team_members tm
            ON tm.team_id = t.id

    ";

    /*
    |--------------------------------------------------------------------------
    | Permission
    |--------------------------------------------------------------------------
    */

    if ($loginRole == "admin" || $loginRole == "manager") {

        $sql .= "

            GROUP BY t.id
            ORDER BY t.id DESC
        ";

        $rows = Database::select($sql);

    }

    elseif ($loginRole == "teamlead") {

        $sql .= "

            WHERE t.team_lead_id=?

            GROUP BY t.id
            ORDER BY t.id DESC
        ";

        $rows = Database::select(

            $sql,

            [

                $loginId

            ]

        );

    }

    else {

        $sql .= "

            INNER JOIN team_members tmm
                ON tmm.team_id=t.id

            WHERE tmm.agent_id=?

            GROUP BY t.id
            ORDER BY t.id DESC
        ";

        $rows = Database::select(

            $sql,

            [

                $loginId

            ]

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Statistics
    |--------------------------------------------------------------------------
    */

    $stats = [

        "totalTeams"    => count($rows),

        "totalAgents"   => 0,

        "monthlyTarget" => 0,

        "bonusEarned"   => count($rows)

    ];

    foreach ($rows as $r) {

        $stats["totalAgents"] += intval($r["total_members"]);

        $stats["monthlyTarget"] += intval($r["monthly_target"]);

    }

    /*
    |--------------------------------------------------------------------------
    | Cards
    |--------------------------------------------------------------------------
    */

    $data = [];

    foreach ($rows as $row) {

        /*
        ----------------------------------------------------
        Team Lead Image
        ----------------------------------------------------
        */

        $teamLeadImage = "https://ui-avatars.com/api/?name=" .
            urlencode($row["team_lead"]) .
            "&background=16284e&color=ffffff";

        if (

            !empty($row["team_lead_image"]) &&
            file_exists("../../uploads/".$row["team_lead_image"])

        ) {

            $teamLeadImage = "../uploads/".$row["team_lead_image"];

        }

        /*
        ----------------------------------------------------
        Team Members
        ----------------------------------------------------
        */

        $members = Database::select(

            "SELECT

                a.name,
                a.profile_image

            FROM team_members tm

            INNER JOIN agents a

                ON a.id = tm.agent_id

            WHERE tm.team_id=?

            LIMIT 5",

            [

                $row["id"]

            ]

        );

        $avatars = "";

        foreach ($members as $member) {

            $img = "https://ui-avatars.com/api/?name=" .
                urlencode($member["name"]);

            if (

                !empty($member["profile_image"]) &&
                file_exists("../../uploads/".$member["profile_image"])

            ) {

                $img = "../uploads/".$member["profile_image"];

            }

            $avatars .= '

                <img

                    src="'.$img.'"

                    class="rounded-circle border border-white shadow-sm me-1"

                    style="width:38px;height:38px;object-fit:cover;">

            ';

        }

        /*
        ----------------------------------------------------
        Work Type Badge
        ----------------------------------------------------
        */

        $workType = "";

        switch ($row["work_type"]) {

            case "followup":

                $workType = '
                    <span class="badge bg-primary">
                        Follow Up
                    </span>
                ';

                break;

            case "booking":

                $workType = '
                    <span class="badge bg-success">
                        Booking
                    </span>
                ';

                break;

            default:

                $workType = '
                    <span class="badge bg-warning text-dark">
                        Both
                    </span>
                ';
        }

        /*
        ----------------------------------------------------
        Progress
        ----------------------------------------------------
        */

        $progress = 0;
                /*
        ----------------------------------------------------
        Buttons
        ----------------------------------------------------
        */

        $buttons = '

            <div class="btn-group">

                <button
                    class="btn btn-sm btn-primary btnViewTeam"
                    data-id="'.$row['id'].'">

                    <i class="fa fa-eye"></i>

                </button>

        ';

        if ($loginRole != "agent") {

            $buttons .= '

                <button
                    class="btn btn-sm btn-warning btnEditTeam"
                    data-id="'.$row['id'].'">

                    <i class="fa fa-edit"></i>

                </button>

                <button
                    class="btn btn-sm btn-danger btnDeleteTeam"
                    data-id="'.$row['id'].'">

                    <i class="fa fa-trash"></i>

                </button>

            ';

        }

        $buttons .= '

            </div>

        ';

        /*
        ----------------------------------------------------
        Team Card
        ----------------------------------------------------
        */

        $card = '

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="card shadow border-0 rounded-4 h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-start">

                        <div class="d-flex">

                            <img

                                src="'.$teamLeadImage.'"

                                class="rounded-circle shadow-sm"

                                style="width:55px;height:55px;object-fit:cover;">

                            <div class="ms-3">

                                <h5 class="mb-1 fw-bold">

                                    '.htmlspecialchars($row["name"]).'

                                </h5>

                                <small class="text-muted">

                                    Team Lead

                                </small>

                               <div class="fw-semibold">

                                    '.htmlspecialchars($row["team_lead"]).'

                                </div>

                                <div class="mt-2">

                                    '.$workType.'

                                </div>

                            </div>

                        </div>

                        '.$buttons.'

                    </div>

                    <hr>

                    <div class="row text-center mb-3">

                        <div class="col-6">

                            <h3 class="fw-bold text-primary">

                                '.$row["total_members"].'

                            </h3>

                            <small class="text-muted">

                                Members

                            </small>

                        </div>

                        <div class="col-6">

                            <h3 class="fw-bold text-success">

                                '.$row["monthly_target"].'

                            </h3>

                            <small class="text-muted">

                                Monthly Target

                            </small>

                        </div>

                    </div>

                    <div class="mb-3">

                        <small class="text-muted">

                            Team Members

                        </small>

                        <div class="mt-2">

                            '.$avatars.'

                        </div>

                    </div>

                    <div class="mb-3">

                        <small class="text-muted">

                            Progress

                        </small>

                        <div class="progress mt-2" style="height:8px;">

                            <div

                                class="progress-bar bg-success"

                                style="width:'.$progress.'%">

                            </div>

                        </div>

                        <small class="text-success fw-semibold">

                            '.$progress.'% Completed

                        </small>

                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-2 border-top">

                        <small class="text-muted">

                            Created

                            '.date("d M Y", strtotime($row["created_at"])).'

                        </small>

                        <span class="badge bg-primary">

                            Active

                        </span>

                    </div>

                </div>

            </div>

        </div>

        ';

        $data[] = [

            "card" => $card

        ];
            }

    /*
    |--------------------------------------------------------------------------
    | Response
    |--------------------------------------------------------------------------
    */

    jsonResponse(

        true,

        "",

        [

            "teams" => $data,

            "stats" => $stats

        ]

    );

} catch (Exception $e) {

    jsonResponse(

        false,

        $e->getMessage()

    );

}