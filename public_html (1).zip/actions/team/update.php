<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    Database::beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Login User
    |--------------------------------------------------------------------------
    */

    $loginId   = $_SESSION['agent_id'];
    $loginRole = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Form Data
    |--------------------------------------------------------------------------
    */

    $teamId         = intval($_POST['team_id'] ?? 0);
    $teamName       = clean($_POST['team_name'] ?? '');
    $monthlyTarget  = intval($_POST['monthly_target'] ?? 0);
    $work_type      = clean($_POST['work_type'] ?? 'both');
    $members        = $_POST['members'] ?? [];

    if (!is_array($members)) {

        $members = [];

    }

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if ($teamId <= 0) {

        jsonResponse(false, "Invalid Team.");

    }

    if ($teamName == "") {

        jsonResponse(false, "Please enter Team Name.");

    }

    if (empty($members)) {

        jsonResponse(false, "Please select at least one member.");

    }

    /*
    |--------------------------------------------------------------------------
    | Existing Team
    |--------------------------------------------------------------------------
    */

    $team = Database::selectOne(

        "SELECT *
         FROM teams
         WHERE id=?",

        [

            $teamId

        ]

    );

    if (!$team) {

        jsonResponse(false, "Team not found.");

    }

    /*
    |--------------------------------------------------------------------------
    | Permission
    |--------------------------------------------------------------------------
    */

    if (

        $loginRole == "teamlead" &&
        $team['team_lead_id'] != $loginId

    ) {

        jsonResponse(false, "Permission denied.");

    }

    /*
    |--------------------------------------------------------------------------
    | Team Lead
    |--------------------------------------------------------------------------
    */

    if (

        $loginRole == "admin" ||
        $loginRole == "manager"

    ) {

        $teamLeadId = intval($_POST['team_lead_id'] ?? 0);

        if ($teamLeadId <= 0) {

            jsonResponse(false, "Please select Team Lead.");

        }

    } else {

        $teamLeadId = $team['team_lead_id'];

    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Name
    |--------------------------------------------------------------------------
    */

    $exists = Database::selectOne(

        "SELECT id
         FROM teams
         WHERE name=?
         AND team_lead_id=?
         AND id<>?",

        [

            $teamName,
            $teamLeadId,
            $teamId

        ]

    );

    if ($exists) {

        jsonResponse(false, "Team already exists.");

    }

    /*
    |--------------------------------------------------------------------------
    | Update Team
    |--------------------------------------------------------------------------
    */

    Database::update(

        "UPDATE teams SET

            name=?,
            team_lead_id=?,
            monthly_target=?,
            work_type=?,
            updated_at=NOW()

        WHERE id=?",

        [

            $teamName,
            $teamLeadId,
            $monthlyTarget,
            $work_type,
            $teamId

        ]

    );

    /*
    |--------------------------------------------------------------------------
    | Remove Old Members
    |--------------------------------------------------------------------------
    */

    Database::delete(

        "DELETE FROM team_members
         WHERE team_id=?",

        [

            $teamId

        ]

    );

    /*
    |--------------------------------------------------------------------------
    | Add Members
    |--------------------------------------------------------------------------
    */

    foreach ($members as $agentId) {

        Database::insert(

            "INSERT INTO team_members
            (
                team_id,
                agent_id,
                assigned_at
            )
            VALUES
            (
                ?,
                ?,
                NOW()
            )",

            [

                $teamId,
                intval($agentId)

            ]

        );

    }

    Database::commit();

    jsonResponse(

        true,

        "Team updated successfully."

    );

} catch (Exception $e) {

    Database::rollback();

    jsonResponse(

        false,

        $e->getMessage()

    );

}