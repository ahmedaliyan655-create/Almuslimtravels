<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    $id = intval($_GET['id'] ?? 0);

    if ($id <= 0) {

        jsonResponse(false, "Invalid Team.");

    }

    $loginId   = $_SESSION['agent_id'];
    $loginRole = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Team
    |--------------------------------------------------------------------------
    */

    $team = Database::selectOne(

        "SELECT *
         FROM teams
         WHERE id=?",

        [

            $id

        ]

    );

    if (!$team) {

        jsonResponse(false, "Team not found.");

    }

    /*
    |--------------------------------------------------------------------------
    | Permission
    |--------------------------------------------------------------------------
    */

    if (

        $loginRole == "teamlead" &&
        $team['team_lead_id'] != $loginId

    ) {

        jsonResponse(false, "Permission denied.");

    }

    /*
    |--------------------------------------------------------------------------
    | Members
    |--------------------------------------------------------------------------
    */

    $rows = Database::select(

        "SELECT agent_id
         FROM team_members
         WHERE team_id=?",

        [

            $id

        ]

    );

    $members = [];

    foreach ($rows as $row) {

        $members[] = intval($row['agent_id']);

    }

    /*
    |--------------------------------------------------------------------------
    | Response
    |--------------------------------------------------------------------------
    */

    jsonResponse(

        true,

        "",

        [

            "id" => $team['id'],

            "team_name" => $team['name'],

            "team_lead_id" => $team['team_lead_id'],

            "monthly_target" => $team['monthly_target'],
            
            "work_type"=>$team["work_type"],

            "members" => $members

        ]

    );

} catch (Exception $e) {

    jsonResponse(

        false,

        $e->getMessage()

    );

}