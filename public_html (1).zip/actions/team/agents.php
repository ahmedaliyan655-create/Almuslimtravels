<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    $loginUserId = $_SESSION['agent_id'];
    $loginRole   = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Get Selected Team Lead
    |--------------------------------------------------------------------------
    */

    $selectedLead = intval($_GET['team_lead_id'] ?? 0);

    /*
    |--------------------------------------------------------------------------
    | Admin / Manager
    |--------------------------------------------------------------------------
    */

    if ($loginRole == "admin" || $loginRole == "manager") {

        /*
        |--------------------------------------------------------------
        | No Team Lead Selected
        |--------------------------------------------------------------
        */

        if ($selectedLead == 0) {

            jsonResponse(true, "", []);

        }

        $agents = Database::select(

            "SELECT
                id,
                name,
                designation,
                profile_image
            FROM agents
            WHERE role='agent'
            AND team_lead_id=?
            AND is_active=1
            ORDER BY name",

            [

                $selectedLead

            ]

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Team Lead
    |--------------------------------------------------------------------------
    */

    elseif ($loginRole == "teamlead") {

        $agents = Database::select(

            "SELECT
                id,
                name,
                designation,
                profile_image
            FROM agents
            WHERE role='agent'
            AND team_lead_id=?
            AND is_active=1
            ORDER BY name",

            [

                $loginUserId

            ]

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Agent
    |--------------------------------------------------------------------------
    */

    else {

        $agents = [];

    }

    /*
    |--------------------------------------------------------------------------
    | Prepare Response
    |--------------------------------------------------------------------------
    */

    $data = [];

    foreach ($agents as $agent) {

        if (

            !empty($agent['profile_image']) &&
            file_exists("../../uploads/" . $agent['profile_image'])

        ) {

            $image = "../uploads/" . $agent['profile_image'];

        } else {

            $image = "https://ui-avatars.com/api/?name=" .
                urlencode($agent['name']) .
                "&background=16284e&color=ffffff";

        }

        $data[] = [

            "id" => $agent['id'],

            "name" => $agent['name'],

            "designation" => $agent['designation'],

            "image" => $image

        ];

    }

    jsonResponse(

        true,

        "",

        $data

    );

} catch (Exception $e) {

    jsonResponse(

        false,

        $e->getMessage()

    );

}