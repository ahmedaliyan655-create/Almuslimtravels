<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    Database::beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Logged In User
    |--------------------------------------------------------------------------
    */

    $loginUserId = $_SESSION['agent_id'];
    $loginRole   = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Form Data
    |--------------------------------------------------------------------------
    */

    $teamName       = clean($_POST['team_name'] ?? '');
    $monthlyTarget  = intval($_POST['monthly_target'] ?? 20);
    $work_type = clean($_POST['work_type'] ?? 'both');
    $members        = $_POST['members'] ?? [];

    /*
    |--------------------------------------------------------------------------
    | Team Lead
    |--------------------------------------------------------------------------
    */

    if ($loginRole == "teamlead") {

        $teamLeadId = $loginUserId;

    } else {

        $teamLeadId = intval($_POST['team_lead_id'] ?? 0);

    }

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if ($teamName == "") {

        jsonResponse(false, "Please enter Team Name.");

    }

    if ($teamLeadId <= 0) {

        jsonResponse(false, "Please select Team Lead.");

    }

    if (!is_array($members) || count($members) == 0) {

        jsonResponse(false, "Please select at least one member.");

    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Team Name (same Team Lead)
    |--------------------------------------------------------------------------
    */

    $exists = Database::selectOne(

        "SELECT id
         FROM teams
         WHERE name=?
         AND team_lead_id=?",

        [

            $teamName,
            $teamLeadId

        ]

    );

    if ($exists) {

        jsonResponse(false, "This team already exists.");

    }

    /*
    |--------------------------------------------------------------------------
    | Create Team
    |--------------------------------------------------------------------------
    */

    $teamId = Database::insert(

        "INSERT INTO teams
        (
            name,
            team_lead_id,
            created_by,
            monthly_target,
            work_type,
            created_at,
            updated_at
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            NOW(),
            NOW()
        )",

        [

            $teamName,
            $teamLeadId,
            $loginUserId,
            $monthlyTarget,
            $work_type

        ]

    );

    /*
    |--------------------------------------------------------------------------
    | Add Members
    |--------------------------------------------------------------------------
    */

    foreach ($members as $agentId) {

        $agentId = intval($agentId);

        /*
        ---------------------------------------
        Insert into team_members
        ---------------------------------------
        */

        Database::insert(

            "INSERT INTO team_members
            (
                team_id,
                agent_id,
                assigned_at
            )
            VALUES
            (
                ?,
                ?,
                NOW()
            )",

            [

                $teamId,
                $agentId

            ]

        );

    }

    Database::commit();

    jsonResponse(

        true,

        "Team created successfully.",

        [

            "team_id" => $teamId

        ]

    );

} catch (Exception $e) {

    Database::rollback();

    jsonResponse(

        false,

        $e->getMessage()

    );

}