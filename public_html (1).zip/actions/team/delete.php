<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    Database::beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Login User
    |--------------------------------------------------------------------------
    */

    $loginId   = $_SESSION['agent_id'];
    $loginRole = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Team ID
    |--------------------------------------------------------------------------
    */

    $teamId = intval($_POST['id'] ?? 0);

    if ($teamId <= 0) {

        jsonResponse(false, "Invalid Team.");

    }

    /*
    |--------------------------------------------------------------------------
    | Find Team
    |--------------------------------------------------------------------------
    */

    $team = Database::selectOne(

        "SELECT *
         FROM teams
         WHERE id=?",

        [

            $teamId

        ]

    );

    if (!$team) {

        jsonResponse(false, "Team not found.");

    }

    /*
    |--------------------------------------------------------------------------
    | Permission Check
    |--------------------------------------------------------------------------
    */

    if (

        $loginRole == "teamlead" &&
        $team['team_lead_id'] != $loginId

    ) {

        jsonResponse(false, "Permission denied.");

    }

    if (

        !in_array($loginRole, ["admin", "manager", "teamlead"])

    ) {

        jsonResponse(false, "Permission denied.");

    }

    /*
    |--------------------------------------------------------------------------
    | Delete Team Members
    |--------------------------------------------------------------------------
    */

    Database::delete(

        "DELETE FROM team_members
         WHERE team_id=?",

        [

            $teamId

        ]

    );

    /*
    |--------------------------------------------------------------------------
    | Delete Team
    |--------------------------------------------------------------------------
    */

    Database::delete(

        "DELETE FROM teams
         WHERE id=?",

        [

            $teamId

        ]

    );

    Database::commit();

    jsonResponse(

        true,

        "Team deleted successfully."

    );

} catch (Exception $e) {

    Database::rollback();

    jsonResponse(

        false,

        $e->getMessage()

    );

}