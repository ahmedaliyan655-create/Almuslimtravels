<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/permissions.php";

header("Content-Type: application/json");

try {

    Database::beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Get Data
    |--------------------------------------------------------------------------
    */

    $agent_id       = intval($_POST['agent_id'] ?? 0);
    $name           = clean($_POST['name'] ?? '');
    $email          = clean($_POST['email'] ?? '');
    $phone          = clean($_POST['phone'] ?? '');
    $designation    = clean($_POST['designation'] ?? '');
    $joining_date   = clean($_POST['joining_date'] ?? '');
    $pin            = trim($_POST['pin'] ?? '');
    $role           = clean($_POST['role'] ?? '');
    $commission_pct = floatval($_POST['commission_pct'] ?? 0);
    $team_id        = !empty($_POST['team_id']) ? intval($_POST['team_id']) : null;
    $team_lead_id = !empty($_POST['team_lead_id'])
    ? intval($_POST['team_lead_id'])
    : null;
    $is_active      = intval($_POST['is_active'] ?? 1);

    $projects = $_POST['projects'] ?? [];

    if (!is_array($projects)) {
        $projects = [];
    }

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if ($agent_id <= 0) {
        jsonResponse(false,"Invalid Agent.");
    }
    if (!canEditStaffMember($agent_id)) {
        jsonResponse(false, "Permission denied.");
    }

    if ($name=="") {
        jsonResponse(false,"Please enter full name.");
    }

    if ($role=="") {
        jsonResponse(false,"Please select role.");
    }

    /*
    |--------------------------------------------------------------------------
    | Existing Agent
    |--------------------------------------------------------------------------
    */

    $agent = Database::selectOne(

        "SELECT *
         FROM agents
         WHERE id=?",

        [$agent_id]

    );

    if(!$agent){

        jsonResponse(false,"Agent not found.");

    }

    if (isTeamLead()) {
        if ($agent['role'] !== 'agent' || $role !== 'agent') {
            jsonResponse(false, "Team Leads can only manage agent accounts.");
        }
        $team_lead_id = (int) authId();
    }

    if (isAdmin() && $agent['role'] === 'manager') {
        jsonResponse(false, "Admins cannot edit the Manager account.");
    }
    if (isAdmin() && !in_array($role, ['agent','teamlead'], true)) {
        jsonResponse(false, "Admins cannot promote staff to Manager or Admin.");
    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Email
    |--------------------------------------------------------------------------
    */

    if($email!=""){

        $exists = Database::selectOne(

            "SELECT id
             FROM agents
             WHERE email=?
             AND id<>?",

            [

                $email,
                $agent_id

            ]

        );

        if($exists){

            jsonResponse(false,"Email already exists.");

        }

    }

    /*
    |--------------------------------------------------------------------------
    | Profile Image
    |--------------------------------------------------------------------------
    */

    $profile_image = $agent['profile_image'];

    if(

        isset($_FILES['profile_image']) &&
        $_FILES['profile_image']['error']==UPLOAD_ERR_OK

    ){

        $extension = strtolower(

            pathinfo(

                $_FILES['profile_image']['name'],

                PATHINFO_EXTENSION

            )

        );

        $allowed=[

            "jpg",
            "jpeg",
            "png",
            "webp"

        ];

        if(!in_array($extension,$allowed)){

            jsonResponse(false,"Only JPG, PNG & WEBP allowed.");

        }

        $uploadDir="../../uploads/";

        if(!is_dir($uploadDir)){

            mkdir($uploadDir,0777,true);

        }

        $newImage=uniqid("staff_").".".$extension;

        if(

            !move_uploaded_file(

                $_FILES['profile_image']['tmp_name'],

                $uploadDir.$newImage

            )

        ){

            jsonResponse(false,"Unable to upload image.");

        }

        if(

            !empty($profile_image) &&
            file_exists($uploadDir.$profile_image)

        ){

            unlink($uploadDir.$profile_image);

        }

        $profile_image=$newImage;

    }

    /*
    |--------------------------------------------------------------------------
    | Default Project
    |--------------------------------------------------------------------------
    */

    $default_project_id = null;

    if(

        ($role=="agent" || $role=="teamlead") && !empty($projects)

    ){

        $default_project_id = intval($projects[0]);

    }

    /*
    |--------------------------------------------------------------------------
    | Update Agent
    |--------------------------------------------------------------------------
    */

    if($pin!=""){

        if(strlen($pin)<4){

            jsonResponse(false,"PIN must be at least 4 digits.");

        }

        $pin_hash=password_hash($pin,PASSWORD_DEFAULT);

        Database::update(

            "UPDATE agents SET

                name=?,
                email=?,
                phone=?,
                designation=?,
                joining_date=?,
                pin_hash=?,
                role=?,
                commission_pct=?,
                team_id=?,
                team_lead_id=?,
                default_project_id=?,
                profile_image=?,
                is_active=?,
                updated_at=NOW()

            WHERE id=?",

            [

                $name,
                $email,
                $phone,
                $designation,
                $joining_date,
                $pin_hash,
                $role,
                $commission_pct,
                $team_id,
                $team_lead_id,
                $default_project_id,
                $profile_image,
                $is_active,
                $agent_id

            ]

        );

    }else{

        Database::update(

            "UPDATE agents SET

                name=?,
                email=?,
                phone=?,
                designation=?,
                joining_date=?,
                role=?,
                commission_pct=?,
                team_id=?,
                team_lead_id=?,
                default_project_id=?,
                profile_image=?,
                is_active=?,
                updated_at=NOW()

            WHERE id=?",

            [

                $name,
                $email,
                $phone,
                $designation,
                $joining_date,
                $role,
                $commission_pct,
                $team_id,
                $team_lead_id,
                $default_project_id,
                $profile_image,
                $is_active,
                $agent_id

            ]

        );

    }

    /*
    |--------------------------------------------------------------------------
    | Remove Old Projects
    |--------------------------------------------------------------------------
    */

   Database::delete(
    "DELETE FROM agent_projects WHERE agent_id=?",
    [$agent_id]
);

if (($role == "agent" || $role == "teamlead") && !empty($projects)) {

    foreach ($projects as $project) {

        Database::insert(
            "INSERT INTO agent_projects (agent_id, project_id)
             VALUES (?, ?)",
            [
                $agent_id,
                intval($project)
            ]
        );
    }
}
    // /*
    // |--------------------------------------------------------------------------
    // | Save Projects
    // |--------------------------------------------------------------------------
    // */

    // if(

    //     ($role=="agent" || $role=="team_lead") &&
    //     !empty($projects)

    // ){

    //     foreach($projects as $project){

    //         Database::insert(

    //             "INSERT INTO agent_projects
    //             (
    //                 agent_id,
    //                 project_id
    //             )
    //             VALUES
    //             (
    //                 ?,
    //                 ?
    //             )",

    //             [

    //                 $agent_id,
    //                 intval($project)

    //             ]

    //         );

    //     }

    // }

    Database::commit();

    jsonResponse(

        true,

        "Staff member updated successfully."

    );

}catch(Exception $e){

    Database::rollback();

    jsonResponse(false,$e->getMessage());

}