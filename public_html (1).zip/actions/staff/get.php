<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/permissions.php";

header("Content-Type: application/json");

try {

    $id = intval($_GET['id'] ?? 0);

    if ($id <= 0) {

        jsonResponse(false, "Invalid staff member.");

    }

    /*
    |--------------------------------------------------------------------------
    | Agent
    |--------------------------------------------------------------------------
    */

    $agent = Database::selectOne(

        "SELECT *
         FROM agents
         WHERE id=?",

        [

            $id

        ]

    );

    if (!$agent) {

        jsonResponse(false, "Staff member not found.");

    }

    /*
    |--------------------------------------------------------------------------
    | Assigned Projects
    |--------------------------------------------------------------------------
    */

    $projects = Database::select(

        "SELECT project_id
         FROM agent_projects
         WHERE agent_id=?",

        [

            $id

        ]

    );

    $assignedProjects = [];

    foreach ($projects as $row) {

        $assignedProjects[] = intval($row['project_id']);

    }

    /*
    |--------------------------------------------------------------------------
    | Profile Image
    |--------------------------------------------------------------------------
    */

    $image = "";

    if (

        !empty($agent['profile_image']) &&

        file_exists("../../uploads/" . $agent['profile_image'])

    ) {

        $image = "../uploads/" . $agent['profile_image'];

    } else {

        $image = "https://ui-avatars.com/api/?name=" .
            urlencode($agent['name']) .
            "&background=16284e&color=ffffff&size=200";

    }

    /*
    |--------------------------------------------------------------------------
    | Response
    |--------------------------------------------------------------------------
    */

    jsonResponse(

        true,

        "",

        [

            "id" => $agent['id'],

            "agent_code" => $agent['agent_code'],

            "name" => $agent['name'],

            "email" => $agent['email'],

            "phone" => $agent['phone'],

            "designation" => $agent['designation'],

            "joining_date" => $agent['joining_date'],

            "role" => $agent['role'],

            "commission_pct" => $agent['commission_pct'],

            "team_id" => $agent['team_id'],
            
            "team_lead_id" => $agent['team_lead_id'],

            "default_project_id" => $agent['default_project_id'],

            "is_active" => $agent['is_active'],

            "profile_image" => $image,

            "projects" => $assignedProjects

        ]

    );

} catch (Exception $e) {

    jsonResponse(false, $e->getMessage());

}