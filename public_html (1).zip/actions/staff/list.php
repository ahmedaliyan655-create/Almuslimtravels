<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/permissions.php";

header('Content-Type: application/json');

try {

    $sql = "
SELECT
    a.*,
    t.name AS team_name,
    tl.name AS team_lead_name,

    GROUP_CONCAT(
        DISTINCT p.project_name
        ORDER BY p.project_name
        SEPARATOR ', '
    ) AS projects

FROM agents a

LEFT JOIN teams t
    ON t.id = a.team_id

LEFT JOIN agents tl
    ON tl.id = a.team_lead_id

LEFT JOIN agent_projects ap
    ON ap.agent_id = a.id

LEFT JOIN projects p
    ON p.id = ap.project_id

GROUP BY a.id

ORDER BY a.id DESC
";
    if (isTeamLead()) {
        $sql = "
            SELECT
                a.*,
                t.name AS team_name,
                tl.name AS team_lead_name,
                GROUP_CONCAT(DISTINCT p.project_name ORDER BY p.project_name SEPARATOR ', ') AS projects
            FROM agents a
            LEFT JOIN teams t ON t.id = a.team_id
            LEFT JOIN agents tl ON tl.id = a.team_lead_id
            LEFT JOIN agent_projects ap ON ap.agent_id = a.id
            LEFT JOIN projects p ON p.id = ap.project_id
            WHERE a.role = 'agent'
              AND (a.team_lead_id = ? OR t.team_lead_id = ?)
            GROUP BY a.id
            ORDER BY a.id DESC
        ";
        $rows = Database::select($sql, [(int) authId(), (int) authId()]);
    } else {
        $rows = Database::select($sql);
    }

    $staff = [];

    foreach ($rows as $row) {

        /*
        |--------------------------------------------------------------------------
        | Profile Image
        |--------------------------------------------------------------------------
        */

        $image = "https://ui-avatars.com/api/?name=" .
            urlencode($row['name']) .
            "&background=16284e&color=ffffff";

        if (
            !empty($row['profile_image']) &&
            file_exists("../../uploads/" . $row['profile_image'])
        ) {

            $image = "../uploads/" . $row['profile_image'];
        }

        /*
        |--------------------------------------------------------------------------
        | Role Badge
        |--------------------------------------------------------------------------
        */

        switch ($row['role']) {

            case "manager":

                $role = '<span class="role-badge role-manager">👑 Manager</span>';
                break;

            case "admin":

                $role = '<span class="role-badge role-admin">🔑 Admin</span>';
                break;

            case "teamlead":

                $role = '<span class="role-badge role-team">🏅 Team Lead</span>';
                break;

            default:

                $role = '<span class="role-badge role-agent">👤 Agent</span>';
                break;
        }

        /*
        |--------------------------------------------------------------------------
        | Team
        |--------------------------------------------------------------------------
        */

       $team = "-";

if (
    $row['role'] == "agent" &&
    !empty($row['team_lead_name'])
) {

    $team = htmlspecialchars($row['team_lead_name']);

}
elseif (
    $row['role'] == "teamlead"
) {

    $team = '<span class="text-primary fw-bold">Self</span>';

}

        /*
        |--------------------------------------------------------------------------
        | Projects
        |--------------------------------------------------------------------------
        */

        $projects = "-";

        if (
            in_array($row['role'], ['agent', 'teamlead']) &&
            !empty($row['projects'])
        ) {

            $projects = "";

            foreach (explode(",", $row['projects']) as $project) {

                $projects .=
                    '<span class="project-badge me-1">' .
                    htmlspecialchars(trim($project)) .
                    '</span>';
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Commission
        |--------------------------------------------------------------------------
        */

        $commission = "-";

        if (
            in_array($row['role'], ['agent', 'teamlead'])
        ) {

            $commission =
                '<span class="commission-badge">' .
                $row['commission_pct'] .
                '%</span>';
        }

        /*
        |--------------------------------------------------------------------------
        | Status
        |--------------------------------------------------------------------------
        */

        $status = $row['is_active']
            ? '<span class="status-active">Active</span>'
            : '<span class="status-inactive">Inactive</span>';

        /*
        |--------------------------------------------------------------------------
        | Actions
        |--------------------------------------------------------------------------
        */

        $actions = '';
        if (canEditStaffMember((int) $row['id'])) {
            $actions .= '<button class="action-btn action-edit btnEdit" data-id="' . (int)$row['id'] . '" title="Edit"><i class="fa fa-edit"></i></button>';
        }
        if (canDeleteStaffMember((int) $row['id'])) {
            $actions .= '<button class="action-btn action-delete btnDelete" data-id="' . (int)$row['id'] . '" title="Delete"><i class="fa fa-trash"></i></button>';
        }
        if ($actions === '') $actions = '<span class="text-muted small">View only</span>';

        /*
        |--------------------------------------------------------------------------
        | Member Card
        |--------------------------------------------------------------------------
        */

        $member = '

        <div class="d-flex align-items-center">

            <img
                src="' . $image . '"
                class="staff-avatar me-3">

            <div>

                <div class="member-name">

                    ' . htmlspecialchars($row['name']) . '

                </div>

                <div class="member-designation">

                    ' . htmlspecialchars($row['designation']) . '

                </div>

            </div>

        </div>

        ';

        /*
        |--------------------------------------------------------------------------
        | Contact
        |--------------------------------------------------------------------------
        */

        $contact = '

        <div class="member-email">

            ' . htmlspecialchars($row['email']) . '

        </div>

        <div class="member-phone">

            ' . htmlspecialchars($row['phone']) . '

        </div>

        ';

        /*
        |--------------------------------------------------------------------------
        | Push Row
        |--------------------------------------------------------------------------
        */

        $staff[] = [

            "member" => $member,

            "role" => $role,

            "team" => $team,

            "projects" => $projects,

            "contact" => $contact,

            "commission" => $commission,

            "status" => $status,

            "actions" => $actions

        ];
    }

    echo json_encode([

        "success" => true,

        "data" => $staff

    ]);

} catch (Exception $e) {

    echo json_encode([

        "success" => false,

        "message" => $e->getMessage()

    ]);
}