<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/permissions.php";

header("Content-Type: application/json");

try {

    Database::beginTransaction();

    $agent_id = intval($_POST['agent_id'] ?? 0);

    if ($agent_id <= 0) {
        jsonResponse(false, "Invalid staff member.");
    }

    /*
    |--------------------------------------------------------------------------
    | Check Staff
    |--------------------------------------------------------------------------
    */

    $agent = Database::selectOne(

        "SELECT profile_image
         FROM agents
         WHERE id=?",

        [$agent_id]

    );

    if (!$agent) {
        jsonResponse(false, "Staff member not found.");
    }

    /*
    |--------------------------------------------------------------------------
    | Delete Assigned Projects
    |--------------------------------------------------------------------------
    */

    Database::delete(

        "DELETE FROM agent_projects
         WHERE agent_id=?",

        [$agent_id]

    );

    /*
    |--------------------------------------------------------------------------
    | Delete Staff
    |--------------------------------------------------------------------------
    */

    Database::delete(

        "DELETE FROM agents
         WHERE id=?",

        [$agent_id]

    );

    /*
    |--------------------------------------------------------------------------
    | Delete Profile Image
    |--------------------------------------------------------------------------
    */

    if (!empty($agent['profile_image'])) {

        $image = "../../uploads/" . $agent['profile_image'];

        if (file_exists($image)) {
            unlink($image);
        }

    }

    Database::commit();

    jsonResponse(true, "Staff member deleted successfully.");

} catch (Exception $e) {

    Database::rollback();

    jsonResponse(false, $e->getMessage());

}