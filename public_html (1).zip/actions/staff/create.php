<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/permissions.php";

header("Content-Type: application/json");

try {

    if (!canManageStaff()) {
        jsonResponse(false, "Permission denied. Only managers and admins can create staff.");
    }

    Database::beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Get Form Data
    |--------------------------------------------------------------------------
    */

    $name           = clean($_POST['name'] ?? '');
    $email          = clean($_POST['email'] ?? '');
    $phone          = clean($_POST['phone'] ?? '');
    $designation    = clean($_POST['designation'] ?? '');
    $joining_date   = clean($_POST['joining_date'] ?? date("Y-m-d"));
    $pin            = trim($_POST['pin'] ?? '');
    $role           = clean($_POST['role'] ?? '');
    $commission_pct = floatval($_POST['commission_pct'] ?? 0);
   $team_id = null;

$team_lead_id = !empty($_POST['team_lead_id'])
    ? intval($_POST['team_lead_id'])
    : null;
    $is_active      = intval($_POST['is_active'] ?? 1);

    $projects = $_POST['projects'] ?? [];

    if (!is_array($projects)) {

        $projects = [];

    }

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if ($name == "") {

        jsonResponse(false, "Please enter full name.");

    }

    if ($role == "") {
        jsonResponse(false, "Please select role.");
    }
    if (!canAssignStaffRole($role)) {
        jsonResponse(false, "You do not have permission to create this role.");
    }

    if ($pin == "") {

        jsonResponse(false, "Please enter login PIN.");

    }

    if (strlen($pin) < 4) {

        jsonResponse(false, "PIN must be at least 4 digits.");

    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Email
    |--------------------------------------------------------------------------
    */

    if ($email != "") {

        $exists = Database::selectOne(

            "SELECT id
             FROM agents
             WHERE email=?
             LIMIT 1",

            [$email]

        );

        if ($exists) {

            jsonResponse(false, "Email already exists.");

        }

    }

    /*
    |--------------------------------------------------------------------------
    | Generate Agent Code
    |--------------------------------------------------------------------------
    */

    do {

        $agent_code = "AG" . rand(10000,99999);

        $check = Database::selectOne(

            "SELECT id
             FROM agents
             WHERE agent_code=?",

            [$agent_code]

        );

    } while ($check);

    /*
    |--------------------------------------------------------------------------
    | Hash PIN
    |--------------------------------------------------------------------------
    */

    $pin_hash = password_hash($pin, PASSWORD_DEFAULT);

    /*
    |--------------------------------------------------------------------------
    | Upload Profile Image
    |--------------------------------------------------------------------------
    */

    $profile_image = "";

    if (

        isset($_FILES['profile_image']) &&

        $_FILES['profile_image']['error'] == UPLOAD_ERR_OK

    ) {

        $extension = strtolower(

            pathinfo(

                $_FILES['profile_image']['name'],

                PATHINFO_EXTENSION

            )

        );

        $allowed = [

            "jpg",
            "jpeg",
            "png",
            "webp"

        ];

        if (!in_array($extension, $allowed)) {

            jsonResponse(false, "Only JPG, PNG & WEBP images are allowed.");

        }

        if ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {

            jsonResponse(false, "Maximum image size is 2MB.");

        }

        $uploadDir = "../../uploads/";

        if (!is_dir($uploadDir)) {

            mkdir($uploadDir, 0777, true);

        }

        $profile_image = uniqid("staff_") . "." . $extension;

        if (

            !move_uploaded_file(

                $_FILES['profile_image']['tmp_name'],

                $uploadDir . $profile_image

            )

        ) {

            jsonResponse(false, "Unable to upload profile image.");

        }

    }

    /*
    |--------------------------------------------------------------------------
    | Default Project
    |--------------------------------------------------------------------------
    */

    $default_project_id = null;

    if (!empty($projects)) {

        $default_project_id = intval($projects[0]);

    }
        /*
    |--------------------------------------------------------------------------
    | Save Agent
    |--------------------------------------------------------------------------
    */

  
    $agentId = Database::insert(
   
        "INSERT INTO agents
        (
            agent_code,
            name,
            email,
            phone,
            profile_image,
            designation,
            joining_date,
            pin_hash,
            role,
            commission_pct,
            team_id,
            team_lead_id,
            default_project_id,
            is_active,
            created_at,
            updated_at
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            NOW(),
            NOW()
        )",

        [

            $agent_code,
            $name,
            $email,
            $phone,
            $profile_image,
            $designation,
            $joining_date,
            $pin_hash,
            $role,
            $commission_pct,
            $team_id,
            $team_lead_id,
            $default_project_id,
            $is_active

        ]

    );

    /*
    |--------------------------------------------------------------------------
    | Assign Projects
    |--------------------------------------------------------------------------
    */

    if (

        ($role == "agent" || $role == "teamlead") &&

        !empty($projects)

    ) {

        foreach ($projects as $project_id) {

            Database::insert(

                "INSERT INTO agent_projects
                (
                    agent_id,
                    project_id
                )
                VALUES
                (
                    ?,
                    ?
                )",

                [

                    $agentId,
                    intval($project_id)

                ]

            );

        }

    }

    /*
    |--------------------------------------------------------------------------
    | Commit
    |--------------------------------------------------------------------------
    */

    Database::commit();

    jsonResponse(

        true,

        "Staff member created successfully.",

        [

            "id" => $agentId

        ]

    );

} catch (Exception $e) {

    Database::rollback();

    if (

        !empty($profile_image) &&

        file_exists("../../uploads/" . $profile_image)

    ) {

        unlink("../../uploads/" . $profile_image);

    }

    jsonResponse(false, $e->getMessage());

}