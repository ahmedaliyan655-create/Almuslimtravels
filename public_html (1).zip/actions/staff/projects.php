<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";

header("Content-Type: application/json");

try {

    $projects = Database::select(

        "SELECT
            id,
            project_name,
            project_code,
            logo
         FROM projects
         WHERE is_active = 1
         ORDER BY project_name ASC"

    );

    $data = [];

    foreach ($projects as $project) {

        $logo = "";

        if (
            !empty($project['logo']) &&
            file_exists("../../uploads/" . $project['logo'])
        ) {

            $logo = "../uploads/" . $project['logo'];

        } else {

            $logo = "https://placehold.co/80x80?text=Logo";

        }

        $data[] = [

            "id" => $project['id'],

            "name" => $project['project_name'],

            "code" => $project['project_code'],

            "logo" => $logo

        ];

    }

    jsonResponse(true, "", $data);

} catch (Exception $e) {

    jsonResponse(false, $e->getMessage());

}