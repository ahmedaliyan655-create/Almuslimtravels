<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/permissions.php';
header('Content-Type: application/json; charset=utf-8');

function out(bool $ok, string $msg='', array $data=[]): never {
    echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data], JSON_UNESCAPED_UNICODE);
    exit;
}
function body(): array {
    $json=json_decode(file_get_contents('php://input'),true);
    return is_array($_POST)&&$_POST ? $_POST : (is_array($json)?$json:($_GET?:[]));
}
function isMyTeamAgent(int $agentId): bool {
    return (bool)Database::selectOne(
        "SELECT a.id FROM agents a LEFT JOIN teams t ON t.id=a.team_id
         WHERE a.id=? AND a.role='agent' AND a.is_active=1
         AND (a.team_lead_id=? OR t.team_lead_id=? OR EXISTS(
            SELECT 1 FROM team_members tm JOIN teams tt ON tt.id=tm.team_id
            WHERE tm.agent_id=a.id AND tt.team_lead_id=?
         )) LIMIT 1",
        [$agentId,authId(),authId(),authId()]
    );
}
function canSeeLead(array $lead): bool {
    $r=authRole(); $assigned=(int)($lead['assigned_to']??0);
    if(in_array($r,['manager','admin'],true)) return true;
    if($r==='agent') return $assigned===(int)authId();
    return $r==='teamlead' && ($assigned===(int)authId() || isMyTeamAgent($assigned));
}
function canAssignLeadTo(int $assignedId): bool {
    $r=authRole();
    if($assignedId<=0) return in_array($r,['manager','admin'],true);
    if(in_array($r,['manager','admin'],true))
        return (bool)Database::selectOne("SELECT id FROM agents WHERE id=? AND role='agent' AND is_active=1",[$assignedId]);
    if($r==='teamlead') return $assignedId===(int)authId() || isMyTeamAgent($assignedId);
    return $assignedId===(int)authId();
}
function logLead(int $id,string $text,string $type='note'): void {
    try {
        Database::insert(
            'INSERT INTO lead_activity_log(lead_id,log_text,log_type,logged_by,logged_by_name) VALUES(?,?,?,?,?)',
            [$id,$text,$type,authId(),authName()]
        );
    } catch (Throwable $e) {
        // Activity history must never make an otherwise valid lead save fail.
        error_log('Lead activity log: '.$e->getMessage());
    }
}
try {
    $d=body(); $action=$d['action']??'list'; $currentRole=strtolower(trim((string)authRole()));

    if($action==='list'){
        $where=[];$p=[];$r=$currentRole;
        if($r==='agent'){ $where[]='l.assigned_to=?';$p[]=(int)authId(); }
        elseif($r==='teamlead'){
            $where[]="(l.assigned_to=? OR l.assigned_to IN (
                SELECT a.id FROM agents a LEFT JOIN teams t ON t.id=a.team_id
                WHERE a.role='agent' AND a.is_active=1 AND
                (a.team_lead_id=? OR t.team_lead_id=? OR EXISTS(
                    SELECT 1 FROM team_members tm JOIN teams tt ON tt.id=tm.team_id
                    WHERE tm.agent_id=a.id AND tt.team_lead_id=?
                ))
            ))";
            array_push($p,(int)authId(),(int)authId(),(int)authId(),(int)authId());
        }
        foreach(['status','priority','source','assigned_to'] as $f){
            if(isset($d[$f]) && trim((string)$d[$f])!==''){
                $where[]="l.$f=?";$p[]=trim((string)$d[$f]);
            }
        }
        // Reference CRM uses an "agent" filter; accept both names.
        if(isset($d['agent']) && trim((string)$d['agent'])!==''){
            $where[]='l.assigned_to=?';
            $p[]=(int)$d['agent'];
        }
        $search=trim((string)($d['search']??''));
        if($search!==''){
            $where[]='(l.name LIKE ? OR l.phone LIKE ? OR l.whatsapp LIKE ? OR l.email LIKE ? OR l.lead_id LIKE ? OR l.campaign LIKE ?)';
            $s="%$search%"; array_push($p,$s,$s,$s,$s,$s,$s);
        }
        $sql="SELECT l.*,a.name assigned_name
              FROM leads l LEFT JOIN agents a ON a.id=l.assigned_to";
        if($where)$sql.=' WHERE '.implode(' AND ',$where);
        $sql.=' ORDER BY CASE WHEN l.follow_up_date IS NOT NULL AND l.follow_up_date<=CURDATE()
                         AND l.status NOT IN (\'Booked\',\'Lost Lead\',\'Duplicate\') THEN 0 ELSE 1 END,
                         l.created_at DESC';
        out(true,'',['leads'=>Database::select($sql,$p)]);
    }

    if($action==='get'){
        $id=(int)($d['id']??0);
        $lead=Database::selectOne('SELECT l.*,a.name assigned_name FROM leads l LEFT JOIN agents a ON a.id=l.assigned_to WHERE l.id=?',[$id]);
        if(!$lead || !canSeeLead($lead)) out(false,'Permission denied.');
        $log=Database::select('SELECT id,log_text,log_type,logged_by_name,created_at FROM lead_activity_log WHERE lead_id=? ORDER BY id DESC',[$id]);
        out(true,'',['lead'=>$lead,'activity'=>$log]);
    }

    if($action==='save'){
        $id=(int)($d['id']??0);
        $fields=['name','phone','whatsapp','email','service_type','source','campaign','travel_month','adults','youth','children','infants','budget','priority','status','assigned_to','follow_up_date','message','notes','enquiry_date'];
        $v=[];
        foreach($fields as $f){
            $value=$d[$f]??'';
            $v[$f]=is_scalar($value)?trim((string)$value):'';
        }
        if($v['name']==='') out(false,'Full name is required.');
        if($v['phone']==='') out(false,'Phone number is required.');
        if(!in_array($v['service_type'],['Umrah','Hajj','Holiday Package','Flights Only','Hotel Only','Visa Only'],true)) $v['service_type']='Umrah';
        if(!in_array($v['source'],['Facebook Ads','Instagram Ads','Website Form','Google Ads','WhatsApp','Direct Call','Referral','Walk-in','Existing Customer'],true)) $v['source']='Website Form';
        if(!in_array($v['priority'],['Hot','Warm','Cold'],true)) $v['priority']='Warm';
        $allowedStatuses=['New Lead','Attempted Contact','No Answer','Wrong Number','Invalid Lead','Interested','Wants Cheapest Package','Wants Family Package','Follow-up Later','Call Tomorrow','Not Ready Yet','Booked','Lost Lead','Duplicate'];
        if(!in_array($v['status'],$allowedStatuses,true)) $v['status']='New Lead';
        foreach(['adults','youth','children','infants'] as $n) $v[$n]=max(0,(int)$v[$n]);
        if($v['adults']===0 && $v['youth']===0 && $v['children']===0 && $v['infants']===0) $v['adults']=1;
        $v['budget']=$v['budget']!==''?(float)preg_replace('/[^0-9.\-]/','',$v['budget']):null;
        if($v['follow_up_date']!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$v['follow_up_date'])) $v['follow_up_date']=null;
        if($v['enquiry_date']==='' || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$v['enquiry_date'])) $v['enquiry_date']=date('Y-m-d');
        if($v['whatsapp']==='') $v['whatsapp']=$v['phone'];
        if($currentRole==='agent') $v['assigned_to']=(string)authId();
        $assigned=(int)($v['assigned_to']!==''?$v['assigned_to']:0);
        if(!canAssignLeadTo($assigned)) out(false,'You cannot assign this lead to that user.');

        if($id){
            $old=Database::selectOne('SELECT * FROM leads WHERE id=?',[$id]);
            if(!$old||!canSeeLead($old)) out(false,'Permission denied.');
            $sets=[];$p=[];
            foreach($fields as $f){$sets[]="`$f`=?";$p[]=$v[$f]!==''?$v[$f]:null;}
            $p[]=$id;
            Database::update('UPDATE leads SET '.implode(',',$sets).' WHERE id=?',$p);
            if((string)$old['status']!==$v['status']) logLead($id,'Status changed to: '.$v['status'],'status');
            if((int)($old['assigned_to']??0)!==$assigned){
                $an=$assigned?(Database::selectOne('SELECT name FROM agents WHERE id=?',[$assigned])['name']??'agent'):'Unassigned';
                logLead($id,'Assigned to '.$an,'assign');
            }
            logLead($id,'Lead updated','note');
            $saved=Database::selectOne('SELECT l.*,a.name assigned_name FROM leads l LEFT JOIN agents a ON a.id=l.assigned_to WHERE l.id=?',[$id]);
            out(true,'Lead updated.',['id'=>$id,'lead'=>$saved]);
        }

        // Generate a collision-resistant public Lead ID.
        do {
            $leadId='LED-'.random_int(10000,99999);
            $exists=Database::selectOne('SELECT id FROM leads WHERE lead_id=? LIMIT 1',[$leadId]);
        } while($exists);
        $new=(int)Database::insert(
            'INSERT INTO leads(lead_id,name,phone,whatsapp,email,service_type,source,campaign,travel_month,adults,youth,children,infants,budget,priority,status,assigned_to,follow_up_date,message,notes,enquiry_date)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$leadId,$v['name'],$v['phone'],$v['whatsapp'],$v['email']?:null,$v['service_type'],$v['source'],$v['campaign']?:null,$v['travel_month']?:null,
             $v['adults'],$v['youth'],$v['children'],$v['infants'],$v['budget'],$v['priority'],$v['status'],$assigned?:null,$v['follow_up_date']?:null,$v['message']?:null,$v['notes']?:null,$v['enquiry_date']]
        );
        if($new<=0) out(false,'Lead could not be created.');
        logLead($new,'Lead created','note');
        $saved=Database::selectOne('SELECT l.*,a.name assigned_name FROM leads l LEFT JOIN agents a ON a.id=l.assigned_to WHERE l.id=?',[$new]);
        out(true,'Lead created successfully.',['id'=>$new,'lead_id'=>$leadId,'lead'=>$saved]);
    }

    if($action==='quick_update'){
        $id=(int)($d['id']??0);$lead=Database::selectOne('SELECT * FROM leads WHERE id=?',[$id]);
        if(!$lead||!canSeeLead($lead))out(false,'Permission denied.');
        if(isset($d['status'])){
            $status=trim((string)$d['status']);
            $allowed=["New Lead","Attempted Contact","No Answer","Wrong Number","Invalid Lead","Interested","Wants Cheapest Package","Wants Family Package","Follow-up Later","Call Tomorrow","Not Ready Yet","Booked","Lost Lead","Duplicate"];
            if(!in_array($status,$allowed,true))out(false,'Invalid lead status.');
            Database::update('UPDATE leads SET status=? WHERE id=?',[$status,$id]);logLead($id,'Status changed to: '.$status,'status');
        }
        if(array_key_exists('assigned_to',$d)){
            $assigned=(int)$d['assigned_to'];
            if(!canAssignLeadTo($assigned))out(false,'You cannot assign this lead to that user.');
            Database::update('UPDATE leads SET assigned_to=? WHERE id=?',[$assigned?:null,$id]);
            $name=$assigned?(Database::selectOne('SELECT name FROM agents WHERE id=?',[$assigned])['name']??'agent'):'Unassigned';
            logLead($id,'Assigned to '.$name,'assign');
        }
        if(isset($d['follow_up_date'])){
            Database::update('UPDATE leads SET follow_up_date=? WHERE id=?',[trim((string)$d['follow_up_date'])?:null,$id]);
            logLead($id,'Follow-up date updated','note');
        }
        out(true,'Lead updated.');
    }

    if($action==='bulk_assign'){
        if(!in_array(authRole(),['manager','admin','teamlead'],true))out(false,'Permission denied.');
        $ids=$d['ids']??[]; if(is_string($ids))$ids=json_decode($ids,true);
        $ids=array_values(array_filter(array_map('intval',is_array($ids)?$ids:[])));
        $assigned=(int)($d['assigned_to']??0);
        if(!$ids)out(false,'No leads selected.');
        if(!canAssignLeadTo($assigned))out(false,'You cannot assign to that user.');
        foreach($ids as $id){
            $lead=Database::selectOne('SELECT * FROM leads WHERE id=?',[$id]);
            if($lead&&canSeeLead($lead)){
                Database::update('UPDATE leads SET assigned_to=? WHERE id=?',[$assigned?:null,$id]);
                logLead($id,'Bulk assigned to '.($assigned?(Database::selectOne('SELECT name FROM agents WHERE id=?',[$assigned])['name']??'agent'):'Unassigned'),'assign');
            }
        }
        out(true,'Selected leads assigned.');
    }

    if($action==='log'){
        $id=(int)($d['lead_id']??0);$lead=Database::selectOne('SELECT * FROM leads WHERE id=?',[$id]);
        if(!$lead||!canSeeLead($lead))out(false,'Permission denied.');
        $text=trim((string)($d['log_text']??''));if($text==='')out(false,'Activity note is required.');
        $type=(string)($d['log_type']??'note');
        if(!in_array($type,['call','note','status','assign','visit','booked','email','whatsapp'],true))$type='note';
        logLead($id,$text,$type);out(true,'Activity added.');
    }

    if($action==='delete'){
        if(!in_array(authRole(),['manager','admin'],true))out(false,'Only Admin or Manager can delete leads.');
        $id=(int)($d['id']??0);
        Database::delete('DELETE FROM lead_activity_log WHERE lead_id=?',[$id]);
        Database::delete('DELETE FROM leads WHERE id=?',[$id]);
        out(true,'Lead deleted.');
    }
    out(false,'Unknown action.');
}catch(Throwable $e){
    error_log('Lead API: '.$e->getMessage());
    http_response_code(500);
    out(false,'Unable to process the lead request.');
}
