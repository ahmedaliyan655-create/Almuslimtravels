<?php

require_once "../../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager', 'admin'], true)) { http_response_code(403); exit('Permission denied.'); }
require_once "../../includes/db.php";
require_once "../../includes/functions.php";

header("Content-Type: application/json");

try {

    $projects = Database::select("

        SELECT *

        FROM projects

        ORDER BY id DESC

    ");

    $data = [];

    foreach ($projects as $row) {

        /*
        |--------------------------------------------------------------------------
        | Logo
        |--------------------------------------------------------------------------
        */

        if (
            !empty($row['logo']) &&
            file_exists("../../uploads/" . $row['logo'])
        ) {

            $logo = '

                <img
                    src="../uploads/' . $row['logo'] . '"
                    class="project-logo">

            ';

        } else {

            $logo = '

                <div class="project-logo-placeholder">

                    <i class="fa-solid fa-layer-group"></i>

                </div>

            ';

        }

        /*
        |--------------------------------------------------------------------------
        | Website
        |--------------------------------------------------------------------------
        */

        $website = "-";

        if (!empty($row['website'])) {

            $website = '

                <a
                    href="' . htmlspecialchars($row['website']) . '"
                    target="_blank">

                    ' . htmlspecialchars($row['website']) . '

                </a>

            ';

        }

        /*
        |--------------------------------------------------------------------------
        | Status
        |--------------------------------------------------------------------------
        */

        if ($row['is_active']) {

            $status = '

                <span class="status-active">

                    Active

                </span>

            ';

        } else {

            $status = '

                <span class="status-inactive">

                    Inactive

                </span>

            ';

        }

        /*
        |--------------------------------------------------------------------------
        | Assigned Staff
        |--------------------------------------------------------------------------
        */

        $staff = Database::selectOne(

            "

            SELECT COUNT(*) total

            FROM agent_projects

            WHERE project_id=?

            ",

            [

                $row['id']

            ]

        );

        /*
        |--------------------------------------------------------------------------
        | Actions
        |--------------------------------------------------------------------------
        */

        $actions = '

            <button
                class="action-btn action-edit btnEdit"
                data-id="' . $row['id'] . '">

                <i class="fa fa-edit"></i>

            </button>

            <button
                class="action-btn action-delete btnDelete"
                data-id="' . $row['id'] . '">

                <i class="fa fa-trash"></i>

            </button>

        ';

        /*
        |--------------------------------------------------------------------------
        | Row
        |--------------------------------------------------------------------------
        */

       $data[] = [

    "logo"         => $logo,

    "project_name" => htmlspecialchars($row['project_name']),

    "project_code" => htmlspecialchars($row['project_code']),

    "website"      => $website,

    "status"       => $status,

    "actions"      => $actions,

    "active"       => (int)$row['is_active']

];

    }

    jsonResponse(true,"",$data);

} catch (Exception $e) {

    jsonResponse(false,$e->getMessage());

}