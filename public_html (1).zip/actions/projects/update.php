<?php

require_once "../../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager', 'admin'], true)) { http_response_code(403); exit('Permission denied.'); }
require_once "../../includes/db.php";
require_once "../../includes/functions.php";

header("Content-Type: application/json");

try {

    /*
    |--------------------------------------------------------------------------
    | Get Form Data
    |--------------------------------------------------------------------------
    */

    $project_id   = (int)($_POST['project_id'] ?? 0);
    $project_name = clean($_POST['project_name'] ?? '');
    $project_code = strtoupper(clean($_POST['project_code'] ?? ''));
    $website      = clean($_POST['website'] ?? '');
    $notes        = trim($_POST['notes'] ?? '');
    $status       = isset($_POST['status']) ? (int)$_POST['status'] : 1;

    if ($project_id <= 0) {
        jsonResponse(false, "Invalid Project.");
    }

    if ($project_name == "") {
        jsonResponse(false, "Project Name is required.");
    }

    if ($project_code == "") {
        jsonResponse(false, "Project Code is required.");
    }

    /*
    |--------------------------------------------------------------------------
    | Get Existing Project
    |--------------------------------------------------------------------------
    */

    $project = Database::selectOne(

        "SELECT * FROM projects WHERE id=? LIMIT 1",

        [$project_id]

    );

    if (!$project) {

        jsonResponse(false, "Project not found.");

    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Name
    |--------------------------------------------------------------------------
    */

    $exists = Database::selectOne(

        "SELECT id
        FROM projects
        WHERE project_name=?
        AND id<>?
        LIMIT 1",

        [

            $project_name,

            $project_id

        ]

    );

    if ($exists) {

        jsonResponse(false, "Project name already exists.");

    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Code
    |--------------------------------------------------------------------------
    */

    $exists = Database::selectOne(

        "SELECT id
        FROM projects
        WHERE project_code=?
        AND id<>?
        LIMIT 1",

        [

            $project_code,

            $project_id

        ]

    );

    if ($exists) {

        jsonResponse(false, "Project code already exists.");

    }

    /*
    |--------------------------------------------------------------------------
    | Upload New Logo
    |--------------------------------------------------------------------------
    */

    $logo = $project['logo'];

    if (

        isset($_FILES['project_logo']) &&

        $_FILES['project_logo']['error'] == UPLOAD_ERR_OK

    ) {

        $extension = strtolower(

            pathinfo(

                $_FILES['project_logo']['name'],

                PATHINFO_EXTENSION

            )

        );

        $allowed = [

            "jpg",
            "jpeg",
            "png",
            "webp",
            "svg"

        ];

        if (!in_array($extension, $allowed)) {

            jsonResponse(false, "Only JPG, PNG, WEBP & SVG allowed.");

        }

        if ($_FILES['project_logo']['size'] > 2 * 1024 * 1024) {

            jsonResponse(false, "Maximum size is 2MB.");

        }

        $uploadDir = "../../uploads/";

        if (!is_dir($uploadDir)) {

            mkdir($uploadDir, 0777, true);

        }

        $newLogo = uniqid("project_") . "." . $extension;

        if (

            !move_uploaded_file(

                $_FILES['project_logo']['tmp_name'],

                $uploadDir . $newLogo

            )

        ) {

            jsonResponse(false, "Unable to upload logo.");

        }

        /*
        |--------------------------------------------------------------------------
        | Delete Old Logo
        |--------------------------------------------------------------------------
        */

        if (

            !empty($project['logo']) &&

            file_exists($uploadDir . $project['logo'])

        ) {

            unlink($uploadDir . $project['logo']);

        }

        $logo = $newLogo;

    }

    /*
    |--------------------------------------------------------------------------
    | Update Project
    |--------------------------------------------------------------------------
    */

    Database::update(

        "UPDATE projects

        SET

            project_name=?,
            project_code=?,
            website=?,
            logo=?,
            notes=?,
            is_active=?

        WHERE id=?",

        [

            $project_name,

            $project_code,

            $website,

            $logo,

            $notes,

            $status,

            $project_id

        ]

    );

    jsonResponse(true, "Project updated successfully.");

} catch (Exception $e) {

    jsonResponse(false, $e->getMessage());

}