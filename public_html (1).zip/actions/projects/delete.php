<?php

require_once "../../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager', 'admin'], true)) { http_response_code(403); exit('Permission denied.'); }
require_once "../../includes/db.php";
require_once "../../includes/functions.php";

header("Content-Type: application/json");

try {

    /*
    |--------------------------------------------------------------------------
    | Validate ID
    |--------------------------------------------------------------------------
    */

    if (empty($_POST['id'])) {

        jsonResponse(false, "Invalid Project.");

    }

    $id = (int)$_POST['id'];

    /*
    |--------------------------------------------------------------------------
    | Get Project
    |--------------------------------------------------------------------------
    */

    $project = Database::selectOne(

        "SELECT *
         FROM projects
         WHERE id = ?",

        [$id]

    );

    if (!$project) {

        jsonResponse(false, "Project not found.");

    }

    /*
    |--------------------------------------------------------------------------
    | Check Assigned Staff
    |--------------------------------------------------------------------------
    */

    $assigned = Database::selectOne(

        "SELECT COUNT(*) AS total
         FROM agent_projects
         WHERE project_id = ?",

        [$id]

    );

    if ($assigned['total'] > 0) {

        jsonResponse(false, "This project is assigned to staff. Remove assignments first.");

    }

    /*
    |--------------------------------------------------------------------------
    | Delete Logo
    |--------------------------------------------------------------------------
    */

    if (

        !empty($project['logo']) &&

        file_exists("../../uploads/" . $project['logo'])

    ) {

        unlink("../../uploads/" . $project['logo']);

    }

    /*
    |--------------------------------------------------------------------------
    | Delete Project
    |--------------------------------------------------------------------------
    */

    Database::delete(

        "DELETE FROM projects
         WHERE id = ?",

        [$id]

    );

    jsonResponse(true, "Project deleted successfully.");

} catch (Exception $e) {

    jsonResponse(false, $e->getMessage());

}