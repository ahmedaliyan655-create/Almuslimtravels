<?php

require_once "../../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager', 'admin'], true)) { http_response_code(403); exit('Permission denied.'); }
require_once "../../includes/db.php";
require_once "../../includes/functions.php";

header("Content-Type: application/json");

try {

    if (empty($_GET['id'])) {

        jsonResponse(false, "Invalid project.");

    }

    $id = (int)$_GET['id'];

    $project = Database::selectOne(

        "SELECT *
         FROM projects
         WHERE id = ?
         LIMIT 1",

        [$id]

    );

    if (!$project) {

        jsonResponse(false, "Project not found.");

    }

    jsonResponse(true, "", [

        "id" => $project['id'],

        "project_name" => $project['project_name'],

        "project_code" => $project['project_code'],

        "website" => $project['website'],

        "notes" => $project['notes'],

        "status" => $project['is_active'],

        "logo" => $project['logo'],

        "monthly_target" => $project['monthly_target']

    ]);

} catch (Exception $e) {

    jsonResponse(false, $e->getMessage());

}