<?php

require_once "../../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager', 'admin'], true)) { http_response_code(403); exit('Permission denied.'); }
require_once "../../includes/db.php";
require_once "../../includes/functions.php";

header("Content-Type: application/json");

try {
    /*
    |--------------------------------------------------------------------------
    | Get Form Data
    |--------------------------------------------------------------------------
    */

    $project_name = clean($_POST['project_name'] ?? '');
    $project_code = strtoupper(clean($_POST['project_code'] ?? ''));
    $website      = clean($_POST['website'] ?? '');
    $notes        = trim($_POST['notes'] ?? '');
    $status       = isset($_POST['status']) ? intval($_POST['status']) : 1;

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if (empty($project_name)) {
        jsonResponse(false, "Project name is required.");
    }

    if (empty($project_code)) {
        jsonResponse(false, "Project code is required.");
    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Project Name
    |--------------------------------------------------------------------------
    */

    $exists = Database::selectOne(
        "SELECT id FROM projects WHERE project_name=? LIMIT 1",
        [$project_name]
    );

    if ($exists) {
        jsonResponse(false, "Project name already exists.");
    }

    /*
    |--------------------------------------------------------------------------
    | Duplicate Project Code
    |--------------------------------------------------------------------------
    */

    $exists = Database::selectOne(
        "SELECT id FROM projects WHERE project_code=? LIMIT 1",
        [$project_code]
    );

    if ($exists) {
        jsonResponse(false, "Project code already exists.");
    }

    /*
    |--------------------------------------------------------------------------
    | Upload Logo
    |--------------------------------------------------------------------------
    */

   $logo = "";

if (
    isset($_FILES['project_logo']) &&
    $_FILES['project_logo']['error'] == UPLOAD_ERR_OK
    ) {

    $extension = strtolower(
        pathinfo(
            $_FILES['project_logo']['name'],
            PATHINFO_EXTENSION
        )
    );

    $allowed = [
        "jpg",
        "jpeg",
        "png",
        "webp",
        "svg"
    ];

    if (!in_array($extension, $allowed)) {

        jsonResponse(false, "Only JPG, PNG, WEBP & SVG allowed.");

    }

    if ($_FILES['project_logo']['size'] > 2 * 1024 * 1024) {

        jsonResponse(false, "Maximum file size is 2MB.");

    }

    $uploadDir = "../../uploads/";

    if (!is_dir($uploadDir)) {

        mkdir($uploadDir, 0777, true);

    }

    $logo = uniqid("project_") . "." . $extension;

    if (
        !move_uploaded_file(
            $_FILES['project_logo']['tmp_name'],
            $uploadDir . $logo
        )
    ) {

        jsonResponse(false, "Unable to upload logo.");

    }

    }
    /*
    |--------------------------------------------------------------------------
    | Save Project
    |--------------------------------------------------------------------------
    */

    $projectId = Database::insert(

        "INSERT INTO projects
        (
            project_name,
            project_code,
            website,
            logo,
            notes,
            monthly_target,
            is_active,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            NOW()
        )",

        [

            $project_name,
            $project_code,
            $website,
            $logo,
            $notes,
            0,
            $status

        ]

    );

    jsonResponse(true, "Project created successfully.", [

        "project_id" => $projectId

    ]);

} catch (Exception $e) {

   if (
    !empty($logo) &&
    file_exists("../../uploads/" . $logo)
) {

    unlink("../../uploads/" . $logo);

}
    jsonResponse(false, $e->getMessage());

}