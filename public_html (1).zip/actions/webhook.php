<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CRM Lead Webhook
|--------------------------------------------------------------------------
| Receives leads from:
| - Elementor / WordPress
| - Facebook Leads
| - Instagram Leads
| - WhatsApp
| - Zapier / Make
|
| Elementor example:
| https://yourcrm.com/api/lead-webhook.php?token=YOUR_SECRET
|
| Meta / other integrations can send:
| X-CRM-Secret: YOUR_SECRET
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');


/*
|--------------------------------------------------------------------------
| JSON Response
|--------------------------------------------------------------------------
*/
function webhookOut(
    bool $success,
    string $message = '',
    array $data = [],
    int $code = 200
): void  {
    http_response_code($code);

    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data'    => $data
    ], JSON_UNESCAPED_UNICODE);

    exit;
}


/*
|--------------------------------------------------------------------------
| CONFIGURATION
|--------------------------------------------------------------------------
|
| Make sure this constant exists in your config/db file:
|
| define('INTEGRATION_SECRET', 'your-secret-here');
|
|--------------------------------------------------------------------------
*/

$secret = defined('INTEGRATION_SECRET')
    ? (string) INTEGRATION_SECRET
    : '';

/*
|--------------------------------------------------------------------------
| Get Authentication Token
|--------------------------------------------------------------------------
|
| Supports both:
|
| 1. Header:
|    X-CRM-Secret: YOUR_SECRET
|
| 2. URL:
|    ?token=YOUR_SECRET
|
| Elementor can use the URL token.
|--------------------------------------------------------------------------
*/

$providedSecret = (string) (
    $_SERVER['HTTP_X_CRM_SECRET']
    ?? $_POST['token']
    ?? $_GET['token']
    ?? ''
);

if (
    $secret === '' ||
    $providedSecret === '' ||
    !hash_equals($secret, $providedSecret)
) {
    webhookOut(
        false,
        'Unauthorized.',
        [],
        401
    );
}


/*
|--------------------------------------------------------------------------
| Only POST Requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    webhookOut(
        false,
        'POST requests only.',
        [],
        405
    );
}


/*
|--------------------------------------------------------------------------
| Detect Lead Source
|--------------------------------------------------------------------------
|
| You can send:
|
| website
| facebook
| instagram
| whatsapp
|
| If nothing is provided, Website Form is used.
|--------------------------------------------------------------------------
*/

$integrationSource = strtolower(
    trim(
        (string) (
            $_SERVER['HTTP_X_CRM_SOURCE']
            ?? $_POST['integration_source']
            ?? $_GET['source']
            ?? ''
        )
    )
);


/*
|--------------------------------------------------------------------------
| Convert Integration Source to CRM Source
|--------------------------------------------------------------------------
*/

$sourceMap = [
    'website'        => 'Website Form',
    'website_form'   => 'Website Form',
    'elementor'      => 'Website Form',
    'wordpress'      => 'Website Form',

    'facebook'       => 'Facebook Ads',
    'facebook_ads'   => 'Facebook Ads',
    'meta'           => 'Facebook Ads',

    'instagram'      => 'Instagram Ads',
    'instagram_ads'  => 'Instagram Ads',

    'whatsapp'       => 'WhatsApp',

    'google'         => 'Google Ads',
    'google_ads'     => 'Google Ads',

    'zapier'         => 'Website Form',
    'make'           => 'Website Form',

    ''               => 'Website Form'
];

$source = $sourceMap[$integrationSource]
    ?? 'Website Form';


/*
|--------------------------------------------------------------------------
| Read Request Body
|--------------------------------------------------------------------------
*/

$raw = file_get_contents('php://input');

$jsonPayload = json_decode(
    $raw ?: '',
    true
);


/*
|--------------------------------------------------------------------------
| Support JSON + Form Data
|--------------------------------------------------------------------------
*/

$payload = is_array($jsonPayload)
    ? $jsonPayload
    : $_POST;


/*
|--------------------------------------------------------------------------
| Support Elementor Nested Payload
|--------------------------------------------------------------------------
|
| Some integrations may send:
|
| payload={"name":"John","phone":"..."}
|--------------------------------------------------------------------------
*/

if (
    isset($payload['payload']) &&
    is_string($payload['payload'])
) {
    $decodedPayload = json_decode(
        $payload['payload'],
        true
    );

    if (is_array($decodedPayload)) {
        $payload = $decodedPayload;
    }
}


/*
|--------------------------------------------------------------------------
| Support Single Lead + Multiple Leads
|--------------------------------------------------------------------------
*/

if (
    isset($payload[0]) &&
    is_array($payload[0])
) {
    $items = $payload;
} else {
    $items = [$payload];
}


/*
|--------------------------------------------------------------------------
| Counters
|--------------------------------------------------------------------------
*/

$created = 0;
$duplicates = 0;
$errors = [];


/*
|--------------------------------------------------------------------------
| Process Leads
|--------------------------------------------------------------------------
*/

foreach ($items as $item) {

    if (!is_array($item)) {

        $errors[] = 'Invalid lead record.';

        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | Basic Lead Information
    |--------------------------------------------------------------------------
    */

    $name = trim(
        (string) (
            $item['name']
            ?? $item['full_name']
            ?? $item['customer_name']
            ?? $item['your-name']
            ?? ''
        )
    );

    $phone = trim(
        (string) (
            $item['phone']
            ?? $item['phone_number']
            ?? $item['mobile']
            ?? $item['your-phone']
            ?? ''
        )
    );

    $email = trim(
        (string) (
            $item['email']
            ?? $item['your-email']
            ?? ''
        )
    );

    $message = trim(
        (string) (
            $item['message']
            ?? $item['your-message']
            ?? ''
        )
    );


    /*
    |--------------------------------------------------------------------------
    | Name Required
    |--------------------------------------------------------------------------
    */

    if ($name === '') {

        $errors[] = 'Name is required.';

        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | Duplicate Check
    |--------------------------------------------------------------------------
    */

    $duplicate = false;


    /*
    |--------------------------------------------------------------------------
    | Phone Duplicate
    |--------------------------------------------------------------------------
    */

    $phoneKey = preg_replace(
        '/\D+/',
        '',
        $phone
    );

    if ($phoneKey !== '') {

        $rows = Database::select(
            "SELECT id, phone
             FROM leads
             WHERE phone IS NOT NULL
             AND phone <> ''
             ORDER BY id DESC
             LIMIT 500"
        );

        foreach ($rows as $row) {

            $existingPhone = preg_replace(
                '/\D+/',
                '',
                (string) $row['phone']
            );

            if (
                $existingPhone !== '' &&
                substr($existingPhone, -10) === substr($phoneKey, -10)
            ) {

                $duplicate = $row;

                break;
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Email Duplicate
    |--------------------------------------------------------------------------
    */

    if (
        !$duplicate &&
        $email !== ''
    ) {

        $duplicate = Database::selectOne(
            "SELECT id
             FROM leads
             WHERE LOWER(email) = LOWER(?)
             LIMIT 1",
            [$email]
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Handle Duplicate
    |--------------------------------------------------------------------------
    */

    if ($duplicate) {

        $duplicates++;

        Database::insert(
            "INSERT INTO integration_logs
            (
                source,
                raw_payload,
                lead_id,
                status,
                error_msg,
                ip_address
            )
            VALUES (?, ?, ?, ?, ?, ?)",
            [
                $source,
                json_encode(
                    $item,
                    JSON_UNESCAPED_UNICODE
                ),
                (int) $duplicate['id'],
                'duplicate',
                'Duplicate lead',
                $_SERVER['REMOTE_ADDR'] ?? null
            ]
        );

        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | Service
    |--------------------------------------------------------------------------
    */

    $service = trim(
        (string) (
            $item['service']
            ?? $item['service_type']
            ?? 'Umrah'
        )
    );

    $allowedServices = [
        'Umrah',
        'Hajj',
        'Holiday Package',
        'Flights Only',
        'Hotel Only',
        'Visa Only'
    ];

    if (!in_array($service, $allowedServices, true)) {
        $service = 'Umrah';
    }


    /*
    |--------------------------------------------------------------------------
    | Priority
    |--------------------------------------------------------------------------
    */

    $priority = trim(
        (string) (
            $item['priority']
            ?? 'Hot'
        )
    );

    if (!in_array(
        $priority,
        ['Hot', 'Warm', 'Cold'],
        true
    )) {
        $priority = 'Hot';
    }


    /*
    |--------------------------------------------------------------------------
    | WhatsApp
    |--------------------------------------------------------------------------
    */

    $whatsapp = trim(
        (string) (
            $item['whatsapp']
            ?? $item['whatsapp_number']
            ?? $phone
        )
    );


    /*
    |--------------------------------------------------------------------------
    | Other Fields
    |--------------------------------------------------------------------------
    */

    $campaign = trim(
        (string) (
            $item['campaign']
            ?? $item['ad_name']
            ?? ''
        )
    );

    $travelMonth = trim(
        (string) (
            $item['travel_month']
            ?? ''
        )
    );

    $adults = (int) (
        $item['adults']
        ?? 1
    );

    $youth = (int) (
        $item['youth']
        ?? 0
    );

    $children = (int) (
        $item['children']
        ?? 0
    );

    $infants = (int) (
        $item['infants']
        ?? 0
    );

    $budget = (
        isset($item['budget']) &&
        $item['budget'] !== ''
    )
        ? (float) $item['budget']
        : null;

    $followUpDate = (
        isset($item['follow_up_date']) &&
        $item['follow_up_date'] !== ''
    )
        ? $item['follow_up_date']
        : null;

    $notes = trim(
        (string) (
            $item['notes']
            ?? ''
        )
    );


    /*
    |--------------------------------------------------------------------------
    | Generate CRM Lead ID
    |--------------------------------------------------------------------------
    */

    $leadCode = 'LED-' . random_int(
        10000,
        99999
    );


    /*
    |--------------------------------------------------------------------------
    | Insert Lead
    |--------------------------------------------------------------------------
    */

    try {

        $leadId = (int) Database::insert(

            "INSERT INTO leads
            (
                lead_id,
                name,
                phone,
                whatsapp,
                email,
                service_type,
                source,
                campaign,
                travel_month,
                adults,
                youth,
                children,
                infants,
                budget,
                priority,
                status,
                assigned_to,
                follow_up_date,
                message,
                notes,
                enquiry_date
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )",

            [
                $leadCode,
                $name,
                $phone,
                $whatsapp,
                $email,
                $service,
                $source,
                $campaign,
                $travelMonth,
                $adults,
                $youth,
                $children,
                $infants,
                $budget,
                $priority,
                'New Lead',
                null,
                $followUpDate,
                $message,
                $notes,
                date('Y-m-d')
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | Lead Activity
        |--------------------------------------------------------------------------
        */

        Database::insert(

            "INSERT INTO lead_activity_log
            (
                lead_id,
                log_text,
                log_type,
                logged_by,
                logged_by_name
            )
            VALUES (?, ?, ?, ?, ?)",

            [
                $leadId,
                'Lead received through ' . $source,
                'note',
                null,
                'Integration'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | Integration Log
        |--------------------------------------------------------------------------
        */

        Database::insert(

            "INSERT INTO integration_logs
            (
                source,
                raw_payload,
                lead_id,
                status,
                error_msg,
                ip_address
            )
            VALUES (?, ?, ?, ?, ?, ?)",

            [
                $source,
                json_encode(
                    $item,
                    JSON_UNESCAPED_UNICODE
                ),
                $leadId,
                'success',
                null,
                $_SERVER['REMOTE_ADDR'] ?? null
            ]
        );


        $created++;

    } catch (Throwable $e) {

        $errors[] = $e->getMessage();

        Database::insert(

            "INSERT INTO integration_logs
            (
                source,
                raw_payload,
                lead_id,
                status,
                error_msg,
                ip_address
            )
            VALUES (?, ?, ?, ?, ?, ?)",

            [
                $source,
                json_encode(
                    $item,
                    JSON_UNESCAPED_UNICODE
                ),
                null,
                'error',
                $e->getMessage(),
                $_SERVER['REMOTE_ADDR'] ?? null
            ]
        );
    }
}


/*
|--------------------------------------------------------------------------
| Final Response
|--------------------------------------------------------------------------
*/

webhookOut(
    true,
    "$created lead(s) received; $duplicates duplicate(s).",
    [
        'created'    => $created,
        'duplicates' => $duplicates,
        'errors'     => $errors
    ]
);

