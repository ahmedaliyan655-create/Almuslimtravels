<?php

header('Content-Type: application/json; charset=utf-8');

$log = [
    'time'   => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'] ?? '',
    'ip'     => $_SERVER['REMOTE_ADDR'] ?? '',
    'headers' => function_exists('getallheaders') ? getallheaders() : [],
    'post'   => $_POST,
    'raw'    => file_get_contents('php://input')
];

file_put_contents(
    __DIR__ . '/elementor-webhook-log.txt',
    json_encode($log, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n\n",
    FILE_APPEND
);

http_response_code(200);

echo json_encode([
    'success' => true,
    'message' => 'Webhook received successfully',
    'method'  => $_SERVER['REQUEST_METHOD'] ?? '',
    'post'    => $_POST
], JSON_UNESCAPED_UNICODE);

exit;