<?php
require_once '../includes/auth.php';
requireLogin();
require_once '../includes/db.php';
require_once '../includes/permissions.php';
header('Content-Type: application/json; charset=utf-8');
function pj($ok, $msg = '', $data = [])
{
    echo json_encode(['success' => $ok, 'message' => $msg, 'data' => $data]);
    exit;
}
try {
    $d = $_POST ?: ($_GET ?: []);
    $action = $d['action'] ?? '';
    $role = authRole();
    if ($action === 'bonus_submit') {
        if (!isAgent() && !isTeamLead()) pj(false, 'Only sales users can submit bonus claims.');
        $type = trim((string)($d['bonus_type'] ?? ''));
        $allowed = ['call30', 'sameday', 'saturday', 'sunday', 'followup', 'review', 'videoreview', 'weekly3', 'weekly4', 'weekly5', 'monthly12', 'special', 'custom'];
        if (!in_array($type, $allowed, true)) pj(false, 'Invalid bonus type.');
        $id = Database::insert("INSERT INTO bonus_claims(agent_id,bonus_type,booking_ref,notes,proof_note,status,amount) VALUES(?,?,?,?,?,'Pending',0)", [authId(), $type, trim((string)($d['booking_ref'] ?? '')), trim((string)($d['notes'] ?? '')), trim((string)($d['proof_note'] ?? ''))]);
        pj(true, 'Bonus claim submitted.', ['id' => $id]);
    }
    if ($action === 'bonus_review') {
        if (!in_array($role, ['manager', 'admin'], true)) pj(false, 'Permission denied.');
        $id = (int)($d['id'] ?? 0);
        $status = $d['status'] ?? '';
        if (!in_array($status, ['Approved', 'Rejected'], true)) pj(false, 'Invalid status.');
        $amount = (float)($d['amount'] ?? 0);
        $defaults = ['call30' => 500, 'sameday' => 1000, 'saturday' => 1000, 'sunday' => 1000, 'followup' => 1000, 'review' => 300, 'videoreview' => 500, 'weekly3' => 1000, 'weekly4' => 2000, 'weekly5' => 5000, 'monthly12' => 10000, 'special' => 0, 'custom' => 0];
        $type = (string)(Database::selectOne('SELECT bonus_type FROM bonus_claims WHERE id=?', [$id])['bonus_type'] ?? '');
        if ($status === 'Approved' && $amount <= 0) $amount = (float)($defaults[$type] ?? 0);
        Database::update('UPDATE bonus_claims SET status=?,amount=?,admin_note=?,reviewed_by=?,reviewed_at=NOW() WHERE id=?', [$status, $amount, trim((string)($d['admin_note'] ?? '')), authId(), $id]);
        pj(true, 'Bonus claim updated.');
    }
    pj(false, 'Unknown action.');
} catch (Throwable $e) {
    http_response_code(500);
    pj(false, $e->getMessage());
}
