<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $id=(int)authId();
    $user=Database::selectOne('SELECT * FROM agents WHERE id=? LIMIT 1',[$id]);
    if(!$user) jsonResponse(false,'Profile not found.');

    $name=trim((string)($_POST['name']??''));
    $email=trim((string)($_POST['email']??''));
    $phone=trim((string)($_POST['phone']??''));
    $designation=trim((string)($_POST['designation']??''));
    if($name==='') jsonResponse(false,'Please enter your full name.');
    if($email==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) jsonResponse(false,'Please enter a valid email address.');

    $dup=Database::selectOne('SELECT id FROM agents WHERE email=? AND id<>? LIMIT 1',[$email,$id]);
    if($dup) jsonResponse(false,'This email is already in use.');

    $image=$user['profile_image']??'';
    if(isset($_FILES['profile_image']) && $_FILES['profile_image']['error']!==UPLOAD_ERR_NO_FILE){
        if($_FILES['profile_image']['error']!==UPLOAD_ERR_OK) jsonResponse(false,'Unable to upload profile image.');
        if((int)$_FILES['profile_image']['size']>2*1024*1024) jsonResponse(false,'Profile image must be 2 MB or smaller.');
        $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($_FILES['profile_image']['tmp_name']);
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) jsonResponse(false,'Only JPG, PNG and WEBP images are allowed.');
        $dir=__DIR__.'/../../uploads/'; if(!is_dir($dir)) mkdir($dir,0775,true);
        $new='staff_'.bin2hex(random_bytes(12)).'.'.$allowed[$mime];
        if(!move_uploaded_file($_FILES['profile_image']['tmp_name'],$dir.$new)) jsonResponse(false,'Unable to save profile image.');
        if($image && is_file($dir.$image)) @unlink($dir.$image);
        $image=$new;
    }

    $newPin=trim((string)($_POST['new_pin']??''));
    $currentPin=trim((string)($_POST['current_pin']??''));
    $confirmPin=trim((string)($_POST['confirm_pin']??''));
    if($newPin!==''){
        if(!ctype_digit($currentPin) || strlen($currentPin)!==4 || !password_verify($currentPin,$user['pin_hash'])) jsonResponse(false,'Current PIN is incorrect.');
        if(!ctype_digit($newPin) || strlen($newPin)!==4) jsonResponse(false,'New PIN must be exactly 4 digits.');
        if($newPin!==$confirmPin) jsonResponse(false,'New PIN and confirmation do not match.');
        $hash=password_hash($newPin,PASSWORD_DEFAULT);
        Database::update('UPDATE agents SET name=?,email=?,phone=?,designation=?,profile_image=?,pin_hash=?,updated_at=NOW() WHERE id=?',[$name,$email,$phone,$designation,$image,$hash,$id]);
    }else{
        Database::update('UPDATE agents SET name=?,email=?,phone=?,designation=?,profile_image=?,updated_at=NOW() WHERE id=?',[$name,$email,$phone,$designation,$image,$id]);
    }

    $_SESSION['agent_name']=$name; $_SESSION['profile_image']=$image;
    $avatar=$image ? '../uploads/'.$image : 'https://ui-avatars.com/api/?name='.urlencode($name).'&background=16284e&color=ffffff';
    jsonResponse(true,'Profile updated successfully.', ['name'=>$name,'profile_image'=>$avatar]);
} catch(Throwable $e){
    error_log('Profile update: '.$e->getMessage());
    jsonResponse(false,'Unable to update profile right now.');
}
