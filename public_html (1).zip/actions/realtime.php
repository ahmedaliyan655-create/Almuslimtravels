<?php

declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/notifications.php';
header('Content-Type: application/json; charset=utf-8');
try {
    $uid = (int)authId();
    $role = strtolower((string)authRole());
    syncSystemNotifications($uid, $role);
    $alerts = notificationsUnreadCount($uid);
    [$bWhere, $bp] = notificationUserScopeWhere($uid, $role);
    $lWhere = '1=1';
    $lp = [];
    if ($role === 'agent') {
        $lWhere = 'l.assigned_to=?';
        $lp = [$uid];
    } elseif ($role === 'teamlead') {
        $ids = array_values(array_unique(array_merge([$uid], teamAgentIds($uid))));
        if ($ids) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $lWhere = "l.assigned_to IN ($ph)";
            $lp = $ids;
        } else {
            $lWhere = '0=1';
        }
    }
    $leads = (int)(Database::selectOne("SELECT COUNT(*) c FROM leads l WHERE $lWhere", $lp)['c'] ?? 0);
    $newLeads = (int)(Database::selectOne("SELECT COUNT(*) c FROM leads l WHERE $lWhere AND l.created_at>=DATE_SUB(NOW(),INTERVAL 1 DAY)", $lp)['c'] ?? 0);
    $bookings = (int)(Database::selectOne("SELECT COUNT(*) c FROM bookings b WHERE $bWhere AND b.updated_at>=DATE_SUB(NOW(),INTERVAL 1 DAY)", $bp)['c'] ?? 0);
    $last = (int)(Database::selectOne("SELECT GREATEST(COALESCE((SELECT MAX(UNIX_TIMESTAMP(l.updated_at)) FROM leads l WHERE $lWhere),0),COALESCE((SELECT MAX(UNIX_TIMESTAMP(b.updated_at)) FROM bookings b WHERE $bWhere),0)) stamp", array_merge($lp, $bp))['stamp'] ?? 0);
    echo json_encode(['success' => true, 'data' => ['alerts' => $alerts, 'unread' => $alerts, 'leads' => $leads, 'new_leads' => $newLeads, 'updated_bookings' => $bookings, 'last_change' => $last, 'server_time' => date('c')]], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Realtime service unavailable.']);
}
