<?php

require_once "../../includes/db.php";
require_once "../../includes/session.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../../login.php");
    exit;
}

$email = strtolower(trim($_POST['email'] ?? ''));
$pin = trim($_POST['pin'] ?? '');

// Lightweight session/IP throttle for PIN guessing.
$now = time();
$attemptWindow = 900;
$maxAttempts = 8;
$attempts = $_SESSION['_login_attempts'] ?? [];
$attempts = array_values(array_filter($attempts, static fn($t) => ($now - (int)$t) < $attemptWindow));
if (count($attempts) >= $maxAttempts) {
    $_SESSION['login_error'] = 'Too many failed login attempts. Please wait 15 minutes and try again.';
    header("Location: ../../login.php");
    exit;
}
$_SESSION['_login_attempts'] = $attempts;

if ($email === '' || $pin === '') {
    $_SESSION['login_error'] = "Please enter your email address and PIN.";
    $_SESSION['login_selected_email'] = $email;
    header("Location: ../../login.php");
    exit;
}

if (!ctype_digit($pin) || strlen($pin) !== 4) {
    $_SESSION['login_error'] = "PIN must be exactly 4 digits.";
    $_SESSION['login_selected_email'] = $email;
    header("Location: ../../login.php");
    exit;
}

try {
    $user = Database::selectOne(
        "SELECT id, name, email, agent_code, role, team_id, default_project_id, profile_image, pin_hash
         FROM agents
         WHERE LOWER(email) = ?
         AND is_active = 1
         LIMIT 1",
        [$email]
    );

    if (!$user || empty($user['pin_hash'])) {
        $_SESSION['login_error'] = "Account not found or has no valid PIN.";
        $_SESSION['login_selected_email'] = $email;
        header("Location: ../../login.php");
        exit;
    }

    if (!password_verify($pin, $user['pin_hash'])) {
        $_SESSION['_login_attempts'][] = $now;
        $_SESSION['login_error'] = "Invalid PIN.";
        $_SESSION['login_selected_email'] = $email;
        header("Location: ../../login.php");
        exit;
    }

    if (password_needs_rehash($user['pin_hash'], PASSWORD_DEFAULT)) {
        $newHash = password_hash($pin, PASSWORD_DEFAULT);
        if ($newHash) {
            Database::update("UPDATE agents SET pin_hash = ? WHERE id = ?", [$newHash, $user['id']]);
        }
    }

    session_regenerate_id(true);
    $_SESSION['_login_attempts'] = [];
    $_SESSION['_rotated_at'] = time();

    $_SESSION['agent_id'] = $user['id'];
    $_SESSION['agent_name'] = $user['name'];
    $_SESSION['agent_code'] = $user['agent_code'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['team_id'] = $user['team_id'];
    $_SESSION['project_id'] = $user['default_project_id'];
    $_SESSION['profile_image'] = $user['profile_image'] ?? '';

    Database::update(
        "UPDATE agents
         SET last_login = NOW(), login_status = 'Online'
         WHERE id = ?",
        [$user['id']]
    );

    header("Location: ../../modules/dashboard.php");
    exit;
} catch (Exception $e) {
    error_log("Login error [{$email}]: " . $e->getMessage());
    $_SESSION['login_error'] = "Unable to process login. Please try again later.";
    $_SESSION['login_selected_email'] = $email;
    header("Location: ../../login.php");
    exit;
}
