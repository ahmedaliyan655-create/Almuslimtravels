<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/auth.php'; requireLogin(); require_once __DIR__.'/../../includes/db.php'; require_once __DIR__.'/../../includes/permissions.php';
header('Content-Type: application/json; charset=utf-8');
try{
 $uid=(int)authId(); $role=strtolower((string)authRole()); $bookingId=(int)($_GET['booking_id']??0);
 if(!in_array($role,['admin','manager','administrator','teamlead'],true)) throw new Exception('Not authorized.');
 $b=Database::selectOne('SELECT project_id FROM bookings WHERE id=?',[$bookingId]); if(!$b) throw new Exception('Booking not found.'); $project=(int)$b['project_id'];
 if(in_array($role,['admin','manager','administrator'],true)){
  $rows=Database::select("SELECT a.id,a.name,a.agent_code FROM agents a WHERE a.role='agent' AND a.is_active=1 AND (a.default_project_id=? OR EXISTS(SELECT 1 FROM agent_projects ap WHERE ap.agent_id=a.id AND ap.project_id=?)) ORDER BY a.name",[$project,$project]);
 }else{
  $ids=array_values(array_unique(teamAgentIds($uid))); if(!$ids){$rows=[];}else{$ph=implode(',',array_fill(0,count($ids),'?'));$params=array_merge([$project,$project],$ids);$rows=Database::select("SELECT a.id,a.name,a.agent_code FROM agents a WHERE a.role='agent' AND a.is_active=1 AND (a.default_project_id=? OR EXISTS(SELECT 1 FROM agent_projects ap WHERE ap.agent_id=a.id AND ap.project_id=?)) AND a.id IN ($ph) ORDER BY a.name",$params);}
 }
 echo json_encode(['success'=>true,'data'=>$rows]);
}catch(Throwable $e){http_response_code(400);echo json_encode(['success'=>false,'message'=>$e->getMessage()]);}
