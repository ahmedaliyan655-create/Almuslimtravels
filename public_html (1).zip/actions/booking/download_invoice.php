<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| AL MUSLIM TRAVEL - INVOICE PDF
|--------------------------------------------------------------------------
| File:
| CRM/actions/booking/download/_invoice.php
|
| Dompdf:
| CRM/vendor/autoload.php
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;


/*
|--------------------------------------------------------------------------
| DATABASE CHECK
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {
    die('Database connection $pdo is not available.');
}


/*
|--------------------------------------------------------------------------
| INPUT
|--------------------------------------------------------------------------
*/

$bookingId = isset($_GET['booking_id'])
    ? (int) $_GET['booking_id']
    : 0;

$type = isset($_GET['type'])
    ? strtolower(trim((string) $_GET['type']))
    : 'full';

$allowedTypes = [
    'full',
    'hotel',
    'flight'
];

if ($bookingId <= 0) {
    die('Invalid booking ID.');
}

if (!in_array($type, $allowedTypes, true)) {
    die('Invalid invoice type.');
}


/*
|--------------------------------------------------------------------------
| COMPANY DETAILS
|--------------------------------------------------------------------------
*/

$companyName    = 'Al Muslim Travel';
$companyEmail   = 'support@almuslimtravel.co.uk';
$companyAddress = '13 Station Road, London, SE25 5AH';
$companyPhone   = '0207 447 5000';

$paymentUrl     = 'https://timestravel.com/payment/';

$bankName       = 'NatWest Bank';
$accountName    = 'Times Travel Ltd';
$accountNumber  = '12333034';
$sortCode       = '60-30-03';


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function e($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function money($amount, string $currency = 'GBP'): string
{
    $symbols = [
        'GBP' => '£',
        'USD' => '$',
        'EUR' => '€'
    ];

    $symbol = $symbols[$currency] ?? ($currency . ' ');

    return $symbol . number_format(
        (float) ($amount ?? 0),
        2
    );
}

function rawMoney($amount): string
{
    return number_format((float) ($amount ?? 0), 2);
}

function formatDateInvoice($date): string
{
    if (!$date) {
        return '-';
    }

    $timestamp = strtotime((string) $date);

    if (!$timestamp) {
        return e($date);
    }

    return date('d M Y', $timestamp);
}

function formatLongDate($date): string
{
    if (!$date) {
        return '-';
    }

    $timestamp = strtotime((string) $date);

    if (!$timestamp) {
        return e($date);
    }

    return date('d M Y', $timestamp);
}

function formatTimeInvoice($time): string
{
    if (!$time) {
        return '-';
    }

    $timestamp = strtotime((string) $time);

    if (!$timestamp) {
        return e($time);
    }

    return date('H:i', $timestamp);
}

function rowValue(array $row, array $keys, $default = '')
{
    foreach ($keys as $key) {
        if (array_key_exists($key, $row) && $row[$key] !== null && $row[$key] !== '') {
            return $row[$key];
        }
    }

    return $default;
}

function normaliseText($value): string
{
    return strtoupper(trim((string) ($value ?? '')));
}


/*
|--------------------------------------------------------------------------
| GET BOOKING
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        b.*,
        a.name AS agent_name,
        a.email AS agent_email,
        a.agent_code,
        p.project_name,
        p.project_code,
        p.logo AS project_logo
    FROM bookings b
    LEFT JOIN agents a
        ON a.id = b.agent_id
    LEFT JOIN projects p
        ON p.id = b.project_id
    WHERE b.id = ?
    LIMIT 1
");

$stmt->execute([$bookingId]);

$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    die('Booking not found.');
}


/*
|--------------------------------------------------------------------------
| GET PASSENGERS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_passengers
    WHERE booking_id = ?
    ORDER BY sort_order ASC, id ASC
");

$stmt->execute([$bookingId]);

$passengers = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| GET FLIGHTS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_flights
    WHERE booking_id = ?
    ORDER BY dept_date ASC, sort_order ASC, id ASC
");

$stmt->execute([$bookingId]);

$flights = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| GET HOTELS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_hotels
    WHERE booking_id = ?
    ORDER BY check_in ASC, sort_order ASC, id ASC
");

$stmt->execute([$bookingId]);

$hotels = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| GET TRANSPORT
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_transports
    WHERE booking_id = ?
    ORDER BY pickup_date ASC, sort_order ASC, id ASC
");

$stmt->execute([$bookingId]);

$transports = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| GET PRODUCTS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_products
    WHERE booking_id = ?
    ORDER BY sort_order ASC, id ASC
");

$stmt->execute([$bookingId]);

$products = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| GET COST ROWS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_cost_rows
    WHERE booking_id = ?
    ORDER BY sort_order ASC, id ASC
");

$stmt->execute([$bookingId]);

$costRows = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| GET PAYMENTS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_payments
    WHERE booking_id = ?
    ORDER BY payment_date ASC, id ASC
");

$stmt->execute([$bookingId]);

$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| CURRENCY
|--------------------------------------------------------------------------
*/

$currency = !empty($booking['currency'])
    ? strtoupper((string) $booking['currency'])
    : 'GBP';


/*
|--------------------------------------------------------------------------
| CUSTOMER / CONTACT DETAILS
|--------------------------------------------------------------------------
*/

$clientName = trim((string) ($booking['client_name'] ?? ''));

$clientMobile = (string) (
    $booking['client_mobile']
    ?? $booking['client_phone']
    ?? ''
);

$clientEmail = (string) (
    $booking['client_email']
    ?? ''
);

$travelDate = (
    $booking['travel_date']
    ?? $booking['date']
    ?? null
);

$gdsPnr = (
    $booking['gds_pnr']
    ?? $booking['gdsPNR']
    ?? $booking['pnr']
    ?? ''
);

$airlinePnr = (
    $booking['airline_pnr']
    ?? $booking['airlinePNR']
    ?? ''
);


/*
|--------------------------------------------------------------------------
| CALCULATE SERVICE AMOUNTS
|--------------------------------------------------------------------------
*/

$hotelAmount     = 0.00;
$flightAmount    = 0.00;
$transportAmount = 0.00;
$visaAmount      = 0.00;
$otherAmount     = 0.00;

$visaRows = [];
$hotelRows = [];

foreach ($costRows as $row) {

    $categoryType = normaliseText(
        $row['category_type'] ?? ''
    );

    $ageCategory = normaliseText(
        $row['age_category'] ?? ''
    );

    $amount = (float) (
        $row['selling_total']
        ?? $row['total']
        ?? $row['amount']
        ?? 0
    );

    /*
    |--------------------------------------------------------------------------
    | HOTEL
    |--------------------------------------------------------------------------
    */

    if (
        $categoryType === 'HOTEL' ||
        $ageCategory === 'MAK HOTEL' ||
        $ageCategory === 'MED HOTEL'
    ) {
        $hotelAmount += $amount;

        // Keep the exact hotel cost row for invoice display.
        $hotelRows[] = $row;

        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | TRANSPORT
    |--------------------------------------------------------------------------
    */

    if (
        $categoryType === 'TRANSPORT' ||
        $categoryType === 'GROUND TRANSPORT' ||
        $ageCategory === 'TRANSPORT'
    ) {
        $transportAmount += $amount;
        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | VISA
    |--------------------------------------------------------------------------
    */

    if (
        $categoryType === 'VISA' ||
        $ageCategory === 'VISA'
    ) {
        $visaAmount += $amount;
        $visaRows[] = $row;
        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | FLIGHT / PASSENGER
    |--------------------------------------------------------------------------
    */

    if (
        in_array(
            $categoryType,
            ['ADULT', 'CHILD', 'INFANT', 'YOUTH', 'FLIGHT'],
            true
        )
        ||
        in_array(
            $ageCategory,
            ['ADULT', 'CHILD', 'YOUTH', 'INFANT', 'FLIGHT'],
            true
        )
    ) {
        $flightAmount += $amount;
        continue;
    }

    $otherAmount += $amount;
}


/*
|--------------------------------------------------------------------------
| FALLBACK SERVICE AMOUNTS
|--------------------------------------------------------------------------
| If the cost rows do not contain a particular category, use the booking
| totals only where the corresponding columns exist.
|--------------------------------------------------------------------------
*/

if ($flightAmount <= 0 && isset($booking['flight_total'])) {
    $flightAmount = (float) $booking['flight_total'];
}

if ($hotelAmount <= 0 && isset($booking['hotel_total'])) {
    $hotelAmount = (float) $booking['hotel_total'];
}

if ($transportAmount <= 0 && isset($booking['transport_total'])) {
    $transportAmount = (float) $booking['transport_total'];
}

if ($visaAmount <= 0 && isset($booking['visa_total'])) {
    $visaAmount = (float) $booking['visa_total'];
}


/*
|--------------------------------------------------------------------------
| PAYMENT TOTAL
|--------------------------------------------------------------------------
*/

$paymentTotal = 0.00;

foreach ($payments as $payment) {

    $creditDebit = normaliseText(
        rowValue(
            $payment,
            ['credit_debit', 'payment_type', 'type'],
            ''
        )
    );

    $paymentStatus = normaliseText(
        rowValue(
            $payment,
            ['payment_status', 'status'],
            ''
        )
    );

    $amount = (float) rowValue(
        $payment,
        ['amount', 'payment_amount', 'received_amount'],
        0
    );

    /*
    | Keep the original business rule:
    | only received DEBIT payments count as paid.
    */
    if (
        $creditDebit === 'DEBIT'
        &&
        in_array(
            $paymentStatus,
            ['RECEIVED', 'PAID', 'COMPLETED'],
            true
        )
    ) {
        $paymentTotal += $amount;
    }
}


/*
|--------------------------------------------------------------------------
| DISPLAY PAYMENT TOTAL
|--------------------------------------------------------------------------
*/

$displayPaid = isset($booking['total_received'])
    ? (float) $booking['total_received']
    : $paymentTotal;


/*
|--------------------------------------------------------------------------
| DISPLAY TOTALS
|--------------------------------------------------------------------------
*/

$grossTotal = isset($booking['gross_total'])
    ? (float) $booking['gross_total']
    : (
        $flightAmount
        + $hotelAmount
        + $transportAmount
        + $visaAmount
        + $otherAmount
    );

$atolCharges = (float) ($booking['atol_charges'] ?? 0);
$safiCharges  = (float) ($booking['safi_charges'] ?? 0);
$discount     = (float) ($booking['discount'] ?? 0);

$totalPayable = isset($booking['total_payable'])
    ? (float) $booking['total_payable']
    : ($grossTotal + $atolCharges + $safiCharges - $discount);

$balanceDue = isset($booking['balance_due'])
    ? (float) $booking['balance_due']
    : max(0, $totalPayable - $displayPaid);


/*
|--------------------------------------------------------------------------
| HOTEL PRICE MATCHING
|--------------------------------------------------------------------------
| booking_hotels does not contain a price column in the current database.
| The exact hotel selling values are stored in booking_cost_rows:
|   selling_price  = unit price
|   selling_total  = exact line total
|
| We NEVER split the overall hotel total between hotel records.
|--------------------------------------------------------------------------
*/

$usedHotelCostRows = [];

function getHotelCostRowForInvoice(
    array $hotel,
    array $hotelRows,
    array &$usedHotelCostRows
): ?array {
    if (empty($hotelRows)) {
        return null;
    }

    $city = normaliseText($hotel['city'] ?? '');
    $preferredCategory = null;

    if (
        strpos($city, 'MAKKAH') !== false ||
        strpos($city, 'MECCA') !== false
    ) {
        $preferredCategory = 'MAK HOTEL';
    } elseif (
        strpos($city, 'MADINAH') !== false ||
        strpos($city, 'MEDINA') !== false
    ) {
        $preferredCategory = 'MED HOTEL';
    }

    if ($preferredCategory !== null) {
        foreach ($hotelRows as $index => $row) {
            if (
                isset($usedHotelCostRows[$index]) ||
                normaliseText($row['age_category'] ?? '') !== $preferredCategory
            ) {
                continue;
            }

            $usedHotelCostRows[$index] = true;
            return $row;
        }
    }

    foreach ($hotelRows as $index => $row) {
        if (isset($usedHotelCostRows[$index])) {
            continue;
        }

        $usedHotelCostRows[$index] = true;
        return $row;
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| INVOICE TITLE
|--------------------------------------------------------------------------
*/

$invoiceTitle = 'INVOICE';
$invoiceNote  = 'Complete Invoice for all services';
$filenamePrefix = 'Invoice';

if ($type === 'hotel') {
    $invoiceTitle = 'HOTEL INVOICE';
    $invoiceNote = 'Hotel accommodation services';
    $filenamePrefix = 'Hotel-Invoice';
}

if ($type === 'flight') {
    $invoiceTitle = 'FLIGHT INVOICE';
    $invoiceNote = 'Flight booking and ticketing services';
    $filenamePrefix = 'Flight-Invoice';
}


/*
|--------------------------------------------------------------------------
| TRAVEL CONSULTANT
|--------------------------------------------------------------------------
*/

$consultantName = trim((string) ($booking['agent_name'] ?? ''));

if ($consultantName === '') {
    $consultantName = '-';
}


/*
|--------------------------------------------------------------------------
| PROJECT LOGO
|--------------------------------------------------------------------------
| Logo is fetched dynamically from the project assigned to this booking:
|
| bookings.project_id
|       ↓
| projects.logo
|       ↓
| CRM/modules/uploads/<logo filename>
|--------------------------------------------------------------------------
*/

$projectLogo = trim((string) ($booking['project_logo'] ?? ''));
$logoPath = null;
$logoImgHtml = '';

if ($projectLogo !== '') {
    $logoFileName = basename($projectLogo);

    $possibleLogoPaths = [
        __DIR__ . '/../../../uploads/' . $logoFileName,
        __DIR__ . '/../../../modules/uploads/' . $logoFileName,
        __DIR__ . '/../../uploads/' . $logoFileName,
        __DIR__ . '/../../../assets/images/' . $logoFileName,
    ];

    foreach ($possibleLogoPaths as $possiblePath) {
        $resolvedPath = realpath($possiblePath);
        if ($resolvedPath !== false && is_file($resolvedPath) && is_readable($resolvedPath)) {
            $logoPath = $resolvedPath;
            break;
        }
    }
}

if ($logoPath !== null) {
    $imageData = @file_get_contents($logoPath);
    $imageInfo = @getimagesize($logoPath);

    if ($imageData !== false) {
        $mimeType = (is_array($imageInfo) && !empty($imageInfo['mime']))
            ? $imageInfo['mime']
            : 'image/png';

        $logoSrc = 'data:' . $mimeType . ';base64,' . base64_encode($imageData);

        $logoImgHtml = '
            <img
                src="' . $logoSrc . '"
                class="project-logo-image"
                alt="' . e($booking['project_name'] ?? 'Project') . '"
            >
        ';
    } else {
        $logoPath = null;
    }
}

if ($logoPath === null) {

    // Fallback if the project has no logo or the logo file cannot be found.
    $projectInitials = 'AT';

    $projectNameForInitials = trim(
        (string) ($booking['project_name'] ?? '')
    );

    if ($projectNameForInitials !== '') {

        $words = preg_split('/\s+/', $projectNameForInitials);

        if (
            is_array($words)
            && count($words) >= 2
        ) {
            $projectInitials = strtoupper(
                substr($words[0], 0, 1)
                . substr($words[1], 0, 1)
            );
        } else {
            $projectInitials = strtoupper(
                substr($projectNameForInitials, 0, 2)
            );
        }
    }

    $logoImgHtml = '
        <div class="logo-fallback">
            ' . e($projectInitials) . '
        </div>
    ';
}

$projectDisplayName = trim(
    (string) ($booking['project_name'] ?? '')
);

if ($projectDisplayName === '') {
    $projectDisplayName = $companyName;
}

$projectCode = trim(
    (string) ($booking['project_code'] ?? '')
);

$logoHtml = '
    <table class="header-brand-row">
        <tr>
            <td style="width:54px;">
                ' . $logoImgHtml . '
            </td>
            <td>
                <div class="logo-text">
                    ' . e($projectDisplayName) . '
                </div>
                ' . (
                    $projectCode !== ''
                    ? '<div class="project-code">'
                        // . e($projectCode)
                        . '</div>'
                    : ''
                ) . '
                <div class="logo-tagline">
                    Have trust. We care for you!
                </div>
            </td>
        </tr>
    </table>

    <div class="company-address-block">
        ' . e($companyAddress) . '<br>
        ' . e($companyEmail) . ' &middot; Tel: ' . e($companyPhone) . '
    </div>

    <div class="consultant-line">
        Travel Consultant: ' . e($consultantName) . '
    </div>
';

/*
|--------------------------------------------------------------------------
| PASSENGER NAMES
|--------------------------------------------------------------------------
*/

$passengerNames = [];

foreach ($passengers as $passenger) {

    $name = trim(
        ($passenger['title'] ?? '') . ' ' .
        ($passenger['firstname'] ?? '') . ' ' .
        ($passenger['surname'] ?? '')
    );

    if ($name !== '') {
        $passengerNames[] = $name;
    }
}

$passengerList = !empty($passengerNames)
    ? implode('<br>', array_map('e', $passengerNames))
    : 'No passenger details';


/*
|--------------------------------------------------------------------------
| AGENT
|--------------------------------------------------------------------------
*/

$agentName = (string) (
    $booking['agent_name']
    ?? '-'
);

$agentEmail = (string) (
    $booking['agent_email']
    ?? $companyEmail
);


/*
|--------------------------------------------------------------------------
| HTML START
|--------------------------------------------------------------------------
*/

$html = <<<HTML
<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<style>

@page {
    size: A4 portrait;
    margin: 18px 20px 30px 20px;
}

* {
    box-sizing: border-box;
}

body {
    font-family: DejaVu Sans, sans-serif;
    font-size: 10px;
    color: #26384d;
    margin: 0;
    padding: 0;
    background: #fff;
}

table {
    border-collapse: collapse;
}

.page-break {
    page-break-before: auto;
}

.keep-together {
    page-break-inside: avoid;
}

.text-right { text-align: right; }
.text-center { text-align: center; }

/* =========================================================
   HEADER — REFERENCE STYLE
   ========================================================= */

.header-table {
    width: 100%;
    margin: 0 0 9px 0;
    padding: 0 0 8px 0;
    border-bottom: 2px solid #0d6b32;
}

.header-table td {
    vertical-align: top;
}

.header-left {
    width: 66%;
}

.header-right {
    width: 34%;
    text-align: right;
    vertical-align: top !important;
}

.header-brand-row {
    width: 100%;
}

.header-brand-row td {
    vertical-align: middle;
}

.project-logo-image {
    width: 48px;
    height: 48px;
    object-fit: contain;
}

.logo-fallback {
    width: 48px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    border-radius: 50%;
    background: #277c38;
    color: #fff;
    font-size: 12px;
    font-weight: bold;
}

.logo-text {
    margin-left: 5px;
    color: #0d6b32;
    font-size: 15px;
    line-height: 16px;
    font-weight: bold;
}

.project-code {
    margin-left: 5px;
    margin-top: 1px;
    color: #777f88;
    font-size: 6.5px;
    font-weight: normal;
    letter-spacing: .15px;
}

.logo-tagline {
    margin-left: 5px;
    margin-top: 1px;
    color: #71808d;
    font-size: 7px;
    line-height: 9px;
    font-style: italic;
}

.company-address-block {
    margin: 2px 0 0 53px;
    color: #66727e;
    font-size: 6.5px;
    line-height: 9px;
}

.consultant-line {
    margin: 1px 0 0 53px;
    color: #0d6b32;
    font-size: 7px;
    font-weight: bold;
}

.invoice-title {
    color: #203b5d;
    font-size: 25px;
    line-height: 25px;
    font-weight: bold;
    letter-spacing: -.6px;
}

.invoice-number {
    margin-top: 1px;
    color: #d29d32;
    font-size: 10px;
    font-weight: bold;
}


/* =========================================================
   INFORMATION CARDS
   ========================================================= */

.info-table {
    width: 100%;
    margin: 5px 0 9px 0;
}

.info-table > tbody > tr > td {
    width: 33.333%;
    vertical-align: top;
}

.info-gap {
    width: 7px !important;
}

.info-card {
    min-height: 86px;
    border: 1px solid #dce2e8;
    border-radius: 6px;
    padding: 8px 9px;
    background: #fbfcfd;
}

.card-heading {
    font-size: 6.5px;
    line-height: 8px;
    font-weight: bold;
    color: #778493;
    letter-spacing: .8px;
    margin-bottom: 6px;
    text-transform: uppercase;
}

.passenger-name {
    font-size: 10px;
    line-height: 11px;
    font-weight: bold;
    color: #1e3858;
}

.contact-row,
.invoice-row {
    width: 100%;
    font-size: 10px;
    line-height: 12px;
    border-bottom: 1px solid #edf0f2;
}

.contact-label,
.invoice-label {
    color: #7b8793;
}

.contact-value,
.invoice-value {
    text-align: right;
    color: #1e3858;
    font-weight: 500;
}

.invoice-value {
    font-weight: bold;
}

.paid-value {
    color: #179b57;
    font-weight: bold;
}

.balance-line {
    border-top: 1px solid #0d6b32;
    margin-top: 2px;
    padding-top: 2px;
}

.balance-label {
    color: #0d6b32;
    font-weight: bold;
    font-size: 10px;
}

.balance-value {
    text-align: right;
    color: #0d6b32;
    font-size: 10px;
    font-weight: bold;
}


/* =========================================================
   SECTION / SERVICES
   ========================================================= */

.section-bar {
    width: 100%;
    background: #24466d;
    color: #fff;
    padding: 5px 7px;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    text-transform: uppercase;
    margin-top: 6px;
}

.services {
    width: 100%;
    table-layout: fixed;
}

.services thead th {
    background: #24466d;
    color: #fff;
    padding: 5px 6px;
    font-size: 10px;
    line-height: 8px;
    text-align: left;
    font-weight: bold;
}

.services thead th:nth-child(1) { width: 63%; }
.services thead th:nth-child(2) { width: 7%; text-align: center; }
.services thead th:nth-child(3) { width: 15%; text-align: right; }
.services thead th:nth-child(4) { width: 15%; text-align: right; }

.services tbody td {
    padding: 5px 6px;
    border-bottom: 1px solid #e5e8eb;
    vertical-align: top;
    font-size: 10px;
    line-height: 9px;
}

.services tbody tr:nth-child(even) td {
    background: #fbfbfb;
}

/* SECTION-WISE ITEMISED SERVICES */
.service-section {
    margin-top: 7px;
    page-break-inside: avoid;
}

.service-section-heading {
    width: 100%;
    /* background: #0d6b32; */
    color: #0d6b32;
    padding: 5px 7px;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: .25px;
}

.service-section .services {
    margin-top: 0;
}

.service-title {
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    color: #1d395a;
    margin-bottom: 1px;
}

.service-detail {
    color: #657789;
    font-size:10px;
    line-height: 8px;
}

.qty-cell {
    text-align: center;
    font-weight: bold;
    color: #26384d;
}

.money-cell {
    text-align: right;
    white-space: nowrap;
    font-weight: bold;
    color: #17324f;
}

/* HOTEL ONLY TABLE */
.hotel-services thead th:nth-child(1) { width: 35%; }
.hotel-services thead th:nth-child(2) { width: 12%; }
.hotel-services thead th:nth-child(3) { width: 13%; }
.hotel-services thead th:nth-child(4) { width: 13%; }
.hotel-services thead th:nth-child(5) { width: 13.5%; text-align: right; }
.hotel-services thead th:nth-child(6) { width: 13.5%; text-align: right; }

.no-service {
    text-align: center;
    padding: 12px !important;
    color: #777;
}


/* =========================================================
   TOTALS
   ========================================================= */

.totals-wrap {
    width: 100%;
    margin-top: 8px;
}

.totals-table {
    width: 30%;
    margin-left: auto;
    border: 1px solid #dce2e8;
    border-radius: 6px;
}

.totals-table td {
    padding: 5px 7px;
    border-bottom: 1px solid #e5e8eb;
    font-size:10px;
    line-height: 8px;
}

.totals-label {
    color: #26384d;
}

.totals-value {
    text-align: right;
    font-weight: bold;
    color: #17324f;
}

.paid-row td {
    color: #159b56;
}

.balance-row td {
    background: #24466d;
    color: #fff !important;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    border-bottom: 0;
}

.balance-row td:last-child {
    text-align: right;
}


/* =========================================================
   PAYMENTS RECEIVED
   ========================================================= */

.payment-section {
    margin-top: 9px;
}

.payment-heading {
    width: 100%;
    background: #24466d;
    color: #fff;
    padding: 5px 7px;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    text-transform: uppercase;
}

.payment-table {
    width: 100%;
    table-layout: fixed;
}

.payment-table th {
    background: #364a63;
    color: #fff;
    padding: 5px 6px;
    text-align: left;
    font-size: 10px;
    line-height: 8px;
}

.payment-table td {
    padding: 5px 6px;
    border-bottom: 1px solid #e3e7ea;
    font-size: 10px;
    line-height: 8px;
}

.payment-table tr:nth-child(even) td {
    background: #fafafa;
}

.payment-table th:nth-child(1) { width: 14%; }
.payment-table th:nth-child(2) { width: 18%; }
.payment-table th:nth-child(3) { width: 20%; }
.payment-table th:nth-child(4) { width: 10%; }
.payment-table th:nth-child(5) { width: 12%; text-align: right; }
.payment-table th:nth-child(6) { width: 26%; }

.payment-amount {
    text-align: right;
    font-weight: bold;
}

.payment-empty {
    text-align: center;
    color: #777;
    padding: 9px !important;
}


/* =========================================================
   DETAILS
   ========================================================= */

.detail-section {
    margin-top: 9px;
}

.detail-heading {
    background: #f0f3f6;
    border-left: 3px solid #0d6b32;
    color: #24466d;
    padding: 5px 7px;
    font-size:10px;
    line-height: 9px;
    font-weight: bold;
}

.detail-box {
    border: 1px solid #e2e6ea;
    border-top: 0;
    padding: 6px 7px;
    margin-bottom: 5px;
    line-height: 10px;
    font-size: 10px;
}

.detail-box strong {
    color: #193650;
}

.detail-label {
    color: #778494;
}


/* =========================================================
   PAYMENT INFORMATION — COMPACT REFERENCE STYLE
   ========================================================= */

.payment-info {
    margin-top: 8px;
    page-break-inside: avoid;
}

.payment-info-title {
    background: #f1f4f7;
    border: 1px solid #dce2e8;
    border-bottom: 0;
    border-left: 3px solid #0d6b32;
    color: #24466d;
    padding: 5px 7px;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
}

.payment-intro {
    border: 1px solid #dce2e8;
    border-top: 0;
    padding: 5px 7px;
    color: #596a7b;
    font-size:10px;
    line-height: 8px;
}

.payment-methods {
    width: 100%;
    margin-top: 5px;
    table-layout: fixed;
}

.payment-methods td {
    width: 50%;
    vertical-align: top;
    padding: 0 3px 0 0;
}

.payment-methods td:last-child {
    padding: 0 0 0 3px;
}

.payment-card {
    border: 1px solid #dce2e8;
    background: #fbfcfd;
    padding: 6px 7px;
    min-height: 78px;
}

.payment-card-title {
    color: #24466d;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    margin-bottom: 2px;
}

.payment-card-subtitle {
    color: #7a8796;
    font-size:10px;
    line-height: 7px;
    margin-bottom: 4px;
}

.payment-total-highlight {
    background: #f6f8fa;
    border-left: 2px solid #d29d32;
    padding: 3px 5px;
    margin: 3px 0 4px;
}

.payment-total-highlight table,
.bank-details {
    width: 100%;
}

.payment-total-highlight td,
.bank-details td {
    padding: 2px 0;
    font-size:10px;
    line-height: 7px;
    border-bottom: 1px solid #edf0f3;
}

.payment-total-highlight td {
    border-bottom: 0;
}

.payment-total-highlight .amount,
.bank-value {
    text-align: right;
    color: #24466d;
    font-weight: bold;
}

.payment-link {
    display: block;
    background: #24466d;
    color: #fff;
    padding: 4px 5px;
    text-align: center;
    font-size:10px;
    line-height: 7px;
    font-weight: bold;
}

.bank-label {
    color: #7a8796;
    width: 42%;
}

.payment-note {
    margin-top: 4px;
    padding: 4px 5px;
    background: #fffaf0;
    border: 1px solid #f0dfb7;
    color: #6b5a39;
    font-size:10px;
    line-height: 7px;
}


/* =========================================================
   TERMS & CONDITIONS — DENSE REFERENCE STYLE
   ========================================================= */

.terms {
    margin-top: 8px;
    font-size: 7.5px;
    line-height: 1.3;
    color: #4d5968;
}

.important-note {
    margin-top: 9px;
    border: 1px solid #e5d6b2;
    border-left: 3px solid #d29d32;
    background: #fffaf0;
    padding: 7px 8px;
    color: #4d5968;
    font-size: 6.2px;
    line-height: 8px;
    page-break-inside: avoid;
}

.important-note-title {
    color: #24466d;
    font-size: 10px;
    line-height: 9px;
    font-weight: bold;
    margin-bottom: 4px;
}

.important-note p {
    margin: 0 0 3px 0;
}

.important-note .bank-title {
    color: #0d6b32;
    font-weight: bold;
    margin-top: 4px;
    margin-bottom: 2px;
}

.important-note .bank-line {
    margin: 0;
    line-height: 8px;
}

.terms-heading {
    background: #fff;
    color: #24466d;
    padding: 0 0 4px 0;
    border-bottom: 2px solid #0d6b32;
    font-size: 9px;
    line-height: 10px;
    font-weight: bold;
    letter-spacing: 1px;
    margin-bottom: 5px;
    page-break-after: avoid;
}

.terms-intro {
    border: 1px solid #e1e6eb;
    border-left: 2px solid #d29d32;
    background: #fbfcfd;
    padding: 5px 6px;
    margin-bottom: 5px;
    line-height: 9px;
    font-size: 7.5px;
}

.terms-columns {
    width: 100%;
    table-layout: fixed;
    border-collapse: collapse;
    margin: 0;
    padding: 0;
}

.terms-columns > tbody > tr > td {
    width: 50%;
    vertical-align: top;
    padding: 0 6px 0 0;
    margin: 0;
}

.terms-columns > tbody > tr > td:last-child {
    padding: 0 0 0 6px;
}

.terms-section {
    margin-bottom: 5px;
}

.terms-section-title {
    color: #24466d;
    font-size: 7.5px;
    line-height: 9px;
    font-weight: bold;
    margin-bottom: 1px;
}

.terms-section-text {
    color: #4d5968;
    font-size: 7px;
    line-height: 8.5px;
}

.terms-bullets {
    margin: 1px 0 0 10px;
    padding: 0;
}

.terms-bullets li {
    margin: 0 0 1px 0;
    padding: 0;
    font-size: 7px;
    line-height: 8.5px;
}

.terms-sub-bullets {
    margin: 1px 0 1px 12px;
    padding: 0;
    list-style-type: circle;
}

.terms-sub-bullets li {
    margin: 0;
    padding: 0;
    font-size: 7px;
    line-height: 8.5px;
}

.terms-declaration {
    margin-top: 5px;
    padding: 5px 7px;
    border: 1px solid #d9e0e7;
    border-left: 3px solid #0d6b32;
    background: #f5f7fa;
    page-break-inside: avoid;
}

.terms-declaration-title {
    color: #24466d;
    font-size: 7.5px;
    line-height: 9px;
    font-weight: bold;
    margin-bottom: 2px;
}

.terms-validity-note {
    margin-top: 5px;
    padding: 5px 7px;
    border: 1px solid #e5d6b2;
    border-left: 3px solid #d29d32;
    background: #fffaf0;
    color: #24466d;
    font-size: 7.5px;
    line-height: 9px;
    font-weight: bold;
    text-align: center;
    page-break-inside: avoid;
}

.terms-footer-note {
    margin-top: 5px;
    padding-top: 4px;
    border-top: 1px solid #d8dee4;
    color: #7f8b99;
    font-size: 7px;
    line-height: 8px;
    text-align: center;
}


/* =========================================================
   FOOTER
   ========================================================= */

.footer {
    position: fixed;
    bottom: -18px;
    left: 0;
    right: 0;
    height: 13px;
    padding-top: 3px;
    border-top: 1px solid #dfe3e7;
    text-align: center;
    color: #7c8793;
    font-size: 10px;
    line-height: 7px;
}

</style>

</head>

<body>

HTML;


/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

$html .= '
<table class="header-table">
    <tr>

        <td class="header-left">
            ' . $logoHtml . '
        </td>

        <td class="header-right">

            <div class="invoice-title">
                ' . e($invoiceTitle) . '
            </div>

            <div class="invoice-number">
                # ' . e($booking['invoice_no'] ?? '') . '
            </div>

        </td>

    </tr>
</table>
';

/*
|--------------------------------------------------------------------------
| INFORMATION CARDS
|--------------------------------------------------------------------------
| Hotel invoices do not show the passenger card.
|--------------------------------------------------------------------------
*/

$html .= '
<table class="info-table">
    <tr>
';

if ($type !== 'hotel') {

    $html .= '
        <td>

            <div class="info-card">

                <div class="card-heading">
                    BILL TO — PASSENGERS
                </div>

                ' . $passengerList . '

            </div>

        </td>

        <td class="info-gap"></td>
    ';
}


/*
|--------------------------------------------------------------------------
| CONTACT DETAILS
|--------------------------------------------------------------------------
*/

$html .= '
        <td>

            <div class="info-card">

                <div class="card-heading">
                    CONTACT DETAILS
                </div>

                <table style="width:100%;">

                    <tr class="contact-row">
                        <td class="contact-label">Name</td>
                        <td class="contact-value">
                            ' . e($clientName) . '
                        </td>
                    </tr>

                    <tr class="contact-row">
                        <td class="contact-label">Mobile</td>
                        <td class="contact-value">
                            ' . e($clientMobile) . '
                        </td>
                    </tr>

                    <tr class="contact-row">
                        <td class="contact-label">Email</td>
                        <td class="contact-value">
                            ' . e($clientEmail) . '
                        </td>
                    </tr>

                    <tr class="contact-row">
                        <td class="contact-label">Travel Date</td>
                        <td class="contact-value">
                            ' . formatLongDate($travelDate) . '
                        </td>
                    </tr>

                </table>

            </div>

        </td>

        <td class="info-gap"></td>
';


/*
|--------------------------------------------------------------------------
| INVOICE DETAILS
|--------------------------------------------------------------------------
*/

$html .= '
        <td>

            <div class="info-card">

                <div class="card-heading">
                    INVOICE DETAILS
                </div>

                <table style="width:100%;">

                    <tr class="invoice-row">
                        <td class="invoice-label">Date</td>
                        <td class="invoice-value">
                            ' . formatLongDate(
                                $booking['invoice_date'] ?? null
                            ) . '
                        </td>
                    </tr>

                    <tr class="invoice-row">
                        <td class="invoice-label">Due Date</td>
                        <td class="invoice-value">
                            ' . formatLongDate(
                                $booking['due_date'] ?? null
                            ) . '
                        </td>
                    </tr>

                

                    <tr class="invoice-row">
                        <td class="invoice-label">Paid</td>
                        <td class="invoice-value paid-value">
                            ' . money(
                                $displayPaid,
                                $currency
                            ) . '
                        </td>
                    </tr>

                    <tr>
                        <td class="balance-label balance-line">
                            Balance Due
                        </td>

                        <td class="balance-value balance-line">
                            ' . money(
                                $balanceDue,
                                $currency
                            ) . '
                        </td>
                    </tr>

                </table>

            </div>

        </td>

    </tr>
</table>
';
/*
|--------------------------------------------------------------------------
| ITEMISED SERVICES — SECTION WISE
|--------------------------------------------------------------------------
| Each service type is displayed in its own numbered section.
| Flight / accommodation detail blocks are not repeated later in the invoice.
|--------------------------------------------------------------------------
*/

if ($type === 'full') {

    $serviceNo = 0;

    $html .= '
    <div class="section-bar">
        ➜ ITEMISED SERVICES
    </div>
    ';

    /*
    |--------------------------------------------------------------------------
    | SERVICE 1 — FLIGHT
    |--------------------------------------------------------------------------
    */

    if (!empty($flights)) {

        $serviceNo++;

        $html .= '
        <div class="service-section">
            <div class="service-section-heading">
                SERVICE ' . $serviceNo . ' &nbsp;—&nbsp; FLIGHT
            </div>

            <table class="services">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style="text-align:center;">Qty</th>
                        <th style="text-align:right;">Unit Price</th>
                        <th style="text-align:right;">Total</th>
                    </tr>
                </thead>
                <tbody>
        ';

        $flightRate = $flightAmount / max(1, count($flights));

        foreach ($flights as $flight) {

            $airlineFlight = trim(
                (string) ($flight['airline_code'] ?? '') . ' ' .
                (string) ($flight['flight_no'] ?? '')
            );

            $route = trim(
                (string) ($flight['origin'] ?? '') .
                ' → ' .
                (string) ($flight['destination'] ?? '')
            );

            $date = formatDateInvoice($flight['dept_date'] ?? null);

            $times =
                formatTimeInvoice($flight['dept_time'] ?? null) .
                ' → ' .
                formatTimeInvoice($flight['arr_time'] ?? null);

            $baggage = (string) ($flight['baggage'] ?? '-');

            $html .= '
                    <tr>
                        <td>
                            <div class="service-title">' . e($airlineFlight) . '</div>
                            <div class="service-detail">
                                ' . e($route) . '
                                · ' . e($date) . '
                                · ' . e($times) . '
                                · Baggage: ' . e($baggage) . '
                            </div>
                        </td>
                        <td class="qty-cell">1</td>
                        <td class="money-cell">' . money($flightRate, $currency) . '</td>
                        <td class="money-cell">' . money($flightRate, $currency) . '</td>
                    </tr>
            ';
        }

        $html .= '
                </tbody>
            </table>
        </div>
        ';
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICE — ACCOMMODATION
    |--------------------------------------------------------------------------
    */

    if (!empty($hotels)) {

        $serviceNo++;

        $html .= '
        <div class="service-section">
            <div class="service-section-heading">
                SERVICE ' . $serviceNo . ' &nbsp;—&nbsp; ACCOMMODATION
            </div>

            <table class="services hotel-services">
                <thead>
                    <tr>
                        <th>Hotel / Accommodation</th>
                        <th>City</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th style="text-align:right;">Price</th>
                        <th style="text-align:right;">Total</th>
                    </tr>
                </thead>
                <tbody>
        ';

        foreach ($hotels as $hotel) {

            $hotelCostRow = getHotelCostRowForInvoice(
                $hotel,
                $hotelRows,
                $usedHotelCostRows
            );

            $hotelUnitPrice = $hotelCostRow !== null
                ? (float) ($hotelCostRow['selling_price'] ?? 0)
                : 0.00;

            $hotelRowTotal = $hotelCostRow !== null
                ? (float) ($hotelCostRow['selling_total'] ?? 0)
                : 0.00;

            $hotelRowQty = $hotelCostRow !== null
                ? (int) ($hotelCostRow['quantity'] ?? 1)
                : 1;

            $hotelName = (string) ($hotel['hotel_name'] ?? '');
            $hotelCity = (string) ($hotel['city'] ?? '');
            $roomType  = (string) ($hotel['room_type'] ?? '-');
            $rooms     = (string) ($hotel['rooms'] ?? 1);

            $checkIn  = formatDateInvoice($hotel['check_in'] ?? null);
            $checkOut = formatDateInvoice($hotel['check_out'] ?? null);

            $html .= '
                    <tr>
                        <td>
                            <div class="service-title">' . e($hotelName) . '</div>
                            <div class="service-detail">
                                ' . e($roomType) . ' · Rooms: ' . e($rooms) . '
                            </div>
                        </td>
                        <td>' . e($hotelCity) . '</td>
                        <td>' . $checkIn . '</td>
                        <td>' . $checkOut . '</td>
                        <td class="money-cell">' .
                            ($hotelCostRow !== null ? money($hotelUnitPrice, $currency) : '-') .
                        '</td>
                        <td class="money-cell">' .
                            ($hotelCostRow !== null ? money($hotelRowTotal, $currency) : '-') .
                        '</td>
                    </tr>
            ';
        }

        $html .= '
                </tbody>
            </table>
        </div>
        ';
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICE — VISA
    |--------------------------------------------------------------------------
    */

    if (!empty($visaRows) || $visaAmount > 0) {

        $serviceNo++;

        $html .= '
        <div class="service-section">
            <div class="service-section-heading">
                SERVICE ' . $serviceNo . ' &nbsp;—&nbsp; VISA
            </div>

            <table class="services">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style="text-align:center;">Qty</th>
                        <th style="text-align:right;">Unit Price</th>
                        <th style="text-align:right;">Total</th>
                    </tr>
                </thead>
                <tbody>
        ';

        if (!empty($visaRows)) {

            foreach ($visaRows as $visaRow) {

                $visaQty = max(1, (int) ($visaRow['quantity'] ?? 1));
                $visaUnitPrice = (float) ($visaRow['selling_price'] ?? 0);
                $visaTotalPrice = (float) (
                    $visaRow['selling_total'] ??
                    ($visaUnitPrice * $visaQty)
                );

                $visaDescription = rowValue(
                    $visaRow,
                    ['description', 'item_name', 'service_name', 'product_name'],
                    'Umrah / Mofa Visa'
                );

                $visaCategory = rowValue(
                    $visaRow,
                    ['age_category', 'category_type'],
                    'VISA'
                );

                $html .= '
                    <tr>
                        <td>
                            <div class="service-title">Umrah / Mofa Visa</div>
                            <div class="service-detail">
                                ' . e($visaDescription) . ' · ' . e($visaCategory) . '
                            </div>
                        </td>
                        <td class="qty-cell">' . $visaQty . '</td>
                        <td class="money-cell">' . money($visaUnitPrice, $currency) . '</td>
                        <td class="money-cell">' . money($visaTotalPrice, $currency) . '</td>
                    </tr>
                ';
            }

        } else {

            $html .= '
                    <tr>
                        <td>
                            <div class="service-title">Umrah / Mofa Visa</div>
                            <div class="service-detail">Visa service</div>
                        </td>
                        <td class="qty-cell">1</td>
                        <td class="money-cell">' . money($visaAmount, $currency) . '</td>
                        <td class="money-cell">' . money($visaAmount, $currency) . '</td>
                    </tr>
            ';
        }

        $html .= '
                </tbody>
            </table>
        </div>
        ';
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICE — GROUND TRANSPORT
    |--------------------------------------------------------------------------
    */

    if (!empty($transports)) {

        $serviceNo++;

        $html .= '
        <div class="service-section">
            <div class="service-section-heading">
                SERVICE ' . $serviceNo . ' &nbsp;—&nbsp; GROUND TRANSPORT
            </div>

            <table class="services">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style="text-align:center;">Qty</th>
                        <th style="text-align:right;">Unit Price</th>
                        <th style="text-align:right;">Total</th>
                    </tr>
                </thead>
                <tbody>
        ';

        $transportRate = $transportAmount / max(1, count($transports));

        foreach ($transports as $transport) {

            $vehicle = (string) ($transport['vehicle'] ?? '');
            $journey = (string) ($transport['journey'] ?? '');

            $html .= '
                    <tr>
                        <td>
                            <div class="service-title">' . e($vehicle) . '</div>
                            <div class="service-detail">' . nl2br(e($journey)) . '</div>
                        </td>
                        <td class="qty-cell">1</td>
                        <td class="money-cell">' . money($transportRate, $currency) . '</td>
                        <td class="money-cell">' . money($transportRate, $currency) . '</td>
                    </tr>
            ';
        }

        $html .= '
                </tbody>
            </table>
        </div>
        ';
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICE — ADDITIONAL PRODUCTS
    |--------------------------------------------------------------------------
    */

    if (!empty($products)) {

        $serviceNo++;

        $html .= '
        <div class="service-section">
            <div class="service-section-heading">
                SERVICE ' . $serviceNo . ' &nbsp;—&nbsp; ADDITIONAL SERVICES
            </div>

            <table class="services">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th style="text-align:center;">Qty</th>
                        <th style="text-align:right;">Unit Price</th>
                        <th style="text-align:right;">Total</th>
                    </tr>
                </thead>
                <tbody>
        ';

        $productCount = count($products);
        $productTotal = $otherAmount;
        $productRate = $productTotal / max(1, $productCount);

        foreach ($products as $product) {

            $productName = rowValue(
                $product,
                ['product_name', 'name', 'description'],
                'Additional Service'
            );

            $html .= '
                    <tr>
                        <td>
                            <div class="service-title">' . e($productName) . '</div>
                            <div class="service-detail">Additional service</div>
                        </td>
                        <td class="qty-cell">1</td>
                        <td class="money-cell">' . money($productRate, $currency) . '</td>
                        <td class="money-cell">' . money($productRate, $currency) . '</td>
                    </tr>
            ';
        }

        $html .= '
                </tbody>
            </table>
        </div>
        ';
    }

    if ($serviceNo === 0) {
        $html .= '
        <div class="service-section">
            <div class="no-service">
                No itemised services found.
            </div>
        </div>
        ';
    }
}


/*
|--------------------------------------------------------------------------
| HOTEL ONLY
|--------------------------------------------------------------------------
*/

if ($type === 'hotel') {

    $html .= '
    <div class="section-bar">
        ➜ HOTEL SERVICES
    </div>

    <table class="services hotel-services">

        <thead>

            <tr>
                <th>Hotel / Accommodation</th>
                <th>City</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th style="text-align:right;">Price</th>
                <th style="text-align:right;">Total</th>
            </tr>

        </thead>

        <tbody>
    ';

    foreach ($hotels as $hotel) {

        // Use the exact stored selling price/total for this hotel.
        // Never divide the aggregate hotel amount between hotels.
        $hotelCostRow = getHotelCostRowForInvoice(
            $hotel,
            $hotelRows,
            $usedHotelCostRows
        );

        $hotelUnitPrice = $hotelCostRow !== null
            ? (float) ($hotelCostRow['selling_price'] ?? 0)
            : 0.00;

        $hotelRowTotal = $hotelCostRow !== null
            ? (float) ($hotelCostRow['selling_total'] ?? 0)
            : 0.00;

        $hotelRowQty = $hotelCostRow !== null
            ? (int) ($hotelCostRow['quantity'] ?? 1)
            : 1;

        $hotelName = (string) ($hotel['hotel_name'] ?? '');
        $hotelCity = (string) ($hotel['city'] ?? '');
        $roomType  = (string) ($hotel['room_type'] ?? '-');
        $rooms     = (string) ($hotel['rooms'] ?? 1);

        $checkIn = formatDateInvoice($hotel['check_in'] ?? null);
        $checkOut = formatDateInvoice($hotel['check_out'] ?? null);

        $html .= '
        <tr>

            <td>
                <div class="service-title">
                    ' . e($hotelName) . '
                </div>

                <div class="service-detail">
                    ' . e($roomType) . '
                    · Rooms: ' . e($rooms) . '
                </div>
            </td>

            <td>
                ' . e($hotelCity) . '
            </td>

            <td>
                ' . $checkIn . '
            </td>

            <td>
                ' . $checkOut . '
            </td>

            <td class="money-cell">
                ' . (
                    $hotelCostRow !== null
                        ? money($hotelUnitPrice, $currency)
                        : '-'
                ) . '
            </td>

            <td class="money-cell">
                ' . (
                    $hotelCostRow !== null
                        ? money($hotelRowTotal, $currency)
                        : '-'
                ) . '
            </td>

        </tr>
        ';
    }

    if (empty($hotels)) {
        $html .= '
        <tr>
            <td colspan="6" class="no-service">
                No hotel services found.
            </td>
        </tr>
        ';
    }

    $html .= '
        </tbody>
    </table>
    ';

    $html .= '
    <div class="totals-wrap">

        <table class="totals-table">

            <tr>
                <td class="totals-label">
                    Hotel Total
                </td>

                <td class="totals-value">
                    ' . money($hotelAmount, $currency) . '
                </td>
            </tr>

        </table>

    </div>
    ';
}


/*
|--------------------------------------------------------------------------
| FLIGHT ONLY
|--------------------------------------------------------------------------
*/

if ($type === 'flight') {

    $html .= '
    <div class="section-bar">
        ➜ FLIGHT SERVICES
    </div>

    <table class="services">

        <thead>

            <tr>
                <th>Flight</th>
                <th>Date</th>
                <th>Departure</th>
                <th>Arrival</th>
            </tr>

        </thead>

        <tbody>
    ';

    foreach ($flights as $flight) {

        $html .= '
        <tr>

            <td>

                <div class="service-title">
                    ' .
                    e($flight['airline_code'] ?? '') .
                    ' ' .
                    e($flight['flight_no'] ?? '') .
                '</div>

                <div class="service-detail">
                    ' .
                    e($flight['origin'] ?? '') .
                    ' → ' .
                    e($flight['destination'] ?? '') .
                    ' · Class: ' .
                    e($flight['booking_class'] ?? '-') .
                '</div>

            </td>

            <td>
                ' . formatDateInvoice(
                    $flight['dept_date'] ?? null
                ) . '
            </td>

            <td>
                ' . formatTimeInvoice(
                    $flight['dept_time'] ?? null
                ) . '
            </td>

            <td>
                ' . formatTimeInvoice(
                    $flight['arr_time'] ?? null
                ) . '
            </td>

        </tr>
        ';
    }

    if (empty($flights)) {

        $html .= '
        <tr>
            <td colspan="4" class="no-service">
                No flight services found.
            </td>
        </tr>
        ';
    }

    $html .= '
        </tbody>

    </table>
    ';
}


/*
|--------------------------------------------------------------------------
| TOTALS
|--------------------------------------------------------------------------
*/

if ($type === 'full') {

    $html .= '
    <div class="totals-wrap">

        <table class="totals-table">

            <tr>
                <td class="totals-label">
                    Gross Total
                </td>

                <td class="totals-value">
                    ' . money($grossTotal, $currency) . '
                </td>
            </tr>
    ';

    if ($atolCharges != 0) {

        $html .= '
            <tr>
                <td class="totals-label">
                    ATOL Charges
                </td>

                <td class="totals-value">
                    ' . money($atolCharges, $currency) . '
                </td>
            </tr>
        ';
    }

    if ($safiCharges != 0) {

        $html .= '
            <tr>
                <td class="totals-label">
                    SAFI Charges
                </td>

                <td class="totals-value">
                    ' . money($safiCharges, $currency) . '
                </td>
            </tr>
        ';
    }

    if ($discount != 0) {

        $html .= '
            <tr>
                <td class="totals-label">
                    Discount
                </td>

                <td class="totals-value">
                    -' . money($discount, $currency) . '
                </td>
            </tr>
        ';
    }

    $html .= '
            <tr>
                <td class="totals-label">
                    Total Payable
                </td>

                <td class="totals-value">
                    ' . money($totalPayable, $currency) . '
                </td>
            </tr>

            <tr class="paid-row">
                <td>
                    Amount Paid
                </td>

                <td class="text-right">
                    ' . money($displayPaid, $currency) . '
                </td>
            </tr>

            <tr class="balance-row">
                <td>
                    BALANCE DUE
                </td>

                <td>
                    ' . money($balanceDue, $currency) . '
                </td>
            </tr>

        </table>

    </div>
    ';
}


/*
|--------------------------------------------------------------------------
| PAYMENTS RECEIVED
|--------------------------------------------------------------------------
*/

if ($type === 'full') {

    $html .= '
    <div class="payment-section">

        <div class="payment-heading">
            ▣ &nbsp; PAYMENTS RECEIVED
        </div>

        <table class="payment-table">

            <thead>

                <tr>
                    <th>Receipt</th>
                    <th>Date</th>
                    <th>Method</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Remarks</th>
                </tr>

            </thead>

            <tbody>
    ';

    if (!empty($payments)) {

        foreach ($payments as $payment) {

            $receipt = rowValue(
                $payment,
                [
                    'receipt_no',
                    'receipt_id',
                    'receipt_number',
                    'payment_reference'
                ],
                '-'
            );

            $paymentDate = rowValue(
                $payment,
                [
                    'payment_date',
                    'date'
                ],
                null
            );

            $method = rowValue(
                $payment,
                [
                    'payment_method',
                    'method',
                    'payment_mode'
                ],
                '-'
            );

            $paymentType = rowValue(
                $payment,
                [
                    'credit_debit',
                    'payment_type',
                    'type'
                ],
                '-'
            );

            $amount = rowValue(
                $payment,
                [
                    'amount',
                    'payment_amount',
                    'received_amount'
                ],
                0
            );

            $remarks = rowValue(
                $payment,
                [
                    'remarks',
                    'remark',
                    'notes',
                    'description'
                ],
                '-'
            );

            $html .= '
            <tr>

                <td>
                    ' . e($receipt) . '
                </td>

                <td>
                    ' . formatLongDate($paymentDate) . '
                </td>

                <td>
                    ' . e($method) . '
                </td>

                <td>
                    ' . e($paymentType) . '
                </td>

                <td class="payment-amount">
                    ' . money($amount, $currency) . '
                </td>

                <td>
                    ' . e($remarks) . '
                </td>

            </tr>
            ';
        }

    } else {

        $html .= '
            <tr>
                <td colspan="6" class="payment-empty">
                    No payments received.
                </td>
            </tr>
        ';
    }

    $html .= '
            </tbody>

        </table>

    </div>
    ';
}


/*
|--------------------------------------------------------------------------
| IMPORTANT NOTE / BANK DETAILS
|--------------------------------------------------------------------------
| This note is intentionally placed immediately above the Terms & Conditions.
|--------------------------------------------------------------------------
*/

if (in_array($type, ['full', 'hotel', 'flight'], true)) {

    $html .= '
    <div class="important-note">

        <div class="important-note-title">
            Important Note
        </div>

        <p>
            Please note that the ticket(s) can only be issued on receipt of a full payment
            received at our end, within the due date and time.
        </p>

        <p>
            * Please note that as certain corresponding banks do not credit the payments
            made online, on the very same day, hence please confirm the relevant information
            with your bank, prior to initiating any online transfers. Please note that the
            fare quoted, can only be honored upon receiving the funds in full.
        </p>

        <p>
            * Please note that Bank deposits / online transfers are only credited on weekdays
            and not on weekends or any other national or gazette holidays.
        </p>

        <div class="bank-title">
            Our account details are as follows:
        </div>

        <p class="bank-line">
            <strong>NatWest bank detail for payment</strong>
        </p>
        <p class="bank-line">Bank name: ' . e($bankName) . '</p>
        <p class="bank-line">A/C title: ' . e($accountName) . '</p>
        <p class="bank-line">A/C no: ' . e($accountNumber) . '</p>
        <p class="bank-line">Sort code: ' . e($sortCode) . '</p>

    </div>
    ';
}


/*
|--------------------------------------------------------------------------
| TERMS & CONDITIONS
|--------------------------------------------------------------------------
*/

if (in_array($type, ['full', 'hotel', 'flight'], true)) {

    /*
    | Pair each section side-by-side (1|2, 3|4, ...) as its own small table
    | so DomPDF can page-break between pairs and fill remaining page space.
    */
    $termsSections = [
        '
        <div class="terms-section">
            <div class="terms-section-title">1. DEFINITIONS</div>
            <div class="terms-section-text">
                &ldquo;We&rdquo;, &ldquo;Us&rdquo;, &ldquo;Our&rdquo; refers to Al-Muslim Travel.<br>
                &ldquo;You&rdquo;, &ldquo;Customer&rdquo;, &ldquo;Passenger&rdquo; refers to the person making the booking and all persons included in the booking.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">2. NATURE OF SERVICE (IMPORTANT)</div>
            <div class="terms-section-text">
                We act solely as an intermediary agent arranging travel services on your behalf with independent third-party suppliers, including but not limited to airlines, hotels, and visa providers.<br>
                All bookings made through us constitute a Linked Travel Arrangement (LTA) and NOT a package holiday under the Package Travel and Linked Travel Arrangements Regulations 2018.<br>
                Each service is separate and subject to the individual supplier&rsquo;s own terms and conditions.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">3. ACCEPTANCE OF TERMS</div>
            <div class="terms-section-text">By confirming your booking and/or making payment, you acknowledge that:</div>
            <ul class="terms-bullets">
                <li>You have read, understood, and accepted these Terms &amp; Conditions</li>
                <li>You understand this is NOT a package holiday</li>
                <li>You agree that all services are subject to supplier terms and policies</li>
            </ul>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">4. BOOKING, PAYMENT &amp; BANKING CONDITIONS</div>
            <ul class="terms-bullets">
                <li>Full payment or deposit (as advised) must be received before services are confirmed</li>
                <li>Tickets/services will only be issued once full cleared payment is received within the specified time</li>
                <li>Cash deposits must be made:
                    <ul class="terms-sub-bullets">
                        <li>Before 4:00 PM on weekdays</li>
                        <li>Before 2:00 PM on Saturdays</li>
                    </ul>
                </li>
            </ul>
            <div class="terms-section-text">
                Payments made after these times may not reflect on the same day, and any fare or tax increase must be paid by the customer.<br>
                Online/bank transfers may not be credited on the same day depending on your bank. Customers are responsible for confirming processing times with their bank before making payment.<br>
                Bank transfers are only credited on working weekdays and not on weekends or public holidays.<br>
                Prices are subject to availability and are not guaranteed until tickets are issued, even if payment has been made.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">5. NON-REFUNDABLE &amp; NON-CHANGEABLE SERVICES</div>
            <div class="terms-section-text">
                Most travel services (including flights, hotels, and visas) are non-refundable but may be changeable to an alternative date, strictly subject to supplier terms and availability.<br>
                Any amendments to flights or hotel bookings may incur additional charges or fare differences, which the customer is fully responsible for paying.
            </div>
            <ul class="terms-bullets">
                <li>All deposits are non-refundable</li>
                <li>Refunds, if any, are strictly subject to policy of the airline, hotel, or supplier.</li>
            </ul>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">6. SUPPLIER RESPONSIBILITY</div>
            <div class="terms-section-text">
                All services are provided by independent third-party suppliers. We have no control over supplier decisions, including cancellations, schedule changes, hotel changes, or service quality.<br>
                In the event of any last-minute changes or cancellations by a supplier, we will use reasonable efforts to arrange a suitable alternative of a similar standard; however, this is subject to availability and any price differences may be payable by the customer.<br>
                We hold no responsibility if any supplier changes or replaces services after confirmation.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">7. FORCE MAJEURE / EXTRAORDINARY EVENTS</div>
            <div class="terms-section-text">We shall not be liable for any disruption, cancellation, or loss caused by events beyond our control, including but not limited to:</div>
            <ul class="terms-bullets">
                <li>War, conflict, or political instability</li>
                <li>Government restrictions or travel bans</li>
                <li>Airline cancellations or operational issues</li>
                <li>Natural disasters or pandemics</li>
                <li>Visa rejection due to incorrect or invalid documents provided by the passenger</li>
            </ul>
            <div class="terms-section-text">In such cases:</div>
            <ul class="terms-bullets">
                <li>Refunds are not guaranteed</li>
                <li>Any refunds are strictly subject to supplier approval</li>
            </ul>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">8. FLIGHT BOOKINGS &amp; TICKETING</div>
            <ul class="terms-bullets">
                <li>Airlines are solely responsible for flight operations</li>
                <li>Tickets are generally issued within 48&ndash;72 hours after full payment (or 12&ndash;24 hours for urgent bookings)</li>
                <li>No paper tickets will be issued (e-tickets only)</li>
            </ul>
            <div class="terms-section-text">Passengers must:</div>
            <ul class="terms-bullets">
                <li>Reconfirm bookings 72 hours before departure</li>
                <li>Arrive at least:
                    <ul class="terms-sub-bullets">
                        <li>3 hours before international flights</li>
                        <li>2 hours before domestic flights</li>
                    </ul>
                </li>
            </ul>
            <div class="terms-section-text">All changes are subject to airline rules, fare restrictions, and seat availability.</div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">9. HOTEL ACCOMMODATION</div>
            <div class="terms-section-text">
                Hotel bookings are made based on specific rate conditions, which are typically non-refundable but may be changeable subject to supplier terms and availability.
            </div>
            <ul class="terms-bullets">
                <li>Alternative hotels of similar standard may be provided if required</li>
                <li>Any upgrades or changes may result in additional charges payable by the customer</li>
                <li>Hotel-related issues (cleanliness, maintenance, service) must be handled directly with the hotel</li>
            </ul>
            <div class="terms-section-text">We are not responsible for hotel service quality or changes made by suppliers.</div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">10. VISA SERVICES</div>
            <ul class="terms-bullets">
                <li>Visa fees are non-refundable once submitted</li>
                <li>We act only as an intermediary and accept no responsibility for delays, refusals, or decisions made by authorities</li>
            </ul>
            <div class="terms-section-text">
                We accept no liability for any issues arising from incorrect, incomplete, or invalid documentation provided by the passenger.<br>
                It is the passenger&rsquo;s sole responsibility to ensure that all documents are accurate, valid, and meet all travel requirements before submission.<br>
                Visa processing times and fees may change without prior notice.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">11. CUSTOMER RESPONSIBILITIES</div>
            <div class="terms-section-text">You are responsible for:</div>
            <ul class="terms-bullets">
                <li>Ensuring all travel documents (passport, visa, insurance) are valid</li>
                <li>Passport validity (minimum 6 months from return date)</li>
                <li>Providing accurate information</li>
                <li>Checking booking details</li>
            </ul>
            <div class="terms-section-text">
                Failure to provide valid documentation may result in denied boarding, visa refusal, or entry refusal, for which we accept no liability and no refunds will be provided.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">12. REFUNDS</div>
            <ul class="terms-bullets">
                <li>Refunds are subject to the policies of the respective suppliers including airlines, hotels, and visa authorities.</li>
                <li>Almuslim Travel will process any eligible refund after receiving the refund from the supplier.</li>
                <li>Refund processing times may vary depending on supplier and banking processes. Normally it take 2-4 months to process the refund.</li>
                <li>Administrative/service fees are non-refundable</li>
            </ul>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">13. AMENDMENTS &amp; CANCELLATIONS</div>
            <ul class="terms-bullets">
                <li>Changes are subject to supplier rules and availability</li>
                <li>Additional charges may apply</li>
                <li>Some bookings cannot be amended once confirmed</li>
                <li>Failure to pay outstanding balance may result in cancellation and loss of deposit</li>
            </ul>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">14. LIMITATION OF LIABILITY</div>
            <div class="terms-section-text">
                We act solely as an agent and shall not be liable for any loss, delay, inconvenience, or damages caused by suppliers or external events.<br>
                Our liability is limited strictly to the service fees charged by us.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">15. CHARGEBACKS &amp; DISPUTES</div>
            <div class="terms-section-text">By proceeding with the booking, you agree that:</div>
            <ul class="terms-bullets">
                <li>You will not initiate a chargeback for services provided in accordance with these Terms</li>
                <li>Any disputes must be raised directly with us first</li>
            </ul>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">16. COMMUNICATION</div>
            <div class="terms-section-text">
                All confirmations and updates via email or messaging platforms (including WhatsApp) are considered valid and binding communication.
            </div>
        </div>
        ',
        '
        <div class="terms-section">
            <div class="terms-section-title">17. GOVERNING LAW</div>
            <div class="terms-section-text">
                These Terms &amp; Conditions are governed by the laws of England and Wales.
            </div>
        </div>
        ',
    ];

    /*
    | Independent columns (odd left / even right) so a long section on one
    | side does not create empty gaps under the shorter section on the other.
    */
    $termsLeftHtml  = '';
    $termsRightHtml = '';

    foreach ($termsSections as $index => $sectionHtml) {
        if ($index % 2 === 0) {
            $termsLeftHtml .= $sectionHtml;
        } else {
            $termsRightHtml .= $sectionHtml;
        }
    }

    $html .= '

    <div class="terms">

        <div class="terms-heading">
            TERMS &amp; CONDITIONS &ndash; LINKED TRAVEL ARRANGEMENTS (LTA)
        </div>

        <table class="terms-columns">
            <tr>
                <td>' . $termsLeftHtml . '</td>
                <td>' . $termsRightHtml . '</td>
            </tr>
        </table>

        <div class="terms-declaration">
            <div class="terms-declaration-title">DECLARATION</div>
            <div class="terms-section-text">By proceeding with payment, you confirm that:</div>
            <ul class="terms-bullets">
                <li>You understand this is a Linked Travel Arrangement (LTA)</li>
                <li>You accept that services may be non-refundable</li>
                <li>You agree to all Terms &amp; Conditions stated above</li>
                <li>You accept responsibility for your travel documents and booking details</li>
            </ul>
        </div>

        <div class="terms-validity-note">
            PLEASE NOTE: THIS QUOTATION IS ONLY VALID UPON RECEIPT OF A DEPOSIT OR FULL PAYMENT UNLESS OTHERWISE SPECIFIED
        </div>

        <div class="terms-footer-note">
            ' . e($companyName) . ' &middot; ' . e($companyAddress) . ' &middot; Tel: ' . e($companyPhone) . ' &middot; ' . e($companyEmail) . '<br>
            By accepting this invoice you agree to all terms above.
        </div>

    </div>

    ';
}




/*
|--------------------------------------------------------------------------
| FOOTER
|--------------------------------------------------------------------------
*/

$html .= '
<div class="footer">
    ' . e($companyName) . '
    &nbsp;|&nbsp;
    ' . e($companyAddress) . '
    &nbsp;|&nbsp;
    Tel: ' . e($companyPhone) . '
    &nbsp;|&nbsp;
    Invoice: ' . e($booking['invoice_no'] ?? '') . '
</div>

</body>
</html>
';


/*
|--------------------------------------------------------------------------
| DOMPDF OPTIONS
|--------------------------------------------------------------------------
*/

$options = new Options();

$options->set('isRemoteEnabled', true);
$options->set('isHtml5ParserEnabled', true);
$options->setChroot(realpath(__DIR__ . '/../../../'));
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);

$dompdf->loadHtml(
    $html,
    'UTF-8'
);

$dompdf->setPaper(
    'A4',
    'portrait'
);

$dompdf->render();


/*
|--------------------------------------------------------------------------
| FILE NAME
|--------------------------------------------------------------------------
*/

$safeInvoiceNo = preg_replace(
    '/[^A-Za-z0-9_-]/',
    '-',
    (string) ($booking['invoice_no'] ?? $bookingId)
);

$filename =
    $filenamePrefix .
    '-' .
    $safeInvoiceNo .
    '.pdf';


/*
|--------------------------------------------------------------------------
| DOWNLOAD PDF
|--------------------------------------------------------------------------
*/

$dompdf->stream(
    $filename,
    [
        'Attachment' => false
    ]
);

exit;