<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/auth.php'; requireLogin();
require_once __DIR__.'/../../includes/db.php'; require_once __DIR__.'/../../includes/permissions.php';
header('Content-Type: application/json; charset=utf-8');
function jr(bool $ok,string $msg,array $data=[],int $code=200): never { http_response_code($code); echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE); exit; }
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS booking_delete_requests (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, requester_id INT UNSIGNED NOT NULL, status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending', requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_by INT UNSIGNED NULL, reviewed_at DATETIME NULL, rejection_reason TEXT NULL, UNIQUE KEY uq_pending_delete (booking_id, requester_id, status), KEY idx_delete_status(status), KEY idx_delete_booking(booking_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    $bookingId=(int)($_POST['booking_id']??0); if($bookingId<=0) jr(false,'Invalid booking ID.',[],400);
    $uid=(int)authId(); $role=strtolower((string)authRole());
    $b=Database::selectOne('SELECT * FROM bookings WHERE id=?',[$bookingId]); if(!$b) jr(false,'Booking not found.',[],404);
    $isPrivileged=in_array($role,['admin','manager','administrator'],true);
    $canDirect=$isPrivileged;
    if($role==='teamlead') {
        $ids=array_values(array_unique(array_merge([$uid],teamAgentIds($uid))));
        $canDirect=in_array((int)$b['agent_id'],$ids,true);
        if($canDirect){
            $lead=Database::selectOne('SELECT default_project_id FROM agents WHERE id=? LIMIT 1',[$uid]);
            $project=(int)($lead['default_project_id']??0);
            $canProject=$project>0 ? ((int)$b['project_id']===$project || (bool)Database::selectOne('SELECT 1 FROM agent_projects WHERE agent_id=? AND project_id=? LIMIT 1',[$uid,$b['project_id']])) : (bool)Database::selectOne('SELECT 1 FROM agent_projects WHERE agent_id=? AND project_id=? LIMIT 1',[$uid,$b['project_id']]);
            $canDirect=$canDirect && $canProject;
        }
    }
    if($role==='agent' && (int)$b['agent_id']!==$uid) jr(false,'You can only delete your own bookings.',[],403);
    $action=strtolower((string)($_GET['action']??''));
    if($role==='agent' && !$canDirect) {
        $approved=Database::selectOne("SELECT id FROM booking_delete_requests WHERE booking_id=? AND requester_id=? AND status='Approved' ORDER BY id DESC LIMIT 1",[$bookingId,$uid]);
        if($approved) {
            $canDirect=true;
        } else {
            $pending=Database::selectOne("SELECT id FROM booking_delete_requests WHERE booking_id=? AND requester_id=? AND status='Pending' LIMIT 1",[$bookingId,$uid]);
            if($pending) jr(false,'Deletion request is already pending.', ['status'=>'Pending'],409);
            $pdo->prepare("INSERT INTO booking_delete_requests (booking_id,requester_id,status) VALUES (?,?,'Pending')")->execute([$bookingId,$uid]);
            jr(true,'Deletion request sent to Admin, Manager and Team Lead. Please wait for approval.', ['status'=>'Pending']);
        }
    }
    if(!$canDirect) jr(false,'You are not authorized to delete this booking.',[],403);
    $pdo->beginTransaction();
    $pdo->prepare('DELETE FROM bookings WHERE id=?')->execute([$bookingId]);
    if($pdo->inTransaction()) $pdo->commit();
    jr(true,'Booking deleted successfully.');
} catch(Throwable $e){ if(isset($pdo)&&$pdo->inTransaction()) $pdo->rollBack(); jr(false,$e->getMessage() ?: 'Delete operation failed.',[],500); }
