<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try{

    /*
    |--------------------------------------------------------------------------
    | Login User
    |--------------------------------------------------------------------------
    */

    $loginId   = $_SESSION['agent_id'];
    $loginRole = $_SESSION['role'];

    /*
    |--------------------------------------------------------------------------
    | Base Query
    |--------------------------------------------------------------------------
    */

    $sql = "

    SELECT

        b.*,

        a.name AS agent_name,

        p.project_name

    FROM bookings b

    LEFT JOIN agents a

        ON a.id=b.agent_id

    LEFT JOIN projects p

        ON p.id=b.project_id

    ";

    /*
    |--------------------------------------------------------------------------
    | Permission
    |--------------------------------------------------------------------------
    */

    if($loginRole=="agent"){

        $sql.="

        WHERE b.agent_id=?

        ORDER BY b.id DESC

        ";

        $rows=Database::select(

            $sql,

            [

                $loginId

            ]

        );

    }

    elseif($loginRole=="teamlead"){

        $sql.="

        WHERE

        (
            b.agent_id = ?

            OR

            EXISTS (
                SELECT 1
                FROM agents teamAgent
                WHERE teamAgent.id = b.agent_id
                  AND teamAgent.role = 'agent'
                  AND teamAgent.team_lead_id = ?
                  AND (
                      teamAgent.default_project_id = b.project_id
                      OR EXISTS (
                          SELECT 1
                          FROM agent_projects ap_agent
                          WHERE ap_agent.agent_id = teamAgent.id
                            AND ap_agent.project_id = b.project_id
                      )
                  )
            )
        )

        AND (
            EXISTS (
                SELECT 1
                FROM agent_projects ap_lead
                WHERE ap_lead.agent_id = ?
                  AND ap_lead.project_id = b.project_id
            )
            OR EXISTS (
                SELECT 1
                FROM agents leadUser
                WHERE leadUser.id = ?
                  AND leadUser.default_project_id = b.project_id
            )
        )

        ORDER BY b.id DESC

        ";

        $rows=Database::select(

            $sql,

            [

                $loginId,
                $loginId,
                $loginId,
                $loginId

            ]

        );

    }

    else{

        $sql.="

        ORDER BY b.id DESC

        ";

        $rows=Database::select($sql);

    }

    /*
    |--------------------------------------------------------------------------
    | Statistics
    |--------------------------------------------------------------------------
    */

    $stats=[

        "totalBookings"=>0,

        "confirmedBookings"=>0,

        "pendingBookings"=>0,

        "cancelledBookings"=>0,

        "totalRevenue"=>0,

        "balanceDue"=>0

    ];

    $data=[];

    foreach($rows as $row){

        $stats["totalBookings"]++;

        if($row["status"]=="Confirmed"){

            $stats["confirmedBookings"]++;

        }

        if($row["status"]=="Pending"){

            $stats["pendingBookings"]++;

        }

        if($row["status"]=="Cancelled"){

            $stats["cancelledBookings"]++;

        }

        $stats["totalRevenue"] += $row["gross_total"];

        $stats["balanceDue"] += $row["balance_due"];

        /*
        |--------------------------------------------------------------------------
        | Status Badge
        |--------------------------------------------------------------------------
        */

        $status='';

        switch($row["status"]){

            case "Confirmed":

                $status='<span class="status status-confirmed">Confirmed</span>';

            break;

            case "Completed":

                $status='<span class="status status-completed">Completed</span>';

            break;

            case "Cancelled":

                $status='<span class="status status-cancelled">Cancelled</span>';

            break;

            case "Ticketed":

                $status='<span class="status status-ticketed">Ticketed</span>';

            break;

            default:

                $status='<span class="status status-pending">Pending</span>';

        }

        /*
        |--------------------------------------------------------------------------
        | Actions
        |--------------------------------------------------------------------------
        */

        $actions='

        <button

            class="action-btn view-btn btnViewBooking"

            data-id="'.$row["id"].'">

            <i class="fa fa-eye"></i>

        </button>

        <button

            class="action-btn edit-btn btnEditBooking"

            data-id="'.$row["id"].'">

            <i class="fa fa-edit"></i>

        </button>

        <button

            class="action-btn invoice-btn btnInvoice"

            data-id="'.$row["id"].'">

            <i class="fa fa-file-invoice"></i>

        </button>

        <button

            class="action-btn delete-btn btnDeleteBooking"

            data-id="'.$row["id"].'">

            <i class="fa fa-trash"></i>

        </button>

        ';

        /*
        |--------------------------------------------------------------------------
        | Push Row
        |--------------------------------------------------------------------------
        */

        $data[]=[

            "id"=>$row["id"],

            "invoice_no"=>$row["invoice_no"],

            "client"=>htmlspecialchars($row["client_name"]),

            "travel_date"=>$row["travel_date"],

            "destination"=>$row["destination"],

            "agent"=>htmlspecialchars($row["agent_name"]),

            "project"=>htmlspecialchars($row["project_name"]),

            "status"=>$status,

            "gross_total"=>"£ ".number_format($row["gross_total"],2),

            "received"=>"£ ".number_format($row["total_received"],2),

            "balance"=>"£ ".number_format($row["balance_due"],2),

            "actions"=>$actions

        ];

    }

    jsonResponse(

        true,

        "",

        [

            "stats"=>$stats,

            "data"=>$data

        ]

    );

}catch(Exception $e){

    jsonResponse(

        false,

        $e->getMessage()

    );

}