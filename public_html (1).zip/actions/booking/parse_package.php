<?php

require_once "../../includes/functions.php";

header("Content-Type: application/json");

try{

    if(empty($_POST['package'])){

        jsonResponse(false,"Package text is empty.");

        exit;

    }

    $text = trim($_POST['package']);

    $summary = [];

    $hotels = [];

    $transport = [];

    $products = [];

    /*
    ==========================================================
    TITLE
    ==========================================================
    */

    if(preg_match('/✨\s*(.*?)\s*✨/',$text,$m)){

        $summary["title"]=trim($m[1]);

    }

    /*
    ==========================================================
    DEPARTURE / RETURN
    ==========================================================
    */

    if(

        preg_match(

            '/Departure Date:\s*(.*?)\|\s*Return Date:\s*(.*)/',

            $text,

            $m

        )

    ){

        $summary["departure"]=convertDate($m[1]);

        $summary["return"]=convertDate($m[2]);

    }

    /*
    ==========================================================
    BAGGAGE
    ==========================================================
    */

    if(preg_match('/Baggage\s*([0-9A-Z ]+)/i',$text,$m)){

        $summary["baggage"]=trim($m[1]);

    }

    /*
    ==========================================================
    HAND CARRY
    ==========================================================
    */

    if(preg_match('/Hand\s*carry\s*([0-9A-Z ]+)/i',$text,$m)){

        $summary["hand_carry"]=trim($m[1]);

    }

    /*
    ==========================================================
    VISA
    ==========================================================
    */

    if(preg_match('/Visa:\s*(.*)/i',$text,$m)){

        $summary["visa"]=trim($m[1]);

        $products[]=[

            "name"=>trim($m[1])

        ];

    }

    /*
    ==========================================================
    TRANSPORT
    ==========================================================
    */

    if(

        preg_match(

            '/Private Transport:\s*(.*)/i',

            $text,

            $m

        )

    ){

        $summary["transport"]=trim($m[1]);

        $transport[]=[

            "vehicle"=>"Car",

            "journey"=>trim($m[1]),

            "vehicles"=>1,

            "pickup_date"=>$summary["departure"],

            "pickup_time"=>"",

            "notes"=>""

        ];

    }

    /*
    ==========================================================
    PRICE
    ==========================================================
    */

    if(

        preg_match(

            '/£([0-9]+)/',

            $text,

            $m

        )

    ){

        $summary["price"]=$m[1];

    }

    /*
    ==========================================================
    MAKKAH HOTEL
    ==========================================================
    */

    if(

        preg_match(

'/MAKKAH.*?Property:\s*(.*?)\s*Room Type:\s*(.*?)\s*Meal Plan:\s*(.*?)\s*Check In:\s*(.*?)\s*Check Out:\s*(.*?)\s*([0-9]+)\s*Nights/is',

            $text,

            $m

        )

    ){

        $hotels[]=[

            "city"=>"MAKKAH",

            "hotel"=>$m[1],

            "room_type"=>cleanRoom($m[2]),

            "rooms"=>roomCount($m[2]),

            "meal"=>mealShort($m[3]),

            "view"=>"",

            "checkin"=>convertDate($m[4]),

            "checkout"=>convertDate($m[5]),

            "nights"=>$m[6],

            "reservation"=>""

        ];

    }

    /*
    ==========================================================
    MADINAH HOTEL
    ==========================================================
    */

    if(

        preg_match(

'/MADINAH.*?Property:\s*(.*?)\s*Room Type:\s*(.*?)\s*Meal Plan:\s*(.*?)\s*Check In:\s*(.*?)\s*Check Out:\s*(.*?)\s*([0-9]+)\s*Nights/is',

            $text,

            $m

        )

    ){

        $hotels[]=[

            "city"=>"MADINAH",

            "hotel"=>$m[1],

            "room_type"=>cleanRoom($m[2]),

            "rooms"=>roomCount($m[2]),

            "meal"=>mealShort($m[3]),

            "view"=>"",

            "checkin"=>convertDate($m[4]),

            "checkout"=>convertDate($m[5]),

            "nights"=>$m[6],

            "reservation"=>""

        ];

    }

    jsonResponse(

        true,

        "",

        [

            "summary"=>$summary,

            "hotels"=>$hotels,

            "transport"=>$transport,

            "products"=>$products

        ]

    );

}catch(Exception $e){

    jsonResponse(false,$e->getMessage());

}

/*==========================================================*/

function convertDate($date){

    $time=strtotime(trim($date));

    return $time ? date("Y-m-d",$time) : "";

}

function roomCount($room){

    if(preg_match('/([0-9]+)/',$room,$m)){

        return $m[1];

    }

    return 1;

}

function cleanRoom($room){

    return preg_replace('/^[0-9]+x\s*/i','',$room);

}

function mealShort($meal){

    $meal=strtolower(trim($meal));

    if(str_contains($meal,"room")) return "R/O";

    if(str_contains($meal,"breakfast")) return "B/B";

    if(str_contains($meal,"half")) return "H/B";

    if(str_contains($meal,"full")) return "F/B";

    return "";

}