<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../includes/db.php';

try {

    /*
    |--------------------------------------------------------------------------
    | GET LOGGED-IN AGENT ID
    |--------------------------------------------------------------------------
    */

    $agentId = 0;

    if (!empty($_SESSION['agent_id'])) {

        $agentId = (int) $_SESSION['agent_id'];

    } elseif (!empty($_SESSION['user_id'])) {

        $agentId = (int) $_SESSION['user_id'];

    } elseif (!empty($_SESSION['id'])) {

        $agentId = (int) $_SESSION['id'];
    }


    if ($agentId <= 0) {

        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Your session has expired. Please login again.',
            'data'    => []
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | GET CURRENT USER
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            role,
            default_project_id,
            is_active
        FROM agents
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $agentId
    ]);

    $agent = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$agent) {

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' => 'Logged-in agent was not found.',
            'data'    => []
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | CHECK ACTIVE
    |--------------------------------------------------------------------------
    */

    if ((int) $agent['is_active'] !== 1) {

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' => 'Your account is inactive.',
            'data'    => []
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | ROLE
    |--------------------------------------------------------------------------
    */

    $role = strtolower(
        trim(
            (string) ($agent['role'] ?? 'agent')
        )
    );


    /*
    |--------------------------------------------------------------------------
    | ADMIN / MANAGER
    |--------------------------------------------------------------------------
    |
    | Admin and Manager can see ALL active projects.
    |
    */

    if (
        in_array(
            $role,
            [
                'admin',
                'administrator',
                'manager'
            ],
            true
        )
    ) {

        $stmt = $pdo->query("
            SELECT
                id,
                project_name,
                project_code,
                status
            FROM projects
            WHERE status = 'active'
            ORDER BY project_name ASC
        ");

        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

    }

    /*
    |--------------------------------------------------------------------------
    | TEAM LEAD
    |--------------------------------------------------------------------------
    |
    | Only projects assigned to this Team Lead are shown.
    | A Team Lead's booking visibility is then restricted by the booking
    | endpoint to this same project set and to agents on their team.
    |
    */
    elseif ($role === 'teamlead') {

        $stmt = $pdo->prepare("
            SELECT DISTINCT
                p.id,
                p.project_name,
                p.project_code,
                p.status
            FROM projects p

            INNER JOIN agent_projects ap
                ON ap.project_id = p.id
               AND ap.agent_id = ?

            WHERE p.status = 'active'

            ORDER BY p.project_name ASC
        ");

        $stmt->execute([$agentId]);

        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | AGENT
    |--------------------------------------------------------------------------
    |
    | Only projects assigned to the logged-in Agent are shown.
    | default_project_id is supported as a fallback because the current
    | CRM stores that assignment in addition to agent_projects.
    |
    */
    elseif ($role === 'agent') {

        $stmt = $pdo->prepare("
            SELECT DISTINCT
                p.id,
                p.project_name,
                p.project_code,
                p.status
            FROM projects p

            LEFT JOIN agent_projects ap
                ON ap.project_id = p.id
               AND ap.agent_id = ?

            WHERE
                p.status = 'active'
                AND (
                    ap.agent_id IS NOT NULL
                    OR p.id = ?
                )

            ORDER BY p.project_name ASC
        ");

        $stmt->execute([
            $agentId,
            (int) ($agent['default_project_id'] ?? 0)
        ]);

        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    else {

        $projects = [];
    }

    /*
    |--------------------------------------------------------------------------
    | RESPONSE
    |--------------------------------------------------------------------------
    */

    echo json_encode([
        'success' => true,
        'message' => 'Projects loaded successfully.',
        'data'    => $projects
    ]);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to load projects.',
        'data'    => []
    ]);
}