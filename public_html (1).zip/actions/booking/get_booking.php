<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/permissions.php';

header('Content-Type: application/json; charset=utf-8');

try {

    $bookingId = filter_input(
        INPUT_GET,
        'booking_id',
        FILTER_VALIDATE_INT
    );

    if (!$bookingId) {

        throw new Exception(
            'Invalid booking ID.'
        );

    }


    /*
     * =====================================================
     * BOOKING
     * =====================================================
     */

    $uid = (int) authId();
    $role = strtolower((string) authRole());
    $where = 'b.id = ?';
    $params = [$bookingId];

    if ($role === 'agent') {
        $where .= ' AND b.agent_id = ?';
        $params[] = $uid;
    } elseif ($role === 'teamlead') {
        $agentRow = Database::selectOne('SELECT default_project_id FROM agents WHERE id=? LIMIT 1', [$uid]);
        $defaultProjectId = (int)($agentRow['default_project_id'] ?? authProject() ?? 0);
        $projectCheck = $defaultProjectId > 0 ? '(b.project_id = ? OR EXISTS (SELECT 1 FROM agent_projects ap WHERE ap.agent_id = ? AND ap.project_id = b.project_id))' : 'EXISTS (SELECT 1 FROM agent_projects ap WHERE ap.agent_id = ? AND ap.project_id = b.project_id)';
        if ($defaultProjectId > 0) { $params[] = $defaultProjectId; }
        $params[] = $uid;
        $teamAgentIds = array_values(array_unique(array_merge([$uid], teamAgentIds($uid))));
        if (!$teamAgentIds) throw new Exception('You are not authorized to view this booking.');
        $ph = implode(',', array_fill(0, count($teamAgentIds), '?'));
        $where .= " AND $projectCheck AND b.agent_id IN ($ph)";
        $params = array_merge($params, $teamAgentIds);
    } elseif (!in_array($role, ['admin','manager','administrator'], true)) {
        throw new Exception('You are not authorized to view this booking.');
    }

    $stmt = $pdo->prepare("SELECT b.*, p.project_name, p.project_code FROM bookings b LEFT JOIN projects p ON p.id = b.project_id WHERE $where LIMIT 1");
    $stmt->execute($params);

    $booking = $stmt->fetch(
        PDO::FETCH_ASSOC
    );


    if (!$booking) {

        throw new Exception(
            'Booking not found.'
        );

    }


    /*
     * =====================================================
     * PASSENGERS
     * =====================================================
     *
     * Change table name below if your
     * passenger table has another name.
     */

    $passengerStmt = $pdo->prepare("
        SELECT *
        FROM booking_passengers
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $passengerStmt->execute([
        $bookingId
    ]);

    $booking['passengers'] =
        $passengerStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * FLIGHTS
     * =====================================================
     */

    $flightStmt = $pdo->prepare("
        SELECT *
        FROM booking_flights
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $flightStmt->execute([
        $bookingId
    ]);

    $booking['flights'] =
        $flightStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * HOTELS
     * =====================================================
     */

    $hotelStmt = $pdo->prepare("
        SELECT *
        FROM booking_hotels
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $hotelStmt->execute([
        $bookingId
    ]);

    $booking['hotels'] =
        $hotelStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * TRANSPORT
     * =====================================================
     */

    $transportStmt = $pdo->prepare("
        SELECT *
        FROM booking_transports
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $transportStmt->execute([
        $bookingId
    ]);

    $booking['transports'] =
        $transportStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * PRODUCTS
     * =====================================================
     */

    $productStmt = $pdo->prepare("
        SELECT *
        FROM booking_products
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $productStmt->execute([
        $bookingId
    ]);

    $booking['products'] =
        $productStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * COSTS
     * =====================================================
     */

    $costStmt = $pdo->prepare("
        SELECT *
        FROM booking_cost_rows
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $costStmt->execute([
        $bookingId
    ]);

    $booking['costs'] =
        $costStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * PAYMENTS
     * =====================================================
     */

    $paymentStmt = $pdo->prepare("
        SELECT *
        FROM booking_payments
        WHERE booking_id = ?
        ORDER BY id ASC
    ");

    $paymentStmt->execute([
        $bookingId
    ]);

    $booking['payments'] =
        $paymentStmt->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * =====================================================
     * SUCCESS
     * =====================================================
     */

    echo json_encode([
        'success' => true,
        'data' => $booking
    ]);

}
catch (
    Throwable $e
) {

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);

}