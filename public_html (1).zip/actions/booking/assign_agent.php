<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/auth.php'; requireLogin(); require_once __DIR__.'/../../includes/db.php'; require_once __DIR__.'/../../includes/permissions.php';
header('Content-Type: application/json; charset=utf-8');
function aj(bool $ok,string $msg,array $data=[],int $code=200): never {http_response_code($code);echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE);exit;}
try{
 $uid=(int)authId(); $role=strtolower((string)authRole());
 if(!in_array($role,['admin','manager','administrator','teamlead'],true)) aj(false,'You are not authorized to assign bookings.',[],403);
 $bookingId=(int)($_POST['booking_id']??0); $agentId=(int)($_POST['agent_id']??0); if($bookingId<=0||$agentId<=0) aj(false,'Booking and agent are required.',[],400);
 $b=Database::selectOne('SELECT * FROM bookings WHERE id=?',[$bookingId]); if(!$b) aj(false,'Booking not found.',[],404);
 $target=Database::selectOne("SELECT id,name,role,is_active,default_project_id FROM agents WHERE id=? LIMIT 1",[$agentId]); if(!$target||!(int)$target['is_active']||strtolower($target['role'])!=='agent') aj(false,'Selected agent is invalid or inactive.',[],400);
 $projectId=(int)$b['project_id'];
 $targetAllowed=(bool)Database::selectOne('SELECT 1 FROM agent_projects WHERE agent_id=? AND project_id=? LIMIT 1',[$agentId,$projectId]);
 if((int)($target['default_project_id']??0)===$projectId) $targetAllowed=true;
 if(!$targetAllowed) aj(false,'Selected agent is not assigned to this booking project.',[],403);
 if($role==='teamlead'){
   $ids=array_values(array_unique(teamAgentIds($uid))); if(!in_array($agentId,$ids,true)) aj(false,'You can only assign bookings to agents in your team.',[],403);
   $canProject=(bool)Database::selectOne('SELECT 1 FROM agent_projects WHERE agent_id=? AND project_id=? LIMIT 1',[$uid,$projectId]);
   $lead=Database::selectOne('SELECT default_project_id FROM agents WHERE id=?',[$uid]); if((int)($lead['default_project_id']??0)===$projectId)$canProject=true;
   if(!$canProject) aj(false,'You are not authorized for this booking project.',[],403);
 }
 $pdo->prepare('UPDATE bookings SET agent_id=?, updated_by=? WHERE id=?')->execute([$agentId,$uid,$bookingId]);
 aj(true,'Booking assigned successfully.',['agent_id'=>$agentId,'agent_name'=>$target['name']]);
}catch(Throwable $e){aj(false,$e->getMessage()?:'Assignment failed.',[],500);}
