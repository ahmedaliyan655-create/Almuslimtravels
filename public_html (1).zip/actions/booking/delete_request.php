<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/auth.php'; requireLogin(); require_once __DIR__.'/../../includes/db.php'; require_once __DIR__.'/../../includes/permissions.php'; require_once __DIR__.'/../../includes/notifications.php';
header('Content-Type: application/json; charset=utf-8');
function jr2(bool $ok,string $msg,array $data=[],int $code=200): never {http_response_code($code);echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE);exit;}
try{
 $pdo->exec("CREATE TABLE IF NOT EXISTS booking_delete_requests (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, requester_id INT UNSIGNED NOT NULL, status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending', requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_by INT UNSIGNED NULL, reviewed_at DATETIME NULL, rejection_reason TEXT NULL, UNIQUE KEY uq_pending_delete (booking_id, requester_id, status), KEY idx_delete_status(status), KEY idx_delete_booking(booking_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
 $uid=(int)authId();$role=strtolower((string)authRole());$action=strtolower((string)($_POST['action']??$_GET['action']??''));$id=(int)($_POST['id']??$_GET['id']??0);
 // The alerts page posts action=status. Keep review handling explicit and backwards-compatible.
 if($action==='review') $action='status';
 if($action==='list'){
   if($role==='agent') $rows=Database::select("SELECT r.*,b.invoice_no,b.client_name,a.name requester FROM booking_delete_requests r JOIN bookings b ON b.id=r.booking_id JOIN agents a ON a.id=r.requester_id WHERE r.requester_id=? ORDER BY r.id DESC",[$uid]);
   elseif(in_array($role,['admin','manager','administrator'],true)) $rows=Database::select("SELECT r.*,b.invoice_no,b.client_name,a.name requester FROM booking_delete_requests r JOIN bookings b ON b.id=r.booking_id JOIN agents a ON a.id=r.requester_id WHERE r.status='Pending' ORDER BY r.id DESC");
   elseif($role==='teamlead') { $ids=array_values(array_unique(array_merge([$uid],teamAgentIds($uid)))); $ph=implode(',',array_fill(0,count($ids),'?')); $rows=$ids?Database::select("SELECT r.*,b.invoice_no,b.client_name,a.name requester FROM booking_delete_requests r JOIN bookings b ON b.id=r.booking_id JOIN agents a ON a.id=r.requester_id WHERE r.status='Pending' AND b.agent_id IN ($ph) ORDER BY r.id DESC",$ids):[]; }
   else $rows=[];
   jr2(true,'',$rows);
 }
 if(!in_array($role,['admin','manager','administrator','teamlead'],true)) jr2(false,'You are not authorized to review deletion requests.',[],403);
 $status=ucfirst(strtolower((string)($_POST['status']??''))); if(!in_array($status,['Approved','Rejected'],true)) jr2(false,'Invalid review status.',[],400);
 $r=Database::selectOne("SELECT r.*,b.agent_id FROM booking_delete_requests r JOIN bookings b ON b.id=r.booking_id WHERE r.id=? AND r.status='Pending'",[$id]); if(!$r) jr2(false,'Pending deletion request not found.',[],404);
 if($role==='teamlead' && !in_array((int)$r['agent_id'],array_values(array_unique(array_merge([$uid],teamAgentIds($uid)))),true)) jr2(false,'You are not authorized to review this request.',[],403);
 $reason=trim((string)($_POST['reason']??''));
 $pdo->beginTransaction(); $pdo->prepare("UPDATE booking_delete_requests SET status=?,reviewed_by=?,reviewed_at=NOW(),rejection_reason=? WHERE id=? AND status='Pending'")->execute([$status,$uid,$status==='Rejected'?$reason:null,$id]); $pdo->commit();
 notifyBookingApprovalReviewed((int)$r['booking_id'], $id, (int)$r['requester_id'], 'delete', $status, $uid, $reason);
 jr2(true,$status==='Approved'?'Deletion request approved. The agent can now delete the booking.':'Deletion request rejected. The agent will see that the request was denied.');
}catch(Throwable $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();jr2(false,$e->getMessage()?:'Review failed.',[],500);}
