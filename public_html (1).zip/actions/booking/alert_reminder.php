<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/auth.php'; requireLogin(); require_once __DIR__.'/../../includes/db.php'; require_once __DIR__.'/../../includes/permissions.php';
header('Content-Type: application/json; charset=utf-8');
function arj(bool $ok,string $msg='',array $data=[],int $code=200): never {http_response_code($code);echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE);exit;}
function visibleBookingIds(int $uid,string $role,?int $project=null,?int $agent=null): array {
 global $pdo;
 $where='1=1';$params=[];
 if($role==='agent'){$where='b.agent_id=?';$params[]=$uid;}
 elseif($role==='teamlead'){$ids=array_values(array_unique(array_merge([$uid],teamAgentIds($uid))));if(!$ids)return []; $ph=implode(',',array_fill(0,count($ids),'?'));$where="b.agent_id IN ($ph)";$params=$ids; if($project){$where.=' AND b.project_id=?';$params[]=$project;}}
 elseif(in_array($role,['admin','manager','administrator'],true)){if($project){$where.=' AND b.project_id=?';$params[]=$project;}if($agent){$where.=' AND b.agent_id=?';$params[]=$agent;}}
 else return [];
 $rows=Database::select("SELECT b.id,b.invoice_no,b.client_name,b.travel_date,b.project_id,b.agent_id,a.name agent_name,p.project_name FROM bookings b LEFT JOIN agents a ON a.id=b.agent_id LEFT JOIN projects p ON p.id=b.project_id WHERE $where ORDER BY b.travel_date DESC,b.id DESC",$params);return $rows;
}
try{
 $uid=(int)authId();$role=strtolower((string)authRole());$action=strtolower((string)($_POST['action']??$_GET['action']??'list'));
 $pdo->exec("CREATE TABLE IF NOT EXISTS booking_alerts (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, created_by INT UNSIGNED NOT NULL, alert_date DATE NOT NULL, seen_at DATETIME NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_alert_date(alert_date,seen_at), KEY idx_alert_booking(booking_id), KEY idx_alert_creator(created_by)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
 if($action==='bookings'){
  $project=(int)($_GET['project_id']??0);$agent=(int)($_GET['agent_id']??0);$rows=visibleBookingIds($uid,$role,$project?:null,$agent?:null);arj(true,'',$rows);
 }
 if($action==='save'){
  $bookingId=(int)($_POST['booking_id']??0);$date=trim((string)($_POST['alert_date']??''));
  if($bookingId<=0||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))arj(false,'Booking and a valid alert date are required.',[],400);
  $visible=visibleBookingIds($uid,$role);$ok=false;foreach($visible as $b){if((int)$b['id']===$bookingId){$ok=true;break;}}if(!$ok)arj(false,'You are not authorized to set an alert for this booking.',[],403);
  $pdo->prepare('INSERT INTO booking_alerts (booking_id,created_by,alert_date) VALUES (?,?,?)')->execute([$bookingId,$uid,$date]); arj(true,'Booking alert saved.');
 }
 if($action==='list'){
  $rows=Database::select("SELECT ba.id,ba.booking_id,ba.alert_date,ba.seen_at,b.invoice_no,b.client_name,b.travel_date,p.project_name,a.name agent_name FROM booking_alerts ba JOIN bookings b ON b.id=ba.booking_id LEFT JOIN projects p ON p.id=b.project_id LEFT JOIN agents a ON a.id=b.agent_id WHERE ba.created_by=? ORDER BY ba.alert_date ASC,ba.id DESC",[$uid]);
  $due=Database::select("SELECT ba.id,ba.booking_id,ba.alert_date,b.invoice_no,b.client_name,b.travel_date,p.project_name FROM booking_alerts ba JOIN bookings b ON b.id=ba.booking_id LEFT JOIN projects p ON p.id=b.project_id WHERE ba.created_by=? AND ba.alert_date<=CURDATE() AND ba.seen_at IS NULL ORDER BY ba.alert_date ASC,ba.id ASC",[$uid]); arj(true,'',['alerts'=>$rows,'due'=>$due]);
 }
 if($action==='seen'){$id=(int)($_POST['id']??0);$pdo->prepare('UPDATE booking_alerts SET seen_at=NOW() WHERE id=? AND created_by=? AND seen_at IS NULL')->execute([$id,$uid]);arj(true,'Alert marked as seen.');}
 arj(false,'Invalid action.',[],400);
}catch(Throwable $e){arj(false,$e->getMessage()?:'Alert operation failed.',[],500);}
