<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../includes/db.php';

// Lightweight compatibility migration for existing CRM installations.
try {
    $pdo->exec("ALTER TABLE booking_flights ADD COLUMN supplier VARCHAR(255) NULL AFTER baggage");
} catch (Throwable $e) {}
try {
    $pdo->exec("ALTER TABLE booking_passengers ADD COLUMN visa_supplier VARCHAR(255) NULL AFTER visa_notes");
} catch (Throwable $e) {}
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS booking_edit_requests (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, requester_id INT UNSIGNED NOT NULL, status ENUM('Pending','Approved','Rejected','Used') NOT NULL DEFAULT 'Pending', requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_by INT UNSIGNED NULL, reviewed_at DATETIME NULL, rejection_reason TEXT NULL, used_at DATETIME NULL, KEY idx_edit_status(status), KEY idx_edit_booking(booking_id), KEY idx_edit_requester(requester_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
} catch (Throwable $e) {}

// Payment compatibility migrations for existing installations.
try {
    $pdo->exec("ALTER TABLE booking_payments ADD COLUMN profile_id VARCHAR(100) NULL AFTER receipt_id");
} catch (Throwable $e) {}
try {
    $pdo->exec("ALTER TABLE booking_payments ADD COLUMN payer_name VARCHAR(150) NULL AFTER profile_id");
} catch (Throwable $e) {}
try {
    $pdo->exec("ALTER TABLE booking_passengers MODIFY title ENUM('MR','MRS','MS','MISS','CHILD','DR','PROF','MST','INFANT') NOT NULL DEFAULT 'MR'");
} catch (Throwable $e) {}
try {
    $pdo->exec("ALTER TABLE booking_products ADD COLUMN supplier VARCHAR(255) NULL AFTER product_type");
} catch (Throwable $e) {}


/*
|--------------------------------------------------------------------------
| JSON RESPONSE HELPER
|--------------------------------------------------------------------------
|
| This was missing from your current save-booking.php.
|
*/

function jsonResponse(
    bool $success,
    string $message = '',
    array $data = [],
    int $statusCode = 200
): never {

    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');


    echo json_encode(
        [
            'success' => $success,
            'message' => $message,
            'data'    => $data
        ],
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| POST STRING
|--------------------------------------------------------------------------
*/

function postString(
    string $key,
    string $default = ''
): string {

    if (!isset($_POST[$key])) {
        return $default;
    }

    if (is_array($_POST[$key])) {
        return $default;
    }

    return trim(
        (string) $_POST[$key]
    );
}


/*
|--------------------------------------------------------------------------
| POST MONEY
|--------------------------------------------------------------------------
*/

function postMoney(
    string $key,
    float $default = 0.00
): float {

    if (!isset($_POST[$key])) {
        return $default;
    }

    if (is_array($_POST[$key])) {
        return $default;
    }

    $value = str_replace(
        [',', '£', '$'],
        '',
        (string) $_POST[$key]
    );

    if ($value === '' || !is_numeric($value)) {
        return $default;
    }

    return max(
        0,
        round((float) $value, 2)
    );
}


/*
|--------------------------------------------------------------------------
| TEAM LEAD AGENT IDS
|--------------------------------------------------------------------------
|
| Returns all agent IDs that belong to teams led by the given team lead.
| Supports both team_members and agents.team_lead_id so existing CRM
| assignments continue to work.
|
*/
function teamAgentIds(int $teamLeadId): array
{
    global $pdo;

    if ($teamLeadId <= 0) {
        return [];
    }

    $ids = [];

    // Direct assignments through agents.team_lead_id.
    $stmt = $pdo->prepare(
        "SELECT id FROM agents WHERE team_lead_id = ? AND id <> ?"
    );
    $stmt->execute([$teamLeadId, $teamLeadId]);

    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $id = (int) $id;
        if ($id > 0) {
            $ids[] = $id;
        }
    }

    // Team assignments through teams.team_lead_id + team_members.
    $stmt = $pdo->prepare(
        "SELECT id FROM teams WHERE team_lead_id = ?"
    );
    $stmt->execute([$teamLeadId]);

    $teamIds = array_map(
        'intval',
        $stmt->fetchAll(PDO::FETCH_COLUMN)
    );

    if (!empty($teamIds)) {
        $placeholders = implode(
            ',',
            array_fill(0, count($teamIds), '?')
        );

        $stmt = $pdo->prepare(
            "SELECT agent_id
             FROM team_members
             WHERE team_id IN ($placeholders)"
        );
        $stmt->execute($teamIds);

        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $id = (int) $id;
            if ($id > 0 && $id !== $teamLeadId) {
                $ids[] = $id;
            }
        }
    }

    return array_values(array_unique($ids));
}


/*
|--------------------------------------------------------------------------
| NULLABLE DATE
|--------------------------------------------------------------------------
*/

function nullableDate(
    ?string $value
): ?string {

    if ($value === null) {
        return null;
    }

    $value = trim($value);

    if ($value === '') {
        return null;
    }

    $date = DateTime::createFromFormat(
        'Y-m-d',
        $value
    );

    if (
        !$date ||
        $date->format('Y-m-d') !== $value
    ) {
        return null;
    }

    return $value;
}


/*
|--------------------------------------------------------------------------
| NORMALIZE TITLE
|--------------------------------------------------------------------------
*/

function normalizeTitle(
    string $title
): string {

    $title = strtoupper(
        trim($title)
    );

    $map = [
        'MR'    => 'Mr',
        'MRS'   => 'Mrs',
        'MS'    => 'Ms',
        'MISS'  => 'Miss',
        'CHILD' => 'Child',
        'DR'    => 'Dr',
        'PROF'  => 'Prof',
        'MST'   => 'Mst',
        'CHD'   => 'Child',
        'INF'   => 'Infant'
    ];

    return $map[$title] ?? 'Mr';
}


/*
|--------------------------------------------------------------------------
| NORMALIZE MEAL
|--------------------------------------------------------------------------
*/

function normalizeMeal(
    string $meal
): string {

    $meal = strtoupper(
        trim($meal)
    );

    $map = [
        'RO' => 'R/O',
        'R/O' => 'R/O',
        'BB' => 'B/B',
        'B/B' => 'B/B',
        'HB' => 'H/B',
        'H/B' => 'H/B',
        'FB' => 'F/B',
        'F/B' => 'F/B'
    ];

    return $map[$meal] ?? 'R/O';
}


/*
|--------------------------------------------------------------------------
| NORMALIZE PAYMENT METHOD
|--------------------------------------------------------------------------
*/

function normalizePaymentMethod(
    string $method
): string {

    $method = trim($method);

    /*
     * IMPORTANT:
     * These values must match the booking_payments.method ENUM
     * used by the database.
     */
    $allowed = [
        'Natwest Bank',
        'HBL Pakistan',
        'E Payment',
        'London Office Card Merchant',
        'Cash - London Office',
        'barclays Bank',
        'Revolut Bank'
    ];

    /*
     * Match case-insensitively, but always return the exact
     * database/UI spelling defined above.
     */
    foreach ($allowed as $allowedMethod) {
        if (strcasecmp($method, $allowedMethod) === 0) {
            return $allowedMethod;
        }
    }

    /*
     * Backward compatibility for old values that may still be
     * submitted by an older browser/cache.
     */
    $legacyMap = [
        'BANK PAY' => 'Natwest Bank',
        'BANK' => 'Natwest Bank',
        'BANK TRANSFER' => 'Natwest Bank',
        'ONLINE TRANSFER' => 'E Payment',
        'ONLINE' => 'E Payment',
        'ONLINE PAY' => 'E Payment',
        'CARD' => 'London Office Card Merchant',
        'CASH' => 'Cash - London Office',
        'CHEQUE' => 'Natwest Bank',
        'CHECK' => 'Natwest Bank'
    ];

    $legacyKey = strtoupper($method);

    return $legacyMap[$legacyKey] ?? 'Natwest Bank';
}


/*
|--------------------------------------------------------------------------
| NORMALIZE CREDIT / DEBIT
|--------------------------------------------------------------------------
*/

function normalizeCreditDebit(
    string $value
): string {

    $value = strtoupper(
        trim($value)
    );

    $allowed = [
        'DEBIT',
        'CREDIT'
    ];

    return in_array(
        $value,
        $allowed,
        true
    )
        ? $value
        : 'DEBIT';
}
/*
|--------------------------------------------------------------------------
| PAYMENT ATTACHMENT UPLOAD
|--------------------------------------------------------------------------
*/

function savePaymentAttachment(
    int $index,
    array &$uploadedFiles
): ?string {

    if (
        !isset($_FILES['payments']) ||
        !isset($_FILES['payments']['error']) ||
        !isset($_FILES['payments']['error'][$index]) ||
        !is_array($_FILES['payments']['error'][$index])
    ) {
        return null;
    }

    $error = (int) (
        $_FILES['payments']['error'][$index]['attachment']
        ?? UPLOAD_ERR_NO_FILE
    );

    if ($error === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Payment attachment upload failed.');
    }

    $tmpName = $_FILES['payments']['tmp_name'][$index]['attachment'] ?? '';
    $size = (int) ($_FILES['payments']['size'][$index]['attachment'] ?? 0);
    $originalName = (string) ($_FILES['payments']['name'][$index]['attachment'] ?? '');

    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        throw new RuntimeException('Invalid payment attachment upload.');
    }

    if ($size <= 0 || $size > 5 * 1024 * 1024) {
        throw new RuntimeException('Payment attachment must be smaller than 5 MB.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmpName);

    $allowed = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Payment attachment must be PDF, JPG, PNG, or WEBP.');
    }

    $uploadDir = __DIR__ . '/../../uploads/payment_attachments';

    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0750, true)) {
        throw new RuntimeException('Unable to create payment attachment directory.');
    }

    if (!is_writable($uploadDir)) {
        throw new RuntimeException('Payment attachment directory is not writable.');
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    $destination = $uploadDir . DIRECTORY_SEPARATOR . $filename;

    if (!move_uploaded_file($tmpName, $destination)) {
        throw new RuntimeException('Unable to save payment attachment.');
    }

    @chmod($destination, 0640);
    $uploadedFiles[] = $destination;

    return 'uploads/payment_attachments/' . $filename;
}


/*
|--------------------------------------------------------------------------
| ONLY POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    jsonResponse(
        false,
        'Invalid request method.',
        [],
        405
    );
}


/* CREATE = booking_id 0, EDIT = existing booking_id */
$editBookingId = 0;
if (isset($_POST['booking_id']) && !is_array($_POST['booking_id'])) {
    $editBookingId = max(0, (int) $_POST['booking_id']);
}

/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| Your project uses agents.
|
| We first try:
|
| $_SESSION['agent_id']
|
| Then:
|
| $_SESSION['user_id']
|
| Then:
|
| $_SESSION['id']
|
*/

$agentId = 0;

if (!empty($_SESSION['agent_id'])) {

    $agentId = (int) $_SESSION['agent_id'];

} elseif (!empty($_SESSION['user_id'])) {

    $agentId = (int) $_SESSION['user_id'];

} elseif (!empty($_SESSION['id'])) {

    $agentId = (int) $_SESSION['id'];
}


if ($agentId <= 0) {

    jsonResponse(
        false,
        'Your session has expired. Please login again.',
        [],
        401
    );
}


/*
|--------------------------------------------------------------------------
| VERIFY AGENT
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        id,
        agent_code,
        name,
        role,
        default_project_id,
        is_active
    FROM agents
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([
    $agentId
]);

$agent = $stmt->fetch();


if (!$agent) {

    jsonResponse(
        false,
        'Logged-in agent was not found.',
        [],
        403
    );
}


if ((int) $agent['is_active'] !== 1) {

    jsonResponse(
        false,
        'Your agent account is inactive.',
        [],
        403
    );
}


/*
|--------------------------------------------------------------------------
| PROJECT
|--------------------------------------------------------------------------
|
| We DO NOT trust project_id coming from the browser.
|
| First:
|   session project
|
| Second:
|   agent default project
|
| Third:
|   first project assigned to agent
|
*/

$projectId = 0;
$roleForProject = strtolower((string)($agent['role'] ?? 'agent'));
$isPrivilegedEdit = $editBookingId > 0 && in_array($roleForProject, ['admin','manager','administrator'], true);

/*
 * Admin/Manager/Administrator editing an existing booking must never
 * depend on their own assigned/default project. Preserve the booking's
 * existing project instead.
 */
if ($isPrivilegedEdit) {
    $stmt = $pdo->prepare('SELECT project_id FROM bookings WHERE id=? LIMIT 1');
    $stmt->execute([$editBookingId]);
    $projectId = (int)($stmt->fetchColumn() ?: 0);
} else {
    if (!empty($_SESSION['project_id'])) {
        $projectId = (int)$_SESSION['project_id'];
    }

    if ($projectId <= 0 && !empty($agent['default_project_id'])) {
        $projectId = (int)$agent['default_project_id'];
    }

    if ($projectId <= 0) {
        $stmt = $pdo->prepare('SELECT project_id FROM agent_projects WHERE agent_id=? ORDER BY id ASC LIMIT 1');
        $stmt->execute([$agentId]);
        $projectId = (int)($stmt->fetchColumn() ?: 0);
    }
}

if ($projectId <= 0) {

    jsonResponse(
        false,
        'No project is assigned to your account. Please assign a project first.',
        [],
        400
    );
}


/*
 * A session-selected project must belong to the authenticated agent.
 * The agent's default project is also trusted because it comes from the
 * authenticated agent record.
 */
if (!$isPrivilegedEdit && (int)($agent['default_project_id'] ?? 0) !== $projectId) {

    $stmt = $pdo->prepare("
        SELECT 1
        FROM agent_projects
        WHERE agent_id = ?
          AND project_id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $agentId,
        $projectId
    ]);

    if (!$stmt->fetchColumn()) {
        jsonResponse(
            false,
            'You are not authorized to create bookings for this project.',
            [],
            403
        );
    }
}


/*
|--------------------------------------------------------------------------
| VERIFY PROJECT
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT id, project_code
    FROM projects
    WHERE id = ?
      AND status = 'Active'
    LIMIT 1
");

$stmt->execute([
    $projectId
]);

if (!$stmt->fetch(PDO::FETCH_ASSOC)) {

    jsonResponse(
        false,
        'Selected project is invalid or inactive.',
        [],
        400
    );
}

$projectRow = Database::selectOne(
    "SELECT id, project_code FROM projects WHERE id = ? AND status = 'Active' LIMIT 1",
    [$projectId]
);
$projectCode = strtoupper(trim((string)($projectRow['project_code'] ?? '')));
if ($projectCode === '') {
    jsonResponse(false, 'Selected project does not have a project code. Please add a project code first.', [], 422);
}
if (strlen($projectCode) > 17) {
    jsonResponse(false, 'Project code is too long for the invoice number. Please use a code of 17 characters or fewer.', [], 422);
}


/*
|--------------------------------------------------------------------------
| BASIC BOOKING DATA
|--------------------------------------------------------------------------
*/

$invoiceNo = postString('invoice_no');

$invoiceDate = nullableDate(
    postString('invoice_date')
);

$dueDate = nullableDate(
    postString('due_date')
);

$gdsPnr = postString('pnr');

$airlinePnr = postString(
    'airline_pnr'
);

$travelDate = nullableDate(
    postString('travel_date')
);

$status = postString(
    'status',
    'New'
);

// IMPORTANT: editing an existing booking must never change its booking status.
// Hotel/flight service statuses are stored separately and can be updated independently.
if ($editBookingId > 0) {
    $existingStatusRow = Database::selectOne(
        'SELECT status FROM bookings WHERE id = ? LIMIT 1',
        [$editBookingId]
    );
    if ($existingStatusRow && isset($existingStatusRow['status'])) {
        $status = (string)$existingStatusRow['status'];
    }
}

$clientName = postString(
    'client_name'
);

$clientMobile = postString(
    'client_mobile'
);

$clientEmail = postString(
    'client_email'
);

if ($clientEmail !== '' && filter_var($clientEmail, FILTER_VALIDATE_EMAIL) === false) {
    jsonResponse(
        false,
        'Please enter a valid client email address.',
        [],
        422
    );
}



/*
|--------------------------------------------------------------------------
| VALIDATION
|--------------------------------------------------------------------------
*/

if ($clientName === '') {

    jsonResponse(
        false,
        'Client name is required.',
        [],
        422
    );
}


if ($invoiceDate === null) {

    /*
     * Your database requires invoice_date.
     * If the user leaves it empty, use today.
     */

    $invoiceDate = date('Y-m-d');
}


/*
|--------------------------------------------------------------------------
| STATUS NORMALIZATION
|--------------------------------------------------------------------------
|
| Your frontend currently has Pending.
|
| Your database enum does NOT have Pending.
|
| Therefore:
|
| Pending -> New
|
| until you decide to add Pending to the DB enum.
|
*/

$allowedStatuses = [
    'New',
    'Confirmed',
    'Departed',
    'In Makkah',
    'In Madinah',
    'Returning',
    'Completed',
    'Cancelled'
];


if ($status === 'Pending') {

    $status = 'New';
}


if (!in_array($status, $allowedStatuses, true)) {

    $status = 'New';
}


/*
|--------------------------------------------------------------------------
| BOOKING SOURCE
|--------------------------------------------------------------------------
|
| Can be supplied by your frontend later.
|
| Current modal does not have this field,
| so default is Manual.
|
*/

$bookingSource = postString(
    'booking_source',
    'Manual'
);


$allowedSources = [
    'Manual',
    'Sabre PNR',
    'Package Parser',
    'Import'
];


if (!in_array($bookingSource, $allowedSources, true)) {

    $bookingSource = 'Manual';
}


/*
|--------------------------------------------------------------------------
| BOOKING TYPE
|--------------------------------------------------------------------------
*/

$bookingType = postString(
    'booking_type'
);


/*
|--------------------------------------------------------------------------
| CHARGES
|--------------------------------------------------------------------------
*/

$atolCharges = postMoney(
    'atol_charges'
);

$iataCharges = postMoney(
    'iata_charges'
);

$discount = postMoney(
    'discount'
);


/*
|--------------------------------------------------------------------------
| NOTES
|--------------------------------------------------------------------------
*/

$notes = postString(
    'notes'
);


/*
|--------------------------------------------------------------------------
| ARRAYS
|--------------------------------------------------------------------------
*/

$passengers = $_POST['passengers'] ?? [];

$flights = $_POST['flights'] ?? [];

$hotels = $_POST['hotels'] ?? [];

$transports = $_POST['transport'] ?? [];

$products = $_POST['products'] ?? [];

$payments = $_POST['payments'] ?? [];


/*
|--------------------------------------------------------------------------
| COST ROWS
|--------------------------------------------------------------------------
|
| These fields don't have name="" attributes in your current HTML.
|
| Therefore our JavaScript sends them manually as:
|
| costs[]
|
*/

$costs = $_POST['costs'] ?? [];


/*
|--------------------------------------------------------------------------
| CALCULATE TOTALS SERVER-SIDE
|--------------------------------------------------------------------------
|
| NEVER trust:
|
| grossTotal
| payableTotal
| balanceTotal
|
| sent by JavaScript.
|
| We calculate them again here.
|
*/

$totalSelling = 0.00;

$totalNet = 0.00;


/*
|--------------------------------------------------------------------------
| COSTS VALIDATION + TOTALS
|--------------------------------------------------------------------------
*/

if (is_array($costs)) {

    foreach ($costs as $cost) {

        if (!is_array($cost)) {
            continue;
        }

        $quantity = max(
            0,
            (int) ($cost['quantity'] ?? 0)
        );

        $baseFare = max(
            0,
            round(
                (float) ($cost['base_fare'] ?? 0),
                2
            )
        );

        $tax = max(
            0,
            round(
                (float) ($cost['tax'] ?? 0),
                2
            )
        );

        $sellingPrice = max(
            0,
            round(
                (float) ($cost['selling_price'] ?? 0),
                2
            )
        );

        $totalNet += (
            ($baseFare + $tax)
            * $quantity
        );

        $totalSelling += (
            $sellingPrice
            * $quantity
        );
    }
}


/*
|--------------------------------------------------------------------------
| TOTALS
|--------------------------------------------------------------------------
|
| This follows your existing frontend calculation:
|
| Selling Total + ATOL + IATA = Gross
|
| Gross - Discount = Payable
|
| Your current VAT display is 0.00.
|
*/

$grossTotal =
    $totalSelling
    + $atolCharges
    + $iataCharges;


$payableTotal =
    max(
        0,
        $grossTotal - $discount
    );


/*
|--------------------------------------------------------------------------
| PAYMENT TOTAL
|--------------------------------------------------------------------------
*/

$totalReceived = 0.00;


if (is_array($payments)) {

    foreach ($payments as $payment) {

        if (!is_array($payment)) {
            continue;
        }

        $amount = max(
            0,
            round(
                (float) ($payment['amount'] ?? 0),
                2
            )
        );

        /*
         * Only actual payment amounts are counted.
         */

        if ($amount > 0) {

            $totalReceived += $amount;
        }
    }
}


$totalReceived = round(
    $totalReceived,
    2
);

if ($totalReceived > $payableTotal) {
    jsonResponse(
        false,
        'Payment received cannot be greater than the payable total.',
        [],
        422
    );
}



/*
|--------------------------------------------------------------------------
| BALANCE
|--------------------------------------------------------------------------
*/

$balanceDue = max(
    0,
    $payableTotal - $totalReceived
);


$grossTotal = round(
    $grossTotal,
    2
);

$balanceDue = round(
    $balanceDue,
    2
);


/*
|--------------------------------------------------------------------------
| PREPARE PROJECT INVOICE SEQUENCE TABLE
|--------------------------------------------------------------------------
| IMPORTANT: MySQL CREATE TABLE is DDL and can implicitly COMMIT an active
| transaction. The sequence table must therefore exist BEFORE beginTransaction().
*/

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS project_invoice_sequences (
        project_id INT UNSIGNED NOT NULL PRIMARY KEY,
        last_number INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
} catch (Throwable $e) {
    error_log('PROJECT INVOICE SEQUENCE TABLE ERROR: ' . $e->getMessage());
    jsonResponse(false, 'Unable to prepare the project invoice sequence. Please check the database.', [], 500);
}

/*
|--------------------------------------------------------------------------
| BEGIN TRANSACTION
|--------------------------------------------------------------------------
*/

$uploadedFiles = [];

try {

    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | CHECK DUPLICATE INVOICE / LOCK EXISTING BOOKING
    |--------------------------------------------------------------------------
    */

    $existingBooking = null;
    $existingFlightStatuses = [];
    $existingFlightStatusesById = [];
    $existingHotelStatuses = [];
    $existingHotelStatusesById = [];
    if ($editBookingId > 0) {
        $stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE");
        $stmt->execute([$editBookingId]);
        $existingBooking = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existingBooking) {
            throw new RuntimeException('Booking not found for editing.');
        }

        $role = strtolower((string)($agent['role'] ?? 'agent'));
        $allowed = in_array($role, ['admin','manager','administrator'], true);
        if ($role === 'agent') {
            $allowed = false;
            if ((int)$existingBooking['agent_id'] === $agentId) {
                $approved = Database::selectOne("SELECT id FROM booking_edit_requests WHERE booking_id=? AND requester_id=? AND status='Approved' ORDER BY id DESC LIMIT 1", [$editBookingId,$agentId]);
                $allowed = (bool)$approved;
            }
        } elseif ($role === 'teamlead') {
            $ids = array_values(array_unique(array_merge([$agentId], teamAgentIds($agentId))));
            $allowed = in_array((int)$existingBooking['agent_id'], $ids, true);
            if ($allowed) {
                $leadProject = (int)($agent['default_project_id'] ?? 0);
                $allowed = ($leadProject > 0 && (int)$existingBooking['project_id'] === $leadProject);
                if (!$allowed) {
                    $chk=$pdo->prepare('SELECT 1 FROM agent_projects WHERE agent_id=? AND project_id=? LIMIT 1');
                    $chk->execute([$agentId,(int)$existingBooking['project_id']]);
                    $allowed=(bool)$chk->fetchColumn();
                }
            }
        }
        if (!$allowed) {
            throw new RuntimeException('You are not authorized to edit this booking.');
        }
        if ($role === 'agent') {
            $pdo->prepare("UPDATE booking_edit_requests SET status='Used', used_at=NOW() WHERE booking_id=? AND requester_id=? AND status='Approved'")->execute([$editBookingId,$agentId]);
        }

        // Invoice numbers are permanent identifiers. Editing a booking must never
        // generate a new number, even if an old browser sends an empty/incorrect value.
        $invoiceNo = (string)($existingBooking['invoice_no'] ?? '');
        $storedInvoicePrefix = strtoupper(trim((string)($existingBooking['invoice_prefix'] ?? '')));
        if ($storedInvoicePrefix !== '') {
            $projectCode = $storedInvoicePrefix;
        } elseif ($invoiceNo !== '' && preg_match('/^[A-Za-z]+/', $invoiceNo, $m)) {
            // Legacy bookings may not have invoice_prefix populated. Recover the
            // original prefix from the permanent invoice number for display/update.
            $projectCode = strtoupper($m[0]);
        }

        // Preserve the booking's original project on edit.
        $projectId = (int)$existingBooking['project_id'];

        // Preserve service-level statuses before child rows are rebuilt below.
        $existingFlightStatuses = [];
        $existingHotelStatuses = [];

        $statusStmt = $pdo->prepare(
            'SELECT id, sort_order, flight_status FROM booking_flights WHERE booking_id = ? ORDER BY sort_order ASC, id ASC'
        );
        $statusStmt->execute([$editBookingId]);
        foreach ($statusStmt->fetchAll(PDO::FETCH_ASSOC) as $serviceRow) {
            $existingFlightStatuses[(int)$serviceRow['sort_order']] = (string)($serviceRow['flight_status'] ?? 'Pending');
            $existingFlightStatusesById[(int)$serviceRow['id']] = (string)($serviceRow['flight_status'] ?? 'Pending');
        }

        $statusStmt = $pdo->prepare(
            'SELECT id, sort_order, hotel_status FROM booking_hotels WHERE booking_id = ? ORDER BY sort_order ASC, id ASC'
        );
        $statusStmt->execute([$editBookingId]);
        foreach ($statusStmt->fetchAll(PDO::FETCH_ASSOC) as $serviceRow) {
            $existingHotelStatuses[(int)$serviceRow['sort_order']] = (string)($serviceRow['hotel_status'] ?? 'Pending');
            $existingHotelStatusesById[(int)$serviceRow['id']] = (string)($serviceRow['hotel_status'] ?? 'Pending');
        }

        // The booking status itself is also locked to its existing DB value.
        $status = (string)($existingBooking['status'] ?? $status);
    }

    /*
    |--------------------------------------------------------------------------
    | PROJECT-BASED SEQUENTIAL INVOICE NUMBER
    |--------------------------------------------------------------------------
    | New bookings receive: PROJECTCODE001, PROJECTCODE002, ...
    | The sequence is stored per project and locked inside the transaction so
    | simultaneous bookings cannot receive the same number.
    */
    if ($editBookingId <= 0) {
        // Table was created before the transaction. Keep sequence operations inside
        // the transaction so SELECT ... FOR UPDATE remains atomic.
        $seqInsert = $pdo->prepare(
            'INSERT IGNORE INTO project_invoice_sequences (project_id, last_number) VALUES (?, 0)'
        );
        $seqInsert->execute([$projectId]);

        $seq = $pdo->prepare(
            'SELECT last_number FROM project_invoice_sequences WHERE project_id = ? FOR UPDATE'
        );
        $seq->execute([$projectId]);
        $lastNumber = (int)($seq->fetchColumn() ?: 0);

        // Protect against older/random invoice numbers already present in this project.
     $maxStmt = $pdo->prepare(
    "SELECT COALESCE(MAX(CAST(SUBSTRING(invoice_no, ?) AS UNSIGNED)), 0)
     FROM bookings
     WHERE project_id = ?
       AND invoice_no COLLATE utf8mb4_general_ci
           REGEXP (
               CONVERT(CONCAT('^', ?, '[0-9]+$') USING utf8mb4)
               COLLATE utf8mb4_general_ci
           )"
);
        $prefixLength = strlen($projectCode) + 1;
        $maxStmt->execute([$prefixLength, $projectId, $projectCode]);
        $existingMax = (int)($maxStmt->fetchColumn() ?: 0);

        $nextNumber = max($lastNumber, $existingMax) + 1;
        if ($nextNumber > 999999999) {
            throw new RuntimeException('Invoice number sequence has reached its maximum value for this project.');
        }

        $updSeq = $pdo->prepare(
            'UPDATE project_invoice_sequences SET last_number = ? WHERE project_id = ?'
        );
        $updSeq->execute([$nextNumber, $projectId]);

        $invoiceNo = $projectCode . str_pad((string)$nextNumber, 3, '0', STR_PAD_LEFT);
    }

    if ($invoiceNo === '') {
        throw new RuntimeException('Invoice number could not be generated.');
    }

    $stmt = $pdo->prepare("
        SELECT id
        FROM bookings
        WHERE invoice_no = ?
          AND id <> ?
        LIMIT 1
    ");
    $stmt->execute([$invoiceNo, $editBookingId]);

    if ($stmt->fetchColumn()) {
        throw new RuntimeException('Invoice number already exists: ' . $invoiceNo);
    }

    /*
    |--------------------------------------------------------------------------
    | CREATE / UPDATE MAIN BOOKING
    |--------------------------------------------------------------------------
    */

    if ($editBookingId > 0) {

        $stmt = $pdo->prepare("
            UPDATE bookings
            SET
                invoice_no = ?,
                invoice_prefix = ?,
                invoice_date = ?,
                due_date = ?,
                gds_pnr = ?,
                airline_pnr = ?,
                travel_date = ?,
                status = ?,
                booking_source = ?,
                booking_type = ?,
                client_name = ?,
                client_mobile = ?,
                client_email = ?,
                agent_id = ?,
                project_id = ?,
                updated_by = ?,
                atol_charges = ?,
                safi_charges = ?,
                discount = ?,
                currency = 'GBP',
                gross_total = ?,
                total_received = ?,
                balance_due = ?,
                notes = ?
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $invoiceNo,
            $projectCode,
            $invoiceDate,
            $dueDate,
            $gdsPnr !== '' ? $gdsPnr : null,
            $airlinePnr !== '' ? $airlinePnr : null,
            $travelDate,
            $status,
            $bookingSource,
            $bookingType !== '' ? $bookingType : null,
            $clientName,
            $clientMobile !== '' ? $clientMobile : null,
            $clientEmail !== '' ? $clientEmail : null,
            (int)$existingBooking['agent_id'],
            (int)$existingBooking['project_id'],
            $agentId,
            $atolCharges,
            $iataCharges,
            $discount,
            $grossTotal,
            $totalReceived,
            $balanceDue,
            $notes !== '' ? $notes : null,
            $editBookingId
        ]);

        $bookingId = $editBookingId;

    } else {

        $stmt = $pdo->prepare("
            INSERT INTO bookings
            (
                invoice_no, invoice_prefix, invoice_date, due_date,
                gds_pnr, airline_pnr, travel_date, status,
                booking_source, booking_type, client_name,
                client_mobile, client_email, agent_id, project_id,
                created_by, atol_charges, safi_charges, discount,
                currency, gross_total, total_received, balance_due, notes
            )
            VALUES
            (
                :invoice_no, :invoice_prefix, :invoice_date, :due_date,
                :gds_pnr, :airline_pnr, :travel_date, :status,
                :booking_source, :booking_type, :client_name,
                :client_mobile, :client_email, :agent_id, :project_id,
                :created_by, :atol_charges, :safi_charges, :discount,
                'GBP', :gross_total, :total_received, :balance_due, :notes
            )
        ");

        $stmt->execute([
            ':invoice_no' => $invoiceNo,
            ':invoice_prefix' => $projectCode,
            ':invoice_date' => $invoiceDate,
            ':due_date' => $dueDate,
            ':gds_pnr' => $gdsPnr !== '' ? $gdsPnr : null,
            ':airline_pnr' => $airlinePnr !== '' ? $airlinePnr : null,
            ':travel_date' => $travelDate,
            ':status' => $status,
            ':booking_source' => $bookingSource,
            ':booking_type' => $bookingType !== '' ? $bookingType : null,
            ':client_name' => $clientName,
            ':client_mobile' => $clientMobile !== '' ? $clientMobile : null,
            ':client_email' => $clientEmail !== '' ? $clientEmail : null,
            ':agent_id' => $agentId,
            ':project_id' => $projectId,
            ':created_by' => $agentId,
            ':atol_charges' => $atolCharges,
            ':safi_charges' => $iataCharges,
            ':discount' => $discount,
            ':gross_total' => $grossTotal,
            ':total_received' => $totalReceived,
            ':balance_due' => $balanceDue,
            ':notes' => $notes !== '' ? $notes : null
        ]);

        $bookingId = (int)$pdo->lastInsertId();

        if ($bookingId <= 0) {
            throw new RuntimeException('Unable to create booking ID.');
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDIT: REPLACE CHILD ROWS
    |--------------------------------------------------------------------------
    | booking_id remains unchanged.
    | Existing payment attachments are remembered so they survive an edit
    | when the user does not upload a replacement file.
    |--------------------------------------------------------------------------
    */

    $existingPaymentAttachments = [];

    if ($editBookingId > 0) {
        $stmtExisting = $pdo->prepare("
            SELECT id, attachment
            FROM booking_payments
            WHERE booking_id = ?
        ");
        $stmtExisting->execute([$bookingId]);

        foreach ($stmtExisting->fetchAll(PDO::FETCH_ASSOC) as $payment) {
            $existingPaymentAttachments[(int)$payment['id']] =
                $payment['attachment'] ?: null;
        }

        foreach ([
            'booking_passengers',
            'booking_flights',
            'booking_hotels',
            'booking_transports',
            'booking_products',
            'booking_cost_rows',
            'booking_payments'
        ] as $table) {
            $pdo->prepare("DELETE FROM `{$table}` WHERE booking_id = ?")
                ->execute([$bookingId]);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PASSENGERS
    |--------------------------------------------------------------------------
    */

    if (is_array($passengers)) {

        $stmtPassenger = $pdo->prepare("
            INSERT INTO booking_passengers
            (booking_id,title,firstname,surname,sort_order)
            VALUES (?,?,?,?,?)
        ");


        $sortOrder = 0;


        foreach ($passengers as $passenger) {

            if (!is_array($passenger)) {
                continue;
            }


            $firstname = trim(
                (string) (
                    $passenger['firstname']
                    ?? ''
                )
            );


            $surname = trim(
                (string) (
                    $passenger['surname']
                    ?? ''
                )
            );


            /*
             * Completely empty passenger row.
             */

            if (
                $firstname === ''
                &&
                $surname === ''
            ) {
                continue;
            }


            if ($firstname === '') {

                throw new RuntimeException(
                    'Passenger first name is required.'
                );
            }


            if ($surname === '') {

                throw new RuntimeException(
                    'Passenger surname is required.'
                );
            }


            $title = normalizeTitle(
                (string) (
                    $passenger['title']
                    ?? 'MR'
                )
            );
            $stmtPassenger->execute([
                $bookingId,
                $title,
                $firstname,
                $surname,
                $sortOrder
            ]);


            $sortOrder++;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | FLIGHTS
    |--------------------------------------------------------------------------
    */

    if (is_array($flights)) {

        $stmtFlight = $pdo->prepare("
            INSERT INTO booking_flights
            (booking_id,airline_code,flight_no,dept_date,origin,destination,dept_time,arr_time,baggage,supplier,flight_status,sort_order)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ");


        $sortOrder = 0;


        foreach ($flights as $flight) {

            if (!is_array($flight)) {
                continue;
            }


            $airline = strtoupper(
                trim(
                    (string) (
                        $flight['airline']
                        ?? ''
                    )
                )
            );


            $flightNo = trim(
                (string) (
                    $flight['flight']
                    ?? ''
                )
            );


            $departureDate = nullableDate(
                isset(
                    $flight['departure_date']
                )
                ? (string) $flight['departure_date']
                : null
            );


            $origin = strtoupper(
                trim(
                    (string) (
                        $flight['origin']
                        ?? ''
                    )
                )
            );


            $destination = strtoupper(
                trim(
                    (string) (
                        $flight['destination']
                        ?? ''
                    )
                )
            );


            $departureTime = trim(
                (string) (
                    $flight['departure_time']
                    ?? ''
                )
            );


            $arrivalTime = trim(
                (string) (
                    $flight['arrival_time']
                    ?? ''
                )
            );


            $baggage = trim(
                (string) (
                    $flight['baggage']
                    ?? ''
                )
            );
            $flightSupplier = trim((string)($flight['supplier'] ?? ''));


            /*
             * Completely empty flight row.
             */

            if (
                $airline === ''
                &&
                $flightNo === ''
                &&
                $departureDate === null
                &&
                $origin === ''
                &&
                $destination === ''
            ) {
                continue;
            }


            if ($airline === '') {

                throw new RuntimeException(
                    'Flight airline is required.'
                );
            }


            if ($flightNo === '') {

                throw new RuntimeException(
                    'Flight number is required.'
                );
            }


            if ($departureDate === null) {

                throw new RuntimeException(
                    'Flight departure date is required.'
                );
            }


            if ($origin === '') {

                throw new RuntimeException(
                    'Flight origin is required.'
                );
            }


            if ($destination === '') {

                throw new RuntimeException(
                    'Flight destination is required.'
                );
            }


            /*
             * Database fields are three characters maximum.
             * Reject invalid values instead of silently truncating them.
             */
            if (strlen($airline) > 3) {
                throw new RuntimeException('Flight airline code must be 2 or 3 characters.');
            }

            if (strlen($origin) !== 3 || strlen($destination) !== 3) {
                throw new RuntimeException('Flight origin and destination must be valid 3-letter airport codes.');
            }


            $originalFlightId = (int)($flight['id'] ?? 0);
            $flightStatus = $originalFlightId > 0
                ? ($existingFlightStatusesById[$originalFlightId] ?? 'Pending')
                : ($existingFlightStatuses[$sortOrder] ?? 'Pending');

            $stmtFlight->execute([
                $bookingId,
                $airline,
                $flightNo,
                $departureDate,
                $origin,
                $destination,
                $departureTime !== ''
                    ? $departureTime
                    : null,
                $arrivalTime !== ''
                    ? $arrivalTime
                    : null,
                $baggage !== ''
                    ? $baggage
                    : null,
                $flightSupplier !== '' ? $flightSupplier : null,
                $flightStatus,
                $sortOrder
            ]);


            $sortOrder++;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | HOTELS
    |--------------------------------------------------------------------------
    */

    if (is_array($hotels)) {

        $stmtHotel = $pdo->prepare("
            INSERT INTO booking_hotels
            (booking_id,hotel_name,city,room_type,rooms,meal_basis,room_view,check_in,nights,check_out,remarks,hotel_supplier,hotel_status,sort_order)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ");


        $sortOrder = 0;


        foreach ($hotels as $hotel) {

            if (!is_array($hotel)) {
                continue;
            }


            $hotelName = trim(
                (string) (
                    $hotel['name']
                    ?? ''
                )
            );


            $city = trim(
                (string) (
                    $hotel['city']
                    ?? ''
                )
            );


            $roomType = trim(
                (string) (
                    $hotel['room_type']
                    ?? ''
                )
            );


            $rooms = max(
                1,
                (int) (
                    $hotel['rooms']
                    ?? 1
                )
            );


            $meal = normalizeMeal(
                (string) (
                    $hotel['meal']
                    ?? 'RO'
                )
            );


            $view = trim(
                (string) (
                    $hotel['view']
                    ?? ''
                )
            );


            $checkIn = nullableDate(
                isset($hotel['check_in'])
                    ? (string) $hotel['check_in']
                    : null
            );


            $nights = max(
                1,
                (int) (
                    $hotel['nights']
                    ?? 1
                )
            );


            $checkOut = nullableDate(
                isset($hotel['check_out'])
                    ? (string) $hotel['check_out']
                    : null
            );


            $remarks = trim(
                (string) (
                    $hotel['remarks']
                    ?? ''
                )
            );
            $hotelSupplier = trim((string)($hotel['supplier'] ?? ''));


            /*
             * Empty hotel row.
             */

            if (
                $hotelName === ''
                &&
                $city === ''
                &&
                $checkIn === null
                &&
                $checkOut === null
            ) {
                continue;
            }


            if ($hotelName === '') {

                throw new RuntimeException(
                    'Hotel name is required.'
                );
            }


            if ($city === '') {

                throw new RuntimeException(
                    'Hotel city is required.'
                );
            }


            if ($checkIn === null) {

                throw new RuntimeException(
                    'Hotel check-in date is required.'
                );
            }


            if ($checkOut === null) {

                throw new RuntimeException(
                    'Hotel check-out date is required.'
                );
            }


            $originalHotelId = (int)($hotel['id'] ?? 0);
            $hotelStatus = $originalHotelId > 0
                ? ($existingHotelStatusesById[$originalHotelId] ?? 'Pending')
                : ($existingHotelStatuses[$sortOrder] ?? 'Pending');

            $stmtHotel->execute([
                $bookingId,
                $hotelName,
                $city,
                $roomType !== ''
                    ? $roomType
                    : null,
                $rooms,
                $meal,
                $view !== ''
                    ? $view
                    : null,
                $checkIn,
                $nights,
                $checkOut,
                $remarks !== ''
                    ? $remarks
                    : null,
                $hotelSupplier !== '' ? $hotelSupplier : null,
                $hotelStatus,
                $sortOrder
            ]);


            $sortOrder++;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | TRANSPORT
    |--------------------------------------------------------------------------
    */

    if (is_array($transports)) {

        $stmtTransport = $pdo->prepare("
            INSERT INTO booking_transports
            (booking_id,vehicle,journey,vehicles_qty,pickup_date,pickup_time,notes,supplier,sort_order)
            VALUES (?,?,?,?,?,?,?,?,?)
        ");


        $sortOrder = 0;


        foreach ($transports as $transport) {

            if (!is_array($transport)) {
                continue;
            }


            $vehicle = trim(
                (string) (
                    $transport['vehicle']
                    ?? ''
                )
            );


            $journey = trim(
                (string) (
                    $transport['journey']
                    ?? ''
                )
            );


            $vehiclesQty = max(
                1,
                (int) (
                    $transport['vehicles']
                    ?? 1
                )
            );


            $pickupDate = nullableDate(
                isset($transport['pickup_date'])
                    ? (string) $transport['pickup_date']
                    : null
            );


            $pickupTime = trim(
                (string) (
                    $transport['pickup_time']
                    ?? ''
                )
            );


            $transportNotes = trim(
                (string) (
                    $transport['notes']
                    ?? ''
                )
            );
            $transportSupplier = trim((string)($transport['supplier'] ?? ''));


            /*
             * Empty transport row.
             *
             * The default vehicle "Car/Bus" alone
             * should NOT create a transport record.
             */

            if (
                $journey === ''
                &&
                $pickupDate === null
                &&
                $pickupTime === ''
                &&
                $transportNotes === ''
            ) {
                continue;
            }


            if ($vehicle === '') {

                $vehicle = 'Car/Bus';
            }


            if ($journey === '') {

                throw new RuntimeException(
                    'Transport journey is required.'
                );
            }


            $stmtTransport->execute([
                $bookingId,
                $vehicle,
                $journey,
                $vehiclesQty,
                $pickupDate,
                $pickupTime !== ''
                    ? $pickupTime
                    : null,
                $transportNotes !== ''
                    ? $transportNotes
                    : null,
                $transportSupplier !== '' ? $transportSupplier : null,
                $sortOrder
            ]);


            $sortOrder++;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PRODUCTS
    |--------------------------------------------------------------------------
    */

    if (is_array($products)) {

        $stmtProduct = $pdo->prepare("
            INSERT INTO booking_products
            (
                booking_id,
                product_name,
                product_type,
                supplier,
                sort_order
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ");


        $sortOrder = 0;


        foreach ($products as $product) {

            /*
             * Your current HTML uses:
             *
             * products[]
             *
             * so this is normally a string.
             */

            if (is_array($product)) {

                $productName = trim(
                    (string) (
                        $product['name']
                        ?? $product['product_name']
                        ?? ''
                    )
                );

                $productType = trim(
                    (string) (
                        $product['type']
                        ?? $product['product_type']
                        ?? ''
                    )
                );

                $productSupplier = trim(
                    (string) (
                        $product['supplier']
                        ?? ''
                    )
                );

            } else {

                $productName = trim(
                    (string) $product
                );

                $productType = '';
                $productSupplier = '';
            }


            if ($productName === '') {
                continue;
            }


            $stmtProduct->execute([
                $bookingId,
                $productName,
                $productType !== ''
                    ? $productType
                    : null,
                $productSupplier !== ''
                    ? $productSupplier
                    : null,
                $sortOrder
            ]);


            $sortOrder++;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | COST ROWS
    |--------------------------------------------------------------------------
    |
    | IMPORTANT:
    |
    | We only save:
    |
    | age_category
    | quantity
    | base_fare
    | tax
    | selling_price
    |
    | We DO NOT insert:
    |
    | net_cost
    | total_net
    | selling_total
    | margin
    |
    | Those are GENERATED columns in your database.
    |
    */

    if (is_array($costs)) {

        $stmtCost = $pdo->prepare("
            INSERT INTO booking_cost_rows
            (
                booking_id,
                age_category,
                category_type,
                quantity,
                base_fare,
                tax,
                selling_price,
                sort_order
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ");


        $sortOrder = 0;


        foreach ($costs as $cost) {

            if (!is_array($cost)) {
                continue;
            }


            $age = strtoupper(
                trim(
                    (string) (
                        $cost['age_category']
                        ?? 'ADULT'
                    )
                )
            );


            $allowedAge = [
                'ADULT','CHILD','YOUTH','INFANT',
                'MAK HOTEL','MED HOTEL','VISA','TRANSPORT','OTHER'
            ];

            if (!in_array($age, $allowedAge, true)) {
                $age = 'ADULT';
            }


            $quantity = max(
                0,
                (int) (
                    $cost['quantity']
                    ?? 0
                )
            );


            $baseFare = max(
                0,
                round(
                    (float) (
                        $cost['base_fare']
                        ?? 0
                    ),
                    2
                )
            );


            $tax = max(
                0,
                round(
                    (float) (
                        $cost['tax']
                        ?? 0
                    ),
                    2
                )
            );


            $sellingPrice = max(
                0,
                round(
                    (float) (
                        $cost['selling_price']
                        ?? 0
                    ),
                    2
                )
            );


            /*
             * Skip completely useless rows.
             */

            if (
                $quantity <= 0
                &&
                $baseFare <= 0
                &&
                $tax <= 0
                &&
                $sellingPrice <= 0
            ) {
                continue;
            }


            $categoryMap = [
                'ADULT' => 'ADULT',
                'CHILD' => 'CHILD',
                'YOUTH' => 'ADULT',
                'INFANT' => 'INFANT',
                'MAK HOTEL' => 'HOTEL',
                'MED HOTEL' => 'HOTEL',
                'VISA' => 'VISA',
                'TRANSPORT' => 'TRANSPORT',
                'OTHER' => 'OTHER'
            ];

            $categoryType = strtoupper(trim(
                (string)($cost['category_type'] ?? ($categoryMap[$age] ?? 'OTHER'))
            ));

            $allowedCategoryTypes = [
                'ADULT','CHILD','INFANT','HOTEL',
                'TRANSPORT','VISA','INSURANCE','OTHER'
            ];

            if (!in_array($categoryType, $allowedCategoryTypes, true)) {
                $categoryType = $categoryMap[$age] ?? 'OTHER';
            }


            $stmtCost->execute([
                $bookingId,
                $age,
                $categoryType,
                $quantity,
                $baseFare,
                $tax,
                $sellingPrice,
                $sortOrder
            ]);


            $sortOrder++;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PAYMENTS
    |--------------------------------------------------------------------------
    */

    if (is_array($payments)) {

        $stmtPayment = $pdo->prepare("
            INSERT INTO booking_payments
            (
                booking_id,
                receipt_id,
                profile_id,
                payer_name,
                payment_date,
                method,
                credit_debit,
                amount,
                payment_status,
                reference_no,
                received_by,
                attachment,
                remarks
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                'Received',
                ?,
                ?,
                ?,
                ?
            )
        ");


        foreach ($payments as $paymentIndex => $payment) {

            if (!is_array($payment)) {
                continue;
            }


            $amount = max(
                0,
                round(
                    (float) (
                        $payment['amount']
                        ?? 0
                    ),
                    2
                )
            );


            /*
             * Don't create £0 payments.
             */

            if ($amount <= 0) {
                continue;
            }


            $receiptId = trim(
                (string) (
                    $payment['receipt_id']
                    ?? ''
                )
            );


            $paymentDate = nullableDate(
                isset($payment['date'])
                    ? (string) $payment['date']
                    : null
            );


            if ($paymentDate === null) {

                $paymentDate = date(
                    'Y-m-d'
                );
            }


            $method = normalizePaymentMethod(
                (string) (
                    $payment['method']
                    ?? 'BANK PAY'
                )
            );


            $creditDebit = normalizeCreditDebit(
                (string) (
                    $payment['currencyType']
                    ?? 'DEBIT'
                )
            );


            $referenceNo = trim(
                (string) (
                    $payment['payment_reference']
                    ?? $payment['reference_no']
                    ?? ''
                )
            );

            $remarks = trim(
                (string) (
                    $payment['remarks']
                    ?? ''
                )
            );

            $profileId = trim((string)($payment['profile_id'] ?? ''));
            $payerName = trim((string)(
                $payment['payer_name']
                ?? $payment['customer_name']
                ?? ''
            ));

            $paymentId = max(0, (int)($payment['payment_id'] ?? 0));

            $attachment = savePaymentAttachment(
                (int)$paymentIndex,
                $uploadedFiles
            );

            if ($attachment === null && $paymentId > 0) {
                $attachment = $existingPaymentAttachments[$paymentId] ?? null;
            }

            $stmtPayment->execute([
                $bookingId,
                $receiptId !== '' ? $receiptId : null,
                $profileId !== '' ? $profileId : null,
                $payerName !== '' ? $payerName : null,
                $paymentDate,
                $method,
                $creditDebit,
                $amount,
                $referenceNo !== '' ? $referenceNo : null,
                $agentId,
                $attachment,
                $remarks !== '' ? $remarks : null
            ]);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | BOOKING LOG
    |--------------------------------------------------------------------------
    */

    $logDescription =
        'Booking ' . ($editBookingId > 0 ? 'updated' : 'created') . ' successfully. '
        . 'Invoice: '
        . $invoiceNo
        . '. '
        . 'Source: '
        . $bookingSource
        . '. '
        . 'Client: '
        . $clientName
        . '. '
        . 'Total payable: £'
        . number_format(
            $payableTotal,
            2,
            '.',
            ''
        );


    $logAction = $editBookingId > 0 ? 'Updated' : 'Created';

    $stmtLog = $pdo->prepare("
        INSERT INTO booking_logs
        (
            booking_id,
            agent_id,
            module,
            action,
            description,
            new_value,
            ip_address
        )
        VALUES
        (
            ?,
            ?,
            'Booking',
            ?,
            ?,
            ?,
            ?
        )
    ");


    $stmtLog->execute([
        $bookingId,
        $agentId,
        $logAction,
        $logDescription,
        json_encode(
            [
                'invoice_no' => $invoiceNo,
                'gds_pnr' => $gdsPnr,
                'airline_pnr' => $airlinePnr,
                'status' => $status,
                'booking_source' => $bookingSource,
                'gross_total' => $grossTotal,
                'discount' => $discount,
                'payable_total' => $payableTotal,
                'total_received' => $totalReceived,
                'balance_due' => $balanceDue
            ],
            JSON_UNESCAPED_UNICODE
        ),
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);


    /*
    |--------------------------------------------------------------------------
    | COMMIT
    |--------------------------------------------------------------------------
    */

    if (!$pdo->inTransaction()) {
        throw new RuntimeException('Booking transaction was unexpectedly closed before commit.');
    }

    $pdo->commit();


    /*
    |--------------------------------------------------------------------------
    | SUCCESS
    |--------------------------------------------------------------------------
    */

    jsonResponse(
        true,
        'Booking ' . ($editBookingId > 0 ? 'updated' : 'saved') . ' successfully.',
        [
            'booking_id' => $bookingId,
            'invoice_no' => $invoiceNo,
            'gds_pnr' => $gdsPnr,
            'payable_total' => number_format(
                $payableTotal,
                2,
                '.',
                ''
            ),
            'total_received' => number_format(
                $totalReceived,
                2,
                '.',
                ''
            ),
            'balance_due' => number_format(
                $balanceDue,
                2,
                '.',
                ''
            )
        ]
    );


} catch (Throwable $e) {

    /*
    |--------------------------------------------------------------------------
    | ROLLBACK
    |--------------------------------------------------------------------------
    */

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }


    /*
    |--------------------------------------------------------------------------
    | SERVER LOG
    |--------------------------------------------------------------------------
    */

    error_log(
        'SAVE BOOKING ERROR: '
        . $e->getMessage()
        . ' | File: '
        . $e->getFile()
        . ' | Line: '
        . $e->getLine()
    );


    /*
    |--------------------------------------------------------------------------
    | TEMPORARY DEBUG RESPONSE
    |--------------------------------------------------------------------------
    |
    | IMPORTANT:
    | We are temporarily showing the real database error so we can identify
    | exactly what is different between Localhost and Hostinger.
    |
    */

    $message = $e->getMessage();


    /*
    |--------------------------------------------------------------------------
    | RETURN ERROR
    |--------------------------------------------------------------------------
    */

    jsonResponse(
        false,
        $message,
        [],
        500
    );
}