<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

require_once __DIR__ . '/../../includes/db.php';


try {

    /*
     * =========================================================
     * READ REQUEST
     * =========================================================
     */

    $serviceType =
        isset($_POST['service_type'])
            ? trim((string) $_POST['service_type'])
            : '';

    $serviceId =
        isset($_POST['service_id'])
            ? (int) $_POST['service_id']
            : 0;

    $newStatus =
        isset($_POST['status'])
            ? trim((string) $_POST['status'])
            : '';


    /*
     * =========================================================
     * VALIDATE SERVICE TYPE
     * =========================================================
     */

    if (
        !in_array(
            $serviceType,
            ['flight', 'hotel'],
            true
        )
    ) {

        throw new Exception(
            'Invalid service type.'
        );

    }


    /*
     * =========================================================
     * VALIDATE ID
     * =========================================================
     */

    if ($serviceId <= 0) {

        throw new Exception(
            'Invalid service ID.'
        );

    }


    /*
     * =========================================================
     * ALLOWED STATUSES
     * =========================================================
     */

    $allowedStatuses = [

        'flight' => [

            'Pending',

            'Booked',

            'Ticketed',

            'Cancelled'

        ],

        'hotel' => [

            'Pending',

            'Reserved',

            'Tentative',

            'Definitive',

            'Cancelled'

        ]

    ];


    if (
        !in_array(
            $newStatus,
            $allowedStatuses[$serviceType],
            true
        )
    ) {

        throw new Exception(
            'Invalid status for this service.'
        );

    }


    /*
     * =========================================================
     * GET TABLE / STATUS COLUMN
     * =========================================================
     */

    if ($serviceType === 'flight') {

        $table = 'booking_flights';

        $statusColumn = 'flight_status';

    } else {

        $table = 'booking_hotels';

        $statusColumn = 'hotel_status';

    }


    /*
     * =========================================================
     * GET CURRENT RECORD
     * =========================================================
     */

    $selectSql = "

        SELECT

            id,

            booking_id,

            {$statusColumn} AS current_status

        FROM {$table}

        WHERE id = ?

        LIMIT 1

    ";


    $statement =
        $pdo->prepare(
            $selectSql
        );


    $statement->execute([
        $serviceId
    ]);


    $service =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$service) {

        throw new Exception(
            'Service record not found.'
        );

    }


    $oldStatus =
        (string) $service['current_status'];


    $bookingId =
        (int) $service['booking_id'];


    /*
     * =========================================================
     * NO CHANGE
     * =========================================================
     */

    if ($oldStatus === $newStatus) {

        echo json_encode([

            'success' => true,

            'message' =>
                'Status is already ' .
                $newStatus,

            'old_status' =>
                $oldStatus,

            'new_status' =>
                $newStatus

        ]);

        exit;

    }


    /*
     * =========================================================
     * UPDATE STATUS
     * =========================================================
     */

    $updateSql = "

        UPDATE {$table}

        SET {$statusColumn} = ?

        WHERE id = ?

        LIMIT 1

    ";


    $statement =
        $pdo->prepare(
            $updateSql
        );


    $statement->execute([

        $newStatus,

        $serviceId

    ]);


    /*
     * =========================================================
     * CREATE BOOKING LOG
     * =========================================================
     */

    $module =
        $serviceType === 'flight'
            ? 'Flight'
            : 'Hotel';


    $action =
        'Update ' .
        ucfirst($serviceType) .
        ' Status';


    $description =
        ucfirst($serviceType) .
        ' status changed from "' .
        $oldStatus .
        '" to "' .
        $newStatus .
        '"';


    /*
     * Get agent/user.
     *
     * We try common session keys.
     */

    $agentId = 0;


    if (
        isset($_SESSION['user_id'])
    ) {

        $agentId =
            (int) $_SESSION['user_id'];

    } elseif (
        isset($_SESSION['id'])
    ) {

        $agentId =
            (int) $_SESSION['id'];

    } elseif (
        isset($_SESSION['agent_id'])
    ) {

        $agentId =
            (int) $_SESSION['agent_id'];

    }


    /*
     * Only create log when we
     * have an agent/user ID.
     */

    if ($agentId > 0) {

        $logSql = "

            INSERT INTO booking_logs (

                booking_id,

                agent_id,

                module,

                action,

                description,

                old_value,

                new_value,

                ip_address

            )

            VALUES (

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?

            )

        ";


        $logStatement =
            $pdo->prepare(
                $logSql
            );


        $logStatement->execute([

            $bookingId,

            $agentId,

            $module,

            $action,

            $description,

            $oldStatus,

            $newStatus,

            $_SERVER['REMOTE_ADDR'] ?? null

        ]);

    }


    /*
     * =========================================================
     * RESPONSE
     * =========================================================
     */

    echo json_encode([

        'success' => true,

        'message' =>
            ucfirst($serviceType) .
            ' status updated successfully.',

        'booking_id' =>
            $bookingId,

        'service_id' =>
            $serviceId,

        'service_type' =>
            $serviceType,

        'old_status' =>
            $oldStatus,

        'new_status' =>
            $newStatus

    ], JSON_UNESCAPED_UNICODE);


} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([

        'success' => false,

        'message' =>
            $e->getMessage()

    ]);

}