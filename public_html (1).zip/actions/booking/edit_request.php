<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/auth.php'; requireLogin();
require_once __DIR__.'/../../includes/db.php'; require_once __DIR__.'/../../includes/permissions.php'; require_once __DIR__.'/../../includes/notifications.php';
header('Content-Type: application/json; charset=utf-8');
function erj(bool $ok,string $msg,array $data=[],int $code=200): never { http_response_code($code); echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE); exit; }
try {
 $pdo->exec("CREATE TABLE IF NOT EXISTS booking_edit_requests (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, requester_id INT UNSIGNED NOT NULL, status ENUM('Pending','Approved','Rejected','Used') NOT NULL DEFAULT 'Pending', requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_by INT UNSIGNED NULL, reviewed_at DATETIME NULL, rejection_reason TEXT NULL, used_at DATETIME NULL, KEY idx_edit_status(status), KEY idx_edit_booking(booking_id), KEY idx_edit_requester(requester_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
 $uid=(int)authId(); $role=strtolower((string)authRole()); $action=strtolower((string)($_POST['action']??$_GET['action']??'')); $bookingId=(int)($_POST['booking_id']??$_GET['booking_id']??0); $requestId=(int)($_POST['id']??$_GET['id']??0);
 // Review requests are identified by request id + review status. Accept them even if an older cached page omits action=status.
 if($action==='' && $requestId>0 && isset($_POST['status'])) $action='status';
 if($action==='review') $action='status';
 if($action==='status') {
   if(!in_array($role,['admin','manager','administrator','teamlead'],true)) erj(false,'Not authorized.',[],403);
   $r=Database::selectOne("SELECT r.*,b.agent_id FROM booking_edit_requests r JOIN bookings b ON b.id=r.booking_id WHERE r.id=? AND r.status='Pending'",[$requestId]); if(!$r) erj(false,'Pending edit request not found.',[],404);
   if($role==='teamlead' && !in_array((int)$r['agent_id'],array_values(array_unique(array_merge([$uid],teamAgentIds($uid)))),true)) erj(false,'Not authorized to review this request.',[],403);
   $status=ucfirst(strtolower((string)($_POST['status']??''))); if(!in_array($status,['Approved','Rejected'],true)) erj(false,'Invalid status.',[],400);
   $reason=trim((string)($_POST['reason']??''));
   $pdo->prepare("UPDATE booking_edit_requests SET status=?,reviewed_by=?,reviewed_at=NOW(),rejection_reason=? WHERE id=? AND status='Pending'")->execute([$status,$uid,$status==='Rejected'?$reason:null,$requestId]);
   notifyBookingApprovalReviewed((int)$r['booking_id'], $requestId, (int)$r['requester_id'], 'edit', $status, $uid, $reason);
   erj(true,$status==='Approved'?'Edit request approved. The agent can now edit the booking.':'Edit request rejected. The agent has been notified.');
 }
 if($bookingId<=0) erj(false,'Invalid booking ID.',[],400);
 $b=Database::selectOne('SELECT * FROM bookings WHERE id=?',[$bookingId]); if(!$b) erj(false,'Booking not found.',[],404);
 if($role!=='agent') erj(false,'Only agents need edit approval requests.',[],403);
 if((int)$b['agent_id']!==$uid) erj(false,'You can only request editing your own bookings.',[],403);
 $approved=Database::selectOne("SELECT id,status,rejection_reason FROM booking_edit_requests WHERE booking_id=? AND requester_id=? AND status='Approved' ORDER BY id DESC LIMIT 1",[$bookingId,$uid]);
 if($approved) erj(true,'Edit request already approved.',$approved);
 $pending=Database::selectOne("SELECT id,status FROM booking_edit_requests WHERE booking_id=? AND requester_id=? AND status='Pending' ORDER BY id DESC LIMIT 1",[$bookingId,$uid]);
 if($pending) erj(false,'Edit request is already pending approval.', ['status'=>'Pending','request_id'=>(int)$pending['id']],409);
 $last=Database::selectOne("SELECT id,status,rejection_reason FROM booking_edit_requests WHERE booking_id=? AND requester_id=? ORDER BY id DESC LIMIT 1",[$bookingId,$uid]);
 $pdo->prepare("INSERT INTO booking_edit_requests (booking_id,requester_id,status) VALUES (?,?,'Pending')")->execute([$bookingId,$uid]);
 $newRequestId=(int)$pdo->lastInsertId();
 notifyBookingApprovalRequested($bookingId,$newRequestId,$uid,'edit');
 erj(true,'Edit request sent to Admin, Manager and Team Lead. Please wait for approval.',['status'=>'Pending','request_id'=>(int)$pdo->lastInsertId()]);
} catch(Throwable $e){ erj(false,$e->getMessage()?:'Request failed.',[],500); }
