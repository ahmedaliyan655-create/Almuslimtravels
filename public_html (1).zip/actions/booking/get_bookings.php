<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../includes/db.php';

// Start the PHP session so booking visibility is enforced from the
// authenticated account, not from browser-supplied filters.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


try {

    /*
     * =========================================================
     * FILTER VALUES
     * =========================================================
     */

    $projectId = isset($_GET['project_id'])
        ? (int) $_GET['project_id']
        : 0;

    $agentId = isset($_GET['agent_id'])
        ? (int) $_GET['agent_id']
        : 0;

    $status = isset($_GET['status'])
        ? trim((string) $_GET['status'])
        : '';

    $travelDate = isset($_GET['travel_date'])
        ? trim((string) $_GET['travel_date'])
        : '';

    $search = isset($_GET['search'])
        ? trim((string) $_GET['search'])
        : '';


    /*
     * =========================================================
     * AUTHENTICATED USER / BOOKING VISIBILITY
     * =========================================================
     *
     * ADMIN / MANAGER:
     *     See every booking from every project.
     *
     * TEAM LEAD:
     *     - If no project is assigned: return ZERO bookings.
     *     - See bookings belonging to the team lead's assigned
     *       projects.
     *     - For team agents, only show a booking when that agent is
     *       a member of the team led by this team lead AND that
     *       agent is also assigned to the booking's project.
     *
     * IMPORTANT:
     *     project_id / agent_id coming from GET are only optional
     *     filters. They NEVER grant additional access.
     */

    $currentAgentId = 0;

    if (!empty($_SESSION['agent_id'])) {
        $currentAgentId = (int) $_SESSION['agent_id'];
    } elseif (!empty($_SESSION['user_id'])) {
        $currentAgentId = (int) $_SESSION['user_id'];
    } elseif (!empty($_SESSION['id'])) {
        $currentAgentId = (int) $_SESSION['id'];
    }

    if ($currentAgentId <= 0) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Your session has expired. Please login again.',
            'data' => [],
            'statistics' => [
                'totalBookings' => 0,
                'confirmedBookings' => 0,
                'pendingBookings' => 0,
                'cancelledBookings' => 0,
                'totalRevenue' => 0,
                'balanceDue' => 0
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $userStmt = $pdo->prepare("
        SELECT
            id,
            role,
            team_id,
            default_project_id,
            is_active
        FROM agents
        WHERE id = ?
        LIMIT 1
    ");
    $userStmt->execute([$currentAgentId]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentUser) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Logged-in user was not found.',
            'data' => [],
            'statistics' => [
                'totalBookings' => 0,
                'confirmedBookings' => 0,
                'pendingBookings' => 0,
                'cancelledBookings' => 0,
                'totalRevenue' => 0,
                'balanceDue' => 0
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ((int) $currentUser['is_active'] !== 1) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Your account is inactive.',
            'data' => [],
            'statistics' => [
                'totalBookings' => 0,
                'confirmedBookings' => 0,
                'pendingBookings' => 0,
                'cancelledBookings' => 0,
                'totalRevenue' => 0,
                'balanceDue' => 0
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $role = strtolower(trim((string) ($currentUser['role'] ?? 'agent')));
    $isAdmin = in_array($role, ['admin', 'manager', 'administrator'], true);
    $isTeamLead = ($role === 'teamlead');


    /*
     * =========================================================
     * BASE QUERY
     * =========================================================
     */

    $sql = "
        SELECT

            b.id,

            b.invoice_no,

            b.invoice_date,

            b.due_date,

            b.gds_pnr,

            b.airline_pnr,

            b.travel_date,

            b.status,

            b.booking_source,

            b.booking_type,

            b.client_name,

            b.client_mobile,

            b.client_email,

            b.destination,

            b.supplier,

            b.agent_id,

            b.project_id,

            b.currency,

            b.gross_total,

            b.total_received,

            b.balance_due,

            b.created_at,

            b.updated_at,

            a.name AS agent_name,

            a.agent_code,

            p.project_name,

            p.project_code,


            /*
             * =================================================
             * FLIGHT WARNING
             * =================================================
             */

            EXISTS (

                SELECT 1

                FROM booking_flights bf

                WHERE bf.booking_id = b.id

                AND bf.flight_status IN (
                    'Pending',
                    'Cancelled'
                )

            ) AS has_unconfirmed_flight,


            /*
             * =================================================
             * HOTEL WARNING
             * =================================================
             */

            EXISTS (

                SELECT 1

                FROM booking_hotels bh

                WHERE bh.booking_id = b.id

                AND bh.hotel_status IN (
                    'Pending',
                    'Tentative',
                    'Cancelled'
                )

            ) AS has_unconfirmed_hotel


        FROM bookings b


        LEFT JOIN agents a
            ON a.id = b.agent_id


        LEFT JOIN projects p
            ON p.id = b.project_id


        WHERE 1 = 1
    ";


    $params = [];


    /*
     * =========================================================
     * ROLE-BASED BOOKING ACCESS
     * =========================================================
     */

    if ($isTeamLead) {

        /*
         * A team lead must have at least one project through either:
         *   1. default_project_id, or
         *   2. agent_projects.
         *
         * If neither exists, the query deliberately returns no rows.
         */
        $teamLeadProjectCondition = "
            (
                b.project_id = ?
                OR EXISTS (
                    SELECT 1
                    FROM agent_projects ap_lead
                    WHERE ap_lead.agent_id = ?
                      AND ap_lead.project_id = b.project_id
                )
            )
        ";

        $defaultProjectId = (int) ($currentUser['default_project_id'] ?? 0);

        if ($defaultProjectId > 0) {
            $params[] = $defaultProjectId;
        } else {
            // Keep placeholder ordering valid when there is no default project.
            $teamLeadProjectCondition = "
                EXISTS (
                    SELECT 1
                    FROM agent_projects ap_lead
                    WHERE ap_lead.agent_id = ?
                      AND ap_lead.project_id = b.project_id
                )
            ";
        }

        $params[] = $currentAgentId;

        $sql .= "
            AND {$teamLeadProjectCondition}

            AND (
                /* Team lead's own bookings */
                b.agent_id = ?

                OR

                /* Team member bookings, but only when the member
                   is assigned to the same project as the booking. */
                EXISTS (
                    SELECT 1
                    FROM agents teamAgent
                    WHERE teamAgent.id = b.agent_id
                      AND (
                          teamAgent.team_lead_id = ?
                          OR teamAgent.id IN (
                              SELECT tm.agent_id
                              FROM team_members tm
                              INNER JOIN teams t
                                  ON t.id = tm.team_id
                              WHERE t.team_lead_id = ?
                          )
                      )
                      AND (
                          teamAgent.default_project_id = b.project_id
                          OR EXISTS (
                              SELECT 1
                              FROM agent_projects ap_agent
                              WHERE ap_agent.agent_id = teamAgent.id
                                AND ap_agent.project_id = b.project_id
                          )
                      )
                )
            )
        ";

        $params[] = $currentAgentId;
        $params[] = $currentAgentId;
        $params[] = $currentAgentId;

    } elseif ($isAdmin) {

        /* Admin / Manager intentionally receives all bookings. */

    } else {

        /*
         * Keep normal agents restricted as well. They can only see
         * their own bookings. This is safer than leaving the endpoint
         * open to arbitrary agent_id values.
         */
        $sql .= "
            AND b.agent_id = ?
        ";
        $params[] = $currentAgentId;
    }


    /*
     * =========================================================
     * PROJECT FILTER
     * =========================================================
     */

    if ($projectId > 0) {

        $sql .= "
            AND b.project_id = ?
        ";

        $params[] = $projectId;

    }


    /*
     * =========================================================
     * AGENT FILTER
     * =========================================================
     */

    if ($agentId > 0) {

        $sql .= "
            AND b.agent_id = ?
        ";

        $params[] = $agentId;

    }


    /*
     * =========================================================
     * STATUS FILTER
     * =========================================================
     */

    if ($status !== '') {

        $sql .= "
            AND b.status = ?
        ";

        $params[] = $status;

    }


    /*
     * =========================================================
     * TRAVEL DATE
     * =========================================================
     */

    if ($travelDate !== '') {

        $sql .= "
            AND b.travel_date = ?
        ";

        $params[] = $travelDate;

    }


    /*
     * =========================================================
     * SEARCH
     * =========================================================
     */

    if ($search !== '') {

        $sql .= "
            AND (

                b.invoice_no LIKE ?

                OR b.client_name LIKE ?

                OR b.client_mobile LIKE ?

                OR b.destination LIKE ?

                OR a.name LIKE ?

                OR p.project_name LIKE ?

            )
        ";

        $searchValue = '%' . $search . '%';

        $params[] = $searchValue;
        $params[] = $searchValue;
        $params[] = $searchValue;
        $params[] = $searchValue;
        $params[] = $searchValue;
        $params[] = $searchValue;

    }


    /*
     * =========================================================
     * ORDER
     * =========================================================
     */

    $sql .= "
        ORDER BY b.id DESC
    ";


    /*
     * =========================================================
     * GET BOOKINGS
     * =========================================================
     */

    $bookings = Database::select(
        $sql,
        $params
    );


    /*
     * =========================================================
     * PREPARE BOOKING IDS
     * =========================================================
     */

    $bookingIds = [];


    foreach ($bookings as $booking) {

        $bookingIds[] =
            (int) $booking['id'];

    }


    /*
     * =========================================================
     * DEFAULT SERVICE ARRAYS
     * =========================================================
     */

    foreach ($bookings as &$booking) {

        $booking['flights'] = [];

        $booking['hotels'] = [];

    }

    unset($booking);


    /*
     * =========================================================
     * LOAD FLIGHTS + HOTELS
     * =========================================================
     */

    if (!empty($bookingIds)) {

        /*
         * -----------------------------------------------------
         * Create placeholders
         * -----------------------------------------------------
         */

        $placeholders =
            implode(
                ',',
                array_fill(
                    0,
                    count($bookingIds),
                    '?'
                )
            );


        /*
         * =====================================================
         * LOAD FLIGHTS
         * =====================================================
         */

        $flightSql = "

            SELECT

                id,

                booking_id,

                airline_code,

                booking_class,

                flight_no,

                dept_date,

                origin,

                destination,

                terminal,

                dept_time,

                arr_time,

                baggage,

                ticket_no,

                flight_status,

                sort_order

            FROM booking_flights

            WHERE booking_id IN ($placeholders)

            ORDER BY

                booking_id ASC,

                sort_order ASC,

                id ASC

        ";


        $flights = Database::select(
            $flightSql,
            $bookingIds
        );


        /*
         * Add flights to bookings
         */

        $bookingIndex = [];


        foreach ($bookings as $index => $booking) {

            $bookingIndex[
                (int) $booking['id']
            ] = $index;

        }


        foreach ($flights as $flight) {

            $bookingId =
                (int) $flight['booking_id'];


            if (
                isset(
                    $bookingIndex[$bookingId]
                )
            ) {

                $bookings[
                    $bookingIndex[$bookingId]
                ]['flights'][] =
                    $flight;

            }

        }


        /*
         * =====================================================
         * LOAD HOTELS
         * =====================================================
         */

        $hotelSql = "

            SELECT

                id,

                booking_id,

                hotel_name,

                city,

                room_type,

                rooms,

                meal_basis,

                room_view,

                check_in,

                nights,

                check_out,

                reservation_no,

                hotel_status,

                expiry_date,

                confirmation_date,

                hotel_supplier,

                remarks,

                sort_order

            FROM booking_hotels

            WHERE booking_id IN ($placeholders)

            ORDER BY

                booking_id ASC,

                sort_order ASC,

                id ASC

        ";


        $hotels = Database::select(
            $hotelSql,
            $bookingIds
        );


        /*
         * Add hotels to bookings
         */

        foreach ($hotels as $hotel) {

            $bookingId =
                (int) $hotel['booking_id'];


            if (
                isset(
                    $bookingIndex[$bookingId]
                )
            ) {

                $bookings[
                    $bookingIndex[$bookingId]
                ]['hotels'][] =
                    $hotel;

            }

        }

    }


    /*
     * =========================================================
     * STATISTICS
     * =========================================================
     */

    $totalBookings = count($bookings);

    $confirmedBookings = 0;

    $pendingBookings = 0;

    $cancelledBookings = 0;

    $totalRevenue = 0.00;

    $balanceDue = 0.00;


    foreach ($bookings as $booking) {

        $bookingStatus =
            (string) ($booking['status'] ?? '');


        if ($bookingStatus === 'Confirmed') {

            $confirmedBookings++;

        }


        if (
            $bookingStatus === 'New'
            || $bookingStatus === 'Departed'
            || $bookingStatus === 'In Makkah'
            || $bookingStatus === 'In Madinah'
            || $bookingStatus === 'Returning'
        ) {

            $pendingBookings++;

        }


        if ($bookingStatus === 'Cancelled') {

            $cancelledBookings++;

        }


        $totalRevenue +=
            (float) ($booking['gross_total'] ?? 0);


        $balanceDue +=
            (float) ($booking['balance_due'] ?? 0);

    }


    /*
     * =========================================================
     * RESPONSE
     * =========================================================
     */

    echo json_encode([

        'success' => true,

        'data' => $bookings,

        'statistics' => [

            'totalBookings' =>
                $totalBookings,

            'confirmedBookings' =>
                $confirmedBookings,

            'pendingBookings' =>
                $pendingBookings,

            'cancelledBookings' =>
                $cancelledBookings,

            'totalRevenue' =>
                round(
                    $totalRevenue,
                    2
                ),

            'balanceDue' =>
                round(
                    $balanceDue,
                    2
                )

        ]

    ], JSON_UNESCAPED_UNICODE);


} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([

        'success' => false,

        'message' =>
            $e->getMessage(),

        'data' => [],

        'statistics' => [

            'totalBookings' => 0,

            'confirmedBookings' => 0,

            'pendingBookings' => 0,

            'cancelledBookings' => 0,

            'totalRevenue' => 0,

            'balanceDue' => 0

        ]

    ]);

}