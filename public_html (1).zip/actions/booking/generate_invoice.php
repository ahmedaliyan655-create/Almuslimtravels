<?php

require_once "../../includes/db.php";
require_once "../../includes/functions.php";
require_once "../../includes/session.php";

header("Content-Type: application/json");

try {

    /*
    |--------------------------------------------------------------------------
    | Validate Request
    |--------------------------------------------------------------------------
    */

    if (empty($_POST['project_id'])) {

        jsonResponse(false, "Project is required.");

        exit;
    }

    $projectId = (int)$_POST['project_id'];

    /*
    |--------------------------------------------------------------------------
    | Get Project Code
    |--------------------------------------------------------------------------
    */

    $project = Database::selectOne(
        "
        SELECT
            id,
            project_code
        FROM projects
        WHERE id = ?
        LIMIT 1
        ",
        [$projectId]
    );

    if (!$project) {

        jsonResponse(false, "Project not found.");

        exit;
    }

    $prefix = strtoupper(trim($project['project_code']));

    /*
    |--------------------------------------------------------------------------
    | NEXT PROJECT-BASED INVOICE PREVIEW
    |--------------------------------------------------------------------------
    | Final numbering is assigned atomically by save_booking.php. This endpoint
    | only previews the next number and does not reserve/consume it.
    */
    $prefix = strtoupper(trim((string)$project['project_code']));

    if ($prefix === '') {
        jsonResponse(false, 'Project does not have a project code.');
        exit;
    }

    $maxStmt = $pdo->prepare(
        "SELECT COALESCE(MAX(CAST(SUBSTRING(invoice_no, ?) AS UNSIGNED)), 0)
         FROM bookings
         WHERE project_id = ?
           AND invoice_no REGEXP CONCAT('^', ?, '[0-9]+$')"
    );
    $maxStmt->execute([strlen($prefix) + 1, $projectId, $prefix]);
    $number = ((int)$maxStmt->fetchColumn()) + 1;
    $invoice = $prefix . str_pad((string)$number, 3, '0', STR_PAD_LEFT);

    /*
    |--------------------------------------------------------------------------
    | Response
    |--------------------------------------------------------------------------
    */

    jsonResponse(
        true,
        "",
        [
            "invoice_prefix" => $prefix,
            "invoice_number" => $number,
            "invoice_no"     => $invoice
        ]
    );

} catch (Exception $e) {

    jsonResponse(false, $e->getMessage());

}