<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../includes/db.php';

try {

    $projectId = isset($_GET['project_id']) ? (int) $_GET['project_id'] : 0;

    $currentAgentId = !empty($_SESSION['agent_id'])
        ? (int) $_SESSION['agent_id']
        : 0;

    if ($currentAgentId <= 0) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Your session has expired. Please login again.',
            'data' => []
        ]);
        exit;
    }

    $userStmt = $pdo->prepare("
        SELECT id, role, is_active
        FROM agents
        WHERE id = ?
        LIMIT 1
    ");
    $userStmt->execute([$currentAgentId]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentUser || (int) $currentUser['is_active'] !== 1) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'You are not allowed to load agents.',
            'data' => []
        ]);
        exit;
    }

    $role = strtolower(trim((string) ($currentUser['role'] ?? 'agent')));

    /*
     * Normal agents never need an Agent filter. The UI hides it,
     * and the endpoint also refuses to expose other agents.
     */
    if ($role === 'agent') {
        echo json_encode([
            'success' => true,
            'data' => []
        ]);
        exit;
    }

    /*
     * Team Lead:
     * Return only agents who:
     *   1. belong to this Team Lead, AND
     *   2. are assigned to the selected project.
     *
     * This prevents a Team Lead from seeing another team's agent
     * even when that agent happens to be assigned to the same project.
     */
    if ($role === 'teamlead') {

        if ($projectId <= 0) {
            echo json_encode([
                'success' => true,
                'data' => []
            ]);
            exit;
        }

        $stmt = $pdo->prepare("
            SELECT DISTINCT
                a.id,
                a.agent_code,
                a.name,
                a.email,
                a.role
            FROM agents a

            INNER JOIN agent_projects ap
                ON ap.agent_id = a.id
               AND ap.project_id = ?

            WHERE a.role = 'agent'
              AND a.team_lead_id = ?
              AND a.is_active = 1

            ORDER BY a.name ASC
        ");

        $stmt->execute([
            $projectId,
            $currentAgentId
        ]);

        echo json_encode([
            'success' => true,
            'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
        ]);
        exit;
    }

    /*
     * Admin / Manager:
     * With a project selected, return agents assigned to that project.
     * With no project selected, return all active agents.
     */
    if (in_array($role, ['admin', 'manager', 'administrator'], true)) {

        if ($projectId > 0) {

            $stmt = $pdo->prepare("
                SELECT DISTINCT
                    a.id,
                    a.agent_code,
                    a.name,
                    a.email,
                    a.role
                FROM agent_projects ap

                INNER JOIN agents a
                    ON a.id = ap.agent_id

                WHERE ap.project_id = ?
                  AND a.is_active = 1

                ORDER BY a.name ASC
            ");

            $stmt->execute([$projectId]);

        } else {

            $stmt = $pdo->query("
                SELECT
                    id,
                    agent_code,
                    name,
                    email,
                    role
                FROM agents
                WHERE is_active = 1
                  AND role IN ('agent', 'teamlead')
                ORDER BY name ASC
            ");
        }

        echo json_encode([
            'success' => true,
            'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'data' => []
    ]);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to load agents.',
        'data' => []
    ]);
}
