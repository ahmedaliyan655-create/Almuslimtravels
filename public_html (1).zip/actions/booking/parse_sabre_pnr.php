<?php

require_once "../../includes/functions.php";

header("Content-Type: application/json");

try{

    if(empty($_POST['sabre'])){

        jsonResponse(false,"Sabre PNR is empty.");

        exit;

    }

    $text=trim($_POST['sabre']);

    $lines=preg_split("/\r\n|\n|\r/",$text);

    $passengers=[];

    $flights=[];

    /*
|--------------------------------------------------------------------------
| PASSENGERS
|--------------------------------------------------------------------------
*/

foreach ($lines as $line) {

    preg_match_all(
        '/(\d+)\.([A-Z]+)\/([A-Z]+)\s+(MR|MRS|MISS|MSTR|MS|DR)/i',
        $line,
        $matches,
        PREG_SET_ORDER
    );

    foreach ($matches as $m) {

        $passengers[] = [

            "title" => strtoupper($m[4]),

            "surname" => ucwords(strtolower($m[2])),

            "firstname" => ucwords(strtolower($m[3]))

        ];

    }

}

    /*
    |--------------------------------------------------------------------------
    | FLIGHTS
    |--------------------------------------------------------------------------
    |
    | Example
    |
    | 1 SV120 T 03SEP LHR JED 1440 2250
    |
    */

    foreach($lines as $line){

        $line=trim($line);

        if(

            preg_match(

                '/^\d+\s+([A-Z0-9]{2})\s*([0-9]{1,4})\s+[A-Z]\s+([0-9]{2}[A-Z]{3})\s+([A-Z]{3})\s+([A-Z]{3})\s+([0-9]{4})\s+([0-9]{4})/',

                $line,

                $m

            )

        ){

            $depart=$m[6];

            $arrive=$m[7];

            $depart=

                substr($depart,0,2).

                ":".

                substr($depart,2,2);

            $arrive=

                substr($arrive,0,2).

                ":".

                substr($arrive,2,2);

            $date=$m[3];

            $day=substr($date,0,2);

            $month=strtoupper(substr($date,2,3));

            $months=[

                "JAN"=>"01",

                "FEB"=>"02",

                "MAR"=>"03",

                "APR"=>"04",

                "MAY"=>"05",

                "JUN"=>"06",

                "JUL"=>"07",

                "AUG"=>"08",

                "SEP"=>"09",

                "OCT"=>"10",

                "NOV"=>"11",

                "DEC"=>"12"

            ];

            $monthNo=$months[$month] ?? "01";

            $year=date("Y");

            $formattedDate=

                $year

                ."-"

                .$monthNo

                ."-"

                .$day;

            $flights[]=[

                "airline"=>$m[1],

                "flight"=>$m[2],

                "date"=>$formattedDate,

                "origin"=>$m[4],

                "destination"=>$m[5],

                "depart"=>$depart,

                "arrive"=>$arrive,

                "baggage"=>""

            ];

        }

    }

    jsonResponse(

        true,

        "",

        [

            "passengers"=>$passengers,

            "flights"=>$flights

        ]

    );

}catch(Exception $e){

    jsonResponse(false,$e->getMessage());

}