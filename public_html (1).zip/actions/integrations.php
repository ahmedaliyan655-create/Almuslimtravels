<?php
require_once '../includes/auth.php';
requireLogin();
require_once '../includes/db.php';
header('Content-Type: application/json; charset=utf-8');
function res($ok, $msg = '', $data = [])
{
    echo json_encode(['success' => $ok, 'message' => $msg, 'data' => $data]);
    exit;
}
try {
    $d = $_POST ?: ($_GET ?: (json_decode(file_get_contents('php://input'), true) ?: []));
    $action = $d['action'] ?? '';
    if ($action === 'logs') {
        res(true, '', ['logs' => Database::select('SELECT il.*,l.lead_id,l.name FROM integration_logs il LEFT JOIN leads l ON l.id=il.lead_id ORDER BY il.id DESC LIMIT 100')]);
    }
    if ($action === 'import_json') {
        $raw = trim((string)($d['payload'] ?? ''));
        $items = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) res(false, 'Invalid JSON — check format.');
        if (!is_array($items)) $items = [$items];
        $created = 0;
        $duplicates = 0;
        $errors = [];
        foreach ($items as $item) {
            $item = is_array($item) ? $item : [];
            $name = trim((string)($item['name'] ?? $item['full_name'] ?? ''));
            $phone = trim((string)($item['phone'] ?? $item['phone_number'] ?? $item['mobile'] ?? ''));
            $email = trim((string)($item['email'] ?? ''));
            if ($name === '') {
                $errors[] = 'A record is missing name';
                continue;
            }
            $dup = $phone !== '' ? Database::selectOne('SELECT id FROM leads WHERE phone=? LIMIT 1', [$phone]) : ($email !== '' ? Database::selectOne('SELECT id FROM leads WHERE email=? LIMIT 1', [$email]) : false);
            if ($dup) {
                $duplicates++;
                Database::insert("INSERT INTO integration_logs(source,raw_payload,lead_id,status,error_msg,ip_address) VALUES('json_import',?,?, 'duplicate',?,?)", [json_encode($item), $dup['id'], 'Duplicate lead', $_SERVER['REMOTE_ADDR'] ?? null]);
                continue;
            }
            $lead = Database::insert("INSERT INTO leads(lead_id,name,phone,whatsapp,email,service_type,source,campaign,travel_month,adults,youth,children,infants,budget,priority,status,assigned_to,follow_up_date,message,notes,enquiry_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ['LED-' . random_int(10000, 99999), $name, $phone, (string)($item['whatsapp'] ?? $phone), $email, (string)($item['service'] ?? 'Umrah'), (string)($item['source'] ?? 'Facebook Ads'), (string)($item['campaign'] ?? $item['ad_name'] ?? ''), (string)($item['travel_month'] ?? ''), (int)($item['adults'] ?? 1), (int)($item['youth'] ?? 0), (int)($item['children'] ?? 0), (int)($item['infants'] ?? 0), ($item['budget'] ?? '') !== '' ? (float)$item['budget'] : null, (string)($item['priority'] ?? 'Warm'), 'New Lead', null, ($item['follow_up_date'] ?? null), (string)($item['message'] ?? ''), (string)($item['notes'] ?? ''), date('Y-m-d')]);
            Database::insert("INSERT INTO lead_activity_log(lead_id,log_text,log_type,logged_by,logged_by_name) VALUES(?,?,?,?,?)", [$lead, 'Imported via JSON', 'note', authId(), authName()]);
            Database::insert("INSERT INTO integration_logs(source,raw_payload,lead_id,status,ip_address) VALUES('json_import',?,?, 'success',?)", [json_encode($item), $lead, $_SERVER['REMOTE_ADDR'] ?? null]);
            $created++;
        }
        res(true, "$created lead(s) imported; $duplicates duplicate(s).", ['created' => $created, 'duplicates' => $duplicates, 'errors' => $errors]);
    }
    if ($action === 'import_csv') {
        $raw = (string)($d['payload'] ?? '');
        $fp = fopen('php://temp', 'r+');
        fwrite($fp, $raw);
        rewind($fp);
        $headers = fgetcsv($fp);
        if (!$headers || count($headers) < 1) res(false, 'CSV header row is required.');
        $headers = array_map(fn($h) => strtolower(trim((string)$h)), $headers);
        $items = [];
        while (($row = fgetcsv($fp)) !== false) {
            if (count(array_filter($row, fn($v) => trim((string)$v) !== '')) === 0) continue;
            $items[] = array_combine(array_pad($headers, count($row), ''), array_pad($row, count($headers), ''));
        }
        fclose($fp);
        $json = json_encode($items);
        $_POST = ['action' => 'import_json', 'payload' => $json];
        $d = $_POST; // fall through using same routine
        $created = 0;
        $duplicates = 0;
        $errors = [];
        foreach ($items as $item) {
            $name = trim((string)($item['name'] ?? $item['full_name'] ?? ''));
            $phone = trim((string)($item['phone'] ?? $item['phone_number'] ?? $item['mobile'] ?? ''));
            $email = trim((string)($item['email'] ?? ''));
            if ($name === '') {
                $errors[] = 'Missing name';
                continue;
            }
            $dup = $phone !== '' ? Database::selectOne('SELECT id FROM leads WHERE phone=? LIMIT 1', [$phone]) : false;
            if ($dup) {
                $duplicates++;
                continue;
            }
            $lead = Database::insert("INSERT INTO leads(lead_id,name,phone,whatsapp,email,service_type,source,campaign,travel_month,adults,youth,children,infants,budget,priority,status,assigned_to,follow_up_date,message,notes,enquiry_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ['LED-' . random_int(10000, 99999), $name, $phone, $phone, $email, $item['service'] ?? 'Umrah', $item['source'] ?? 'Facebook Ads', $item['campaign'] ?? $item['ad_name'] ?? '', $item['travel_month'] ?? '', (int)($item['adults'] ?? 1), 0, (int)($item['children'] ?? 0), (int)($item['infants'] ?? 0), ($item['budget'] ?? '') !== '' ? (float)$item['budget'] : null, 'Warm', 'New Lead', null, null, $item['message'] ?? $item['notes'] ?? '', '', date('Y-m-d')]);
            Database::insert("INSERT INTO integration_logs(source,raw_payload,lead_id,status,ip_address) VALUES('csv_import',?,?, 'success',?)", [json_encode($item), $lead, $_SERVER['REMOTE_ADDR'] ?? null]);
            $created++;
        }
        res(true, "$created lead(s) imported; $duplicates duplicate(s).", ['created' => $created, 'duplicates' => $duplicates, 'errors' => $errors]);
    }
    if ($action === 'url_lead') {
        $d['source'] = $d['source'] ?? 'Website Form';
        $name = trim((string)($d['name'] ?? $d['full_name'] ?? ''));
        if ($name === '') res(false, 'Name is required.');
        $lead = Database::insert("INSERT INTO leads(lead_id,name,phone,whatsapp,email,service_type,source,campaign,travel_month,adults,youth,children,infants,budget,priority,status,enquiry_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ['LED-' . random_int(10000, 99999), $name, (string)($d['phone'] ?? ''), (string)($d['whatsapp'] ?? $d['phone'] ?? ''), (string)($d['email'] ?? ''), (string)($d['service'] ?? 'Umrah'), (string)$d['source'], (string)($d['campaign'] ?? ''), (string)($d['travel_month'] ?? ''), (int)($d['adults'] ?? 1), (int)($d['youth'] ?? 0), (int)($d['children'] ?? 0), (int)($d['infants'] ?? 0), ($d['budget'] ?? '') !== '' ? (float)$d['budget'] : null, 'Warm', 'New Lead', date('Y-m-d')]);
        res(true, 'Lead received.', ['id' => $lead]);
    }
    res(false, 'Unknown integration action.');
} catch (Throwable $e) {
    http_response_code(500);
    res(false, $e->getMessage());
}
