<?php

declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/notifications.php';
header('Content-Type: application/json; charset=utf-8');
function njson(bool $ok, string $msg = '', array $data = [], int $code = 200): never
{
  http_response_code($code);
  echo json_encode(['success' => $ok, 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
  exit;
}
try {
  $uid = (int)authId();
  $role = strtolower((string)authRole());
  notificationsEnsureSchema();
  $action = strtolower((string)($_POST['action'] ?? $_GET['action'] ?? 'list'));
  syncSystemNotifications($uid, $role);
  if ($action === 'count') njson(true, '', ['unread' => notificationsUnreadCount($uid)]);
  if ($action === 'list') {
    $category = trim((string)($_GET['category'] ?? $_POST['category'] ?? 'all'));
    $unread = (int)($_GET['unread'] ?? $_POST['unread'] ?? 0);
    $search = trim((string)($_GET['search'] ?? $_POST['search'] ?? ''));
    $page = max(1, (int)($_GET['page'] ?? $_POST['page'] ?? 1));
    $perPage = min(50, max(10, (int)($_GET['per_page'] ?? $_POST['per_page'] ?? 20)));
    $offset = ($page - 1) * $perPage;
    $where = ['user_id=?', 'archived_at IS NULL'];
    $params = [$uid];
    if ($category !== '' && $category !== 'all') {
      $where[] = 'category=?';
      $params[] = $category;
    }
    if ($unread === 1) {
      $where[] = 'is_read=0';
    }
    if ($search !== '') {
      $where[] = '(title LIKE ? OR message LIKE ?)';
      $params[] = '%' . $search . '%';
      $params[] = '%' . $search . '%';
    }
    $whereSql = implode(' AND ', $where);
    $total = (int)(Database::selectOne("SELECT COUNT(*) c FROM notifications WHERE $whereSql", $params)['c'] ?? 0);
    $rows = Database::select("SELECT id,type,category,title,message,priority,entity_type,entity_id,action_url,is_read,read_at,created_at FROM notifications WHERE $whereSql ORDER BY is_read ASC, created_at DESC LIMIT $perPage OFFSET $offset", $params);
    njson(true, '', ['notifications' => $rows, 'pagination' => ['page' => $page, 'per_page' => $perPage, 'total' => $total, 'pages' => $total ? ceil($total / $perPage) : 0], 'unread' => notificationsUnreadCount($uid)]);
  }
  $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
  if ($action === 'read') {
    if ($id <= 0) njson(false, 'Invalid notification.', [], 400);
    Database::update("UPDATE notifications SET is_read=1,read_at=COALESCE(read_at,NOW()) WHERE id=? AND user_id=? AND archived_at IS NULL", [$id, $uid]);
    njson(true, 'Notification marked as read.', ['unread' => notificationsUnreadCount($uid)]);
  }
  if ($action === 'unread') {
    if ($id <= 0) njson(false, 'Invalid notification.', [], 400);
    Database::update("UPDATE notifications SET is_read=0,read_at=NULL WHERE id=? AND user_id=? AND archived_at IS NULL", [$id, $uid]);
    njson(true, 'Notification marked as unread.', ['unread' => notificationsUnreadCount($uid)]);
  }
  if ($action === 'archive') {
    if ($id <= 0) njson(false, 'Invalid notification.', [], 400);
    Database::update("UPDATE notifications SET archived_at=NOW() WHERE id=? AND user_id=?", [$id, $uid]);
    njson(true, 'Notification archived.', ['unread' => notificationsUnreadCount($uid)]);
  }
  if ($action === 'mark_all_read') {
    Database::update("UPDATE notifications SET is_read=1,read_at=COALESCE(read_at,NOW()) WHERE user_id=? AND is_read=0 AND archived_at IS NULL", [$uid]);
    njson(true, 'All notifications marked as read.', ['unread' => 0]);
  }
  if ($action === 'archive_all') {
    Database::update("UPDATE notifications SET archived_at=NOW() WHERE user_id=? AND archived_at IS NULL", [$uid]);
    njson(true, 'Notifications archived.', ['unread' => 0]);
  }
  njson(false, 'Unknown notification action.', [], 400);
} catch (Throwable $e) {
  njson(false, 'Notification service unavailable.', [], 500);
}
