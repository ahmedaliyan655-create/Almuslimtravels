<?php
ob_start();
ob_clean();
require_once "includes/session.php";
require_once "includes/db.php";
require_once "includes/auth.php";

redirectIfLoggedIn();

$error = "";
$selectedEmail = "";

if (isset($_SESSION['login_error'])) {
    $error = $_SESSION['login_error'];
    unset($_SESSION['login_error']);
}

if (isset($_SESSION['login_selected_email'])) {
    $selectedEmail = $_SESSION['login_selected_email'];
    unset($_SESSION['login_selected_email']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CRM Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {

            height: 100vh;

            background: #005a5a;

            display: flex;
            justify-content: center;
            align-items: center;

            overflow: hidden;

        }

        .login-card {

            background: #fff;

            width: 100%;
            max-width: 430px;

            border-radius: 20px;

            padding: 40px 35px;

            box-shadow:
                0 15px 40px rgba(0, 0, 0, .25);

            animation: fade .7s;

        }

        @keyframes fade {

            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {

                opacity: 1;
                transform: translateY(0);

            }

        }


       .logo{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:18px;
    margin-bottom:30px;
}

.logo-img{
    width:100%;
    height:auto;
    display:block;
    object-fit:contain;
}

.company{
    display:flex;
    flex-direction:column;
    justify-content:center;
}

.company h2{
    margin:0;
    font-size:42px;
    line-height:1.05;
    font-weight:700;
    color:#14532d;
    font-family:Georgia, serif;
    letter-spacing:.4px;
}

.company p{
    margin-top:6px;
    font-size:15px;
    color:#8a6b39;
    font-style:italic;
    letter-spacing:.3px;
}

        .company h2 {

            margin: 0;
            font-size: 38px;
            font-weight: 700;

            color: #1d5c2f;

            font-family: Georgia, serif;

        }

        .company p {

            margin: 0;
            font-style: italic;
            color: #777;

            font-size: 14px;

        }

        .login-title {

            display: inline-block;

            padding: 8px 22px;

            background: #f5f5f5;

            border-radius: 8px;

            font-weight: 600;

            font-size: 15px;

            margin: 20px auto;

        }

        .form-label {

            font-size: 14px;
            font-weight: 600;
            color: #555;

        }

        .form-control,
        .form-select {
            height: 52px;
            border-radius: 10px;
            border: 1px solid #dfe5ea;
            padding: 0 14px;
        }

        .login-input-wrap {
            position: relative;
        }
        .login-input-wrap > i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7b8794;
            z-index: 2;
        }
        .login-email-input {
            padding-left: 44px !important;
        }
        .login-security-note {
            margin-top: 18px;
            text-align: center;
            color: #8a94a3;
            font-size: 11px;
        }

        .demo {

            background: #f8f9fa;

            border-radius: 8px;

            padding: 12px;

            font-size: 12px;

            color: #888;

            text-align: center;

            margin: 20px 0;

        }

        .btn-login {

            height: 55px;

            border-radius: 12px;

            background: #c4963a;

            font-size: 18px;

            font-weight: 600;

            color: #fff;

            transition: .3s;

        }

        .btn-login:hover {
            color: #fff;
            background: #005a5a;
            transform: translateY(-2px);

        }

        @media(max-width:768px) {

            .login-card {

                margin: 20px;

                padding: 30px 25px;

            }

            .company h2 {

                font-size: 30px;

            }

            .logo-circle {

                width: 60px;
                height: 60px;

            }

        }

        @media(max-width:450px) {

            .company h2 {

                font-size: 24px;

            }

            .company p {

                font-size: 12px;

            }

            .logo {

                flex-direction: column;

                gap: 10px;

            }

            .login-card {

                padding: 25px 20px;

            }

        }
    </style>

</head>

<body>

    <div class="login-card">

       <div class="logo">

    <img src="assets/images/login.webp" alt="CoreNex Solution" class="logo-img">

    <!-- <div class="company">
        <p>Have trust. We care for you!</p>
    </div> -->

</div>
        <div class="text-center">

            <span class="login-title">
                CRM Login
            </span>

        </div>
        <?php if($error!=""){ ?>
        <div class="alert alert-danger">

        <?= $error; ?>

        </div>

        <?php } ?>
        <form action="actions/auth/login.php" method="POST">

            <div class="mb-3">

                <label class="form-label" for="loginEmail">
                    Email Address
                </label>

                <div class="login-input-wrap">
                    <i class="fa-regular fa-envelope"></i>
                    <input
                        type="email"
                        class="form-control login-email-input"
                        id="loginEmail"
                        name="email"
                        value="<?= htmlspecialchars($selectedEmail, ENT_QUOTES, 'UTF-8'); ?>"
                        autocomplete="username"
                        required
                        placeholder="Enter your email address">
                </div>

            </div>

            <div class="mb-3">

                <label class="form-label" for="loginPin">
                    4-Digit PIN
                </label>

                <input
                    type="password"
                    class="form-control text-center"
                    id="loginPin"
                    name="pin"
                    inputmode="numeric"
                    pattern="[0-9]{4}"
                    maxlength="4"
                    autocomplete="current-password"
                    required
                    placeholder="Enter 4 digit PIN">

            </div>


            <div class="d-grid">

            <button
            type="submit"
            name="login"
            class="btn btn-login">

            <i class="fa-solid fa-lock me-2"></i>

            Login

            </button>

            </div>

        </form>

        <div class="login-security-note">
            <i class="fa-solid fa-shield-halved"></i>
            Secure staff login &nbsp;•&nbsp; Email + 4-digit PIN
        </div>

    </div>

</body>

</html>