<?php
declare(strict_types=1);
require_once __DIR__.'/includes/auth.php';
requireLogin();
require_once __DIR__.'/includes/db.php';
require_once __DIR__.'/includes/permissions.php';

if (!isManager() && !isAdmin() && strtolower((string)authRole()) !== 'administrator') {
    http_response_code(403);
    exit('Forbidden');
}

header('Content-Type: text/plain; charset=utf-8');

$changes = [];
$errors = [];
$pdo = Database::connection();

function tableExists(PDO $pdo, string $table): bool {
    $st = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');
    $st->execute([$table]);
    return (bool)$st->fetchColumn();
}
function columnExists(PDO $pdo, string $table, string $column): bool {
    $st = $pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?');
    $st->execute([$table, $column]);
    return (bool)$st->fetchColumn();
}
function indexExists(PDO $pdo, string $table, string $index): bool {
    $st = $pdo->prepare('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name=? AND index_name=?');
    $st->execute([$table, $index]);
    return (bool)$st->fetchColumn();
}
function runChange(PDO $pdo, string $sql, string $label, array &$changes, array &$errors): void {
    try { $pdo->exec($sql); $changes[] = $label; }
    catch (Throwable $e) { $errors[] = $label . ': ' . $e->getMessage(); }
}

try {
    // Missing workflow tables are created safely for older CRM databases.
    $tables = [
        'booking_delete_requests' => "CREATE TABLE IF NOT EXISTS booking_delete_requests (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            booking_id INT UNSIGNED NOT NULL,
            requester_id INT UNSIGNED NOT NULL,
            status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
            requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_by INT UNSIGNED NULL,
            reviewed_at DATETIME NULL,
            rejection_reason TEXT NULL,
            UNIQUE KEY uq_pending_delete (booking_id,requester_id,status),
            KEY idx_delete_status (status),
            KEY idx_delete_booking (booking_id),
            KEY idx_delete_requester (requester_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
        'booking_edit_requests' => "CREATE TABLE IF NOT EXISTS booking_edit_requests (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            booking_id INT UNSIGNED NOT NULL,
            requester_id INT UNSIGNED NOT NULL,
            status ENUM('Pending','Approved','Rejected','Used') NOT NULL DEFAULT 'Pending',
            requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_by INT UNSIGNED NULL,
            reviewed_at DATETIME NULL,
            rejection_reason TEXT NULL,
            used_at DATETIME NULL,
            KEY idx_edit_request_status (status),
            KEY idx_edit_request_booking (booking_id),
            KEY idx_edit_request_requester (requester_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
        'booking_alerts' => "CREATE TABLE IF NOT EXISTS booking_alerts (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            booking_id INT UNSIGNED NOT NULL,
            created_by INT UNSIGNED NOT NULL,
            alert_date DATE NOT NULL,
            seen_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_booking_alert_date (alert_date,seen_at),
            KEY idx_booking_alert_booking (booking_id),
            KEY idx_booking_alert_creator (created_by)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    ];
    foreach ($tables as $table => $sql) {
        if (!tableExists($pdo, $table)) runChange($pdo, $sql, "Created missing table $table", $changes, $errors);
    }

    if (!tableExists($pdo, 'notifications')) {
        runChange($pdo, "CREATE TABLE notifications (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            type VARCHAR(50) NOT NULL DEFAULT 'system',
            category VARCHAR(50) NOT NULL DEFAULT 'system',
            title VARCHAR(180) NOT NULL,
            message TEXT NOT NULL,
            priority ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',
            entity_type VARCHAR(50) NULL,
            entity_id INT UNSIGNED NULL,
            action_url VARCHAR(500) NULL,
            dedupe_key VARCHAR(191) NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            read_at DATETIME NULL,
            archived_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_notifications_user_read (user_id,is_read,created_at),
            INDEX idx_notifications_category (user_id,category,created_at),
            INDEX idx_notifications_entity (entity_type,entity_id),
            UNIQUE KEY uq_notifications_dedupe (dedupe_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci", 'Created notifications table', $changes, $errors);
    }

    if (!tableExists($pdo, 'project_invoice_sequences')) {
        runChange($pdo, "CREATE TABLE project_invoice_sequences (
            project_id INT UNSIGNED NOT NULL PRIMARY KEY,
            last_number INT UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci", 'Created project invoice sequence table', $changes, $errors);
    }

    // Service supplier fields.
    if (tableExists($pdo, 'booking_flights') && !columnExists($pdo, 'booking_flights', 'supplier')) {
        runChange($pdo, "ALTER TABLE booking_flights ADD COLUMN supplier VARCHAR(255) NULL AFTER baggage", 'Added flight supplier column', $changes, $errors);
    }
    if (tableExists($pdo, 'booking_hotels') && !columnExists($pdo, 'booking_hotels', 'hotel_supplier')) {
        runChange($pdo, "ALTER TABLE booking_hotels ADD COLUMN hotel_supplier VARCHAR(255) NULL AFTER confirmation_date", 'Added hotel supplier column', $changes, $errors);
    }
    if (tableExists($pdo, 'booking_passengers') && !columnExists($pdo, 'booking_passengers', 'visa_supplier')) {
        runChange($pdo, "ALTER TABLE booking_passengers ADD COLUMN visa_supplier VARCHAR(255) NULL AFTER visa_notes", 'Added visa supplier column', $changes, $errors);
    }
    if (tableExists($pdo, 'booking_transports') && !columnExists($pdo, 'booking_transports', 'supplier')) {
        runChange($pdo, "ALTER TABLE booking_transports ADD COLUMN supplier VARCHAR(255) NULL AFTER driver_mobile", 'Added transport supplier column', $changes, $errors);
    }
    if (tableExists($pdo, 'booking_products') && !columnExists($pdo, 'booking_products', 'supplier')) {
        runChange($pdo, "ALTER TABLE booking_products ADD COLUMN supplier VARCHAR(255) NULL AFTER product_type", 'Added additional product supplier column', $changes, $errors);
    }

    // Important index that the old dump could miss.
    if (tableExists($pdo, 'booking_delete_requests') && !indexExists($pdo, 'booking_delete_requests', 'idx_delete_requester')) {
        runChange($pdo, 'ALTER TABLE booking_delete_requests ADD KEY idx_delete_requester (requester_id)', 'Added delete requester index', $changes, $errors);
    }

    // Old installs sometimes had a different agent status column. This CRM uses is_active.
    if (tableExists($pdo, 'agents') && !columnExists($pdo, 'agents', 'is_active')) {
        runChange($pdo, "ALTER TABLE agents ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER default_project_id", 'Added agents.is_active', $changes, $errors);
    }

} catch (Throwable $e) {
    $errors[] = 'Upgrade failed: ' . $e->getMessage();
}

echo "Al Muslim Travel CRM upgrade complete\n\n";
echo 'Applied: ' . count($changes) . " change(s)\n";
if ($changes) echo "- " . implode("\n- ", $changes) . "\n";
if ($errors) {
    echo "\nErrors:\n- " . implode("\n- ", $errors) . "\n";
} else {
    echo "\nNo database errors detected.\n";
}
echo "\nDelete upgrade.php after successful deployment.\n";
