/*==================================================
    TOASTR CONFIGURATION
==================================================*/

toastr.options = {

    "closeButton": true,

    "progressBar": true,

    "newestOnTop": true,

    "positionClass": "toast-top-right",

    "preventDuplicates": true,

    "showDuration": "300",

    "hideDuration": "300",

    "timeOut": "3000",

    "extendedTimeOut": "1000",

    "showMethod": "fadeIn",

    "hideMethod": "fadeOut"

};