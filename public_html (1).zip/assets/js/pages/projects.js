/*==================================================
    AL MUSLIM TRAVEL CRM
    PROJECT MODULE
==================================================*/

let projectTable = null;

/*==================================================
    DOCUMENT READY
==================================================*/

$(function () {

    initProjectTable();

    bindEvents();

});

/*==================================================
    EVENTS
==================================================*/

function bindEvents() {

    /*
    -----------------------------------------
    Logo Preview
    -----------------------------------------
    */

    $("#projectLogo").on("change", function (e) {

        const file = e.target.files[0];

        if (!file) return;

        const reader = new FileReader();

        reader.onload = function (event) {

            $("#logoPreview").attr("src", event.target.result);

        };

        reader.readAsDataURL(file);

    });

}

/*==================================================
    DATATABLE
==================================================*/

function initProjectTable() {

    projectTable = $("#projectsTable").DataTable({

        processing: true,

        responsive: true,

        searching: true,

        paging: true,

        ordering: true,

        autoWidth: false,

        pageLength: 10,

        language: {

            emptyTable: "No projects found.",

            processing: "Loading Projects..."

        },

        columnDefs: [

    {

        orderable:false,

        targets:[1,6]

    }

]

    });

    loadProjects();

}

/*==================================================
    LOAD PROJECTS
==================================================*/

function loadProjects() {

    showLoading();

    $.ajax({

        url: "../actions/projects/list.php",

        type: "GET",

        dataType: "json",

        success: function (response) {

            hideLoading();

            if(response.success){

                renderProjects(response.data);

            }else{

                toastr.error("Something went wrong.");

            }

        },

        error:function(){

            hideLoading();

            toastr.warning("Project Data Not add yet.");

        }

    });

}

/*==================================================
    RENDER TABLE
==================================================*/

function renderProjects(data){

    projectTable.clear();

    $("#totalProjectBadge").text(data.length + " Projects");

    $("#totalProjects").text(data.length);

    let active = 0;

    let websites = 0;

    let revenue = 0;

    if(data.length===0){

        projectTable.draw();

        return;

    }

    $.each(data,function(index,row){

        if(row.active){

            active++;

        }

        if(row.website_count){

            websites++;

        }

        revenue += Number(row.revenue);

       projectTable.row.add([

            index + 1,

            row.logo,

            row.project_name,

            row.project_code,

            row.website,

            row.status,

            row.actions

        ]);

    });

    projectTable.draw(false);

    $("#activeProjects").text(active);

    $("#websiteProjects").text(websites);

    $("#projectRevenue").text("£"+numberFormat(revenue));

}

/*==================================================
    REFRESH
==================================================*/

function refreshProjects(){

    loadProjects();

}

/*==================================================
    LOADING
==================================================*/

function showLoading(){

    if($("#projectLoading").length) return;

    $("#projectsTable_wrapper").append(

        '<div id="projectLoading" class="text-center py-4">'+

        '<div class="spinner-border text-primary"></div>'+

        '<div class="mt-2">Loading Projects...</div>'+

        '</div>'

    );

}

function hideLoading(){

    $("#projectLoading").remove();

}

/*==================================================
    FORMAT NUMBER
==================================================*/

function numberFormat(value){

    return Number(value).toLocaleString();

}

/*==================================================
    ALERT
==================================================*/

function showError(message){

    toastr.error("Something went wrong.");

}
/*==================================================
    SAVE PROJECT
==================================================*/

$("#projectForm").on("submit", function (e) {

    e.preventDefault();
    let url = $("#project_id").val() === ""
    ? "../actions/projects/create.php"
    : "../actions/projects/update.php";
    let projectName = $("#project_name").val().trim();
    let projectCode = $("#project_code").val().trim();

    if (projectName == "") {

        toastr.error("Please enter Project Name.");

        $("#project_name").focus();

        return;

    }

    if (projectCode == "") {

        toastr.error("Please enter Project Code.");

        $("#project_code").focus();

        return;

    }

    let formData = new FormData(this);

    $("#btnSaveProject")
        .prop("disabled", true)
        .html('<i class="fa fa-spinner fa-spin me-2"></i> Saving...');

    $.ajax({

        url: url,

        type: "POST",

        data: formData,

        processData: false,

        contentType: false,

        dataType: "json",

        success: function (response) {

            $("#btnSaveProject")
                .prop("disabled", false)
                .html('<i class="fa-solid fa-floppy-disk me-2"></i> Save Project');

            if (response.success) {

                toastr.success(response.message);

                $("#projectForm")[0].reset();

                $("#project_id").val("");

                $("#logoPreview").attr(
                    "src",
                    "https://placehold.co/180x180?text=Logo"
                );

                refreshProjects();

            } else {

                alert(response.message);

            }

        },

        error: function () {

            $("#btnSaveProject")
                .prop("disabled", false)
                .html('<i class="fa-solid fa-floppy-disk me-2"></i> Save Project');

            toastr.error("Unable to save project");

        }

    });

});


/*==================================================
    RESET FORM
==================================================*/

$("#btnResetProject").click(function () {

    $("#projectForm")[0].reset();

    $("#project_id").val("");

    $("#logoPreview").attr(
        "src",
        "https://placehold.co/180x180?text=Logo"
    );

    $("#btnSaveProject")
        .html('<i class="fa-solid fa-floppy-disk me-2"></i> Save Project');

});


/*==================================================
    EDIT BUTTON
==================================================*/

$(document).on("click", ".btnEdit", function () {

    let id = $(this).data("id");

    loadProject(id);

});


/*==================================================
    LOAD SINGLE PROJECT
==================================================*/

function loadProject(id) {

    $.ajax({

        url: "../actions/projects/get.php",

        type: "GET",

        data: {

            id: id

        },

        dataType: "json",

        success: function (response) {

            if (response.success) {

                fillProjectForm(response.data);

            } else {

                toastr.error(response.message);

            }

        },

        error: function () {

           toastr.error("Unable to load project.");

        }

    });

}


/*==================================================
    FILL FORM
==================================================*/

function fillProjectForm(data) {

    $("#project_id").val(data.id);

    $("#project_name").val(data.project_name);

    $("#project_code").val(data.project_code);

    $("#website").val(data.website);

    $("#notes").val(data.notes);

    $("#status").val(data.status);

    if (data.logo !== "") {

    $("#logoPreview").attr(
        "src",
        "../uploads/" + data.logo
    );

} else {

    $("#logoPreview").attr(
        "src",
        "https://placehold.co/180x180?text=Logo"
    );

}

    $("#btnSaveProject").html(

        '<i class="fa-solid fa-pen me-2"></i> Update Project'

    );

    $("html,body").animate({

        scrollTop: $("#projectForm").offset().top - 80

    }, 400);

}
/*==================================================
    DELETE PROJECT
==================================================*/

$(document).on("click", ".btnDelete", function () {

    let id = $(this).data("id");

    if (!confirm("Are you sure you want to delete this project?")) {
        return;
    }

    $.ajax({

        url: "../actions/projects/delete.php",

        type: "POST",

        data: {
            id: id
        },

        dataType: "json",

        success: function (response) {

            if (response.success) {

                toastr.success(response.message);

                refreshProjects();

            } else {

                 toastr.error("Unable to delete project.");

            }

        },

        error: function () {

        toastr.error("Unable to delete project.");
        }

    });

});


/*==================================================
    VIEW PROJECT
==================================================*/

$(document).on("click", ".btnView", function () {

    let id = $(this).data("id");

    $.ajax({

        url: "../actions/projects/get.php",

        type: "GET",

        data: {
            id: id
        },

        dataType: "json",

        success: function (response) {

            if (!response.success) {

                alert(response.message);

                return;

            }

            let p = response.data;

            let html = "";

            html += "<b>Project Name:</b> " + p.project_name + "<br><br>";

            html += "<b>Project Code:</b> " + p.project_code + "<br><br>";

            html += "<b>Website:</b> " + p.website + "<br><br>";

            html += "<b>Status:</b> ";

            html += p.status == 1 ? "Active" : "Inactive";

            alert(html);

        }

    });

});


/*==================================================
    CANCEL EDIT
==================================================*/

$("#btnCancel").click(function () {

    $("#projectForm")[0].reset();

    $("#project_id").val("");

    $("#logoPreview").attr(

        "src",

        "https://placehold.co/180x180?text=Logo"

    );

    $("#btnSaveProject").html(

        '<i class="fa-solid fa-floppy-disk me-2"></i> Save Project'

    );

});


/*==================================================
    RELOAD
==================================================*/

function reloadProjects(){

    if(projectTable){

        projectTable.ajax.reload(null,false);

    }else{

        refreshProjects();

    }

}


/*==================================================
    UPDATE DASHBOARD
==================================================*/

function updateDashboard(data){

    $("#totalProjects").text(data.total);

    $("#activeProjects").text(data.active);

    $("#websiteProjects").text(data.websites);

    $("#projectRevenue").text("£"+numberFormat(data.revenue));

}


/*==================================================
    SUCCESS MESSAGE
==================================================*/

function successMessage(message){

    alert(message);

}


/*==================================================
    ERROR MESSAGE
==================================================*/

function errorMessage(message){

    alert(message);

}


/*==================================================
    IMAGE RESET
==================================================*/

function resetLogo(){

    $("#logoPreview").attr(

        "src",

        "https://placehold.co/180x180?text=Logo"

    );

}


/*==================================================
    CLEAR FORM
==================================================*/

function clearProjectForm(){

    $("#projectForm")[0].reset();

    $("#project_id").val("");

    resetLogo();

    $("#btnSaveProject").html(

        '<i class="fa-solid fa-floppy-disk me-2"></i> Save Project'

    );

}


/*==================================================
    AUTO REFRESH
==================================================*/

setInterval(function(){

    refreshProjects();

},300000);


/*==================================================
    END
==================================================*/
