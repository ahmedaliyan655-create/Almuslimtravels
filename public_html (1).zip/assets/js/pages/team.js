/*==================================================
    TEAM MODULE
==================================================*/

let teamModal = new bootstrap.Modal(
    document.getElementById("teamModal")
);

let deleteModal = new bootstrap.Modal(
    document.getElementById("deleteTeamModal")
);

/*==================================================
    INITIALIZE
==================================================*/

$(document).ready(function(){

    loadTeams();

    if($("#team_lead_id").length){

        loadTeamLeads();

    }else{

        loadAgents();

    }

});
/*==================================================
    OPEN CREATE MODAL
==================================================*/

$("#btnCreateTeam").click(function () {

    resetTeamForm();
    if($("#team_lead_id").length){

        loadTeamLeads();

    }
    $("#modalTitle").text("Create Team");

    $("#btnSaveTeam")
        .html('<i class="fa fa-save me-2"></i> Save Team');

    teamModal.show();

});

/*==================================================
    RESET FORM
==================================================*/

function resetTeamForm(){

    $("#teamForm")[0].reset();

    $("#team_id").val("");

    $("#agentContainer").html("");

    $("#modalTitle").text("Create Team");
    $("#selectedCount").text("0 Selected");

    $("#searchAgent").val("");

    $("#agentContainer").html("");

    $("#btnSaveTeam")
        .html('<i class="fa fa-save me-2"></i> Save Team');

    if($("#team_lead_id").length){

        $("#team_lead_id").val("");

        loadTeamLeads();

    }else{

        loadAgents();

    }

}

/*==================================================
    LOAD AGENTS
==================================================*/

function loadAgents(teamLeadId = "") {

    $.ajax({

        url: "../actions/team/agents.php",

        type: "GET",

        data: {

            team_lead_id: teamLeadId

        },

        dataType: "json",

        success: function (response) {

            if (!response.success) {

                toastr.error(response.message);

                return;

            }

            renderAgents(response.data);

        },

        error: function () {

            toastr.error("Unable to load agents.");

        }

    });

}

/*==================================================
    RENDER AGENTS
==================================================*/

/*==================================================
    RENDER AGENTS
==================================================*/

function renderAgents(data) {

    let html = "";

    $.each(data, function (i, row) {

        html += `

        <div class="col-lg-4 col-md-6 mb-3 agent-item">

            <label class="agent-box">

                <input
                    type="checkbox"
                    hidden
                    name="members[]"
                    value="${row.id}">

                <div class="agent-card">

                    <img
                        src="${row.image}"
                        class="agent-avatar">

                    <h6>

                        ${row.name}

                    </h6>

                    <small>

                        ${row.designation}

                    </small>

                </div>

            </label>

        </div>

        `;

    });

    $("#agentContainer").html(html);

}
/*==================================================
    SELECT AGENT
==================================================*/

$(document).on("click", ".agent-box", function () {

    let checkbox = $(this).find("input");

    checkbox.prop("checked", !checkbox.prop("checked"));

    $(this).toggleClass("selected", checkbox.is(":checked"));

    $("#selectedCount").text(

        $("input[name='members[]']:checked").length +

        " Selected"

    );

});
/*==================================================
    SAVE TEAM
==================================================*/

$("#teamForm").on("submit", function (e) {

    e.preventDefault();

    if ($("#team_name").val().trim() == "") {

        toastr.error("Please enter Team Name.");

        $("#team_name").focus();

        return;

    }

    if ($("#monthly_target").val() == "") {

        toastr.error("Please enter Monthly Target.");

        $("#monthly_target").focus();

        return;

    }

    if ($("input[name='members[]']:checked").length == 0) {

        toastr.error("Please select at least one team member.");

        return;

    }

    let formData = new FormData(this);

    let url = $("#team_id").val() == ""
        ? "../actions/team/create.php"
        : "../actions/team/update.php";

    $("#btnSaveTeam")
        .prop("disabled", true)
        .html('<i class="fa fa-spinner fa-spin me-2"></i> Saving...');

    $.ajax({

        url: url,

        type: "POST",

        data: formData,

        processData: false,

        contentType: false,

        dataType: "json",

        success: function (response) {

            $("#btnSaveTeam")
                .prop("disabled", false)
                .html('<i class="fa fa-save me-2"></i> Save Team');

            if (response.success) {

                toastr.success(response.message);

                teamModal.hide();

                resetTeamForm();

                loadTeams();

            } else {

                toastr.error(response.message);

            }

        },

        error: function (xhr) {

            $("#btnSaveTeam")
                .prop("disabled", false)
                .html('<i class="fa fa-save me-2"></i> Save Team');

            console.log(xhr.responseText);

            toastr.error("Unable to save team.");

        }

    });

});


/*==================================================
    LOAD TEAMS
==================================================*/

/*==================================================
    LOAD TEAMS
==================================================*/

function loadTeams() {

    $("#teamContainer").html(

        '<div class="col-12 text-center py-5">' +

        '<div class="spinner-border text-primary"></div>' +

        '<div class="mt-3">Loading Teams...</div>' +

        '</div>'

    );

    $.ajax({

        url: "../actions/team/list.php",

        type: "GET",

        dataType: "json",

        success: function (response) {

            if (!response.success) {

                toastr.error(response.message);

                return;

            }

            renderTeams(response.data.teams);

            updateStats(response.data.stats);

        },

        error: function () {

            toastr.error("Unable to load teams.");

        }

    });

}


/*==================================================
    UPDATE STATISTICS
==================================================*/

function updateStats(stats) {

    $("#totalTeams").text(stats.totalTeams);

    $("#totalAgents").text(stats.totalAgents);

    $("#monthlyTarget").text(stats.monthlyTarget);

    $("#bonusEarned").text(stats.bonusEarned);

}


/*==================================================
    RENDER TEAM CARDS
==================================================*/

function renderTeams(data) {

    if (data.length == 0) {

        $("#teamContainer").html("");

        $("#emptyTeams").show();

        return;

    }

    $("#emptyTeams").hide();

    let html = "";

    $.each(data, function (i, team) {

        html += team.card;

    });

    $("#teamContainer").html(html);

}


/*==================================================
    REFRESH
==================================================*/

function refreshTeams() {

    loadTeams();

}
/*==================================================
    EDIT TEAM
==================================================*/

$(document).on("click", ".btnEditTeam", function () {

    let id = $(this).data("id");

    $.ajax({

        url: "../actions/team/get.php",

        type: "GET",

        data: {
            id: id
        },

        dataType: "json",

        success: function (response) {

            if (!response.success) {

                toastr.error(response.message);

                return;

            }

            let team = response.data;

            resetTeamForm();

            $("#modalTitle").text("Update Team");

            $("#btnSaveTeam")
                .html('<i class="fa fa-save me-2"></i> Update Team');

            $("#team_id").val(team.id);

            $("#team_name").val(team.team_name);

            $("#monthly_target").val(team.monthly_target);

            $("#work_type").val(team.work_type);

            /*
            ----------------------------------------
            Team Lead
            ----------------------------------------
            */

            $("#team_lead_id")
                .val(team.team_lead_id)
                .trigger("change");

            /*
            ----------------------------------------
            Wait until agents are loaded
            ----------------------------------------
            */

           $("#team_lead_id").val(team.team_lead_id);

            loadAgents(team.team_lead_id);

            setTimeout(function () {

                $.each(team.members, function (i, id) {

                    let checkbox = $('input[name="members[]"][value="' + id + '"]');

                    checkbox.prop("checked", true);

                    checkbox.closest(".agent-box").addClass("selected");

                });

            }, 300);

            teamModal.show();

        },

        error: function () {

            toastr.error("Unable to load team.");

        }

    });

});


/*==================================================
    DELETE BUTTON
==================================================*/

let deleteTeamId = 0;

$(document).on("click", ".btnDeleteTeam", function () {

    deleteTeamId = $(this).data("id");

    deleteModal.show();

});


/*==================================================
    CONFIRM DELETE
==================================================*/

$("#btnDeleteTeam").click(function () {

    $.ajax({

        url: "../actions/team/delete.php",

        type: "POST",

        data: {
            id: deleteTeamId
        },

        dataType: "json",

        success: function (response) {

            if (response.success) {

                toastr.success(response.message);

                deleteModal.hide();
                deleteTeamId = 0;
                loadTeams();

            } else {

                toastr.error(response.message);

            }

        },

        error: function () {

            toastr.error("Unable to delete team.");

        }

    });

});


/*==================================================
    VIEW TEAM DETAILS
==================================================*/

$(document).on("click", ".btnViewTeam", function () {

    let id = $(this).data("id");

    window.location =
        "team-details.php?id=" + id;

});


/*==================================================
    TEAM LEAD CHANGE
==================================================*/

$(document).on("change","#team_lead_id",function(){

    let id=$(this).val();

    if(id==""){

        $("#agentContainer").html("");

        return;

    }

    loadAgents(id);

});


/*==================================================
    LOAD AGENTS OF TEAM LEAD
==================================================*/

// function loadAgents(teamLeadId=""){

//     $.ajax({

//         url:"../actions/team/agents.php",

//         type:"GET",

//         data:{
//             team_lead_id:teamLeadId
//         },

//         dataType:"json",

//         success:function(response){

//             if(!response.success){

//                 toastr.error(response.message);

//                 return;

//             }

//             renderAgents(response.data);

//         }

//     });

// }
/*==================================================
    LOAD TEAM LEADS
==================================================*/

function loadTeamLeads(){

    $.ajax({

        url:"../actions/team/teamleads.php",

        type:"GET",

        dataType:"json",

        success:function(response){

            if(!response.success){

                toastr.error(response.message);

                return;

            }

            let html='<option value="">Select Team Lead</option>';

            $.each(response.data,function(i,row){

                html+=`

                <option value="${row.id}">

                    ${row.name}

                </option>

                `;

            });

            $("#team_lead_id").html(html);

        }

    });

}
$(document).on("keyup", "#teamSearch", function () {

    let value = $(this).val().toLowerCase();

    $("#teamContainer .col-lg-4").each(function () {

        $(this).toggle(

            $(this).text().toLowerCase().indexOf(value) > -1

        );

    });

});

$(document).on("click", "#btnEmptyCreate", function () {

    $("#btnCreateTeam").trigger("click");

});


// $(document).on("change","input[name='members[]']",function(){

//     $(this)

//         .closest(".agent-box")

//         .toggleClass(

//             "selected",

//             $(this).is(":checked")

//         );

//     $("#selectedCount").text(

//         $("input[name='members[]']:checked").length +

//         " Selected"

//     );

// });


$("#searchAgent").on("keyup",function(){

    let value=$(this).val().toLowerCase();

    $(".agent-item").each(function(){

        $(this).toggle(

            $(this)

            .text()

            .toLowerCase()

            .indexOf(value)>-1

        );

    });

});