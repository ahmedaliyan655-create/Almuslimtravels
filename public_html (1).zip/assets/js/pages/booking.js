/* =========================================================
   BOOKING MODAL + SABRE PNR SYSTEM
   COMPLETE PRODUCTION VERSION
========================================================= */

"use strict";


/* =========================================================
   GLOBAL COUNTERS
========================================================= */

let passengerIndex = 1;
let flightIndex = 1;
let hotelIndex = 1;
let transportIndex = 1;
let productIndex = 1;
let costIndex = 0;
let paymentIndex = 1;


/* =========================================================
   GLOBAL MODAL HELPERS
========================================================= */

/*
 * IMPORTANT:
 *
 * We explicitly control display:
 *
 * OPEN  -> display:flex + show
 * CLOSE -> display:none + remove show
 *
 * This fixes the problem caused by:
 *
 * bookingModal.style.display = "flex"
 *
 * after Sabre PNR is applied.
 */


/* =========================================================
   CREATE BOOKING MODAL
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    const newBookingButton =
        document.getElementById("newBooking");

    const bookingModal =
        document.getElementById("bookingModal");

    const closeBookingModalButton =
        document.getElementById("closeBookingModal");

    const bookingCancelButton =
        document.getElementById("bookingCancelButton");


    /* =====================================================
       SAFETY CHECK
    ====================================================== */

    if (!bookingModal) {

        console.error(
            "Booking modal (#bookingModal) was not found."
        );

        return;

    }


    /* =====================================================
       OPEN BOOKING MODAL
    ====================================================== */

    function openBookingModal() {

        if (!bookingModal) {
            return;
        }

        /*
         * Remove any old inline display state first.
         */

        bookingModal.style.display = "flex";

        bookingModal.classList.add("show");

        document.body.style.overflow = "hidden";

    }


    /* =====================================================
       CLOSE BOOKING MODAL
    ====================================================== */

    function closeBookingModal() {

        if (!bookingModal) {
            return;
        }

        /*
         * IMPORTANT:
         *
         * Remove BOTH:
         *
         * 1. show class
         * 2. inline display:flex
         *
         * This is the main fix.
         */

        bookingModal.classList.remove("show");

        bookingModal.style.display = "none";

        document.body.style.overflow = "";

    }


    /* =====================================================
       MAKE FUNCTIONS GLOBAL
    ====================================================== */

    window.openBookingModal =
        openBookingModal;

    window.closeBookingModal =
        closeBookingModal;


    /* =====================================================
       NEW BOOKING BUTTON
    ====================================================== */

    if (newBookingButton) {

        newBookingButton.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                if (
                    typeof window.resetBookingFormForCreate ===
                    "function"
                ) {
                    window.resetBookingFormForCreate();
                } else if (
                    typeof window.setBookingCreateMode ===
                    "function"
                ) {
                    window.setBookingCreateMode();
                }

                openBookingModal();

            }
        );

    }


    /* =====================================================
       CLOSE X BUTTON
    ====================================================== */

    if (closeBookingModalButton) {

        closeBookingModalButton.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                closeBookingModal();

            }
        );

    }


    /* =====================================================
       CANCEL BUTTON
    ====================================================== */

    if (bookingCancelButton) {

        bookingCancelButton.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                closeBookingModal();

            }
        );

    }


    /* =====================================================
       CLICK OUTSIDE BOOKING MODAL
    ====================================================== */

    bookingModal.addEventListener(
        "click",
        function (event) {

            /* Do not close when clicking the backdrop.
             * Booking modal may only be closed by X or Cancel.
             */
            return;

        }
    );


    /* =====================================================
       ESC KEY
    ====================================================== */

});


/* =========================================================
   DELETE ROW
========================================================= */

function deleteRow(button) {

    if (!button) {
        return;
    }

    const row =
        button.closest("tr");

    if (row) {

        row.remove();

    }

}


/* =========================================================
   PASSENGER
========================================================= */

function addPassenger() {

    const tbody =
        document.getElementById("passengerRows");

    if (!tbody) {
        return;
    }


    const row =
        document.createElement("tr");


    row.innerHTML = `

        <td>

            <select
                name="passengers[${passengerIndex}][title]"
            >

                <option value="Mr">
                    Mr
                </option>

                <option value="Mrs">
                    Mrs
                </option>

                <option value="Ms">
                    Ms
                </option>

                <option value="Miss">
                    Miss
                </option>

                <option value="Master">
                    Master
                </option>

                <option value="Child">
                    Child
                </option>

            </select>

        </td>


        <td>

            <input
                type="text"
                name="passengers[${passengerIndex}][surname]"
                placeholder="SURNAME"
            >

        </td>


        <td>

            <input
                type="text"
                name="passengers[${passengerIndex}][firstname]"
                placeholder="FIRSTNAME"
            >

        </td>

        <td>

            <button
                type="button"
                class="btn-delete"
                onclick="deleteRow(this)"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(row);

    passengerIndex++;

}


/* =========================================================
   FLIGHT
========================================================= */

function addFlight() {

    const tbody =
        document.getElementById("flightRows");

    if (!tbody) {
        return;
    }


    const row =
        document.createElement("tr");


    row.innerHTML = `

        <td>

            <input
                type="text"
                name="flights[${flightIndex}][airline]"
            >

        </td>


        <td>

            <input
                type="text"
                name="flights[${flightIndex}][flight]"
            >

        </td>


        <td>

            <input
                type="date"
                name="flights[${flightIndex}][departure_date]"
            >

        </td>


        <td>

            <input
                type="text"
                name="flights[${flightIndex}][origin]"
                placeholder="LHR"
            >

        </td>


        <td>

            <input
                type="text"
                name="flights[${flightIndex}][destination]"
                placeholder="DXB"
            >

        </td>


        <td>

            <input
                type="time"
                name="flights[${flightIndex}][departure_time]"
            >

        </td>


        <td>

            <input
                type="time"
                name="flights[${flightIndex}][arrival_time]"
            >

        </td>


        <td>

            <input
                type="text"
                name="flights[${flightIndex}][baggage]"
            >

        </td>

        <td>
            <input type="text" name="flights[${flightIndex}][supplier]" placeholder="Supplier">
        </td>


        <td>

            <button
                type="button"
                class="btn-delete"
                onclick="deleteRow(this)"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(row);

    flightIndex++;

}


/* =========================================================
   HOTEL
========================================================= */

function addHotel() {

    const tbody =
        document.getElementById("hotelRows");

    if (!tbody) {
        return;
    }


    const row =
        document.createElement("tr");


    row.innerHTML = `

        <td>

            <input
                type="text"
                name="hotels[${hotelIndex}][name]"
            >

        </td>


        <td>

            <input
                type="text"
                name="hotels[${hotelIndex}][city]"
            >

        </td>


        <td>

            <input
                type="text"
                name="hotels[${hotelIndex}][room_type]"
            >

        </td>


        <td>

            <input
                type="number"
                name="hotels[${hotelIndex}][rooms]"
                value="1"
                min="1"
            >

        </td>


        <td>

            <select
                name="hotels[${hotelIndex}][meal]"
            >

                <option value="RO">
                    RO
                </option>

                <option value="BB">
                    BB
                </option>

                <option value="HB">
                    HB
                </option>

                <option value="FB">
                    FB
                </option>

            </select>

        </td>


         <td>

                  <select name="hotels[${hotelIndex}][view]">
                                    <option value="No View">No view</option>
                                    <option value="City View">City View</option>
                                    <option value="Patio View">Patio View</option>
                                    <option value="Haram View">Haram View</option>
                                    <option value="Partial Kaba View">Partial Kaaba View</option>
                                    <option value="Kaaba View">Kaaba View</option>

                                </select>

                                    </td>


                                    <td>

                                        <input type="date"
                                               name="hotels[${hotelIndex}][check_in]"
                                               style="max-width: 119px;">
                                    </td>


                                    <td>

                                        <input type="number"
                                               name="hotels[${hotelIndex}][nights]"
                                               value="1"
                                               min="1">

                                    </td>


                                    <td>

                                        <input type="date"
                                               name="hotels[${hotelIndex}][check_out]"
                                               style="max-width: 119px;">

                                    </td>




        <td>

            <input
                type="text"
                name="hotels[${hotelIndex}][remarks]"
            >

        </td>

        <td>
            <input type="text" name="hotels[${hotelIndex}][supplier]" placeholder="Supplier">
        </td>


        <td>

            <button
                type="button"
                class="btn-delete"
                onclick="deleteRow(this)"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(row);

    hotelIndex++;

}


/* =========================================================
   TRANSPORT
========================================================= */

function addTransport() {

    const tbody =
        document.getElementById("transportRows");

    if (!tbody) {
        return;
    }


    const row =
        document.createElement("tr");


    row.innerHTML = `

        <td>

            <input
                type="text"
                name="transport[${transportIndex}][vehicle]"
                value="Car/Bus"
            >

        </td>


        <td>

            <input
                type="text"
                name="transport[${transportIndex}][journey]"
            >

        </td>


        <td>

            <input
                type="number"
                name="transport[${transportIndex}][vehicles]"
                value="1"
                min="1"
            >

        </td>


        <td>

            <input
                type="date"
                name="transport[${transportIndex}][pickup_date]"
            >

        </td>


        <td>

            <input
                type="time"
                name="transport[${transportIndex}][pickup_time]"
            >

        </td>


        <td>

            <input
                type="text"
                name="transport[${transportIndex}][notes]"
            >

        </td>

        <td>
            <input type="text" name="transport[${transportIndex}][supplier]" placeholder="Supplier">
        </td>


        <td>

            <button
                type="button"
                class="btn-delete"
                onclick="deleteRow(this)"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(row);

    transportIndex++;

}


/* =========================================================
   PRODUCT
========================================================= */

function addProduct() {

    const productRows = document.getElementById("productRows");

    if (!productRows) {
        return;
    }

    const row = document.createElement("div");

    row.className = "product-row";

    row.innerHTML = `
        <input
            type="text"
            name="products[${productIndex}][name]"
            placeholder="e.g. ETA VISA / Tourist Visa / Umrah Visa / Others"
        >

        <input
            type="text"
            name="products[${productIndex}][supplier]"
            placeholder="Supplier"
        >

        <button
            type="button"
            class="btn-delete"
            onclick="deleteProduct(this)">
            ×
        </button>
    `;

    productRows.appendChild(row);
    productIndex++;
}


function deleteProduct(button) {

    const row = button.closest(".product-row");

    if (!row) {
        return;
    }

    const productRows = document.getElementById("productRows");

    if (!productRows) {
        return;
    }

    const rows = productRows.querySelectorAll(".product-row");


    /*
     * Keep one empty product row
     */
    if (rows.length <= 1) {

        const input = row.querySelector("input");

        if (input) {
            input.value = "";
        }

        return;
    }

    row.remove();
}


/* =========================================================
   COST CALCULATION
========================================================= */

function calculateCosts() {

    let grandTotalNet = 0;

    let grandSellingTotal = 0;

    let grandMargin = 0;


    document
        .querySelectorAll("#costRows tr")
        .forEach(function (row) {


            const qty =
                parseFloat(
                    row.querySelector(".qty")?.value
                ) || 0;


            const baseFare =
                parseFloat(
                    row.querySelector(".base-fare")?.value
                ) || 0;


            const tax =
                parseFloat(
                    row.querySelector(".tax")?.value
                ) || 0;


            const sellingPrice =
                parseFloat(
                    row.querySelector(".selling-price")?.value
                ) || 0;


            const netCost =
                baseFare + tax;


            const totalNet =
                netCost * qty;


            const sellingTotal =
                sellingPrice * qty;


            const margin =
                sellingTotal - totalNet;


            const netCostElement =
                row.querySelector(".net-cost");

            if (netCostElement) {

                netCostElement.textContent =
                    netCost.toFixed(2);

            }


            const totalNetElement =
                row.querySelector(".total-net");

            if (totalNetElement) {

                totalNetElement.textContent =
                    totalNet.toFixed(2);

            }


            const sellingTotalElement =
                row.querySelector(".selling-total");

            if (sellingTotalElement) {

                sellingTotalElement.textContent =
                    sellingTotal.toFixed(2);

            }


            const marginElement =
                row.querySelector(".margin");

            if (marginElement) {

                marginElement.textContent =
                    margin.toFixed(2);


                marginElement.classList.remove(
                    "green-text",
                    "red-text"
                );


                if (margin >= 0) {

                    marginElement.classList.add(
                        "green-text"
                    );

                } else {

                    marginElement.classList.add(
                        "red-text"
                    );

                }

            }


            grandTotalNet +=
                totalNet;

            grandSellingTotal +=
                sellingTotal;

            grandMargin +=
                margin;

        });


    const atol =
        parseFloat(
            document.getElementById(
                "atolCharges"
            )?.value
        ) || 0;


    const iata =
        parseFloat(
            document.getElementById(
                "iataCharges"
            )?.value
        ) || 0;


    const discount =
        parseFloat(
            document.getElementById(
                "discount"
            )?.value
        ) || 0;


    const grossTotal =
        grandSellingTotal +
        atol +
        iata;


    const payable =
        grossTotal -
        discount;


    const totalNetElement =
        document.getElementById(
            "totalNet"
        );

    if (totalNetElement) {

        totalNetElement.textContent =
            grandTotalNet.toFixed(2);

    }


    const totalSellingElement =
        document.getElementById(
            "totalSelling"
        );

    if (totalSellingElement) {

        totalSellingElement.textContent =
            grandSellingTotal.toFixed(2);

    }


    const totalMarginElement =
        document.getElementById(
            "totalMargin"
        );

    if (totalMarginElement) {

        totalMarginElement.textContent =
            grandMargin.toFixed(2);


        totalMarginElement.classList.remove(
            "green-text",
            "red-text"
        );


        if (grandMargin >= 0) {

            totalMarginElement.classList.add(
                "green-text"
            );

        } else {

            totalMarginElement.classList.add(
                "red-text"
            );

        }

    }


    const grossTotalElement =
        document.getElementById(
            "grossTotal"
        );

    if (grossTotalElement) {

        grossTotalElement.textContent =
            grossTotal.toFixed(2);

    }


    const vatTotalElement =
        document.getElementById(
            "vatTotal"
        );

    if (vatTotalElement) {

        vatTotalElement.textContent =
            "0.00";

    }


    const discountTotalElement =
        document.getElementById(
            "discountTotal"
        );

    if (discountTotalElement) {

        discountTotalElement.textContent =
            discount.toFixed(2);

    }


    const payableTotalElement =
        document.getElementById(
            "payableTotal"
        );

    if (payableTotalElement) {

        payableTotalElement.textContent =
            payable.toFixed(2);

    }


    if (
        typeof calculatePaymentBalance ===
        "function"
    ) {

        calculatePaymentBalance(
            payable
        );

    }

}


/* =========================================================
   ADD COST
========================================================= */

function addCost() {

    const tbody =
        document.getElementById("costRows");

    if (!tbody) {

        console.error(
            "addCost: #costRows was not found."
        );

        return;
    }


    /*
     * =====================================================
     * SAFELY GET COST INDEX
     * =====================================================
     */

    if (
        typeof costIndex !== "number" ||
        !Number.isFinite(costIndex)
    ) {

        console.error(
            "addCost: costIndex is not initialized."
        );

        return;
    }


    const rowIndex = costIndex;


    /*
     * =====================================================
     * CREATE ROW
     * =====================================================
     */

    const row =
        document.createElement("tr");


    row.innerHTML = `

        <!-- COST TYPE -->

        <td>

            <select
                class="cost-input age"
                name="costs[${rowIndex}][age_category]"
            >

                <option value="ADULT">
                    ADULT
                </option>

                <option value="CHILD">
                    CHILD
                </option>

                <option value="INFANT">
                    INFANT
                </option>

                <option value="MAK HOTEL">
                    MAKKAH HOTEL
                </option>

                <option value="MED HOTEL">
                    MADINA HOTEL
                </option>

                <option value="VISA">
                    VISA
                </option>

                <option value="TRANSPORT">
                    TRANSPORT
                </option>

                <option value="OTHER">
                    OTHER
                </option>

            </select>

        </td>


        <!-- QUANTITY -->

        <td>

            <input
                class="cost-input qty"
                name="costs[${rowIndex}][quantity]"
                type="number"
                value="1"
                min="1"
                step="1"
            >

        </td>


        <!-- BASE FARE -->

        <td>

            <input
                class="cost-input base-fare"
                name="costs[${rowIndex}][base_fare]"
                type="number"
                value="0"
                min="0"
                step="0.01"
                placeholder="0.00"
            >

        </td>


        <!-- TAX -->

        <td>

            <input
                class="cost-input tax"
                name="costs[${rowIndex}][tax]"
                type="number"
                value="0"
                min="0"
                step="0.01"
                placeholder="0.00"
            >

        </td>


        <!-- NET COST -->

        <td class="net-cost">
            0.00
        </td>


        <!-- TOTAL NET -->

        <td class="total-net">
            0.00
        </td>


        <!-- SELLING PRICE -->

        <td>

            <input
                class="cost-input selling-price"
                name="costs[${rowIndex}][selling_price]"
                type="number"
                value="0"
                min="0"
                step="0.01"
                placeholder="0.00"
            >

        </td>


        <!-- SELLING TOTAL -->

        <td class="selling-total">
            0.00
        </td>


        <!-- MARGIN -->

        <td class="margin green-text">
            0.00
        </td>


        <!-- DELETE -->

        <td>

            <button
                type="button"
                class="btn-delete"
                onclick="deleteCostRow(this)"
                aria-label="Delete cost row"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(row);


    /*
     * =====================================================
     * INCREMENT INDEX
     * =====================================================
     */

    costIndex++;


    /*
     * =====================================================
     * EVENTS + CALCULATION
     * =====================================================
     */

    attachCostEvents();

    calculateCosts();

}


/* =========================================================
   DELETE COST ROW
========================================================= */

function deleteCostRow(button) {

    const tbody =
        document.getElementById(
            "costRows"
        );

    if (!tbody) {
        return;
    }


    if (
        tbody.children.length <= 1
    ) {

        return;

    }


    const row =
        button.closest("tr");

    if (row) {

        row.remove();

    }


    calculateCosts();

}


/* =========================================================
   ATTACH COST EVENTS
========================================================= */

function attachCostEvents() {

    document
        .querySelectorAll(
            "#costRows .cost-input"
        )
        .forEach(function (input) {


            input.removeEventListener(
                "input",
                calculateCosts
            );


            input.removeEventListener(
                "change",
                calculateCosts
            );


            input.addEventListener(
                "input",
                calculateCosts
            );


            input.addEventListener(
                "change",
                calculateCosts
            );

        });


    const atol =
        document.getElementById(
            "atolCharges"
        );

    if (atol) {

        atol.removeEventListener(
            "input",
            calculateCosts
        );

        atol.addEventListener(
            "input",
            calculateCosts
        );

    }


    const iata =
        document.getElementById(
            "iataCharges"
        );

    if (iata) {

        iata.removeEventListener(
            "input",
            calculateCosts
        );

        iata.addEventListener(
            "input",
            calculateCosts
        );

    }


    const discount =
        document.getElementById(
            "discount"
        );

    if (discount) {

        discount.removeEventListener(
            "input",
            calculateCosts
        );

        discount.addEventListener(
            "input",
            calculateCosts
        );

    }

}


/* =========================================================
   PAYMENT
========================================================= */

function addPayment() {

    const tbody =
        document.getElementById(
            "paymentRows"
        );

    if (!tbody) {
        return;
    }


    const row =
        document.createElement("tr");


    row.innerHTML = `

        <td>

            <input
                type="hidden"
                name="payments[${paymentIndex}][payment_id]"
                value=""
            >

            <input
                type="text"
                name="payments[${paymentIndex}][receipt_id]"
            >

        </td>

        <td>

            <input
                type="text"
                name="payments[${paymentIndex}][profile_id]"
            >

        </td>




        <td>

            <input type="text"
                name="payments[${paymentIndex}][payer_name]">

         </td>


        <td>

                                    <select name="payments[${paymentIndex}][method]">
                            <option value="Natwest Bank" selected>
                                Natwest Bank
                            </option>

                            <option value="HBL Pakistan">
                                HBL Pakistan
                            </option>

                            <option value="E Payment">
                                E Payment
                            </option>

                            <option value="London Office Card Merchant">
                                London Office Card Merchant
                            </option>

                            <option value="Cash - London Office">
                                Cash - London Office
                            </option>

                            <option value="barclays Bank">
                                barclays Bank
                            </option>

                            <option value="Revolut Bank">
                                Revolut Bank
                            </option>
                        </select>

                                    </td>

                                        <td>

                                        <input type="date"
                                               name="payments[${paymentIndex}][date]">

                                    </td>

                                    <td>

                                        <input type="text"
                                               name="payments[${paymentIndex}][payment_reference]">

                                    </td>

                                    <td>

                                        <input type="number"
                                               class="payment-amount"
                                               name="payments[${paymentIndex}][amount]"
                                               value="0"
                                               step="0.01">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="payments[${paymentIndex}][remarks]">

                                    </td>

                                     <td>

                                        <input type="file"
                                               name="payments[${paymentIndex}][attachment]">

                                    </td>


                                    <td>

                                        <button type="button"
                                                class="btn-delete"
                                                onclick="deleteRow(this)">

                                            ×

                                        </button>

                                    </td>

    `;


    tbody.appendChild(row);

    paymentIndex++;

    attachPaymentEvents();

    calculateReceived();

}


/* =========================================================
   PAYMENT CALCULATION
========================================================= */

function calculateReceived() {

    let total = 0;


    document
        .querySelectorAll(".payment-amount")
        .forEach(function (input) {

            total +=
                parseFloat(
                    input.value
                ) || 0;

        });


    const totalReceived =
        document.getElementById(
            "totalReceived"
        );

    if (totalReceived) {

        totalReceived.textContent =
            total.toFixed(2);

    }


    const payableElement =
        document.getElementById(
            "payableTotal"
        );

    const payable =
        parseFloat(
            payableElement?.textContent
        ) || 0;


    const balanceElement =
        document.getElementById(
            "balanceTotal"
        );

    if (balanceElement) {

        balanceElement.textContent =
            Math.max(
                payable - total,
                0
            ).toFixed(2);

    }

}


/* =========================================================
   PAYMENT EVENTS
========================================================= */

function attachPaymentEvents() {

    document
        .querySelectorAll(".payment-amount")
        .forEach(function (input) {


            input.removeEventListener(
                "input",
                calculateReceived
            );


            input.addEventListener(
                "input",
                calculateReceived
            );

        });

}


/* =========================================================
   BALANCE
========================================================= */

function calculatePaymentBalance(
    payable
) {

    let received = 0;


    document
        .querySelectorAll(".payment-amount")
        .forEach(function (input) {

            received +=
                parseFloat(
                    input.value
                ) || 0;

        });


    const balanceElement =
        document.getElementById(
            "balanceTotal"
        );


    if (balanceElement) {

        balanceElement.textContent =
            Math.max(
                payable - received,
                0
            ).toFixed(2);

    }

}




/* ==========================================================
   SAVE BOOKING
   COMPLETE SERVER-SIDE VERSION
========================================================== */

/* ==========================================================
   SAVE BOOKING
========================================================== */

async function saveBooking() {

    const bookingModal =
        document.getElementById("bookingModal");


    if (!bookingModal) {

        alert(
            "Booking modal not found."
        );

        return;
    }


    /*
     * ------------------------------------------------------
     * PREVENT DOUBLE CLICK
     * ------------------------------------------------------
     */

    const saveButton =
        bookingModal.querySelector(
            ".btn-save"
        );


    if (saveButton) {

        saveButton.disabled = true;

        saveButton.dataset.originalText =
            saveButton.innerHTML;

        saveButton.innerHTML =
            "⏳ Saving...";
    }


    try {

        /*
         * ------------------------------------------------------
         * FORM DATA
         * ------------------------------------------------------
         */

        const formData =
            new FormData();


        /*
         * ------------------------------------------------------
         * NORMAL BOOKING FIELDS
         * ------------------------------------------------------
         *
         * We serialize normal fields here.
         *
         * IMPORTANT:
         *
         * Payment fields are intentionally skipped.
         * Payments are serialized separately below.
         *
         * This prevents payment fields from being added twice
         * and allows us to correctly preserve payment_id and
         * upload payment attachments.
         * ------------------------------------------------------
         */

        bookingModal
            .querySelectorAll(
                "input[name], select[name], textarea[name]"
            )
            .forEach(function (element) {

                /*
                 * Ignore disabled fields
                 */

                if (element.disabled) {
                    return;
                }


                /*
                 * Ignore package/sabre modal fields
                 */

                if (
                    element.closest(
                        "#packageImportModal"
                    )
                ) {
                    return;
                }


                if (
                    element.closest(
                        "#sabrePnrModal"
                    )
                ) {
                    return;
                }


                /*
                 * --------------------------------------------------
                 * IMPORTANT:
                 *
                 * PAYMENT FIELDS ARE HANDLED SEPARATELY BELOW.
                 * --------------------------------------------------
                 */

                if (
                    typeof element.name === "string" &&
                    element.name.indexOf("payments[") === 0
                ) {
                    return;
                }


                /*
                 * Checkboxes
                 */

                if (
                    element.type ===
                    "checkbox"
                ) {

                    if (element.checked) {

                        formData.append(
                            element.name,
                            element.value || "1"
                        );
                    }

                    return;
                }


                /*
                 * Radio buttons
                 */

                if (
                    element.type ===
                    "radio"
                ) {

                    if (element.checked) {

                        formData.append(
                            element.name,
                            element.value
                        );
                    }

                    return;
                }


                /*
                 * File inputs
                 *
                 * Non-payment files, if any, are handled normally.
                 */

                if (
                    element.type ===
                    "file"
                ) {

                    if (
                        element.files &&
                        element.files.length > 0
                    ) {

                        formData.append(
                            element.name,
                            element.files[0],
                            element.files[0].name
                        );
                    }

                    return;
                }


                /*
                 * Normal field
                 */

                formData.append(
                    element.name,
                    element.value
                );

            });


        /*
         * ------------------------------------------------------
         * PAYMENTS
         * ------------------------------------------------------
         *
         * IMPORTANT:
         *
         * We handle payments manually.
         *
         * This guarantees that:
         *
         * payments[0][payment_id]
         * payments[0][receipt_id]
         * payments[0][profile_id]
         * payments[0][payer_name]
         * payments[0][method]
         * payments[0][date]
         * payments[0][payment_reference]
         * payments[0][amount]
         * payments[0][remarks]
         * payments[0][attachment]
         *
         * are sent correctly.
         *
         * Existing payment_id is extremely important during EDIT.
         * ------------------------------------------------------
         */

        const paymentRows =
            bookingModal.querySelectorAll(
                "#paymentRows tr"
            );


        paymentRows.forEach(
            function (row, index) {

                /*
                 * --------------------------------------------------
                 * Find payment fields
                 * --------------------------------------------------
                 */

                const paymentIdInput =
                    row.querySelector(
                        'input[name$="[payment_id]"]'
                    );


                const receiptInput =
                    row.querySelector(
                        'input[name$="[receipt_id]"]'
                    );


                const profileInput =
                    row.querySelector(
                        'input[name$="[profile_id]"]'
                    );


                const payerNameInput =
                    row.querySelector(
                        'input[name$="[payer_name]"]'
                    );


                const methodInput =
                    row.querySelector(
                        'select[name$="[method]"], input[name$="[method]"]'
                    );


                const dateInput =
                    row.querySelector(
                        'input[name$="[date]"]'
                    );


                const referenceInput =
                    row.querySelector(
                        'input[name$="[payment_reference]"]'
                    );


                const amountInput =
                    row.querySelector(
                        'input[name$="[amount]"]'
                    );


                const remarksInput =
                    row.querySelector(
                        'input[name$="[remarks]"], textarea[name$="[remarks]"]'
                    );


                const attachmentInput =
                    row.querySelector(
                        'input[type="file"][name$="[attachment]"]'
                    );


                /*
                 * --------------------------------------------------
                 * Existing payment ID
                 * --------------------------------------------------
                 *
                 * First priority:
                 * hidden payment_id input.
                 *
                 * Second priority:
                 * row data-payment-id.
                 *
                 * This makes the code more tolerant of your
                 * edit-booking loader.
                 * --------------------------------------------------
                 */

                let paymentId = "";


                if (paymentIdInput) {

                    paymentId =
                        String(
                            paymentIdInput.value || ""
                        ).trim();
                }


                if (
                    paymentId === "" &&
                    row.dataset.paymentId
                ) {

                    paymentId =
                        String(
                            row.dataset.paymentId
                        ).trim();
                }


                /*
                 * --------------------------------------------------
                 * Values
                 * --------------------------------------------------
                 */

                const receiptId =
                    receiptInput?.value || "";


                const profileId =
                    profileInput?.value || "";


                const payerName =
                    payerNameInput?.value || "";


                const method =
                    methodInput?.value ||
                    "Natwest Bank";


                const paymentDate =
                    dateInput?.value || "";


                const paymentReference =
                    referenceInput?.value || "";


                const amount =
                    amountInput?.value || "0";


                const remarks =
                    remarksInput?.value || "";


                /*
                 * --------------------------------------------------
                 * Send payment_id
                 * --------------------------------------------------
                 *
                 * For an existing payment this MUST contain the
                 * original database payment ID.
                 *
                 * For a new payment it remains empty.
                 * --------------------------------------------------
                 */

                formData.append(
                    `payments[${index}][payment_id]`,
                    paymentId
                );


                /*
                 * Receipt ID
                 */

                formData.append(
                    `payments[${index}][receipt_id]`,
                    receiptId
                );


                /*
                 * Profile ID
                 */

                formData.append(
                    `payments[${index}][profile_id]`,
                    profileId
                );


                /*
                 * Payer name
                 */

                formData.append(
                    `payments[${index}][payer_name]`,
                    payerName
                );


                /*
                 * Payment method
                 */

                formData.append(
                    `payments[${index}][method]`,
                    method
                );


                /*
                 * Payment date
                 */

                formData.append(
                    `payments[${index}][date]`,
                    paymentDate
                );


                /*
                 * Payment reference
                 */

                formData.append(
                    `payments[${index}][payment_reference]`,
                    paymentReference
                );


                /*
                 * Amount
                 */

                formData.append(
                    `payments[${index}][amount]`,
                    amount
                );


                /*
                 * Remarks
                 */

                formData.append(
                    `payments[${index}][remarks]`,
                    remarks
                );


                /*
                 * --------------------------------------------------
                 * PAYMENT ATTACHMENT
                 * --------------------------------------------------
                 *
                 * IMPORTANT:
                 *
                 * If the user selected a NEW file:
                 * send the actual File object.
                 *
                 * If the user did NOT select a new file:
                 * send NOTHING for attachment.
                 *
                 * PHP will then use payment_id to restore the
                 * existing attachment.
                 * --------------------------------------------------
                 */

                if (
                    attachmentInput &&
                    attachmentInput.files &&
                    attachmentInput.files.length > 0
                ) {

                    const file =
                        attachmentInput.files[0];


                    formData.append(
                        `payments[${index}][attachment]`,
                        file,
                        file.name
                    );

                }

            }
        );


        /*
         * ------------------------------------------------------
         * COST TABLE
         * ------------------------------------------------------
         *
         * Your cost inputs do not have name=""
         * attributes.
         *
         * Therefore we send them manually.
         * ------------------------------------------------------
         */

        const costRows =
            bookingModal.querySelectorAll(
                "#costRows tr"
            );


        costRows.forEach(
            function (row, index) {

                const age =
                    row.querySelector(
                        ".age"
                    )?.value ||
                    "ADULT";


                const quantity =
                    row.querySelector(
                        ".qty"
                    )?.value ||
                    "0";


                const baseFare =
                    row.querySelector(
                        ".base-fare"
                    )?.value ||
                    "0";


                const tax =
                    row.querySelector(
                        ".tax"
                    )?.value ||
                    "0";


                const sellingPrice =
                    row.querySelector(
                        ".selling-price"
                    )?.value ||
                    "0";


                /*
                 * Don't send completely empty
                 * cost rows.
                 */

                if (
                    Number(quantity) <= 0 &&
                    Number(baseFare) <= 0 &&
                    Number(tax) <= 0 &&
                    Number(sellingPrice) <= 0
                ) {
                    return;
                }


                /*
                 * Age category
                 */

                formData.append(
                    `costs[${index}][age_category]`,
                    age
                );


                /*
                 * Quantity
                 */

                formData.append(
                    `costs[${index}][quantity]`,
                    quantity
                );


                /*
                 * Base fare
                 */

                formData.append(
                    `costs[${index}][base_fare]`,
                    baseFare
                );


                /*
                 * Tax
                 */

                formData.append(
                    `costs[${index}][tax]`,
                    tax
                );


                /*
                 * Selling price
                 */

                formData.append(
                    `costs[${index}][selling_price]`,
                    sellingPrice
                );

            }
        );


        /*
         * ------------------------------------------------------
         * CHARGES
         * ------------------------------------------------------
         */

        const atol =
            document.getElementById(
                "atolCharges"
            );


        const iata =
            document.getElementById(
                "iataCharges"
            );


        const discount =
            document.getElementById(
                "discount"
            );


        formData.set(
            "atol_charges",
            atol?.value || "0"
        );


        formData.set(
            "iata_charges",
            iata?.value || "0"
        );


        formData.set(
            "discount",
            discount?.value || "0"
        );


        /*
         * ------------------------------------------------------
         * EDIT / CREATE MODE
         * ------------------------------------------------------
         */

        const editBookingId =
            bookingModal.dataset.bookingId ||
            bookingModal.querySelector(
                'input[name="booking_id"]'
            )?.value ||
            "";


        formData.set(
            "booking_id",
            String(editBookingId).trim()
        );


        formData.set(
            "booking_source",
            "Manual"
        );


        /*
         * ------------------------------------------------------
         * DEBUG PAYMENT DATA
         * ------------------------------------------------------
         *
         * Keep this temporarily while testing.
         *
         * Open browser console and you will see exactly
         * what payment data is being sent.
         * ------------------------------------------------------
         */

        console.log(
            "========== BOOKING SAVE =========="
        );

        console.log(
            "Booking ID:",
            editBookingId
        );


        console.log(
            "Payment rows:",
            paymentRows.length
        );


        for (
            const [key, value]
            of formData.entries()
        ) {

            if (
                key.startsWith(
                    "payments["
                )
            ) {

                if (
                    value instanceof File
                ) {

                    console.log(
                        key,
                        "FILE:",
                        value.name,
                        value.size,
                        value.type
                    );

                } else {

                    console.log(
                        key,
                        value
                    );
                }
            }
        }


        /*
         * ------------------------------------------------------
         * SAVE
         * ------------------------------------------------------
         */

        const response =
            await fetch(
                "../actions/booking/save_booking.php",
                {
                    method: "POST",
                    body: formData,
                    credentials: "same-origin"
                }
            );


        /*
         * ------------------------------------------------------
         * GET RAW RESPONSE
         * ------------------------------------------------------
         *
         * This prevents:
         *
         * "Invalid server response"
         *
         * from hiding the real PHP error.
         * ------------------------------------------------------
         */

        const rawText =
            await response.text();


        let data;


        try {

            data =
                JSON.parse(
                    rawText
                );

        } catch (jsonError) {

            console.error(
                "INVALID JSON FROM SERVER:",
                rawText
            );


            throw new Error(
                "Server returned invalid JSON. Check the PHP error/log."
            );
        }


        /*
         * ------------------------------------------------------
         * SERVER ERROR
         * ------------------------------------------------------
         */

        if (!response.ok) {

            throw new Error(
                data.message ||
                `Server error ${response.status}`
            );
        }


        /*
         * ------------------------------------------------------
         * SUCCESS
         * ------------------------------------------------------
         */

        if (data.success) {

            alert(
                data.message ||
                (
                    editBookingId
                        ? "Booking updated successfully."
                        : "Booking saved successfully."
                )
            );


            /*
             * Reload booking list
             */

            window.location.href =
                "booking.php";


            return;
        }


        /*
         * ------------------------------------------------------
         * APPLICATION ERROR
         * ------------------------------------------------------
         */

        throw new Error(
            data.message ||
            "Unable to save booking."
        );


    } catch (error) {

        console.error(
            "SAVE BOOKING ERROR:",
            error
        );


        alert(
            error.message ||
            "An error occurred while saving the booking."
        );


    } finally {

        /*
         * ------------------------------------------------------
         * RESTORE SAVE BUTTON
         * ------------------------------------------------------
         */

        if (saveButton) {

            saveButton.disabled =
                false;


            saveButton.innerHTML =
                saveButton.dataset.originalText ||
                "💾 Save Booking";
        }

    }

}

/* =========================================================
   INITIALIZE COST / PAYMENT
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        attachCostEvents();

        attachPaymentEvents();

        calculateCosts();

        calculateReceived();

    }
);


/* =========================================================
   SABRE PNR SYSTEM
========================================================= */

(function () {

    "use strict";


    /* =====================================================
       SABRE GLOBAL STATE
    ===================================================== */

    let sabreResults = [];

    let sabreApplied = {};

    let sabreUid = 1;


    /* =====================================================
       SAMPLE PNR
    ===================================================== */

    const SABRE_SAMPLE = `
1.KHAN/ZAKIR MR 2.KHAN/AMINA MRS
1 QR 103 Y 15MAY 3 MANCHL HK2 0635 1840
2 QR 1143 Y 15MAY 3 DOHJED HK2 2015 2205
3 QR 1142 Y 29MAY 3 JEDDOH HK2 0110 0420
4 QR 102 Y 29MAY 3 DOHMAN HK2 0600 1250

---

1.AHMED/BILAL MR 2.AHMED/SARA MRS 3.AHMED/YUSUF MST
1 SV 118 Y 20MAY 4 LHRJED HK3 0930 2015
2 SV 117 Y 03JUN 6 JEDLHR HK3 0830 1345
`;


    /* =====================================================
       UID
    ===================================================== */

    function uid() {

        return (
            "sabre_" +
            Date.now() +
            "_" +
            (sabreUid++)
        );

    }


    /* =====================================================
       ESCAPE HTML
    ===================================================== */

    function escapeHtml(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }


        return String(value)

            .replace(
                /&/g,
                "&amp;"
            )

            .replace(
                /</g,
                "&lt;"
            )

            .replace(
                />/g,
                "&gt;"
            )

            .replace(
                /"/g,
                "&quot;"
            )

            .replace(
                /'/g,
                "&#039;"
            );

    }


    /* =====================================================
       MONTHS
    ===================================================== */

    const MONTHS = {

        JAN: "01",
        FEB: "02",
        MAR: "03",
        APR: "04",
        MAY: "05",
        JUN: "06",
        JUL: "07",
        AUG: "08",
        SEP: "09",
        OCT: "10",
        NOV: "11",
        DEC: "12"

    };


    /* =====================================================
       SABRE DATE
    ===================================================== */

    function parseSabreDate(value) {

        if (!value) {
            return "";
        }


        const match =
            String(value)
                .trim()
                .toUpperCase()
                .match(
                    /^(\d{1,2})(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)$/
                );


        if (!match) {
            return "";
        }


        const day =
            String(match[1])
                .padStart(2, "0");


        const month =
            MONTHS[match[2]];


        let year =
            new Date().getFullYear();


        const current =
            new Date();


        const candidate =
            new Date(
                year +
                "-" +
                month +
                "-" +
                day +
                "T00:00:00"
            );


        if (
            candidate <
            new Date(
                current.getTime() -
                (
                    180 *
                    24 *
                    60 *
                    60 *
                    1000
                )
            )
        ) {

            year++;

        }


        return (
            year +
            "-" +
            month +
            "-" +
            day
        );

    }


    /* =====================================================
       SABRE TIME
    ===================================================== */

    function parseSabreTime(value) {

        if (!value) {
            return "";
        }


        value =
            String(value)
                .trim()
                .toUpperCase();


        /*
         * 0635
         */

        let match =
            value.match(
                /^(\d{1,2})(\d{2})$/
            );


        if (match) {

            return (
                String(match[1])
                    .padStart(2, "0") +
                ":" +
                match[2]
            );

        }


        /*
         * 0635A / 0635P
         */

        match =
            value.match(
                /^(\d{1,2})(\d{2})(A|P)$/
            );


        if (match) {

            let hour =
                parseInt(
                    match[1],
                    10
                );


            const minute =
                match[2];


            const ampm =
                match[3];


            if (
                ampm === "P" &&
                hour < 12
            ) {

                hour += 12;

            }


            if (
                ampm === "A" &&
                hour === 12
            ) {

                hour = 0;

            }


            return (
                String(hour)
                    .padStart(2, "0") +
                ":" +
                minute
            );

        }


        /*
         * 0635AM / 0635PM
         */

        match =
            value.match(
                /^(\d{1,2})(\d{2})(AM|PM)$/
            );


        if (match) {

            let hour =
                parseInt(
                    match[1],
                    10
                );


            const minute =
                match[2];


            const ampm =
                match[3];


            if (
                ampm === "PM" &&
                hour < 12
            ) {

                hour += 12;

            }


            if (
                ampm === "AM" &&
                hour === 12
            ) {

                hour = 0;

            }


            return (
                String(hour)
                    .padStart(2, "0") +
                ":" +
                minute
            );

        }


        return "";

    }


    /* =====================================================
       UNIVERSAL SABRE DATE / TIME HELPERS
       These names are used by the universal flight parser.
       They intentionally accept both classic Sabre tokens and
       common exported/converted date-time formats.
    ===================================================== */

    function parseUniversalSabreDate(value) {
        if (!value) return "";

        let v = String(value)
            .trim()
            .toUpperCase()
            .replace(/[.,]/g, "")
            .replace(/\s+/g, "");

        if (!v) return "";

        // YYYY-MM-DD / YYYY/MM/DD
        let m = v.match(/^(20\d{2})[-\/](\d{1,2})[-\/](\d{1,2})$/);
        if (m) {
            const d = new Date(
                Number(m[1]),
                Number(m[2]) - 1,
                Number(m[3])
            );
            if (
                d.getFullYear() === Number(m[1]) &&
                d.getMonth() === Number(m[2]) - 1 &&
                d.getDate() === Number(m[3])
            ) {
                return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
            }
            return "";
        }

        // DD/MM/YYYY or DD-MM-YYYY
        m = v.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](20\d{2})$/);
        if (m) {
            const day = Number(m[1]);
            const month = Number(m[2]);
            const year = Number(m[3]);
            const d = new Date(year, month - 1, day);
            if (
                d.getFullYear() === year &&
                d.getMonth() === month - 1 &&
                d.getDate() === day
            ) {
                return `${year}-${String(month).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
            }
            return "";
        }

        // DDMMM, DDMMMYY, DDMMMYYYY, DD-MMM-YY, DD/MMM/YYYY
        m = v.match(/^(\d{1,2})[-\/]?(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[-\/]?(\d{2}|\d{4})?$/);
        if (m) {
            const day = Number(m[1]);
            const month = Number(MONTHS[m[2]]);
            let year;

            if (m[3]) {
                year = Number(m[3]);
                if (year < 100) year += year >= 70 ? 1900 : 2000;
            } else {
                year = new Date().getFullYear();

                // Sabre PNRs commonly omit the year. Choose the nearest
                // plausible occurrence around today's date.
                const now = new Date();
                let candidate = new Date(year, month - 1, day);

                if (candidate.getTime() < now.getTime() - 180 * 86400000) {
                    year++;
                    candidate = new Date(year, month - 1, day);
                }
            }

            const d = new Date(year, month - 1, day);
            if (
                d.getFullYear() === year &&
                d.getMonth() === month - 1 &&
                d.getDate() === day
            ) {
                return `${year}-${String(month).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
            }
        }

        // JS/ISO datetime: 2026-05-15T...
        m = v.match(/^(20\d{2})[-\/](\d{1,2})[-\/](\d{1,2})(?:T|\s)/);
        if (m) {
            return `${m[1]}-${String(m[2]).padStart(2,"0")}-${String(m[3]).padStart(2,"0")}`;
        }

        return "";
    }


    function parseUniversalTime(value) {
        if (value === null || value === undefined) return "";

        let v = String(value)
            .trim()
            .toUpperCase()
            .replace(/\s+/g, "");

        if (!v) return "";

        // ISO datetime / datetime strings: extract HH:MM first.
        let m = v.match(/(?:T|\s)(\d{1,2}):(\d{2})(?::\d{2})?/);
        if (m) {
            const h = Number(m[1]);
            const min = Number(m[2]);
            if (h >= 0 && h <= 23 && min >= 0 && min <= 59) {
                return `${String(h).padStart(2,"0")}:${String(min).padStart(2,"0")}`;
            }
        }

        // H:MM AM/PM, HH:MM A/P, H.MM PM
        m = v.match(/^(\d{1,2})[:.](\d{2})(AM|PM|A|P)?$/);
        if (m) {
            let hour = Number(m[1]);
            const minute = Number(m[2]);
            const ap = m[3] || "";

            if (minute > 59) return "";

            if (ap === "P" || ap === "PM") {
                if (hour < 12) hour += 12;
            } else if (ap === "A" || ap === "AM") {
                if (hour === 12) hour = 0;
            }

            if (hour >= 0 && hour <= 23) {
                return `${String(hour).padStart(2,"0")}:${String(minute).padStart(2,"0")}`;
            }
            return "";
        }

        // Sabre compact: 0635, 635, 0635A, 635P, 1230AM
        m = v.match(/^(\d{1,4})(AM|PM|A|P)?$/);
        if (m) {
            let digits = m[1];
            const ap = m[2] || "";

            let hour;
            let minute;

            if (digits.length <= 2) {
                hour = Number(digits);
                minute = 0;
            } else {
                minute = Number(digits.slice(-2));
                hour = Number(digits.slice(0, -2));
            }

            if (minute > 59) return "";

            if (ap === "P" || ap === "PM") {
                if (hour < 12) hour += 12;
            } else if (ap === "A" || ap === "AM") {
                if (hour === 12) hour = 0;
            }

            // Without AM/PM, allow normal 24-hour GDS values.
            if (!ap && hour > 23) return "";

            if (hour >= 0 && hour <= 23) {
                return `${String(hour).padStart(2,"0")}:${String(minute).padStart(2,"0")}`;
            }
        }

        return "";
    }


    /* =====================================================
       SPLIT MULTIPLE PNR
    ===================================================== */

    function splitMultiPNR(raw) {

        if (
            !raw ||
            !raw.trim()
        ) {

            return [];

        }


        /*
         * Method 1:
         *
         * ---
         * ===
         * ***
         */

        const dividerRegex =
            /\n\s*[-=*]{3,}[^\n]*\n/g;


        if (
            dividerRegex.test(raw)
        ) {

            return raw
                .split(dividerRegex)
                .map(function (item) {

                    return item.trim();

                })
                .filter(Boolean);

        }


        /*
         * Method 2:
         *
         * RP/ lines
         */

        const rpParts =
            raw.split(
                /(?=\nRP\/)/i
            );


        if (
            rpParts.length > 1
        ) {

            return rpParts
                .map(function (item) {

                    return item.trim();

                })
                .filter(Boolean);

        }


        /*
         * Method 3:
         *
         * Three or more blank lines
         */

        const blankParts =
            raw.split(/\n{3,}/);


        if (
            blankParts.length > 1
        ) {

            return blankParts
                .map(function (item) {

                    return item.trim();

                })
                .filter(Boolean);

        }


        /*
         * Method 4:
         *
         * New passenger list after flights.
         */

        const lines =
            raw.split(/\r?\n/);


        const chunks = [];

        let current = [];

        let seenFlight = false;


        lines.forEach(
            function (line) {


                const isPassengerStart =
                    /^\s*1\.\s*[A-Z][A-Z\-]+\//i
                        .test(line);


                if (
                    isPassengerStart &&
                    seenFlight &&
                    current.length
                ) {

                    chunks.push(
                        current.join("\n")
                    );


                    current = [];

                    seenFlight = false;

                }


                const isFlight =
                    /^\s*\d+\s+[A-Z0-9]{2}\s*\d+/i
                        .test(line);


                if (isFlight) {

                    seenFlight = true;

                }


                current.push(line);

            }
        );


        if (current.length) {

            chunks.push(
                current.join("\n")
            );

        }


        if (
            chunks.length > 1
        ) {

            return chunks
                .map(function (item) {

                    return item.trim();

                })
                .filter(Boolean);

        }


        return [
            raw.trim()
        ];

    }


    /* =====================================================
       EXTRACT PNR CODE
    ===================================================== */

    function extractPNRCode(raw) {

        if (!raw) return "";

        const text = String(raw)
            .replace(/\r\n/g, "\n")
            .replace(/\r/g, "\n");

        /* PRIMARY: main Sabre/GDS locator immediately after *. */
        let match = text.match(/^\s*\*([A-Z0-9]{6})\b/im);
        if (match) return match[1].toUpperCase();

        /* Explicit PNR labels. */
        match = text.match(
            /\bPNR(?:\s+REFERENCE|\s+REF(?:ERENCE)?|\s+CODE)?\s*[:\-]?\s*([A-Z0-9]{6})\b/i
        );
        if (match) return match[1].toUpperCase();

        /* RP/AGENCY/ABC123. */
        match = text.match(/\bRP\/[^\/\s]+\/([A-Z0-9]{6})\b/i);
        if (match) return match[1].toUpperCase();

        /* Standalone fallback. Never inspect *XXXXXX metadata after /DC. */
        for (const line of text.split("\n")) {
            const standalone = line.match(/(?:^|\s)([A-Z0-9]{6})(?:\s|$)/i);
            if (standalone) {
                const value = standalone[1].toUpperCase();
                if (!/^(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)$/.test(value)) {
                    return value;
                }
            }
        }

        return "";
    }

    /* =====================================================
       NORMALIZE TITLE
    ===================================================== */

    function normalizeTitle(title) {

        const value = String(title || "").toUpperCase().trim();

        switch (value) {
            case "MR": return "Mr";
            case "MRS": return "Mrs";
            case "MS":
            case "MST": return "Ms";
            case "MISS":
            case "MIS": return "Miss";
            case "MSTR": return "Master";
            case "CHD":
            case "CNN": return "Child";
            case "INF":
            case "INFT": return "Infant";
            case "DR": return "Dr";
            case "PROF": return "Prof";
            default: return "Mr";
        }
    }

    /* =====================================================
       PARSE PNR
    ===================================================== */

    /* =====================================================
   UNIVERSAL SABRE PNR PARSER
   Supports multiple Sabre formats
===================================================== */

function parsePNR(raw) {

    const passengers = [];
    const flights = [];

    if (!raw || !String(raw).trim()) {
        return { gdsPnr: "", passengers: [], flights: [] };
    }

    const normalizedRaw = String(raw)
        .replace(/\r\n/g, "\n")
        .replace(/\r/g, "\n")
        .replace(/\u00A0/g, " ")
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'");

    const lines = normalizedRaw
        .split("\n")
        .map(line => line.replace(/\t/g, " ").replace(/\s+/g, " ").trim())
        .filter(Boolean);

    const gdsPnr = extractPNRCode(normalizedRaw);

function parseSabreFlightLine(line) {

    const original = String(line || "")
        .replace(/\u00A0/g, " ")
        .replace(/\t/g, " ")
        .replace(/[|]/g, " ")
        .trim();

    if (!original) return null;

    /*
     * COMPACT SABRE SEGMENT RECOVERY
     *
     * Examples:
     * 1QR103Y15MAYLHRDOHHK1/0635/1840
     * 1QR103Y15MAYLHRDOH HK1 0635 1840
     * 1 QR103Y15MAYLHRDOH*HK1 0635 1840
     */
    const compactSegment = original.match(
        /^\s*(\d{1,3})\s*([A-Z0-9]{2})\s*(\d{1,4})([A-Z])?\s*(\d{1,2})(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)\s*([A-Z]{3})\s*(?:[-\/→ ]\s*)?([A-Z]{3})([\s\S]*)$/i
    );

    if (compactSegment) {
        const compactDate = parseUniversalSabreDate(
            compactSegment[5] + compactSegment[6]
        );

        if (compactDate) {
            const compactTail = compactSegment[9] || "";
            const compactTimes = [
                ...compactTail.matchAll(/\b(\d{1,2}(?::|\.)\d{2}|\d{3,4})(AM|PM|A|P)?\b/gi)
            ].map(m => parseUniversalTime(m[1] + (m[2] || ""))).filter(Boolean);

            return {
                id: uid(),
                segment: compactSegment[1],
                airline: compactSegment[2].toUpperCase(),
                flight: compactSegment[3],
                booking_class: (compactSegment[4] || "").toUpperCase(),
                departure_date: compactDate,
                origin: compactSegment[7].toUpperCase(),
                destination: compactSegment[8].toUpperCase(),
                departure_time: compactTimes[0] || "",
                arrival_time: compactTimes[1] || "",
                arrival_date: "",
                baggage: ""
            };
        }
    }

    /*
     * UNIVERSAL SABRE FLIGHT PARSER
     *
     * Accepts common Sabre/GDS variations:
     * 1 QR 103 Y 15MAY 3 MANCHL HK2 0635 1840
     * 1 QR 103Y 15MAY MANCHL HK2 0635 1840
     * 1 QR103Y 15MAY LHR-DOH HK2 0635 1840
     * 1 QR 0103 Y 15MAY LHR/DOH HK1 6:35A 6:40P
     * 1 QR 103 Y 15MAY 3 LHR DOH HK2 0635 1840
     *
     * The parser deliberately searches for the flight structure
     * instead of depending on exact column spacing.
     */

    const cleaned = original
        .replace(/^\s*[*+>]\s*/, "")
        .replace(/^\s*(?:SEGMENT|SEG|SECTOR)\s*[:#-]?\s*/i, "");

    const segmentMatch = cleaned.match(/^\s*(\d{1,3})(?:[.)-]\s*|\s+|(?=[A-Z]))/i);
    if (!segmentMatch) return null;

    const segment = segmentMatch[1];

    /*
     * Airline may be separated from the flight number or compact:
     * QR 103 / QR103 / QR-103
     */
    const head = cleaned.slice(segmentMatch[0].length);

    const airlineMatch = head.match(/^\s*([A-Z0-9]{2})\s*[-/]?\s*(\d{1,4})\s*([A-Z])?(?=\s|$|\d{1,2}(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))/i);
    if (!airlineMatch) return null;

    const airline = airlineMatch[1].toUpperCase();
    const flightNumber = airlineMatch[2];
    const bookingClass = airlineMatch[3] ? airlineMatch[3].toUpperCase() : "";

    let rest = head.slice(airlineMatch[0].length).trim();

    /*
     * Some displays put booking class separately:
     * QR 103 Y 15MAY...
     */
    let classValue = bookingClass;
    if (!classValue) {
        const classMatch = rest.match(/^([A-Z])(?=\s|\d)/);
        if (classMatch) {
            classValue = classMatch[1].toUpperCase();
            rest = rest.slice(classMatch[0].length).trim();
        }
    }

    /*
     * Remove common harmless markers before date/route.
     */
    rest = rest
        .replace(/^\s*(?:HK|HL|HN|KK|KL|TK|UC|UN|NO|RQ|SA|RR|GK|WL)\d*\s+/i, "")
        .trim();

    /*
     * DATE
     *
     * Accept:
     * 15MAY
     * 15MAY26
     * 15-MAY
     * 15/MAY/26
     * 2026-05-15
     * 15/05/2026
     * 15-05-2026
     */
    let departureDate = "";
    let dateToken = "";

    const isoDate = rest.match(/^(20\d{2})[-/](\d{1,2})[-/](\d{1,2})(?:\s+|$)/);
    const dmyNumeric = rest.match(/^(\d{1,2})[-/](\d{1,2})[-/](20\d{2})(?:\s+|$)/);
    const sabreDate = rest.match(/^(\d{1,2})[-/]?(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(?:[-/]?(\d{2,4}))?(?=\s|$|[A-Z]{3})/i);

    if (isoDate) {
        departureDate = `${isoDate[1]}-${String(isoDate[2]).padStart(2,"0")}-${String(isoDate[3]).padStart(2,"0")}`;
        dateToken = isoDate[0].trim();
    } else if (dmyNumeric) {
        departureDate = `${dmyNumeric[3]}-${String(dmyNumeric[2]).padStart(2,"0")}-${String(dmyNumeric[1]).padStart(2,"0")}`;
        dateToken = dmyNumeric[0].trim();
    } else if (sabreDate) {
        dateToken = sabreDate[0].trim();
        departureDate = parseUniversalSabreDate(
            sabreDate[1] + sabreDate[2] + (sabreDate[3] || "")
        );
    }

    if (!departureDate) {
        /*
         * If a date exists later in the line, use it.
         * This handles displays containing a booking class/day marker first.
         */
        const later = rest.match(/\b(\d{1,2})(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(\d{2,4})?\b/i);
        if (later) {
            departureDate = parseUniversalSabreDate(
                later[1] + later[2] + (later[3] || "")
            );
            dateToken = later[0];
            rest = rest.replace(later[0], " ").trim();
        }
    } else {
        rest = rest.slice(dateToken.length).trim();
    }

    if (!departureDate) return null;

    /*
     * Remove optional day-of-week / day number:
     * M, T, W, TH, F, SA, SU, MON, TUE...
     */
    rest = rest.replace(
        /^(?:MON|TUE|WED|THU|FRI|SAT|SUN|MO|TU|WE|TH|FR|SA|SU|M|T|W|F|S|\d{1,2})\b\s*/i,
        ""
    ).trim();

    /*
     * Remove segment status / confirmation and other Sabre metadata,
     * but keep route and times.
     */
    rest = rest
        .replace(/\*(?:HK|HL|HN|KK|KL|TK|UC|UN|NO|RQ|SA|RR|GK|WL)\d*/gi, " ")
        .replace(/(?:^|\s)(?:HK|HL|HN|KK|KL|TK|UC|UN|NO|RQ|SA|RR|GK|WL)\d+(?=\s|$)/gi, " ")
        .replace(/\/DC[A-Z0-9]+/gi, " ")
        .replace(/\/E\b/gi, " ")
        .replace(/\*[A-Z0-9]+/gi, " ")
        .replace(/\s+/g, " ")
        .trim();

    /*
     * ROUTE
     *
     * LHRBAH
     * LHR-BAH
     * LHR/BAH
     * LHR BAH
     * LHR → BAH
     */
    let origin = "";
    let destination = "";
    let routeMatch = null;

    routeMatch = rest.match(/\b([A-Z]{3})\s*(?:-|\/|→|TO)\s*([A-Z]{3})\b/i);
    if (!routeMatch) {
        routeMatch = rest.match(/(?:^|\s)([A-Z]{3})([A-Z]{3})(?=\s|$|[/*])/i);
    }
    if (!routeMatch) {
        routeMatch = rest.match(/\b([A-Z]{3})\s+([A-Z]{3})\b/i);
    }

    if (!routeMatch) return null;

    origin = routeMatch[1].toUpperCase();
    destination = routeMatch[2].toUpperCase();

    /*
     * TIMES
     *
     * 0635 / 1840
     * 635A / 1840P
     * 6:35A / 18:40
     * 06:35 / 18:40
     * 6.35A / 18.40
     */
    const timeTokens = [];
    const timeRegex = /(?:^|\s)(\d{1,2}(?::|\.|)?\d{2}\s*(?:AM|PM|A|P)?|\d{3,4}\s*(?:AM|PM|A|P))(?=\s|$)/gi;

    let tm;
    while ((tm = timeRegex.exec(rest)) !== null) {
        const value = tm[1].replace(/\s+/g, "");
        const parsed = parseUniversalTime(value);
        if (parsed) timeTokens.push(parsed);
    }

    /*
     * Fallback for times attached to other text, e.g. HK1/0635/1840.
     */
    if (timeTokens.length < 2) {
        const compactTimes = [...rest.matchAll(/\b(\d{1,2}:\d{2}|\d{1,2}\.\d{2}|\d{3,4})(AM|PM|A|P)?\b/gi)];
        for (const m of compactTimes) {
            const parsed = parseUniversalTime(m[1] + (m[2] || ""));
            if (parsed && !timeTokens.includes(parsed)) timeTokens.push(parsed);
            if (timeTokens.length >= 2) break;
        }
    }

    const departureTime = timeTokens[0] || "";
    const arrivalTime = timeTokens[1] || "";

    /*
     * Arrival date if printed after the times.
     */
    let arrivalDate = "";
    const afterTimes = rest;
    const allDates = [...afterTimes.matchAll(/\b(\d{1,2})(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(\d{2,4})?\b/gi)];
    if (allDates.length) {
        const candidate = allDates[allDates.length - 1];
        const parsed = parseUniversalSabreDate(
            candidate[1] + candidate[2] + (candidate[3] || "")
        );
        if (parsed && parsed !== departureDate) arrivalDate = parsed;
    }

    /*
     * A valid flight record needs:
     * segment + airline + flight number + date + route.
     * Times are optional because some PNR displays omit them.
     */
    return {
        id: uid(),
        segment: segment,
        airline: airline,
        flight: flightNumber,
        booking_class: classValue,
        departure_date: departureDate,
        origin: origin,
        destination: destination,
        departure_time: departureTime,
        arrival_time: arrivalTime,
        arrival_date: arrivalDate,
        baggage: ""
    };
}


    /*
     * UNIVERSAL PASSENGER EXTRACTION
     *
     * Handles:
     * 1.1SMITH/JOHN MR
     * 1.SMITH/JOHN MR
     * 1.1SMITH/JOHN MR*ADT
     * 1.SMITH/JOHN/MR
     * 1 SMITH/JOHN MR
     * SMITH/JOHN MR
     * 1.1BAHAR/TANISHA SHANAZ MIS*CNN
     *
     * Multiple records on one line are supported.
     */
    function detectPassengerType(value) {
        const text = String(value || '').toUpperCase();
        if (/\b(?:CNN|CHD|CHILD)\b/.test(text)) return 'CNN';
        if (/\b(?:YTH|YOUTH)\b/.test(text)) return 'YTH';
        if (/\b(?:INF|INFT|INFANT)\b/.test(text)) return 'INF';
        if (/\b(?:ADT|ADULT)\b/.test(text)) return 'ADT';
        return '';
    }

    function addPassenger(surname, firstname, title, passengerType = '') {
        surname = String(surname || '')
            .replace(/\s+/g, ' ')
            .replace(/[^A-Z0-9' -]/gi, '')
            .trim()
            .toUpperCase();

        firstname = String(firstname || '')
            .replace(/\s+/g, ' ')
            .replace(/[*].*$/g, '')
            .replace(/[^A-Z0-9' -]/gi, '')
            .trim()
            .toUpperCase();

        passengerType = detectPassengerType(passengerType || title || firstname);
        title = normalizeTitle(title || '');

        if (passengerType === 'CNN') title = 'Child';
        else if (passengerType === 'YTH') title = 'Youth';
        else if (passengerType === 'INF') title = 'Infant';

        if (!surname || !firstname) return;
        if (surname.length < 2 || firstname.length < 2) return;
        if (/^(PNR|PASSENGER|NAME|TICKET|TKT|PHONE|PHONES|RECEIVED|AGENCY|CONTACT)$/i.test(surname)) return;

        passengers.push({
            id: uid(),
            surname,
            firstname,
            title,
            passenger_type: passengerType || 'ADT'
        });
    }

    function parsePassengerLine(line) {
        const original = String(line || '')
            .replace(/\r/g, ' ')
            .replace(/\n/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

        if (!original || !original.includes('/')) return false;

        let found = false;

        /*
         * IMPORTANT:
         * Sabre passenger records use the FIRST slash as the boundary:
         *
         *   1.1ALI NISA/MUHAMMAD RAYYAN MR*YTH
         *       ^^^^^^^^^
         *       complete surname, including spaces
         *
         * Do NOT capture surname with a single-token regex. First find
         * every numbered passenger marker, then slice the complete record.
         */
        const markerRegex = /(?:^|\s)(\d+\.\d*)\s*(?=[A-Z][A-Z'\-]*(?:\s+[A-Z][A-Z'\-]*){0,8}\s*\/)/gi;
        const markers = [];
        let markerMatch;

        while ((markerMatch = markerRegex.exec(original)) !== null) {
            markers.push({
                index: markerMatch.index + (markerMatch[0].length - markerMatch[0].trimStart().length),
                length: markerMatch[0].trimStart().length,
                number: markerMatch[1]
            });
        }

        if (markers.length) {
            for (let i = 0; i < markers.length; i++) {
                const start = markers[i].index + markers[i].length;
                const end = i + 1 < markers.length ? markers[i + 1].index : original.length;
                const record = original.slice(start, end).trim();

                const slashIndex = record.indexOf('/');
                if (slashIndex <= 0) continue;

                const surname = record.slice(0, slashIndex).trim();
                let tail = record.slice(slashIndex + 1).trim();
                if (!surname || !tail) continue;

                // Never treat flight/segment rows such as
                // `1 QR 34O 04DEC 5 BHXDOH*HK5 /DCQR...` as passengers.
                // A Sabre passenger surname is alphabetic words only.
                if (!/^[A-Z][A-Z'\-]*(?:\s+[A-Z][A-Z'\-]*){0,8}$/i.test(surname)) {
                    continue;
                }

                const passengerType = detectPassengerType(tail);
                const titleMatch = tail.match(/(?:^|\s|\/)(MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)(?=\s|\/|\*|$)/i);
                const title = titleMatch ? titleMatch[1] : '';

                let firstname = tail
                    .replace(/\*(?:ADT|CNN|CHD|INF|INFT|INS|YTH|YOUTH|UNN)\b/gi, ' ')
                    .replace(/\b(?:ADT|CNN|CHD|INF|INFT|INS|YTH|YOUTH)\b/gi, ' ')
                    .replace(/\/(?:MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)\b/gi, ' ')
                    .replace(/\b(?:MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)\b/gi, ' ')
                    .replace(/\*/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();

                addPassenger(surname, firstname, title, passengerType);
                found = true;
            }

            return found;
        }

        /* Compact numbered fallback: 1 SMITH/JOHN MR 2 DOE/JANE MRS */
        const compactNumbered = /(?:^|\s)(\d+)\s*\.?\s*(?=[A-Z][A-Z'\-]*(?:\s+[A-Z][A-Z'\-]*){0,8}\s*\/)/gi;
        const compactMarkers = [];
        let compactMatch;

        while ((compactMatch = compactNumbered.exec(original)) !== null) {
            compactMarkers.push({
                index: compactMatch.index + (compactMatch[0].length - compactMatch[0].trimStart().length),
                length: compactMatch[0].trimStart().length
            });
        }

        if (compactMarkers.length) {
            for (let i = 0; i < compactMarkers.length; i++) {
                const start = compactMarkers[i].index + compactMarkers[i].length;
                const end = i + 1 < compactMarkers.length ? compactMarkers[i + 1].index : original.length;
                const record = original.slice(start, end).trim();
                const slashIndex = record.indexOf('/');
                if (slashIndex <= 0) continue;

                const surname = record.slice(0, slashIndex).trim();
                const tail = record.slice(slashIndex + 1).trim();
                if (!/^[A-Z][A-Z'\-]*(?:\s+[A-Z][A-Z'\-]*){0,8}$/i.test(surname)) continue;
                const passengerType = detectPassengerType(tail);
                const titleMatch = tail.match(/\b(MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)\b/i);
                const firstname = tail
                    .replace(/\*(?:ADT|CNN|CHD|INF|INFT|INS|YTH|YOUTH|UNN)\b/gi, ' ')
                    .replace(/\b(?:ADT|CNN|CHD|INF|INFT|INS|YTH|YOUTH)\b/gi, ' ')
                    .replace(/\b(?:MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)\b/gi, ' ')
                    .replace(/\*/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();

                addPassenger(surname, firstname, titleMatch ? titleMatch[1] : '', passengerType);
                found = true;
            }
            return found;
        }

        /* Non-numbered fallback: SMITH/JOHN MR */
        const slashIndex = original.indexOf('/');
        if (slashIndex > 0) {
            const surname = original.slice(0, slashIndex).trim();
            let tail = original.slice(slashIndex + 1).trim();

            if (/^[A-Z][A-Z0-9' -]{1,60}$/.test(surname)) {
                const passengerType = detectPassengerType(tail);
                const titleMatch = tail.match(/\b(MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)\b/i);
                const firstname = tail
                    .replace(/\*(?:ADT|CNN|CHD|INF|INFT|INS|YTH|YOUTH|UNN)\b/gi, ' ')
                    .replace(/\b(?:ADT|CNN|CHD|INF|INFT|INS|YTH|YOUTH)\b/gi, ' ')
                    .replace(/\b(?:MR|MRS|MS|MISS|MIS|MST|MSTR|MASTER|CHD|CNN|INF|INFT|DR|PROF)\b/gi, ' ')
                    .replace(/\*/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();

                addPassenger(surname, firstname, titleMatch ? titleMatch[1] : '', passengerType);
                return true;
            }
        }

        return false;
    }

    /*
     * First pass: passengers.
     */
    lines.forEach(line => {
        /*
         * Only attempt passenger parsing where a name slash is present.
         */
        if (
            /\//.test(line) &&
            !/^\s*(?:RP|DK|AP|PE|TK|SSR|OSI|RM|OP|PQ|ER|IR|IG|WP|WPN|WPB|WPA|WPNI|ETR|TKT|FA|FB|FO|FHE|FHA|FHM|FHL|FHP)\b/i.test(line) &&
            !/^\s*\d+\s+[A-Z0-9]{2}\s*[-\/]?\s*\d{1,4}[A-Z]?\s+/i.test(line)
        ) {
            parsePassengerLine(line);
        }
    });

    /*
     * Second pass: flights.
     * Try the complete line first, then recover flight segments embedded
     * in a line containing other PNR information.
     */
    lines.forEach(line => {
        let flight = parseSabreFlightLine(line);

        if (flight) {
            flights.push(flight);
            return;
        }

        /*
         * Some exports prefix a flight line with text or a segment marker.
         * Recover a substring beginning with "1 QR 123..." etc.
         */
        const embedded = line.match(/(?:^|\s)(\d{1,3})[.)-]?\s+[A-Z0-9]{2}\s*[-/]?\s*\d{1,4}[A-Z]?\s+/i);
        if (embedded) {
            const candidate = line.slice(embedded.index + (embedded[0].length - embedded[0].trimStart().length));
            flight = parseSabreFlightLine(candidate);
            if (flight) flights.push(flight);
        }
    });

    /*
     * Extra fallback for compact segment formats:
     * 1QR103Y15MAYLHRDOHHK1/0635/1840
     */
    if (!flights.length) {
        const compactRegex = /(?:^|\s)(\d{1,3})\s*([A-Z0-9]{2})\s*(\d{1,4})([A-Z])?\s*(\d{1,2}(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC))\s*([A-Z]{3})\s*(?:[-\/→ ]\s*)?([A-Z]{3})\b([^]*)/gi;

        for (const line of lines) {
            const m = compactRegex.exec(line);
            if (!m) continue;

            const date = parseUniversalSabreDate(m[4] + (m[5] || ''));
            if (!date) continue;

            const times = [...String(m[8] || "").matchAll(/\b(\d{1,4})(A|P)?\b/gi)]
                .map(x => parseUniversalTime(x[1] + (x[2] || "")))
                .filter(Boolean);

            flights.push({
                id: uid(),
                segment: m[1],
                airline: m[2].toUpperCase(),
                flight: m[3],
                booking_class: (m[4] || "").toUpperCase(),
                departure_date: date,
                origin: m[6].toUpperCase(),
                destination: m[7].toUpperCase(),
                departure_time: times[0] || "",
                arrival_time: times[1] || "",
                arrival_date: "",
                baggage: ""
            });
        }
    }

    /*
     * Deduplicate passengers and flights.
     */
    const uniquePassengers = [];
    const passengerKeys = new Set();

    for (const passenger of passengers) {
        const key = [
            passenger.surname,
            passenger.firstname,
            passenger.title
        ].join("|").toUpperCase();

        if (!passengerKeys.has(key)) {
            passengerKeys.add(key);
            uniquePassengers.push(passenger);
        }
    }

    const uniqueFlights = [];
    const flightKeys = new Set();

    for (const flight of flights) {
        const key = [
            flight.airline,
            flight.flight,
            flight.departure_date,
            flight.origin,
            flight.destination,
            flight.departure_time,
            flight.arrival_time
        ].join("|").toUpperCase();

        if (!flightKeys.has(key)) {
            flightKeys.add(key);
            uniqueFlights.push(flight);
        }
    }

    return {
        gdsPnr,
        passengers: uniquePassengers,
        flights: uniqueFlights
    };
}


    /* =====================================================
       GENERATE INVOICE
    ===================================================== */

    function generateInvoiceNumber() {

        return (
            "AMT" +
            Math.floor(
                10000 +
                Math.random() * 90000
            )
        );

    }


    /* =====================================================
       SABRE ERROR
    ===================================================== */

    function showSabreError(
        message
    ) {

        const error =
            document.getElementById(
                "sabrePnrError"
            );


        if (!error) {
            return;
        }


        error.textContent =
            "⚠️ " + message;


        error.style.display =
            "block";

    }


    function clearSabreError() {

        const error =
            document.getElementById(
                "sabrePnrError"
            );


        if (error) {

            error.textContent =
                "";

            error.style.display =
                "none";

        }

    }


    /* =====================================================
       PARSE ALL SABRE PNR
    ===================================================== */

    function parseAllSabrePNR() {

        const textarea =
            document.getElementById(
                "sabrePnrInput"
            );


        const raw =
            textarea
                ? textarea.value
                : "";


        clearSabreError();


        if (!raw.trim()) {

            showSabreError(
                "Please paste Sabre PNR data first."
            );

            return;

        }


        const chunks =
            splitMultiPNR(raw);


        const parsed =
            chunks
                .map(
                    function (chunk) {

                        const data =
                            parsePNR(chunk);


                        return {

                            id:
                                uid(),

                            pnrCode:
                                data.gdsPnr ||
                                extractPNRCode(
                                    chunk
                                ),

                            invoiceNo:
                                '',

                            raw:
                                chunk,

                            passengers:
                                data.passengers,

                            flights:
                                data.flights,

                            applied:
                                false

                        };

                    }
                )
                .filter(
                    function (result) {

                        return (
                            result.passengers.length >
                                0 ||
                            result.flights.length >
                                0
                        );

                    }
                );


        if (!parsed.length) {

            showSabreError(
                "Could not detect passengers or flights. Please check the Sabre PNR format."
            );

            return;

        }


        sabreResults =
            parsed;


        sabreApplied =
            {};


        renderSabreResults();

    }


    /* =====================================================
       RENDER SABRE RESULTS
    ===================================================== */

    function renderSabreResults() {

        const container =
            document.getElementById(
                "sabrePnrResults"
            );


        if (!container) {
            return;
        }


        container.innerHTML =
            "";


        if (!sabreResults.length) {
            return;
        }


        const applyAllButton =
            document.getElementById(
                "applyAllSabrePNR"
            );


        if (applyAllButton) {

            applyAllButton.style.display =
                sabreResults.length > 1
                    ? "block"
                    : "none";

        }


        sabreResults.forEach(
            function (
                result,
                resultIndex
            ) {

                container.insertAdjacentHTML(
                    "beforeend",

                    createSabreResultHTML(
                        result,
                        resultIndex
                    )
                );

            }
        );

    }


    /* =====================================================
       RESULT HTML
    ===================================================== */

    function createSabreResultHTML(
        result,
        resultIndex
    ) {

        const applied =
            !!sabreApplied[
                result.id
            ];


        const passengerHTML =
            result.passengers
                .map(
                    function (
                        passenger,
                        index
                    ) {

                        return `

                            <div
                                class="sabre-passenger-row"
                                data-result="${resultIndex}"
                                data-passenger="${index}"
                            >

                                <select
                                    class="sabre-pax-title"
                                    data-field="title"
                                >

                                    <option
                                        value="Mr"
                                        ${
                                            passenger.title ===
                                            "Mr"
                                                ? "selected"
                                                : ""
                                        }
                                    >
                                        MR
                                    </option>

                                    <option
                                        value="Mrs"
                                        ${
                                            passenger.title ===
                                            "Mrs"
                                                ? "selected"
                                                : ""
                                        }
                                    >
                                        MRS
                                    </option>

                                    <option
                                        value="Ms"
                                        ${
                                            passenger.title ===
                                            "Ms"
                                                ? "selected"
                                                : ""
                                        }
                                    >
                                        MS
                                    </option>

                                    <option
                                        value="Miss"
                                        ${
                                            passenger.title ===
                                            "Miss"
                                                ? "selected"
                                                : ""
                                        }
                                    >
                                        MISS
                                    </option>

                                    <option
                                        value="Child"
                                        ${
                                            passenger.title ===
                                            "Child"
                                                ? "selected"
                                                : ""
                                        }
                                    >
                                        CHILD
                                    </option>

                                </select>


                                <input
                                    type="text"
                                    value="${escapeHtml(
                                        passenger.surname
                                    )}"
                                    data-field="surname"
                                    placeholder="SURNAME"
                                >


                                <input
                                    type="text"
                                    value="${escapeHtml(
                                        passenger.firstname
                                    )}"
                                    data-field="firstname"
                                    placeholder="FIRST NAME"
                                >


                                <button
                                    type="button"
                                    class="sabre-remove"
                                    onclick="
                                        removeSabrePassenger(
                                            ${resultIndex},
                                            ${index}
                                        )
                                    "
                                >
                                    ×
                                </button>

                            </div>

                        `;

                    }
                )
                .join("");


        const miniFlights =
            result.flights
                .map(
                    function (flight) {

                        return `

                            <div
                                class="sabre-flight-mini"
                            >

                                <strong>
                                    ${escapeHtml(
                                        flight.airline
                                    )}
                                    ${escapeHtml(
                                        flight.flight
                                    )}
                                </strong>

                                <span>
                                    ${escapeHtml(
                                        formatDisplayDate(
                                            flight.departure_date
                                        )
                                    )}
                                </span>

                                <span>
                                    ${escapeHtml(
                                        flight.origin
                                    )}
                                    →
                                    ${escapeHtml(
                                        flight.destination
                                    )}
                                </span>

                                <span>
                                    ${escapeHtml(
                                        flight.departure_time
                                    )}
                                </span>

                            </div>

                        `;

                    }
                )
                .join("");


        const flightRows =
            result.flights
                .map(
                    function (
                        flight,
                        index
                    ) {

                        return `

                            <tr>

                                <td>

                                    <input
                                        type="text"
                                        value="${escapeHtml(
                                            flight.airline
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'airline',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="text"
                                        value="${escapeHtml(
                                            flight.flight
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'flight',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="date"
                                        value="${escapeHtml(
                                            flight.departure_date
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'departure_date',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="text"
                                        value="${escapeHtml(
                                            flight.origin
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'origin',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="text"
                                        value="${escapeHtml(
                                            flight.destination
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'destination',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="time"
                                        value="${escapeHtml(
                                            flight.departure_time
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'departure_time',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="time"
                                        value="${escapeHtml(
                                            flight.arrival_time
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'arrival_time',
                                                this.value
                                            )
                                        "
                                    >

                                </td>


                                <td>

                                    <input
                                        type="text"
                                        value="${escapeHtml(
                                            flight.baggage || ""
                                        )}"
                                        onchange="
                                            updateSabreFlight(
                                                ${resultIndex},
                                                ${index},
                                                'baggage',
                                                this.value
                                            )
                                        "
                                        placeholder="e.g. 23kg"
                                    >

                                </td>


                                <td>

                                    <button
                                        type="button"
                                        class="sabre-remove"
                                        onclick="
                                            removeSabreFlight(
                                                ${resultIndex},
                                                ${index}
                                            )
                                        "
                                    >
                                        ×
                                    </button>

                                </td>

                            </tr>

                        `;

                    }
                )
                .join("");


        return `

            <div
                class="sabre-result-card ${
                    applied
                        ? "applied"
                        : ""
                }"
                id="sabreResult_${result.id}"
            >


                <div
                    class="sabre-result-header"
                >

                    <div
                        class="sabre-result-info"
                    >

                        <div>

                            <div
                                class="sabre-stat-label"
                            >
                                GDS PNR
                            </div>

                            <div
                                class="sabre-stat-value sabre-pnr-code"
                            >
                                ${escapeHtml(
                                    result.pnrCode
                                )}
                            </div>

                        </div>


                        <div>

                            <div
                                class="sabre-stat-label"
                            >
                                Invoice No
                            </div>

                            <div
                                class="sabre-stat-value"
                            >
                                ${escapeHtml(
                                    result.invoiceNo
                                )}
                            </div>

                        </div>


                        <div>

                            <div
                                class="sabre-stat-label"
                            >
                                Passengers
                            </div>

                            <div
                                class="sabre-stat-value"
                            >
                                ${
                                    result.passengers.length
                                }
                                pax
                            </div>

                        </div>


                        <div>

                            <div
                                class="sabre-stat-label"
                            >
                                Flight Legs
                            </div>

                            <div
                                class="sabre-stat-value"
                            >
                                ${
                                    result.flights.length
                                }
                                ${
                                    result.flights.length === 1
                                        ? "leg"
                                        : "legs"
                                }
                            </div>

                        </div>

                    </div>


                    <div
                        class="sabre-result-actions"
                    >

                        ${
                            applied

                                ?

                            `

                                <div
                                    class="sabre-applied"
                                >
                                    ✓ Applied to Booking
                                </div>

                            `

                                :

                            `

                                <button
                                    type="button"
                                    class="sabre-apply-one"
                                    onclick="
                                        applyOneSabrePNR(
                                            ${resultIndex}
                                        )
                                    "
                                >
                                    ➕ Apply to Booking
                                </button>

                            `

                        }

                    </div>

                </div>


                <div
                    class="sabre-result-body"
                >

                    <div
                        class="sabre-result-grid"
                    >


                        <div
                            class="
                                sabre-preview-box
                                sabre-passengers-box
                            "
                        >

                            <div
                                class="sabre-preview-title"
                            >
                                👤 Passengers
                                (${result.passengers.length})
                            </div>

                            ${passengerHTML}

                        </div>


                        <div
                            class="
                                sabre-preview-box
                                sabre-flights-box
                            "
                        >

                            <div
                                class="sabre-preview-title"
                            >
                                ✈ Flights
                                (${result.flights.length} legs)
                            </div>


                            <div
                                class="sabre-flight-summary"
                            >

                                ${miniFlights}

                            </div>

                        </div>

                    </div>


                    <div
                        class="sabre-flight-edit-title"
                    >
                        ✏ Edit Flight Details
                    </div>


                    <div
                        class="sabre-flight-table-wrapper"
                    >

                        <table
                            class="sabre-flight-table"
                        >

                            <thead>

                                <tr>

                                    <th>A/L</th>

                                    <th>Flight</th>

                                    <th>Date</th>

                                    <th>From</th>

                                    <th>To</th>

                                    <th>Departs</th>

                                    <th>Arrives</th>

                                    <th>Baggage</th>

                                    <th>Action</th>

                                </tr>

                            </thead>


                            <tbody>

                                ${flightRows}

                            </tbody>

                        </table>

                    </div>


                    <button
                        type="button"
                        class="sabre-add-leg"
                        onclick="
                            addSabreFlight(
                                ${resultIndex}
                            )
                        "
                    >
                        + Add Leg
                    </button>

                </div>

            </div>

        `;

    }


    /* =====================================================
       FORMAT DISPLAY DATE
    ===================================================== */

    function formatDisplayDate(
        value
    ) {

        if (!value) {
            return "";
        }


        const parts =
            value.split("-");


        if (
            parts.length !== 3
        ) {

            return value;

        }


        return (
            parts[2] +
            "/" +
            parts[1] +
            "/" +
            parts[0]
        );

    }


    /* =====================================================
       UPDATE SABRE PASSENGER
    ===================================================== */

    function updateSabrePassenger(
        resultIndex,
        passengerIndex,
        field,
        value
    ) {

        if (
            !sabreResults[resultIndex]
        ) {

            return;

        }


        if (
            !sabreResults[resultIndex]
                .passengers[passengerIndex]
        ) {

            return;

        }


        sabreResults[resultIndex]
            .passengers[passengerIndex][field] =
            value;

    }


    /* =====================================================
       UPDATE SABRE FLIGHT
    ===================================================== */

    window.updateSabreFlight =
        function (
            resultIndex,
            flightIndex,
            field,
            value
        ) {


            if (
                !sabreResults[resultIndex]
            ) {

                return;

            }


            if (
                !sabreResults[resultIndex]
                    .flights[flightIndex]
            ) {

                return;

            }


            sabreResults[resultIndex]
                .flights[flightIndex][field] =
                value;

        };


    /* =====================================================
       REMOVE SABRE PASSENGER
    ===================================================== */

    window.removeSabrePassenger =
        function (
            resultIndex,
            passengerIndex
        ) {


            if (
                !sabreResults[resultIndex]
            ) {

                return;

            }


            sabreResults[resultIndex]
                .passengers
                .splice(
                    passengerIndex,
                    1
                );


            renderSabreResults();

        };


    /* =====================================================
       REMOVE SABRE FLIGHT
    ===================================================== */

    window.removeSabreFlight =
        function (
            resultIndex,
            flightIndex
        ) {


            if (
                !sabreResults[resultIndex]
            ) {

                return;

            }


            sabreResults[resultIndex]
                .flights
                .splice(
                    flightIndex,
                    1
                );


            renderSabreResults();

        };


    /* =====================================================
       ADD SABRE FLIGHT
    ===================================================== */

    window.addSabreFlight =
        function (
            resultIndex
        ) {


            if (
                !sabreResults[resultIndex]
            ) {

                return;

            }


            sabreResults[resultIndex]
                .flights
                .push({

                    id:
                        uid(),

                    airline:
                        "",

                    flight:
                        "",

                    departure_date:
                        "",

                    origin:
                        "",

                    destination:
                        "",

                    departure_time:
                        "",

                    arrival_time:
                        "",

                    baggage:
                        ""

                });


            renderSabreResults();

        };


    /* =====================================================
       APPLY ONE PNR
    ===================================================== */

    window.applyOneSabrePNR =
        function (
            resultIndex
        ) {


            const result =
                sabreResults[
                    resultIndex
                ];


            if (!result) {
                return;
            }


            /*
             * Apply data to booking.
             */

            applyPNRToCurrentBooking(
                result
            );


            /*
             * Mark as applied.
             */

            sabreApplied[
                result.id
            ] = true;


            renderSabreResults();

        };


    /* =====================================================
       APPLY ALL PNRs
    ===================================================== */

    function applyAllSabrePNRs() {

        if (
            !sabreResults.length
        ) {

            return;

        }


        const combined = {

            id:
                uid(),

            pnrCode:
                sabreResults
                    .map(function (r) {

                        return r.pnrCode;

                    })
                    .join(", "),

            invoiceNo:
                sabreResults[0]
                    .invoiceNo,

            passengers:
                sabreResults.flatMap(
                    function (r) {

                        return r.passengers;

                    }
                ),

            flights:
                sabreResults.flatMap(
                    function (r) {

                        return r.flights;

                    }
                )

        };


        applyPNRToCurrentBooking(
            combined
        );


        sabreResults.forEach(
            function (result) {

                sabreApplied[
                    result.id
                ] = true;

            }
        );


        renderSabreResults();

    }


    /* =====================================================
       SET BOOKING FIELD
    ===================================================== */

    function setSabreBookingField(
        fieldName,
        value
    ) {

        const field =
            document.querySelector(
                '[name="' +
                fieldName +
                '"]'
            );


        if (!field) {

            console.warn(
                "Booking field not found:",
                fieldName
            );

            return;

        }


        field.value =
            value || "";


        field.dispatchEvent(
            new Event(
                "input",
                {
                    bubbles: true
                }
            )
        );


        field.dispatchEvent(
            new Event(
                "change",
                {
                    bubbles: true
                }
            )
        );

    }


    /* =====================================================
       APPLY PNR TO CURRENT BOOKING
    ===================================================== */

    function applyPNRToCurrentBooking(
        result
    ) {


        /*
         * ================================================
         * INVOICE
         * ================================================
         */

        if (
            result.invoiceNo
        ) {

            setSabreBookingField(
                "invoice_no",
                result.invoiceNo
            );

        }


        /*
         * ================================================
         * PNR
         * ================================================
         */

        setSabreBookingField(
            "pnr",
            result.pnrCode
        );


        /*
         * ================================================
         * TRAVEL DATE
         * ================================================
         */

        if (
            result.flights &&
            result.flights.length
        ) {

            setSabreBookingField(
                "travel_date",
                result.flights[0]
                    .departure_date
            );

        }


        /*
         * ================================================
         * DESTINATION
         * ================================================
         */

        if (
            result.flights &&
            result.flights.length
        ) {

            const lastFlight =
                result.flights[
                    result.flights.length - 1
                ];


            setSabreBookingField(
                "destination",
                lastFlight.destination
            );

        }


        /*
         * ================================================
         * PASSENGERS
         * ================================================
         */

        populateBookingPassengers(
            result.passengers || []
        );


        /*
         * ================================================
         * FLIGHTS
         * ================================================
         */

        populateBookingFlights(
            result.flights || []
        );


        /*
         * ================================================
         * COST QUANTITY
         * ================================================
         */

        updateCostPassengerQuantity(
            result.passengers
                ? result.passengers.length
                : 0
        );


        /*
         * ================================================
         * CLOSE SABRE
         * ================================================
         */

        closeSabreModal();


        /*
         * ================================================
         * OPEN BOOKING MODAL
         *
         * IMPORTANT:
         *
         * We call the global function instead
         * of manually adding "show".
         *
         * This keeps opening/closing consistent.
         * ================================================
         */

        if (
            typeof window.openBookingModal ===
            "function"
        ) {

            window.openBookingModal();

        } else {

            /*
             * Fallback
             */

            const bookingModal =
                document.getElementById(
                    "bookingModal"
                );


            if (bookingModal) {

                bookingModal.classList.add(
                    "show"
                );

                bookingModal.style.display =
                    "flex";

                document.body.style.overflow =
                    "hidden";

            }

        }


        /*
         * ================================================
         * SUCCESS MESSAGE
         * ================================================
         */

        setTimeout(
            function () {

                alert(
                    "Sabre PNR applied successfully.\n\n" +
                    "PNR: " +
                    result.pnrCode +
                    "\nPassengers: " +
                    (
                        result.passengers ||
                        []
                    ).length +
                    "\nFlight Legs: " +
                    (
                        result.flights ||
                        []
                    ).length
                );

            },
            100
        );

    }


    /* =====================================================
       POPULATE BOOKING PASSENGERS
    ===================================================== */

    function populateBookingPassengers(
        passengers
    ) {

        const tbody =
            document.getElementById(
                "passengerRows"
            );


        if (!tbody) {

            console.warn(
                "passengerRows not found."
            );

            return;

        }


        /*
         * Remove existing rows.
         */

        tbody.innerHTML =
            "";


        /*
         * Reset counter.
         */

        passengerIndex =
            passengers.length;


        passengers.forEach(
            function (
                passenger,
                index
            ) {


                const row =
                    document.createElement(
                        "tr"
                    );


                const title =
                    normalizeTitle(
                        passenger.title
                    );


                row.innerHTML = `

                    <td>

                        <select
                            name="passengers[${index}][title]"
                        >

                            <option
                                value="Mr"
                                ${
                                    title === "Mr"
                                        ? "selected"
                                        : ""
                                }
                            >
                                Mr
                            </option>


                            <option
                                value="Mrs"
                                ${
                                    title === "Mrs"
                                        ? "selected"
                                        : ""
                                }
                            >
                                Mrs
                            </option>


                            <option
                                value="Ms"
                                ${
                                    title === "Ms"
                                        ? "selected"
                                        : ""
                                }
                            >
                                Ms
                            </option>


                            <option
                                value="Miss"
                                ${
                                    title === "Miss"
                                        ? "selected"
                                        : ""
                                }
                            >
                                Miss
                            </option>

                            <option
                                value="Master"
                                ${
                                    title === "Master"
                                        ? "selected"
                                        : ""
                                }
                            >
                                Master
                            </option>


                            <option
                                value="Child"
                                ${
                                    title === "Child"
                                        ? "selected"
                                        : ""
                                }
                            >
                                Child
                            </option>

                        </select>

                    </td>


                    <td>

                        <input
                            type="text"
                            name="passengers[${index}][surname]"
                            value="${escapeHtml(
                                passenger.surname
                            )}"
                            placeholder="SURNAME"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="passengers[${index}][firstname]"
                            value="${escapeHtml(
                                passenger.firstname
                            )}"
                            placeholder="FIRSTNAME"
                        >

                    </td>


                    <td>

                        <button
                            type="button"
                            class="btn-delete"
                            onclick="deleteRow(this)"
                        >
                            ×
                        </button>

                    </td>

                `;


                tbody.appendChild(
                    row
                );

            }
        );

    }


    /* =====================================================
       POPULATE BOOKING FLIGHTS
    ===================================================== */

    function populateBookingFlights(
        flights
    ) {

        const tbody =
            document.getElementById(
                "flightRows"
            );


        if (!tbody) {

            console.warn(
                "flightRows not found."
            );

            return;

        }


        /*
         * Clear existing flights.
         */

        tbody.innerHTML =
            "";


        /*
         * Reset counter.
         */

        flightIndex =
            flights.length;


        flights.forEach(
            function (
                flight,
                index
            ) {


                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>

                        <input
                            type="text"
                            name="flights[${index}][airline]"
                            value="${escapeHtml(
                                flight.airline
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="flights[${index}][flight]"
                            value="${escapeHtml(
                                flight.flight
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="date"
                            name="flights[${index}][departure_date]"
                            value="${escapeHtml(
                                flight.departure_date
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="flights[${index}][origin]"
                            value="${escapeHtml(
                                flight.origin
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="flights[${index}][destination]"
                            value="${escapeHtml(
                                flight.destination
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="time"
                            name="flights[${index}][departure_time]"
                            value="${escapeHtml(
                                flight.departure_time
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="time"
                            name="flights[${index}][arrival_time]"
                            value="${escapeHtml(
                                flight.arrival_time
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="flights[${index}][baggage]"
                            value="${escapeHtml(
                                flight.baggage || ""
                            )}"
                            placeholder="e.g. 23kg"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="flights[${index}][supplier]"
                            value="${escapeHtml(
                                flight.supplier || ""
                            )}"
                            placeholder="Supplier"
                        >

                    </td>


                    <td>

                        <button
                            type="button"
                            class="btn-delete"
                            onclick="deleteRow(this)"
                        >
                            ×
                        </button>

                    </td>

                `;


                tbody.appendChild(
                    row
                );

            }
        );

    }


    /* =====================================================
       UPDATE COST PASSENGER QUANTITY
    ===================================================== */

    function updateCostPassengerQuantity(
        passengerCount
    ) {

        const qty =
            document.querySelector(
                "#costRows .qty"
            );


        if (!qty) {
            return;
        }


        if (
            passengerCount > 0
        ) {

            qty.value =
                passengerCount;


            qty.dispatchEvent(
                new Event(
                    "input",
                    {
                        bubbles: true
                    }
                )
            );


            qty.dispatchEvent(
                new Event(
                    "change",
                    {
                        bubbles: true
                    }
                )
            );

        }

    }


    /* =====================================================
       SABRE PASSENGER EDIT EVENTS
    ===================================================== */

    document.addEventListener(
        "change",
        function (event) {


            const element =
                event.target;


            if (
                !element.closest(
                    ".sabre-passenger-row"
                )
            ) {

                return;

            }


            const row =
                element.closest(
                    ".sabre-passenger-row"
                );


            const resultIndex =
                parseInt(
                    row.dataset.result,
                    10
                );


            const passengerIndexValue =
                parseInt(
                    row.dataset.passenger,
                    10
                );


            const field =
                element.dataset.field;


            updateSabrePassenger(
                resultIndex,
                passengerIndexValue,
                field,
                element.value
            );

        }
    );


    /* =====================================================
       OPEN SABRE MODAL
    ===================================================== */

    function openSabreModal() {

        const modal =
            document.getElementById(
                "sabrePnrModal"
            );


        if (!modal) {

            console.error(
                "Sabre modal (#sabrePnrModal) was not found."
            );

            return;

        }


        /*
         * Explicitly set display.
         */

        modal.style.display =
            "flex";


        modal.classList.add(
            "show"
        );


        document.body.style.overflow =
            "hidden";

    }


    /* =====================================================
       CLOSE SABRE MODAL
    ===================================================== */

    function closeSabreModal() {

        const modal =
            document.getElementById(
                "sabrePnrModal"
            );


        if (!modal) {
            return;
        }


        /*
         * IMPORTANT:
         *
         * Remove BOTH class and inline display.
         */

        modal.classList.remove(
            "show"
        );


        modal.style.display =
            "none";


        /*
         * Only restore body scrolling
         * if booking modal is not open.
         */

        const bookingModal =
            document.getElementById(
                "bookingModal"
            );


        if (
            !bookingModal ||
            !bookingModal.classList.contains(
                "show"
            )
        ) {

            document.body.style.overflow =
                "";

        }

    }


    /*
     * Make Sabre close/open functions global.
     */

    window.openSabreModal =
        openSabreModal;

    window.closeSabreModal =
        closeSabreModal;


    /* =====================================================
       CLEAR SABRE PARSER
    ===================================================== */

    function clearSabreParser() {

        const textarea =
            document.getElementById(
                "sabrePnrInput"
            );


        if (textarea) {

            textarea.value =
                "";

        }


        sabreResults =
            [];


        sabreApplied =
            {};


        const results =
            document.getElementById(
                "sabrePnrResults"
            );


        if (results) {

            results.innerHTML =
                "";

        }


        const applyAll =
            document.getElementById(
                "applyAllSabrePNR"
            );


        if (applyAll) {

            applyAll.style.display =
                "none";

        }


        clearSabreError();

    }


    /* =====================================================
       LOAD SABRE SAMPLE
    ===================================================== */

    function loadSabreSample() {

        const textarea =
            document.getElementById(
                "sabrePnrInput"
            );


        if (textarea) {

            textarea.value =
                SABRE_SAMPLE;

        }


        sabreResults =
            [];


        sabreApplied =
            {};


        const results =
            document.getElementById(
                "sabrePnrResults"
            );


        if (results) {

            results.innerHTML =
                "";

        }


        clearSabreError();

    }


    /* =====================================================
       SABRE INITIALIZATION
    ===================================================== */

    document.addEventListener(
        "DOMContentLoaded",
        function () {


            /* =============================================
               OPEN SABRE
            ============================================= */

            const openButton =
                document.getElementById(
                    "openSabrePNR"
                );


            if (openButton) {

                openButton.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        openSabreModal();

                    }
                );

            }


            /* =============================================
               CLOSE SABRE
            ============================================= */

            const closeButton =
                document.getElementById(
                    "closeSabrePNR"
                );


            if (closeButton) {

                closeButton.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        closeSabreModal();

                    }
                );

            }


            /* =============================================
               PARSE
            ============================================= */

            const parseButton =
                document.getElementById(
                    "parseSabrePNR"
                );


            if (parseButton) {

                parseButton.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        parseAllSabrePNR();

                    }
                );

            }


            /* =============================================
               SAMPLE
            ============================================= */

            const sampleButton =
                document.getElementById(
                    "loadSabreSample"
                );


            if (sampleButton) {

                sampleButton.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        loadSabreSample();

                    }
                );

            }


            /* =============================================
               CLEAR
            ============================================= */

            const clearButton =
                document.getElementById(
                    "clearSabrePNR"
                );


            if (clearButton) {

                clearButton.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        clearSabreParser();

                    }
                );

            }


            /* =============================================
               APPLY ALL
            ============================================= */

            const applyAllButton =
                document.getElementById(
                    "applyAllSabrePNR"
                );


            if (applyAllButton) {

                applyAllButton.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        applyAllSabrePNRs();

                    }
                );

            }


            /* =============================================
               SABRE CLICK OUTSIDE
            ============================================= */

            const modal =
                document.getElementById(
                    "sabrePnrModal"
                );


            if (modal) {

                modal.addEventListener(
                    "click",
                    function (event) {

                        if (
                            event.target === modal
                        ) {

                            closeSabreModal();

                        }

                    }
                );

            }


            /* =============================================
               SABRE ESC
            ============================================= */

            document.addEventListener(
                "keydown",
                function (event) {


                    if (
                        event.key !== "Escape"
                    ) {

                        return;

                    }


                    const sabreModal =
                        document.getElementById(
                            "sabrePnrModal"
                        );


                    const bookingModal =
                        document.getElementById(
                            "bookingModal"
                        );


                    /*
                     * Close Sabre first if open.
                     */

                    if (
                        sabreModal &&
                        sabreModal.classList.contains(
                            "show"
                        )
                    ) {

                        closeSabreModal();

                        return;

                    }


                }
            );

        }
    );

})();


/* =========================================================
   SMART PACKAGE PARSER
========================================================= */

(function () {

    "use strict";


    /* =====================================================
       VARIABLES
    ====================================================== */

    let parsedPackage = null;


    /* =====================================================
       ELEMENTS
    ====================================================== */

    const packageModal =
        document.getElementById("packageImportModal");

    const openPackageBtn =
        document.getElementById("openPackageImport");

    const closePackageBtn =
        document.getElementById("closePackageImport");

    const packageText =
        document.getElementById("packageText");

    const parsePackageBtn =
        document.getElementById("parsePackageBtn");

    const loadPackageSample =
        document.getElementById("loadPackageSample");

    const clearPackageText =
        document.getElementById("clearPackageText");

    const packageResult =
        document.getElementById("packageResult");

    const applyPackageBtn =
        document.getElementById("applyPackageToBooking");


    /* =====================================================
       OPEN MODAL
    ====================================================== */

    if (openPackageBtn) {

        openPackageBtn.addEventListener("click", function () {

            packageModal.classList.add("show");

            document.body.style.overflow = "hidden";

            setTimeout(function () {

                packageText.focus();

            }, 100);

        });

    }


    /* =====================================================
       CLOSE MODAL
    ====================================================== */

    function closePackageModal() {

        packageModal.classList.remove("show");

        document.body.style.overflow = "";

    }


    if (closePackageBtn) {

        closePackageBtn.addEventListener(
            "click",
            closePackageModal
        );

    }


    /* =====================================================
       CLOSE WHEN CLICK OUTSIDE
    ====================================================== */

    if (packageModal) {

        packageModal.addEventListener("click", function (e) {

            if (e.target === packageModal) {

                closePackageModal();

            }

        });

    }


    /* =====================================================
       ESC KEY
    ====================================================== */

    document.addEventListener("keydown", function (e) {

        if (
            e.key === "Escape" &&
            packageModal.classList.contains("show")
        ) {

            closePackageModal();

        }

    });


    /* =====================================================
       SAMPLE
    ====================================================== */

    if (loadPackageSample) {

        loadPackageSample.addEventListener(
            "click",
            function () {

                packageText.value =
`✨ Sep 14-Nights Umrah Travel Arrangements ✨
Departure Date: 12-Sep-2026 | Return Date: 26-Sep-2026

☑ Flights: ➢
◆ Baggage 20KG 🧳
◆ Hand carry 7KG

☑ Visa: 8x E-Waiver Visa's

☑ Private Transport: Full Ground Transport (11-Seater)

MAKKAH
☑ Property: Al Ebaa Hotel (4-Star)
2x Quad Room · R/O · 7 nights

MADINAH
☑ Property: Durrat Al Eiman Hotel (4-Star)
2x Quad Room · R/O · 7 nights`;

                packageText.focus();

            }
        );

    }


    /* =====================================================
       CLEAR
    ====================================================== */

    if (clearPackageText) {

        clearPackageText.addEventListener(
            "click",
            function () {

                packageText.value = "";

                packageResult.innerHTML = "";

                packageResult.classList.remove("show");

                parsedPackage = null;

                if (applyPackageBtn) {

                    applyPackageBtn.disabled = true;

                }

            }
        );

    }


    /* =====================================================
       DATE PARSER
    ====================================================== */

    /* =========================================================
   UNIVERSAL DATE PARSER
   Supports:
   25-Sep-26
   25-Sep-2026
   25/Sep/26
   25/Sep/2026
   25 Sep 26
   25 Sep 2026
   25-09-26
   25-09-2026
   25 September 2026
========================================================= */

function parseDate(dateString) {

    if (!dateString) {
        return "";
    }

    let value = String(dateString)
        .trim()
        .replace(/[,\u00A0]/g, " ")
        .replace(/\s+/g, " ");

    const months = {
        jan: "01",
        january: "01",

        feb: "02",
        february: "02",

        mar: "03",
        march: "03",

        apr: "04",
        april: "04",

        may: "05",

        jun: "06",
        june: "06",

        jul: "07",
        july: "07",

        aug: "08",
        august: "08",

        sep: "09",
        sept: "09",
        september: "09",

        oct: "10",
        october: "10",

        nov: "11",
        november: "11",

        dec: "12",
        december: "12"
    };

    let day;
    let month;
    let year;

    /* ---------------------------------------------
       DD-MMM-YYYY / DD-MMM-YY
    --------------------------------------------- */

    let match = value.match(
        /^(\d{1,2})[-\/\s]([A-Za-z]+)[-\/\s](\d{2,4})$/i
    );

    if (match) {

        day = parseInt(match[1], 10);

        month =
            months[
                match[2]
                    .toLowerCase()
            ];

        year =
            parseInt(
                match[3],
                10
            );

        if (year < 100) {
            year += 2000;
        }

        if (!month) {
            return "";
        }

        return (
            year +
            "-" +
            month +
            "-" +
            String(day).padStart(2, "0")
        );
    }

    /* ---------------------------------------------
       DD-MM-YYYY / DD-MM-YY
    --------------------------------------------- */

    match = value.match(
        /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{2,4})$/
    );

    if (match) {

        day =
            parseInt(match[1], 10);

        month =
            parseInt(match[2], 10);

        year =
            parseInt(match[3], 10);

        if (year < 100) {
            year += 2000;
        }

        if (
            month < 1 ||
            month > 12 ||
            day < 1 ||
            day > 31
        ) {
            return "";
        }

        return (
            year +
            "-" +
            String(month).padStart(2, "0") +
            "-" +
            String(day).padStart(2, "0")
        );
    }

    return "";
}


    /* =====================================================
       DISPLAY DATE
    ====================================================== */

    function displayDate(date) {

        if (!date) {

            return "";

        }

        const parts = date.split("-");

        if (parts.length !== 3) {

            return date;

        }

        return (
            parts[2] +
            "-" +
            parts[1] +
            "-" +
            parts[0]
        );

    }


    /* =====================================================
       PARSE PACKAGE
    ====================================================== */

/* =========================================================
   UNIVERSAL SMART PACKAGE PARSER
========================================================= */

function parsePackage(text) {

    const result = {
        title: "",
        departureDate: "",
        returnDate: "",
        baggage: "",
        visa: "",
        transport: "",
        transportItems: [],
        price: "",
        hotels: [],
        raw: text
    };

    if (!text || !String(text).trim()) {
        return result;
    }

    /* =====================================================
       UNIVERSAL NORMALIZATION
       Handles WhatsApp, Word, copied PDFs, bullets, emoji,
       markdown *bold*, tabs, CRLF and mixed spacing.
    ====================================================== */

    const normalizedText = String(text)
        .replace(/\r\n/g, "\n")
        .replace(/\r/g, "\n")
        .replace(/\u00A0/g, " ")
        .replace(/[\u200B-\u200D\uFEFF]/g, "")
        .replace(/[ \t]+/g, " ");

    const stripDecorators = function (value) {
        return String(value || "")
            // WhatsApp / copied-message bullets and checkmarks, including U+2705.
            .replace(/^[\s*_~`☑✔✓◆🔹➢•▪◾▶►→✅]+/u, "")
            .replace(/^[\s*_~`]+|[\s*_~`]+$/g, "")
            .replace(/^[☑✔✓◆🔹➢•▪◾▶►→✅]+\s*/u, "")
            .replace(/\s*[✨⭐🌟📦🎯]+\s*$/u, "")
            .trim();
    };

    const lines = normalizedText
        .split("\n")
        .map(function (line) {
            return stripDecorators(cleanValue(line));
        })
        .filter(Boolean);

    const plainText = lines.join("\n");

    /* =====================================================
       LOCAL HELPERS
    ====================================================== */

    const normalizeLabel = function (value) {
        return stripDecorators(value)
            .replace(/[:：]+\s*$/, "")
            .replace(/\s+/g, " ")
            .trim();
    };

    const dateFromText = function (value) {
        if (!value) return "";

        const source = String(value).trim();
        const candidates = [];

        // YYYY-MM-DD / YYYY/MM/DD
        let m = source.match(/\b20\d{2}[-\/]\d{1,2}[-\/]\d{1,2}\b/);
        if (m) candidates.push(m[0]);

        // DD-MMM-YYYY / DD/MMM/YYYY / DD MMM YYYY
        m = source.match(/\b\d{1,2}[-\/\s](?:JAN|JANUARY|FEB|FEBRUARY|MAR|MARCH|APR|APRIL|MAY|JUN|JUNE|JUL|JULY|AUG|AUGUST|SEP|SEPT|SEPTEMBER|OCT|OCTOBER|NOV|NOVEMBER|DEC|DECEMBER)[-\/\s]\d{2,4}\b/i);
        if (m) candidates.push(m[0]);

        // DD-MM-YYYY / DD/MM/YYYY
        m = source.match(/\b\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4}\b/);
        if (m) candidates.push(m[0]);

        // DD-MMM (year omitted)
        m = source.match(/\b\d{1,2}[-\/](?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|SEPT|OCT|NOV|DEC)\b/i);
        if (m) candidates.push(m[0]);

        for (const candidate of candidates) {
            const parsed = parseDate(candidate);
            if (parsed) return parsed;
        }

        return "";
    };

    const detectCity = function (value) {
        const v = normalizeLabel(value).toUpperCase()
            .replace(/\bHOTEL\b/g, "")
            .replace(/\bCITY\b/g, "")
            .trim();

        if (/^(MAKKAH|MECCA)$/.test(v)) return "MAKKAH";
        if (/^(MADINAH|MADINA|MEDINA)$/.test(v)) return "MADINAH";
        if (/^(ISTANBUL|TURKEY)$/.test(v)) return "ISTANBUL";
        if (/^(RIYADH|RIYAD)$/.test(v)) return "RIYADH";
        if (/^(JEDDAH|JEDDA)$/.test(v)) return "JEDDAH";
        if (/^(TAIF|TA'IF)$/.test(v)) return "TAIF";
        return "";
    };

    const cityFromHeader = function (value) {
        const v = normalizeLabel(value).toUpperCase();
        if (/\b(?:MAKKAH|MECCA)\b/.test(v)) return "MAKKAH";
        if (/\b(?:MADINAH|MADINA|MEDINA)\b/.test(v)) return "MADINAH";
        if (/\bISTANBUL\b|\bTURKEY\b/.test(v)) return "ISTANBUL";
        if (/\bRIYADH\b|\bRIYAD\b/.test(v)) return "RIYADH";
        if (/\bJEDDAH\b|\bJEDDA\b/.test(v)) return "JEDDAH";
        if (/\bTAIF\b|\bTA'IF\b/.test(v)) return "TAIF";
        return "";
    };

    const mealFromText = function (value) {
        const v = String(value || "").toUpperCase();
        if (/\b(?:FULL[\s-]*BOARD|FULL[\s-]*BOARDING|FB)\b/.test(v)) return "FB";
        if (/\b(?:HALF[\s-]*BOARD|HALF[\s-]*BOARDING|HB)\b/.test(v)) return "HB";
        if (/\b(?:BED[\s-]*AND[\s-]*BREAKFAST|B\s*&\s*B|BREAKFAST|BB)\b/.test(v)) return "BB";
        if (/\b(?:ROOM[\s-]*ONLY|R\s*\/\s*O|RO)\b/.test(v)) return "RO";
        return "";
    };

    const viewFromText = function (value) {
        const v = String(value || "").toLowerCase();
        if (/kaaba|kaba|kabah/.test(v)) return "Kaaba View";
        if (/haram/.test(v)) return "Haram View";
        if (/partial/.test(v) && /kaaba|kaba/.test(v)) return "Partial Kaaba View";
        if (/patio/.test(v)) return "Patio View";
        if (/city/.test(v)) return "City View";
        return "";
    };

    const roomInfoFromText = function (value) {
        const v = stripDecorators(value);

        // Do not interpret nights, meals, views or transport routes as rooms.
        if (!/\brooms?\b|\b(single|double|twin|triple|quad|family|suite|sharing)\b/i.test(v)) {
            return { rooms: 0, roomType: "" };
        }
        const out = { rooms: 0, roomType: "" };

        // 02 Triple rooms / 01 Quad room / 2x Quad Room / 2 x Quad Room
        let m = v.match(/\b(\d+)\s*x\s*(private\s+)?(.+?)(?=\s*[·|,;]|\s+\d+\s*nights?\b|$)/i);
        if (!m) {
            m = v.match(/^\s*(\d+)\s+(private\s+)?(.+?)(?:\s+rooms?\b|\s*$)/i);
        }
        if (!m) {
            m = v.match(/\b(\d+)\s+(private\s+)?(single|double|twin|triple|quad|family|sharing|bedroom|room[^·|,;]*)\s*rooms?\b/i);
        }

        if (m) {
            out.rooms = parseInt(m[1], 10) || 1;
            let type = (m[3] || "").trim();
            type = type.replace(/\s+rooms?\b.*$/i, "").trim();
            type = type.replace(/\s*[·|,;].*$/, "").trim();
            if (type) {
                out.roomType = type
                    .replace(/\btrple\b/gi, "Triple")
                    .replace(/\broom\b/gi, "")
                    .trim() + " Room";
            }
        }

        // Room Type: Triple Room, Rooms: 2, 2 rooms - Triple
        if (!out.rooms) {
            const count = v.match(/\b(?:rooms?|no\.?\s*of\s*rooms?)\s*[:=-]?\s*(\d+)\b/i);
            if (count) out.rooms = parseInt(count[1], 10) || 1;
        }

        if (!out.roomType) {
            const type = v.match(/\broom\s*type\s*[:=-]?\s*([^·|,;]+?)(?:\s+\d+\s*nights?\b|$)/i);
            if (type) out.roomType = type[1]
                .replace(/\btrple\b/gi, "Triple")
                .replace(/\s*room\s*$/i, "")
                .trim() + " Room";
        }

        if (!out.roomType) {
            const simple = v.match(/\b(single|double|twin|triple|quad|family|suite|sharing)\s+rooms?\b/i);
            if (simple) out.roomType = simple[1].trim() + " Room";
        }

        return out;
    };

    const createHotel = function (city, name) {
        return {
            city: city || "OTHER",
            name: stripDecorators(name || ""),
            roomType: "",
            rooms: 1,
            meal: "RO",
            view: "",
            checkIn: "",
            nights: 1,
            checkOut: "",
            remarks: "",
            _explicitNights: false
        };
    };

    const hotelHeaderCity = function (line) {
        const cleaned = normalizeLabel(line);
        if (!/\bHOTEL\b/i.test(cleaned)) return "";
        if (/[→]|\s(?:-|–|—|to)\s/i.test(cleaned)) return "";
        const city = cityFromHeader(cleaned);
        if (!city) return "";
        // Only treat a simple city/hotel heading as a hotel section.
        if (/^(?:[^A-Z]*)(?:MAKKAH|MECCA|MADINAH|MADINA|MEDINA|ISTANBUL|TURKEY|RIYADH|RIYAD|JEDDAH|JEDDA|TAIF|TA'IF)\s+HOTEL(?:S)?[^A-Z]*$/i.test(cleaned)) {
            return city;
        }
        return "";
    };

    /* =====================================================
       TITLE
    ====================================================== */

    for (let i = 0; i < lines.length; i++) {
        const line = stripDecorators(lines[i]);
        if (!line) continue;

        if (/^(?:november|december|january|february|march|april|may|june|july|august|september|october)\b.*\bumrah\b/i.test(line) ||
            /\bumrah\b.*\bpackage\b/i.test(line) ||
            /\bpackage\b/i.test(line) ||
            /\btravel\s+arrangements?\b/i.test(line) ||
            /\bumrah\b/i.test(line)) {
            if (!/^(?:flight|flights|hotel|hotels|visa|visas|transport|transportation|price)\s*:/i.test(line)) {
                result.title = line.replace(/^[✨⭐🌟📦🎯]+\s*/u, "").trim();
                break;
            }
        }
    }

    /* =====================================================
       DEPARTURE / RETURN DATE
       Explicit labels first; then infer from hotel sequence.
    ====================================================== */

    const departureMatch = plainText.match(/\b(?:departure|depart|travel|journey)\s*date\s*[:\-]?\s*([^|\n]+)/i);
    const returnMatch = plainText.match(/\b(?:return|arrival)\s*date\s*[:\-]?\s*([^|\n]+)/i);

    if (departureMatch) result.departureDate = dateFromText(departureMatch[1]);
    if (returnMatch) result.returnDate = dateFromText(returnMatch[1]);

    /* =====================================================
       BAGGAGE
       Supports:
       23kg+07kg hand carry
       23 kg + 7 kg hand luggage
       Baggage: 20KG / Hand carry 7KG
       20kg checked + 7kg cabin
    ====================================================== */

    const baggageParts = [];
    let checked = "";
    let cabin = "";

    const baggageLineMatches = plainText.match(/[^\n]*(?:baggage|luggage|hand\s*carry|cabin)[^\n]*/gi) || [];

    for (const line of baggageLineMatches) {
        const v = line.toLowerCase();

        const hand = v.match(/(?:hand\s*carry|hand\s*luggage|cabin\s*(?:baggage|luggage)?|carry\s*on)[^\d]{0,10}(\d+(?:\.\d+)?)\s*(?:kg|kgs)\b/i);
        if (hand && !cabin) cabin = hand[1] + " kg cabin";

        const checkedMatch = v.match(/(?:checked\s*)?(?:baggage|luggage)[^\d]{0,10}(\d+(?:\.\d+)?)\s*(?:kg|kgs)\b/i);
        if (checkedMatch && !checked) checked = checkedMatch[1] + " kg checked";

        // "23kg+07kg hand carry" / "23kg + 7kg cabin"
        if (!checked) {
            const pair = v.match(/(\d+(?:\.\d+)?)\s*kg\s*\+\s*(\d+(?:\.\d+)?)\s*kg\s*(?:hand\s*carry|hand\s*luggage|cabin|carry\s*on)/i);
            if (pair) {
                checked = pair[1] + " kg checked";
                cabin = pair[2] + " kg cabin";
            }
        }
    }

    if (!checked) {
        const pair = plainText.match(/\b(\d+(?:\.\d+)?)\s*kg\s*\+\s*(\d+(?:\.\d+)?)\s*kg\s*(?:hand\s*carry|hand\s*luggage|cabin|carry\s*on)\b/i);
        if (pair) {
            checked = pair[1] + " kg checked";
            cabin = pair[2] + " kg cabin";
        }
    }

    if (checked) baggageParts.push(checked);
    if (cabin) baggageParts.push(cabin);
    if (baggageParts.length) result.baggage = baggageParts.join(" + ");

    /* =====================================================
       VISA
       Supports Visa, Visas, Visa's, Umrah Visa, ETA-Visas,
       visa included, and quantity + visa descriptions.
    ====================================================== */

    for (const line of lines) {
        if (/(?:^|\b)(?:umrah\s+)?visas?(?:['’]s)?\b/i.test(line)) {
            const value = line
                .replace(/^\s*(?:umrah\s+)?visas?(?:['’]s)?\s*[:\-]\s*/i, "")
                .trim();

            if (value && !/^(?:are\s+)?included$/i.test(value)) {
                result.visa = value;
                break;
            }
            if (/\bincluded\b/i.test(line)) {
                result.visa = cleanValue(line);
                break;
            }
        }
    }

    if (!result.visa) {
        const included = plainText.match(/\bvisas?\b[^\n]*\bincluded\b[^\n]*/i);
        if (included) result.visa = cleanValue(included[0]);
    }

    /* =====================================================
       TRANSPORT
       Supports:
       Transportation: ...
       Private Transportation:
       Private Transport - ...
       Transfer:
       Airport → Hotel
       Hotel - Makkah Hotel
    ====================================================== */

    const transportItems = [];
    let inTransport = false;

    const transportHeaderRegex = /^(?:.*\b(?:private\s+)?transport(?:ation)?\b.*|.*\btransfers?\b.*|.*\bground\s+transport\b.*)$/i;
    const transportStopRegex = /^(?:ziarat|ziyarat|visa|visas|price|cost|regards|thanks|terms|conditions|flight|flights|hotel|hotels)\s*[:\-]?\s*$/i;

    for (let i = 0; i < lines.length; i++) {
        const line = normalizeLabel(lines[i]);
        if (!line) continue;

        if (!inTransport && transportHeaderRegex.test(line)) {
            inTransport = true;

            let headerValue = "";
            let headerMatch = line.match(/\b(?:private\s+)?transport(?:ation)?\b\s*[:\-]?\s*(.*)$/i);
            if (headerMatch) {
                headerValue = headerMatch[1].trim();
            } else {
                headerMatch = line.match(/\btransfers?\b\s*[:\-]?\s*(.*)$/i);
                if (headerMatch) headerValue = headerMatch[1].trim();
            }

            if (headerValue && !/^(?:private|full|included)$/i.test(headerValue)) {
                transportItems.push(headerValue);
            }

            continue;
        }

        if (!inTransport) continue;

        const routeLike = /\b(?:airport|hotel|makkah|madinah|madina|medina|jeddah|riyadh|taif|mecca)\b/i.test(line) &&
            /(?:→|\b(?:airport|hotel|makkah|madinah|madina|medina|jeddah|riyadh|taif|mecca)\b\s*[-–—]\s*\b(?:airport|hotel|makkah|madinah|madina|medina|jeddah|riyadh|taif|mecca)\b|\s[-–—]\s|\s+to\s+)/i.test(line);

        // Keep actual transfer routes before checking for section boundaries.
        if (routeLike) {
            const value = line
                .replace(/^(?:\d+\s*[.)\-:]|[☑✔✓◆🔹➢•])\s*/u, "")
                .trim();
            if (value) transportItems.push(value);
            continue;
        }

        // A non-route line after the transport section marks the next section.
        if (transportStopRegex.test(line) || hotelHeaderCity(line)) {
            inTransport = false;
            continue;
        }

        // Numbered/bulleted transfer descriptions.
        const numbered = line.match(/^\d+\s*[.)\-:]\s*(.+)$/);
        const bullet = line.match(/^[☑✔✓◆🔹➢•]\s*(.+)$/u);
        const value = numbered ? numbered[1] : (bullet ? bullet[1] : "");
        if (value && /\b(?:airport|hotel|makkah|madinah|madina|medina|jeddah|riyadh|taif|mecca|transfer|transport)\b/i.test(value)) {
            transportItems.push(cleanValue(value));
        }
    }

    result.transportItems = [...new Set(transportItems)];
    result.transport = result.transportItems.join(" | ");

    /* =====================================================
       PRICE
       Supports £13,200, £ 13200, 13200 GBP, Family Deal,
       Price:, Total Price:, Price Per Person:, etc.
    ====================================================== */

    const pricePatterns = [
        /(?:price|cost|deal|package|fare)[^\n]{0,100}?[£$€]\s*([\d,]+(?:\.\d+)?)/i,
        /[£$€]\s*([\d,]+(?:\.\d+)?)/i,
        /(?:price|cost|deal|fare)[^\n]{0,100}?\b([\d,]+(?:\.\d+)?)\s*(?:GBP|SAR|USD|EUR)\b/i
    ];

    for (const pattern of pricePatterns) {
        const match = normalizedText.match(pattern);
        if (match) {
            result.price = match[1].replace(/,/g, "");
            break;
        }
    }

    /* =====================================================
       HOTELS — UNIVERSAL FORMAT ENGINE

       Supports both the old structured format and WhatsApp:

       MAKKAH
       Property: Hotel
       2x Quad Room · R/O · 7 nights

       *🕋MAKKAH HOTEL*
       Swissotel Makkah Hotel
       02 Triple rooms
       01 Quad room
       View: Kaaba View
       Meal: Full-Board
       Check In: 09-NOV-2026
       Check Out: 17-NOV-2026
    ====================================================== */

    let currentCity = "";
    let currentHotel = null;

    const finishHotel = function () {
        if (!currentHotel || !currentHotel.name) return;

        if (currentHotel.checkIn && currentHotel.checkOut && !currentHotel._explicitNights) {
            const start = new Date(currentHotel.checkIn + "T00:00:00");
            const end = new Date(currentHotel.checkOut + "T00:00:00");
            const diff = Math.round((end - start) / 86400000);
            if (diff > 0) currentHotel.nights = diff;
        }

        if (!currentHotel.checkIn) {
            if (result.hotels.length === 0 && result.departureDate) {
                currentHotel.checkIn = result.departureDate;
            } else {
                const previous = result.hotels[result.hotels.length - 1];
                if (previous && previous.checkOut) currentHotel.checkIn = previous.checkOut;
            }
        }

        if (currentHotel.checkIn && !currentHotel.checkOut && currentHotel.nights) {
            currentHotel.checkOut = addDays(currentHotel.checkIn, currentHotel.nights);
        }

        if (currentHotel.checkIn && currentHotel.checkOut && !currentHotel._explicitNights) {
            const start = new Date(currentHotel.checkIn + "T00:00:00");
            const end = new Date(currentHotel.checkOut + "T00:00:00");
            const diff = Math.round((end - start) / 86400000);
            if (diff > 0) currentHotel.nights = diff;
        }

        currentHotel.name = currentHotel.name
            .replace(/^property\s*:\s*/i, "")
            .trim();

        result.hotels.push(currentHotel);
        currentHotel = null;
    };

    const startHotel = function (city, name) {
        finishHotel();
        currentHotel = createHotel(city || currentCity || "OTHER", name);
    };

    for (let i = 0; i < lines.length; i++) {
        const line = stripDecorators(lines[i]);
        const low = line.toLowerCase();

        /* Explicit city header */
        const city = detectCity(line);
        if (city) {
            currentCity = city;
            continue;
        }

        /* Hotel section header: *🕌 MADINAH HOTEL*, MAKKAH HOTEL, etc. */
        const headerCity = hotelHeaderCity(line);
        if (headerCity) {
            currentCity = headerCity;

            // If hotel name is on the next meaningful line, use it.
            const next = lines[i + 1] ? stripDecorators(lines[i + 1]) : "";
            if (next &&
                !/:/.test(next) &&
                !/^\d+\s*x?\b/i.test(next) &&
                !/^(?:view|meal|check\s*in|check\s*out|rooms?|nights?)\b/i.test(next) &&
                !/^(?:flight|visa|transport|transportation|ziarat|price|regards)\b/i.test(next)) {
                startHotel(currentCity, next);
                i++;
            } else {
                finishHotel();
            }
            continue;
        }

        /* Property: Hotel Name */
        const propertyMatch = line.match(/^\s*property\s*[:\-]\s*(.+)$/i);
        if (propertyMatch) {
            startHotel(currentCity || "OTHER", propertyMatch[1]);
            continue;
        }

        if (!currentHotel) continue;

        /* Stop hotel when a new major section begins */
        if (/^(?:flight|flights|visa|visas|transport(?:ation)?|private\s+transport(?:ation)?|transfer|transfers|ziarat|ziyarat|price|cost|total\s+price|package\s+price|regards|thanks|terms|conditions)\b/i.test(low)) {
            finishHotel();
            continue;
        }

        /* Room information */
        const roomInfo = roomInfoFromText(line);
        if (roomInfo.rooms || roomInfo.roomType) {
            if (roomInfo.rooms) currentHotel.rooms += currentHotel.roomType ? roomInfo.rooms : (currentHotel.rooms === 1 ? roomInfo.rooms - 1 : roomInfo.rooms);
            if (roomInfo.roomType) currentHotel.roomType = currentHotel.roomType
                ? currentHotel.roomType + ", " + roomInfo.roomType
                : roomInfo.roomType;

            // Room, meal and nights can all be present on one line:
            // "2x Quad Room · R/O · 7 nights".
            const inlineMeal = mealFromText(line);
            if (inlineMeal) currentHotel.meal = inlineMeal;

            const inlineNights = line.match(/\b(\d+)\s*nights?\b/i);
            if (inlineNights) {
                currentHotel.nights = parseInt(inlineNights[1], 10) || 1;
                currentHotel._explicitNights = true;
            }

            continue;
        }

        /* Meal */
        const meal = mealFromText(line);
        if (meal) {
            currentHotel.meal = meal;
            continue;
        }

        /* View */
        const view = viewFromText(line);
        if (view) {
            currentHotel.view = view;
            continue;
        }

        /* Check-in */
        const checkIn = line.match(/^.*?check\s*[- ]?in\s*[:\-]?\s*(.+)$/i);
        if (checkIn) {
            currentHotel.checkIn = dateFromText(checkIn[1]);
            continue;
        }

        /* Check-out */
        const checkOut = line.match(/^.*?check\s*[- ]?out\s*[:\-]?\s*(.+)$/i);
        if (checkOut) {
            currentHotel.checkOut = dateFromText(checkOut[1]);
            continue;
        }

        /* Dates on same line: 03-NOV-2026 to 09-NOV-2026 */
        const range = line.match(/(\d{1,2}[-\/\s](?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|SEPT|OCT|NOV|DEC|JANUARY|FEBRUARY|MARCH|APRIL|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[-\/\s]\d{2,4}).*?(?:to|→|–|—|-).*?(\d{1,2}[-\/\s](?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|SEPT|OCT|NOV|DEC|JANUARY|FEBRUARY|MARCH|APRIL|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[-\/\s]\d{2,4})/i);
        if (range) {
            currentHotel.checkIn = dateFromText(range[1]);
            currentHotel.checkOut = dateFromText(range[2]);
            continue;
        }

        /* Nights */
        const nights = line.match(/\b(\d+)\s*nights?\b/i);
        if (nights) {
            currentHotel.nights = parseInt(nights[1], 10) || 1;
            currentHotel._explicitNights = true;
            continue;
        }

        /* Ignore generic section/detail lines */
        if (/^(?:meal|view|rooms?|room\s*type|check\s*in|check\s*out|nights?)\s*[:\-]/i.test(line)) continue;

        /* A hotel name can be a plain line after a city header. */
        if (currentHotel.name && currentHotel.name.toLowerCase() !== line.toLowerCase()) {
            if (!/^(?:02|01|03|04|05|06|07|08|09|10|11|12)\b/i.test(line) &&
                !/^\d+\s*(?:x|rooms?|nights?)/i.test(line)) {
                currentHotel.remarks = currentHotel.remarks
                    ? currentHotel.remarks + " | " + line
                    : line;
            }
        }
    }

    finishHotel();

    /* =====================================================
       NORMALIZE HOTEL ROOM COUNTS / SEQUENCE
    ====================================================== */

    result.hotels.forEach(function (hotel, index) {
        if (!hotel.rooms || hotel.rooms < 1) hotel.rooms = 1;
        if (!hotel.roomType) hotel.roomType = "Room";

        if (!hotel.checkIn) {
            hotel.checkIn = index === 0
                ? result.departureDate
                : (result.hotels[index - 1].checkOut || result.departureDate);
        }

        if (!hotel.checkOut && hotel.checkIn && hotel.nights) {
            hotel.checkOut = addDays(hotel.checkIn, hotel.nights);
        }

        if (hotel.checkIn && hotel.checkOut && !hotel._explicitNights) {
            const start = new Date(hotel.checkIn + "T00:00:00");
            const end = new Date(hotel.checkOut + "T00:00:00");
            const diff = Math.round((end - start) / 86400000);
            if (diff > 0) hotel.nights = diff;
        }
    });

    /* =====================================================
       INFER PACKAGE DATES FROM HOTELS WHEN NOT PROVIDED
    ====================================================== */

    if (!result.departureDate && result.hotels.length) {
        result.departureDate = result.hotels[0].checkIn || "";
    }

    if (!result.returnDate && result.hotels.length) {
        const lastHotel = result.hotels[result.hotels.length - 1];
        result.returnDate = lastHotel.checkOut || "";
    }

    /* If title is still empty, use the first meaningful line. */
    if (!result.title && lines.length) {
        result.title = lines[0];
    }

    result.hotels.forEach(function (hotel) {
        delete hotel._explicitNights;
    });

    return result;
}


    /* =====================================================
       CLEAN VALUE
    ====================================================== */

    function cleanValue(value) {

        return String(value || "")
            .replace(
                /^[☑✔✓◆🔹➢•▪◾▶►→✅\-]+\s*/u,
                ""
            )
            .replace(
                /\s+/g,
                " "
            )
            .trim();

    }


    /* =====================================================
       ADD DAYS
    ====================================================== */

    function addDays(dateString, days) {

        if (!dateString) {

            return "";

        }

        const date =
            new Date(
                dateString + "T00:00:00"
            );


        if (isNaN(date.getTime())) {

            return "";

        }


        date.setDate(
            date.getDate() +
            parseInt(days || 0, 10)
        );


        return (
            date.getFullYear() +
            "-" +
            String(
                date.getMonth() + 1
            ).padStart(2, "0") +
            "-" +
            String(
                date.getDate()
            ).padStart(2, "0")
        );

    }


    /* =====================================================
       RENDER RESULT
    ====================================================== */

    function renderPackageResult(data) {

        if (!packageResult) {

            return;

        }


        let hotelsHTML = "";


        if (
            data.hotels &&
            data.hotels.length
        ) {

            hotelsHTML =
                data.hotels.map(function (hotel) {

                    return `
                        <div class="package-hotel-item">

                            <div class="package-hotel-city">
                                ${escapeHTML(hotel.city)}
                            </div>

                            <div class="package-hotel-name">
                                ${escapeHTML(hotel.name)}
                            </div>

                            <div class="package-hotel-info">

                                ${hotel.rooms || 1}x
                                ${escapeHTML(hotel.roomType || "Room")}
                                ·
                                ${escapeHTML(hotel.meal || "RO")}
                                ·
                                ${hotel.nights || 1}
                                nights

                                <br>

                                ${
                                    hotel.checkIn
                                        ? escapeHTML(
                                            displayDate(
                                                hotel.checkIn
                                            )
                                        )
                                        : "-"
                                }

                                →

                                ${
                                    hotel.checkOut
                                        ? escapeHTML(
                                            displayDate(
                                                hotel.checkOut
                                            )
                                        )
                                        : "-"
                                }

                            </div>

                        </div>
                    `;

                }).join("");

        } else {

            hotelsHTML = `
                <div class="package-no-hotels">
                    No hotel information detected.
                </div>
            `;

        }


        packageResult.innerHTML = `

            <div class="package-result-grid">

                <!-- SUMMARY -->

                <div class="package-summary-card">

                    <div class="package-summary-title">
                        📋 Package Summary
                    </div>


                    <div class="package-summary-row">

                        <div class="package-summary-label">
                            Title:
                        </div>

                        <div class="package-summary-value">
                            ${escapeHTML(
                                data.title || "Not detected"
                            )}
                        </div>

                    </div>


                    <div class="package-summary-row">

                        <div class="package-summary-label">
                            Depart:
                        </div>

                        <div class="package-summary-value">
                            ${
                                data.departureDate
                                    ? escapeHTML(
                                        displayDate(
                                            data.departureDate
                                        )
                                    )
                                    : "Not detected"
                            }
                        </div>

                    </div>


                    <div class="package-summary-row">

                        <div class="package-summary-label">
                            Return:
                        </div>

                        <div class="package-summary-value">
                            ${
                                data.returnDate
                                    ? escapeHTML(
                                        displayDate(
                                            data.returnDate
                                        )
                                    )
                                    : "Not detected"
                            }
                        </div>

                    </div>


                    <div class="package-summary-row">

                        <div class="package-summary-label">
                            Baggage:
                        </div>

                        <div class="package-summary-value">
                            ${
                                escapeHTML(
                                    data.baggage ||
                                    "Not detected"
                                )
                            }
                        </div>

                    </div>


                    <div class="package-summary-row">

                        <div class="package-summary-label">
                            Visa:
                        </div>

                        <div class="package-summary-value">
                            ${
                                escapeHTML(
                                    data.visa ||
                                    "Not detected"
                                )
                            }
                        </div>

                    </div>


                    <div class="package-summary-row">

                        <div class="package-summary-label">
                            Transport:
                        </div>

                        <div class="package-summary-value">
                            ${
                                escapeHTML(
                                    data.transport ||
                                    "Not detected"
                                )
                            }
                        </div>

                    </div>


                    ${
                        data.price
                            ? `
                                <div class="package-summary-row">

                                    <div class="package-summary-label">
                                        Price/pax:
                                    </div>

                                    <div class="package-summary-value">
                                        £${escapeHTML(
                                            data.price
                                        )}
                                    </div>

                                </div>
                            `
                            : ""
                    }

                </div>


                <!-- HOTELS -->

                <div class="package-hotels-card">

                    <div class="package-hotels-title">

                        🏨 Hotels (${data.hotels.length})

                    </div>

                    ${hotelsHTML}

                </div>

            </div>

        `;


        packageResult.classList.add("show");


        if (applyPackageBtn) {

            applyPackageBtn.disabled = false;

        }

    }


    /* =====================================================
       ESCAPE HTML
    ====================================================== */

    function escapeHTML(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }

        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    }


    /* =====================================================
       PARSE BUTTON
    ====================================================== */

    if (parsePackageBtn) {

        parsePackageBtn.addEventListener(
            "click",
            function () {

                const text =
                    packageText.value.trim();


                if (!text) {

                    showPackageError(
                        "Please paste the package information first."
                    );

                    return;

                }


                try {

                    parsedPackage =
                        parsePackage(text);


                    renderPackageResult(
                        parsedPackage
                    );

                } catch (error) {

                    console.error(
                        "Package parser error:",
                        error
                    );

                    showPackageError(
                        "Unable to parse the package. Please check the text format."
                    );

                }

            }
        );

    }


    /* =====================================================
       ERROR
    ====================================================== */

    function showPackageError(message) {

        packageResult.innerHTML = `
            <div class="package-error">
                ⚠ ${escapeHTML(message)}
            </div>
        `;

        packageResult.classList.add("show");

        if (applyPackageBtn) {

            applyPackageBtn.disabled = true;

        }

    }


    /* =====================================================
       APPLY PACKAGE TO BOOKING
    ====================================================== */

    if (applyPackageBtn) {

        applyPackageBtn.addEventListener(
            "click",
            function () {

                if (!parsedPackage) {

                    showPackageError(
                        "Please parse the package first."
                    );

                    return;

                }


                applyPackageToBooking(
                    parsedPackage
                );

            }
        );

    }


    /* =====================================================
       APPLY TO BOOKING
    ====================================================== */

    function applyPackageToBooking(data) {

        /* -----------------------------------------------
           BOOKING DETAILS
        ------------------------------------------------ */

        setField(
            'input[name="travel_date"]',
            data.departureDate
        );


        /*
         * IMPORTANT:
         * We are NOT setting any cost price,
         * base fare, selling price or tax here.
         */


        /* -----------------------------------------------
           CLIENT / BOOKING TITLE
        ------------------------------------------------ */

        const invoiceDate =
            document.querySelector(
                'input[name="invoice_date"]'
            );


        if (
            invoiceDate &&
            !invoiceDate.value
        ) {

            invoiceDate.value =
                getToday();

        }


        /* -----------------------------------------------
           HOTELS
        ------------------------------------------------ */

        if (
            data.hotels &&
            data.hotels.length
        ) {

            applyHotels(
                data.hotels
            );

        }


        /* -----------------------------------------------
           TRANSPORT
        ------------------------------------------------ */

        if (
            data.transportItems &&
            data.transportItems.length
        ) {

            applyTransport(
                data.transportItems
            );

        }


        /* -----------------------------------------------
           ADDITIONAL PRODUCTS
        ------------------------------------------------ */

        applyPackageProducts(
            data
        );


        /* -----------------------------------------------
           CLOSE PACKAGE MODAL
        ------------------------------------------------ */

        closePackageModal();


        /* -----------------------------------------------
           SUCCESS MESSAGE
        ------------------------------------------------ */

        showPackageSuccess();

    }


    /* =====================================================
       SET FIELD
    ====================================================== */

    function setField(selector, value) {

        const element =
            document.querySelector(selector);


        if (!element) {

            return;

        }


        if (
            value !== null &&
            value !== undefined &&
            value !== ""
        ) {

            element.value = value;

            element.dispatchEvent(
                new Event(
                    "change",
                    {
                        bubbles: true
                    }
                )
            );

        }

    }


    /* =====================================================
       APPLY HOTELS
    ====================================================== */

    function applyHotels(hotels) {

        const hotelRows =
            document.getElementById(
                "hotelRows"
            );


        if (!hotelRows) {

            return;

        }


        /*
         * Remove the initial empty/default row.
         */

        hotelRows.innerHTML = "";


        hotels.forEach(
            function (hotel, index) {

                const row =
                    document.createElement("tr");


                row.innerHTML = `

                    <td>

                        <input
                            type="text"
                            name="hotels[${index}][name]"
                            value="${escapeAttribute(
                                hotel.name
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="hotels[${index}][city]"
                            value="${escapeAttribute(
                                hotel.city
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="hotels[${index}][room_type]"
                            value="${escapeAttribute(
                                hotel.roomType
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="number"
                            name="hotels[${index}][rooms]"
                            value="${hotel.rooms || 1}"
                            min="1"
                        >

                    </td>


                    <td>

                        <select
                            name="hotels[${index}][meal]"
                        >

                            <option value="RO"
                                ${hotel.meal === "RO" ? "selected" : ""}>
                                RO
                            </option>

                            <option value="BB"
                                ${hotel.meal === "BB" ? "selected" : ""}>
                                BB
                            </option>

                            <option value="HB"
                                ${hotel.meal === "HB" ? "selected" : ""}>
                                HB
                            </option>

                            <option value="FB"
                                ${hotel.meal === "FB" ? "selected" : ""}>
                                FB
                            </option>

                        </select>

                    </td>


                    <td>

                       <select name="hotels[${index}][view]">

    <option value="No View"
        ${hotel.view === "No View" ? "selected" : ""}>
        No view
    </option>

    <option value="City View"
        ${hotel.view === "City View" ? "selected" : ""}>
        City View
    </option>

    <option value="Patio View"
        ${hotel.view === "Patio View" ? "selected" : ""}>
        Patio View
    </option>

    <option value="Haram View"
        ${hotel.view === "Haram View" ? "selected" : ""}>
        Haram View
    </option>

    <option value="Partial Kaba View"
        ${hotel.view === "Partial Kaba View" ? "selected" : ""}>
        Partial Kaaba View
    </option>

    <option value="Kaaba View"
        ${hotel.view === "Kaaba View" ? "selected" : ""}>
        Kaaba View
    </option>

</select>

                    </td>


                    <td>

                        <input
                            type="date"
                            name="hotels[${index}][check_in]"
                            value="${escapeAttribute(
                                hotel.checkIn || ""
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="number"
                            name="hotels[${index}][nights]"
                            value="${hotel.nights || 1}"
                            min="1"
                        >

                    </td>


                    <td>

                        <input
                            type="date"
                            name="hotels[${index}][check_out]"
                            value="${escapeAttribute(
                                hotel.checkOut || ""
                            )}"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="hotels[${index}][remarks]"
                            value="Imported from package"
                        >

                    </td>


                    <td>

                        <input
                            type="text"
                            name="hotels[${index}][supplier]"
                            value="${escapeAttribute(hotel.supplier || hotel.hotel_supplier || "")}"
                            placeholder="Supplier"
                        >

                    </td>


                    <td>

                        <button
                            type="button"
                            class="btn-delete"
                            onclick="deleteRow(this)"
                        >
                            ×
                        </button>

                    </td>

                `;


                hotelRows.appendChild(row);

            }
        );

    }


    /* =====================================================
       APPLY TRANSPORT
    ====================================================== */

    function applyTransport(items) {

        const transportRows = document.getElementById("transportRows");
        if (!transportRows || !Array.isArray(items)) return;

        transportRows.innerHTML = "";

        let rows = items.filter(Boolean).map(function (item) {
            return String(item).trim();
        });

        /* The first item can be a generic header such as "Full Ground...". */
        if (rows.length > 1) {
            const looksLikeJourney = function (value) {
                return /\b(?:airport|hotel|makkah|madinah|madina|medina|istanbul|jeddah|riyadh|taif)\b/i.test(value);
            };
            const journeyRows = rows.filter(looksLikeJourney);
            if (journeyRows.length) rows = journeyRows;
        }

        rows.forEach(function (journey) {

            const row = document.createElement("tr");

            row.innerHTML = `
                <td>
                    <input type="text"
                           name="transport[${transportIndex}][vehicle]"
                           value="Car/Bus">
                </td>
                <td>
                    <input type="text"
                           name="transport[${transportIndex}][journey]"
                           value="${escapeAttribute(journey)}">
                </td>
                <td>
                    <input type="number"
                           name="transport[${transportIndex}][vehicles]"
                           value="1" min="1">
                </td>
                <td>
                    <input type="date"
                           name="transport[${transportIndex}][pickup_date]">
                </td>
                <td>
                    <input type="time"
                           name="transport[${transportIndex}][pickup_time]">
                </td>
                <td>
                    <input type="text"
                           name="transport[${transportIndex}][notes]"
                           value="Imported from package">
                </td>
                <td>
                    <input type="text"
                           name="transport[${transportIndex}][supplier]"
                           value="${escapeAttribute("")}"
                           placeholder="Supplier">
                </td>
                <td>
                    <button type="button"
                            class="btn-delete"
                            onclick="deleteRow(this)">×</button>
                </td>
            `;

            transportRows.appendChild(row);
            transportIndex++;
        });
    }


    /* =====================================================
       APPLY PRODUCTS
    ====================================================== */

   function applyPackageProducts(data) {

    const productRows = document.getElementById("productRows");

    if (!productRows) {
        return;
    }

    /*
     * We DO NOT add price/cost here.
     * Only textual products/services.
     */

    const products = [];

    if (data.visa) {
        products.push(data.visa);
    }

    if (data.transport) {
        products.push(data.transport);
    }

    if (data.baggage) {
        products.push("Baggage: " + data.baggage);
    }

    if (!products.length) {
        return;
    }

    productRows.innerHTML = "";

    products.forEach(function (product) {

        // Create row
        const row = document.createElement("div");

        row.className = "product-row";

        row.style.display = "flex";
        row.style.alignItems = "center";
        row.style.gap = "6px";
        row.style.marginBottom = "6px";


        // Create input
        const input = document.createElement("input");

        input.type = "text";
        input.name = `products[${productIndex}][name]`;
        input.placeholder = "Additional Product";
        input.value = product;

        input.style.flex = "1";

        const supplierInput = document.createElement("input");
        supplierInput.type = "text";
        supplierInput.name = `products[${productIndex}][supplier]`;
        supplierInput.placeholder = "Supplier";
        supplierInput.style.flex = "0 0 180px";

        // Create delete button
        const deleteButton = document.createElement("button");

        deleteButton.type = "button";
        deleteButton.innerHTML = "×";

        deleteButton.className = "btn-delete";

        // deleteButton.style.whiteSpace = "nowrap";


        // Delete row
        deleteButton.addEventListener("click", function () {

            row.remove();

        });


        // Add input + button to row
        row.appendChild(input);
        row.appendChild(supplierInput);
        row.appendChild(deleteButton);

        // Add row to container
        productRows.appendChild(row);
        productIndex++;

    });

}


    /* =====================================================
       ESCAPE ATTRIBUTE
    ====================================================== */

    function escapeAttribute(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }

        return String(value)

            .replace(
                /&/g,
                "&amp;"
            )

            .replace(
                /"/g,
                "&quot;"
            )

            .replace(
                /</g,
                "&lt;"
            )

            .replace(
                />/g,
                "&gt;"
            );

    }


    /* =====================================================
       TODAY
    ====================================================== */

    function getToday() {

        const now =
            new Date();


        return (
            now.getFullYear() +
            "-" +
            String(
                now.getMonth() + 1
            ).padStart(2, "0") +
            "-" +
            String(
                now.getDate()
            ).padStart(2, "0")
        );

    }


    /* =====================================================
       SUCCESS
    ====================================================== */

    function showPackageSuccess() {

        const message =
            document.createElement("div");


        message.innerHTML =
            "✓ Package successfully imported into booking";


        message.style.position =
            "fixed";

        message.style.top =
            "25px";

        message.style.right =
            "25px";

        message.style.zIndex =
            "1000000";

        message.style.padding =
            "12px 18px";

        message.style.background =
            "#079b6f";

        message.style.color =
            "#ffffff";

        message.style.borderRadius =
            "8px";

        message.style.fontSize =
            "14px";

        message.style.fontWeight =
            "700";

        message.style.boxShadow =
            "0 8px 25px rgba(0,0,0,.18)";


        document.body.appendChild(
            message
        );


        setTimeout(
            function () {

                message.remove();

            },
            3000
        );

    }

})();


/* ==========================================================
   PACKAGE -> BOOKING FIELD HELPER
========================================================== */

function setBookingField(fieldName, value) {

    const bookingModal =
        document.getElementById("bookingModal");

    if (!bookingModal) {
        console.warn(
            "Booking modal not found."
        );

        return false;
    }


    /*
     * Normal field
     */

    const normalField =
        bookingModal.querySelector(
            `[name="${fieldName}"]`
        );


    if (normalField) {

        normalField.value =
            value ?? "";

        normalField.dispatchEvent(
            new Event("input", {
                bubbles: true
            })
        );

        normalField.dispatchEvent(
            new Event("change", {
                bubbles: true
            })
        );

        return true;
    }


    /*
     * SPECIAL:
     * FLIGHT DESTINATION
     *
     * Your actual field is:
     *
     * flights[0][destination]
     */

    if (fieldName === "destination") {

        let destinationField =
            bookingModal.querySelector(
                '[name="flights[0][destination]"]'
            );


        /*
         * If first flight row doesn't exist,
         * create one.
         */

        if (!destinationField) {

            if (
                typeof addFlight ===
                "function"
            ) {
                addFlight();
            }

            destinationField =
                bookingModal.querySelector(
                    '[name="flights[0][destination]"]'
                );
        }


        if (destinationField) {

            destinationField.value =
                value ?? "";

            destinationField.dispatchEvent(
                new Event("input", {
                    bubbles: true
                })
            );

            destinationField.dispatchEvent(
                new Event("change", {
                    bubbles: true
                })
            );

            return true;
        }
    }


    /*
     * SPECIAL:
     * FLIGHT ORIGIN
     */

    if (fieldName === "origin") {

        let originField =
            bookingModal.querySelector(
                '[name="flights[0][origin]"]'
            );


        if (!originField) {

            if (
                typeof addFlight ===
                "function"
            ) {
                addFlight();
            }

            originField =
                bookingModal.querySelector(
                    '[name="flights[0][origin]"]'
                );
        }


        if (originField) {

            originField.value =
                value ?? "";

            originField.dispatchEvent(
                new Event("input", {
                    bubbles: true
                })
            );

            originField.dispatchEvent(
                new Event("change", {
                    bubbles: true
                })
            );

            return true;
        }
    }


    /*
     * Don't treat missing optional
     * package fields as fatal.
     */

    console.warn(
        "Booking field not found:",
        fieldName
    );

    return false;
}