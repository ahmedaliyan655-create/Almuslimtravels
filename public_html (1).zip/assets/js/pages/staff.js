/*==================================================
    AL MUSLIM TRAVEL CRM
    Staff Module
==================================================*/

$(document).ready(function () {

    /**********************************************
        IMAGE PREVIEW
    **********************************************/

    $("#profileImage").on("change", function (e) {

        const file = e.target.files[0];

        if (!file) return;

        const reader = new FileReader();

        reader.onload = function (event) {

            $("#profilePreview").attr("src", event.target.result);

        };

        reader.readAsDataURL(file);

    });

    /**********************************************
        ROLE CHANGE
    **********************************************/

    $("#role").on("change", function () {

        const role = $(this).val();

        $(".staff-role-card").removeClass("active");

        if (role === "manager") {

            $(".manager-card").addClass("active");

            $("#projectArea").slideUp();

            $("#teamArea").slideUp();

        }

        else if (role === "admin") {

            $(".admin-card").addClass("active");

            $("#projectArea").slideUp();

            $("#teamArea").slideUp();

        }

        else if (role === "teamlead") {

            $(".lead-card").addClass("active");

            $("#projectArea").slideDown();

            $("#teamArea").slideUp();

        }

        else if (role === "agent") {

            $(".agent-card").addClass("active");

            $("#projectArea").slideDown();

            $("#teamArea").slideDown();

        }

        else {

            $("#projectArea").slideUp();

            $("#teamArea").slideUp();

        }

    });

    /**********************************************
        PROJECT CARD CLICK
    **********************************************/

    $(document).on("click", ".project-box", function () {

    let checkbox = $(this).find("input");

    checkbox.prop("checked", !checkbox.prop("checked"));

    $(this).toggleClass("selected", checkbox.prop("checked"));

    });

    /**********************************************
        RESET FORM
    **********************************************/

    $("#btnReset").click(function () {

        $("#staffForm")[0].reset();

        $("#agent_id").val("");

        $("#profilePreview").attr(
            "src",
            "https://ui-avatars.com/api/?name=User&background=16284e&color=ffffff&size=200"
        );

        $("#projectArea").hide();

        $("#teamArea").hide();

        $(".project-box").removeClass("selected");

        $(".project-box input").prop("checked", false);

        $(".staff-role-card").removeClass("active");

        $("#btnSave")
            .html('<i class="fa-solid fa-floppy-disk me-2"></i> Save Member');

    });

});
/**********************************************
    DATATABLE
**********************************************/

let staffTable = null;

initStaffTable();

/**********************************************
    INITIALIZE TABLE
**********************************************/

function initStaffTable() {

    staffTable = $("#staffTable").DataTable({

        processing: true,

        responsive: true,

        ordering: true,

        searching: true,

        paging: true,

        pageLength: 10,

        autoWidth: false,

        language: {

            emptyTable: "No staff members found.",

            processing: "Loading staff..."

        },

        columnDefs: [
            {
                orderable: false,
                targets: [8]
            }
        ]

    });

    loadStaff();

}

/**********************************************
    LOAD STAFF
**********************************************/

function loadStaff() {

    showLoading();

    $.ajax({

        url: "../actions/staff/list.php",

        type: "GET",

        dataType: "json",

        success: function (response) {

            hideLoading();

            if (response.success) {

                renderStaff(response.data);

            } else {

                showError(response.message);

            }

        },

        error: function () {

            hideLoading();

            // showError("Unable to load staff members.");

        }

    });

}

/**********************************************
    RENDER TABLE
**********************************************/

function renderStaff(data) {

    staffTable.clear();

    $("#totalStaff").text(data.length + " Members");

    if (data.length === 0) {

        staffTable.draw();

        return;

    }

    staffTable.clear();

$.each(data,function(i,row){

staffTable.row.add([

i+1,

row.member,

row.role,

row.team,

row.projects,

row.contact,

row.commission,

row.status,

row.actions

]);

});

staffTable.draw(false);

    staffTable.draw(false);

}

/**********************************************
    RELOAD TABLE
**********************************************/

function refreshStaffTable() {

    loadStaff();

}

/**********************************************
    LOADING
**********************************************/

function showLoading() {

    if ($("#tableLoading").length === 0) {

        $("#staffTable_wrapper").append(

            '<div id="tableLoading" class="text-center py-4">' +

            '<div class="spinner-border text-primary"></div>' +

            '<div class="mt-2">Loading Staff...</div>' +

            '</div>'

        );

    }

}

function hideLoading() {

    $("#tableLoading").remove();

}

/**********************************************
    ERROR
**********************************************/

function showError(message) {

    alert(message);

}

/**********************************************
    EMPTY TABLE
**********************************************/

function showEmpty() {

    staffTable.clear().draw();

    $("#totalStaff").text("0 Members");

}
/**********************************************
    LOAD PROJECTS
**********************************************/

function loadProjects() {
    console.log("Loading projects...");
    $.ajax({

        url: "../actions/staff/projects.php",

        type: "GET",

        dataType: "json",

        success: function (response) {

            if (!response.success) {

                toastr.error(response.message);

                return;

            }

            let html = "";

            $.each(response.data, function (i, project) {

                html += `

                    <div class="col-md-4 col-lg-3 mb-3">

                        <label class="project-box">

                            <input
                                type="checkbox"
                                name="projects[]"
                                value="${project.id}"
                                hidden>

                            <div class="project-logo">

                                <img
                                    src="${project.logo}"
                                    class="img-fluid" style="width: 100px;">
                            </div>

                            <h6>

                                ${project.name}

                            </h6>

                            <small>

                                ${project.code}

                            </small>

                        </label>

                    </div>

                `;

            });

            $("#projectList").html(html);

        },

        error: function () {

            toastr.error("Unable to load projects.");

        }

    });

}
loadProjects();

/**********************************************
    SAVE STAFF
**********************************************/
$("#staffForm").on("submit", function (e) {

    e.preventDefault();

    if ($("#name").val().trim() == "") {

        toastr.error("Please enter Full Name.");
        $("#name").focus();
        return;

    }

    if ($("#email").val().trim() == "") {

        toastr.error("Please enter Email.");
        $("#email").focus();
        return;

    }

    if ($("#phone").val().trim() == "") {

        toastr.error("Please enter Phone.");
        $("#phone").focus();
        return;

    }

    /*
    |--------------------------------------------------------------------------
    | PIN Required Only For New Staff
    |--------------------------------------------------------------------------
    */

    if ($("#agent_id").val() == "" && $("#pin").val().trim() == "") {

        toastr.error("Please enter Login PIN.");
        $("#pin").focus();
        return;

    }

    if ($("#role").val() == "") {

    toastr.error("Please select Role.");
    return;

}

if ($("#role").val() == "agent" && $("#team_lead_id").val() == "") {

    toastr.error("Please select Team Lead.");

    $("#team_lead_id").focus();

    return;

}

let formData = new FormData(this);
    /*
    |--------------------------------------------------------------------------
    | CREATE / UPDATE URL
    |--------------------------------------------------------------------------
    */

    let url = $("#agent_id").val() == ""
        ? "../actions/staff/create.php"
        : "../actions/staff/update.php";

    $("#btnSave")
        .prop("disabled", true)
        .html('<i class="fa fa-spinner fa-spin me-2"></i> Saving...');

    $.ajax({

        url: url,

        type: "POST",

        data: formData,

        processData: false,

        contentType: false,

        dataType: "json",

        success: function (response) {

            $("#btnSave")
                .prop("disabled", false)
                .html('<i class="fa-solid fa-floppy-disk me-2"></i> Save Member');

            if (response.success) {

                toastr.success(response.message);

                $("#staffForm")[0].reset();
                $("#team_lead_id").val("");

                $("#teamLeadArea").hide();
                $("#agent_id").val("");

                $("#profilePreview").attr(
                    "src",
                    "https://ui-avatars.com/api/?name=User&background=16284e&color=ffffff&size=200"
                );

                $(".project-box").removeClass("selected");

                $(".project-box input").prop("checked", false);

                $("#projectArea").hide();

                $("#teamArea").hide();

                $(".staff-role-card").removeClass("active");
                $("#pin").attr("placeholder", "Enter Login PIN");
                $("#btnSave").html(
                    '<i class="fa-solid fa-floppy-disk me-2"></i> Save Member'
                );

                refreshStaffTable();

            } else {

                toastr.error(response.message);

            }

        },

        error: function (xhr) {

            $("#btnSave")
                .prop("disabled", false)
                .html('<i class="fa-solid fa-floppy-disk me-2"></i> Save Member');

            console.log(xhr.responseText);

            toastr.error("Unable to save staff member.");

        }

    });

});
/**********************************************
    EDIT STAFF
**********************************************/

$(document).on("click", ".btnEdit", function () {

    let id = $(this).data("id");

    $.ajax({

        url: "../actions/staff/get.php",

        type: "GET",

        data: {

            id: id

        },

        dataType: "json",

        success: function (response) {

            if (!response.success) {

                toastr.error(response.message);

                return;

            }

            let staff = response.data;

            /*
            ----------------------------
            Hidden ID
            ----------------------------
            */

            $("#agent_id").val(staff.id);

            /*
            ----------------------------
            Basic Information
            ----------------------------
            */

            $("#name").val(staff.name);

            $("#email").val(staff.email);

            $("#phone").val(staff.phone);

            $("#designation").val(staff.designation);

            $("#joining_date").val(staff.joining_date);

            $("#role").val(staff.role).trigger("change");

            $("#commission_pct").val(staff.commission_pct);

            $("#team_id").val(staff.team_id);
            setTimeout(function () {

                $("#team_lead_id").val(staff.team_lead_id);

            }, 100);
            $("#is_active").val(staff.is_active);
            $("#pin").attr(
                "placeholder",
                "Enter new PIN only if you want to change it"
            );
            /*
            ----------------------------
            Profile Image
            ----------------------------
            */

            $("#profilePreview").attr(

                "src",

                staff.profile_image

            );

            /*
            ----------------------------
            Uncheck All Projects
            ----------------------------
            */

            $(".project-box").removeClass("selected");

            $(".project-box input").prop("checked", false);

            /*
            ----------------------------
            Check Assigned Projects
            ----------------------------
            */

            $.each(staff.projects, function (i, projectId) {

                let checkbox = $('input[name="projects[]"][value="' + projectId + '"]');

                checkbox.prop("checked", true);

                checkbox.closest(".project-box").addClass("selected");

            });

            /*
            ----------------------------
            Button
            ----------------------------
            */

            $("#btnSave")
                .html('<i class="fa fa-save me-2"></i> Update Member');

            /*
            ----------------------------
            Scroll
            ----------------------------
            */

            $("html, body").animate({

                scrollTop: $("#staffForm").offset().top - 30

            }, 400);

        },

        error: function () {

            toastr.error("Unable to load staff member.");

        }

    });

});
$(document).on("click", ".btnDelete", function () {

    let agent_id = $(this).data("id");

    if (!confirm("Are you sure you want to delete this staff member?")) {
        return;
    }

    $.ajax({

        url: "../actions/staff/delete.php",

        type: "POST",

        data: {
            agent_id: agent_id
        },

        dataType: "json",

        success: function (response) {

            if (response.success) {

                toastr.success(response.message);

                refreshStaffTable();

            } else {

                toastr.error(response.message);

            }

        },

        error: function (xhr) {

            console.log(xhr.responseText);

            toastr.error("Unable to delete staff member.");

        }

    });

});
$(document).on("change", "#role", function () {
// $("#role").on("change", function () {

    if ($(this).val() === "agent") {

        $("#teamLeadArea").slideDown();

    } else {

        $("#teamLeadArea").slideUp();

        $("#team_lead_id").val("");

    }

});