let bookingTable = null;
let bookingsRequestController = null;
let bookingsRequestSequence = 0;


/* =========================================================
   ROLE-BASED BOOKING FILTERS
========================================================= */

function getBookingPageRole() {
    const filterCard = document.getElementById("bookingFilterCard");

    if (!filterCard) {
        return "";
    }

    return (
        filterCard.getAttribute("data-role") ||
        ""
    ).toLowerCase().trim();
}

function applyBookingFilterPermissions() {

    const role = getBookingPageRole();

    const agentWrap =
        document.getElementById("agentFilterWrap");

    const agentSelect =
        document.getElementById("agentFilter");

    if (!agentWrap || !agentSelect) {
        return;
    }

    /*
     * Agent:
     * No Agent filter because an Agent can only ever see his/her
     * own bookings.
     */
    if (role === "agent") {

        agentWrap.style.display = "none";
        agentSelect.disabled = true;
        agentSelect.value = "";

        return;
    }

    /*
     * Team Lead:
     * Agent filter is available only after selecting one of the
     * Team Lead's assigned projects. The PHP endpoint further
     * restricts it to agents belonging to this Team Lead.
     */
    if (role === "teamlead") {

        agentWrap.style.display = "";
        agentSelect.disabled = true;
        agentSelect.innerHTML =
            '<option value="">Select Project First</option>';

        return;
    }

    /*
     * Admin / Manager:
     * Full Agent filter is available. It is initially populated
     * with all active agents and becomes project-specific after
     * a project is selected.
     */
    if (
        role === "admin" ||
        role === "manager" ||
        role === "administrator"
    ) {

        agentWrap.style.display = "";
        agentSelect.disabled = false;

        return;
    }

    agentWrap.style.display = "none";
    agentSelect.disabled = true;
}


/* =========================================================
   DOCUMENT READY
========================================================= */

$(document).ready(function () {

    /*
     * Prevent this booking view script from initializing twice.
     * This protects against the page/template loading booking.js
     * more than once.
     */
    if (window.__alMuslimBookingViewInitialized) {
        return;
    }
    window.__alMuslimBookingViewInitialized = true;

    /*
     * =====================================================
     * INITIALIZE DATATABLE
     * =====================================================
     */

    if ($.fn.DataTable.isDataTable("#bookingTable")) {

        bookingTable = $("#bookingTable").DataTable();

    } else {

        bookingTable = $("#bookingTable").DataTable({

            responsive: true,

            autoWidth: false,

            pageLength: 25,

            order: [
                [0, "desc"]
            ],

            columnDefs: [

                {
                    targets: 0,
                    orderable: false
                },

                {
                    targets: 10,
                    orderable: false,
                    searchable: false
                }

            ]

        });

    }


    applyBookingFilterPermissions();

    /*
     * =====================================================
     * LOAD PROJECTS
     * =====================================================
     */

    loadProjects();


    /*
     * =====================================================
     * LOAD BOOKINGS
     * =====================================================
     */

    loadBookings();


    /*
     * =====================================================
     * PROJECT CHANGE
     * =====================================================
     */

    $("#projectFilter").on(
        "change",
        function () {

            const projectId =
                $(this).val();


            resetAgentFilter();

            const role = getBookingPageRole();

            if (!projectId) {

                if (
                    role === "admin" ||
                    role === "manager" ||
                    role === "administrator"
                ) {
                    loadAllBookingAgents();
                }

                loadBookings();

                return;

            }

            if (role !== "agent") {
                loadProjectAgents(projectId);
            } else {
                loadBookings();
            }

        }
    );


    /*
     * =====================================================
     * AGENT CHANGE
     * =====================================================
     */

    $("#agentFilter").on(
        "change",
        function () {

            loadBookings();

        }
    );


    /*
     * =====================================================
     * STATUS CHANGE
     * =====================================================
     */

    $("#statusFilter").on(
        "change",
        function () {

            loadBookings();

        }
    );


    /*
     * =====================================================
     * TRAVEL DATE CHANGE
     * =====================================================
     */

    $("#travelDate").on(
        "change",
        function () {

            loadBookings();

        }
    );


    /*
     * =====================================================
     * SEARCH BUTTON
     * =====================================================
     */

    $("#filterBtn").on(
        "click",
        function () {

            loadBookings();

        }
    );


    /*
     * =====================================================
     * SEARCH ENTER
     * =====================================================
     */

    $("#searchBooking").on(
        "keydown",
        function (event) {

            if (event.key === "Enter") {

                event.preventDefault();

                loadBookings();

            }

        }
    );


});


/* =========================================================
   LOAD PROJECTS
========================================================= */

function loadProjects() {

    const projectSelect =
        document.getElementById(
            "projectFilter"
        );


    if (!projectSelect) {

        return;

    }


    fetch(
        "../actions/booking/get_projects.php"
    )

        .then(function (response) {

            if (!response.ok) {

                throw new Error(
                    "HTTP Error: " +
                    response.status
                );

            }

            return response.json();

        })

        .then(function (result) {

            if (!result.success) {

                throw new Error(
                    result.message ||
                    "Unable to load projects"
                );

            }


            projectSelect.innerHTML = `

                <option value="">
                    All Projects
                </option>

            `;


            result.data.forEach(
                function (project) {

                    const option =
                        document.createElement(
                            "option"
                        );


                    option.value =
                        project.id;


                    option.textContent =
                        project.project_name;


                    projectSelect.appendChild(
                        option
                    );

                }
            );

            const role = getBookingPageRole();

            if (
                role === "admin" ||
                role === "manager" ||
                role === "administrator"
            ) {
                loadAllBookingAgents();
            }

        })

        .catch(function (error) {

            console.error(
                "Failed to load projects:",
                error
            );

        });

}


/* =========================================================
   LOAD AGENTS
========================================================= */

function loadAllBookingAgents() {

    const agentSelect =
        document.getElementById("agentFilter");

    if (!agentSelect) {
        return;
    }

    agentSelect.disabled = true;

    agentSelect.innerHTML =
        '<option value="">Loading agents...</option>';

    fetch("../actions/booking/get_project_agents.php?project_id=0")
        .then(function (response) {

            if (!response.ok) {
                throw new Error("HTTP Error: " + response.status);
            }

            return response.json();
        })
        .then(function (result) {

            if (!result.success) {
                throw new Error(
                    result.message || "Unable to load agents"
                );
            }

            agentSelect.innerHTML =
                '<option value="">All Agents</option>';

            result.data.forEach(function (agent) {

                const option =
                    document.createElement("option");

                option.value = agent.id;
                option.textContent = agent.name;

                if (agent.agent_code) {
                    option.textContent +=
                        " (" + agent.agent_code + ")";
                }

                agentSelect.appendChild(option);
            });

            agentSelect.disabled = false;
        })
        .catch(function (error) {

            console.error(
                "Failed to load all agents:",
                error
            );

            agentSelect.innerHTML =
                '<option value="">All Agents</option>';

            agentSelect.disabled = false;
        });
}



function loadProjectAgents(
    projectId
) {

    const agentSelect =
        document.getElementById(
            "agentFilter"
        );


    if (!agentSelect) {

        return;

    }


    agentSelect.disabled = true;


    agentSelect.innerHTML = `

        <option value="">
            Loading agents...
        </option>

    `;


    fetch(
        "../actions/booking/get_project_agents.php?project_id=" +
        encodeURIComponent(projectId)
    )

        .then(function (response) {

            if (!response.ok) {

                throw new Error(
                    "HTTP Error: " +
                    response.status
                );

            }

            return response.json();

        })

        .then(function (result) {

            if (!result.success) {

                throw new Error(
                    result.message ||
                    "Unable to load agents"
                );

            }


            agentSelect.innerHTML = `

                <option value="">
                    All Agents
                </option>

            `;


            result.data.forEach(
                function (agent) {

                    const option =
                        document.createElement(
                            "option"
                        );


                    option.value =
                        agent.id;


                    option.textContent =
                        agent.name;


                    if (
                        agent.agent_code
                    ) {

                        option.textContent +=
                            " (" +
                            agent.agent_code +
                            ")";

                    }


                    agentSelect.appendChild(
                        option
                    );

                }
            );


            agentSelect.disabled = false;


            loadBookings();

        })

        .catch(function (error) {

            console.error(
                "Failed to load project agents:",
                error
            );


            agentSelect.innerHTML = `

                <option value="">
                    All Agents
                </option>

            `;


            agentSelect.disabled = false;


            loadBookings();

        });

}


/* =========================================================
   RESET AGENT FILTER
========================================================= */

function resetAgentFilter() {

    const agentSelect =
        document.getElementById("agentFilter");

    if (!agentSelect) {
        return;
    }

    const role = getBookingPageRole();

    agentSelect.value = "";

    if (role === "agent") {

        agentSelect.innerHTML =
            '<option value="">All Agents</option>';
        agentSelect.disabled = true;
        return;
    }

    if (role === "teamlead") {

        agentSelect.innerHTML =
            '<option value="">Select Project First</option>';
        agentSelect.disabled = true;
        return;
    }

    if (
        role === "admin" ||
        role === "manager" ||
        role === "administrator"
    ) {

        agentSelect.innerHTML =
            '<option value="">All Agents</option>';
        agentSelect.disabled = false;
        return;
    }

    agentSelect.innerHTML =
        '<option value="">All Agents</option>';
    agentSelect.disabled = true;
}

/* =========================================================
   LOAD BOOKINGS
========================================================= */

function loadBookings() {

    if (!bookingTable) {

        console.error(
            "bookingTable is not initialized."
        );

        return;

    }


    const projectId =
        $("#projectFilter").val() || "";


    const agentId =
        $("#agentFilter").val() || "";


    const status =
        $("#statusFilter").val() || "";


    const travelDate =
        $("#travelDate").val() || "";


    const search =
        $("#searchBooking").val().trim();


    const params =
        new URLSearchParams();


    if (projectId) {

        params.append(
            "project_id",
            projectId
        );

    }


    if (agentId) {

        params.append(
            "agent_id",
            agentId
        );

    }


    if (status) {

        params.append(
            "status",
            status
        );

    }


    if (travelDate) {

        params.append(
            "travel_date",
            travelDate
        );

    }


    if (search) {

        params.append(
            "search",
            search
        );

    }


    /*
     * =====================================================
     * REQUEST CONTROL
     * =====================================================
     * Cancel any previous request so an older response can never
     * append rows after a newer request has started.
     */

    const requestSequence = ++bookingsRequestSequence;

    if (bookingsRequestController) {
        bookingsRequestController.abort();
    }

    bookingsRequestController =
        typeof AbortController !== "undefined"
            ? new AbortController()
            : null;


    /*
     * IMPORTANT:
     * Do NOT clear/draw the table before the response arrives.
     * Clearing here was causing a visible blank/repaint cycle and
     * made overlapping requests much more noticeable.
     */

    /*
     * =====================================================
     * FETCH
     * =====================================================
     */

    const requestOptions = {
        credentials: "same-origin",
        cache: "no-store"
    };

    if (bookingsRequestController) {
        requestOptions.signal = bookingsRequestController.signal;
    }

    fetch(
        "../actions/booking/get_bookings.php?" +
        params.toString(),
        requestOptions
    )

        .then(function (response) {

            if (!response.ok) {

                throw new Error(
                    "HTTP Error: " +
                    response.status
                );

            }

            return response.json();

        })

        .then(function (result) {

            /* Ignore responses from an older request. */
            if (requestSequence !== bookingsRequestSequence) {
                return;
            }

            console.log(
                "BOOKINGS RESPONSE:",
                result
            );


            if (!result.success) {

                throw new Error(
                    result.message ||
                    "Unable to load bookings"
                );

            }


            /*
             * =================================================
             * REPLACE TABLE DATA
             * =================================================
             * Clear only after the newest response has arrived.
             */

            bookingTable.clear();

            /*
             * =================================================
             * ADD ROWS
             * =================================================
             */

            result.data.forEach(

                function (
                    booking,
                    index
                ) {


                    /*
                     * -----------------------------------------
                     * FLIGHT CELL
                     * -----------------------------------------
                     */

                    const flightCell =
                        buildFlightCell(
                            booking
                        );


                    /*
                     * -----------------------------------------
                     * HOTEL CELL
                     * -----------------------------------------
                     */

                    const hotelCell =
                        buildHotelCell(
                            booking
                        );


                    /*
                     * -----------------------------------------
                     * ADD ROW
                     * -----------------------------------------
                     */

                    bookingTable.row.add([


                        /*
                         * #
                         */

                        index + 1,


                        /*
                         * INVOICE
                         */

                        `
                        <strong>
                            ${escapeHtml(
                                booking.invoice_no || ""
                            )}
                        </strong>
                        `,


                        /*
                         * CLIENT
                         */

                        `
                        <div>

                            <strong>
                                ${escapeHtml(
                                    booking.client_name || ""
                                )}
                            </strong>

                            ${
                                booking.client_mobile
                                ?
                                `
                                <small
                                    class="d-block text-muted">

                                    ${escapeHtml(
                                        booking.client_mobile
                                    )}

                                </small>
                                `
                                :
                                ""
                            }

                        </div>
                        `,


                        /*
                         * TRAVEL DATE
                         */

                        formatDate(
                            booking.travel_date
                        ),


  /*
                         * HOTEL
                         */

                        hotelCell,

                        /*
                         * FLIGHT
                         */

                        flightCell,

                           /*
                         * BOOKING STATUS
                         */

                        getStatusBadge(
                            booking.status
                        ),

                        /*
                         * GROSS
                         */

                        `
                        £${formatMoney(
                            booking.gross_total
                        )}
                        `,


                        /*
                         * RECEIVED
                         */

                        `
                        £${formatMoney(
                            booking.total_received
                        )}
                        `,


                        /*
                         * BALANCE
                         */

                        `
                        <strong>
                            £${formatMoney(
                                booking.balance_due
                            )}
                        </strong>
                        `,


                        /*
                         * ACTIONS
                         */

                     `
<div
    class="btn-group btn-group-sm">


    <!-- =============================================
         VIEW
    ============================================== -->

    <button
        type="button"
        class="btn btn-info"
        onclick="viewBooking(${Number(
            booking.id
        )})"
        title="View">

        <i
            class="fas fa-eye">
        </i>

    </button>



    <!-- =============================================
         EDIT
    ============================================== -->

    <button
        type="button"
        class="btn btn-primary"
        onclick="editBooking(${Number(
            booking.id
        )})"
        title="Edit">

        <i
            class="fas fa-edit">
        </i>

    </button>



    ${["admin","manager","administrator","teamlead"].includes(getBookingPageRole()) ? `
    <button
        type="button"
        class="btn btn-warning"
        onclick="assignBookingAgent(${Number(booking.id)})"
        title="Assign Booking">
        <i class="fas fa-user-check"></i>
    </button>` : ""}

    <!-- =============================================
         INVOICE MENU
    ============================================== -->

    <button
        type="button"
        class="btn btn-dark invoice-menu-trigger"
        data-booking-id="${Number(booking.id)}"
        title="Invoices & Documents"
        aria-expanded="false">
        <i class="fas fa-file-invoice"></i>
    </button>

    <div class="invoice-menu-template" data-booking-id="${Number(booking.id)}">
        <div class="invoice-menu-title">
            <span><i class="fas fa-file-invoice-dollar"></i> Documents</span>
            <button type="button" class="invoice-menu-close" aria-label="Close">&times;</button>
        </div>
        <a class="invoice-menu-item" href="../actions/booking/download_invoice.php?booking_id=${Number(booking.id)}&type=full" target="_blank">
            <span class="invoice-menu-icon full"><i class="fas fa-file-pdf"></i></span>
            <span><strong>Full Invoice</strong><small>Complete booking invoice</small></span>
            <i class="fas fa-chevron-right arrow"></i>
        </a>
        <a class="invoice-menu-item" href="../actions/booking/download_invoice.php?booking_id=${Number(booking.id)}&type=hotel" target="_blank">
            <span class="invoice-menu-icon hotel"><i class="fas fa-hotel"></i></span>
            <span><strong>Hotel Invoice</strong><small>Accommodation charges</small></span>
            <i class="fas fa-chevron-right arrow"></i>
        </a>
        <a class="invoice-menu-item" href="../actions/booking/download_invoice.php?booking_id=${Number(booking.id)}&type=flight" target="_blank">
            <span class="invoice-menu-icon flight"><i class="fas fa-plane"></i></span>
            <span><strong>Flight Invoice</strong><small>Flight charges</small></span>
            <i class="fas fa-chevron-right arrow"></i>
        </a>
    </div>

    <!-- =============================================
         DELETE
    ============================================== -->

    <button
        type="button"
        class="btn btn-danger"
        onclick="deleteBooking(${Number(
            booking.id
        )})"
        title="Delete">

        <i
            class="fas fa-trash">
        </i>

    </button>


</div>
`

                    ]);

                }

            );


            /*
             * =================================================
             * DRAW
             * =================================================
             */

            bookingTable.draw();


            /*
             * =================================================
             * WARNING ROWS
             * =================================================
             */

            bookingTable.rows().every(

                function (rowIndex) {

                    const rowNode =
                        this.node();


                    if (!rowNode) {

                        return;

                    }


                    const booking =
                        result.data[rowIndex];


                    if (!booking) {

                        return;

                    }


                    const issues = [];


                    if (
                        Number(
                            booking.has_unconfirmed_flight || 0
                        ) === 1
                    ) {

                        issues.push(
                            "Flight"
                        );

                    }


                    if (
                        Number(
                            booking.has_unconfirmed_hotel || 0
                        ) === 1
                    ) {

                        issues.push(
                            "Hotel"
                        );

                    }


                    if (issues.length > 0) {

                        $(rowNode).addClass(
                            "booking-service-warning"
                        );


                        $(rowNode).attr(
                            "title",
                            "Attention required: " +
                            issues.join(", ")
                        );

                    }

                }

            );


            /*
             * =================================================
             * UPDATE STATISTICS
             * =================================================
             */

            updateBookingStatistics(
                result.statistics
            );

        })

        .catch(function (error) {

            /* Aborted requests are expected when filters change quickly. */
            if (error && error.name === "AbortError") {
                return;
            }

            /* Never let an older request alter the current table. */
            if (requestSequence !== bookingsRequestSequence) {
                return;
            }

            console.error(
                "Failed to load bookings:",
                error
            );


            bookingTable
                .clear()
                .draw();


            updateBookingStatistics({

                totalBookings: 0,

                confirmedBookings: 0,

                pendingBookings: 0,

                cancelledBookings: 0,

                totalRevenue: 0,

                balanceDue: 0

            });

        });

}


/* =========================================================
   BUILD FLIGHT CELL
========================================================= */

function buildFlightCell(
    booking
) {

    const flights =
        Array.isArray(
            booking.flights
        )
            ? booking.flights
            : [];


    if (flights.length === 0) {

        return `
            <span class="text-muted">
                No Flight
            </span>
        `;

    }


    /*
     * First flight
     */

    const firstFlight =
        flights[0];


    const firstName =
        getFlightName(
            firstFlight
        );


    const firstStatus =
        firstFlight.flight_status ||
        "Pending";


    const firstIcon =
        getServiceStatusIcon(
            "flight",
            firstStatus
        );


    /*
     * Remaining flights
     */

    const remaining =
        flights.length - 1;


    let moreHtml = "";


    if (remaining > 0) {

        moreHtml = `

            <button type="button" class="service-more" aria-expanded="false">

                +${remaining} more

            </button>

        `;

    }


    /*
     * Hover panel
     */

    const hoverPanel =
        buildFlightHoverPanel(
            flights
        );


    return `

        <div class="service-hover-wrapper">

            <div class="service-summary">

                <span class="service-status-icon">

                    ${firstIcon}

                </span>

                <span
                    class="service-main-name"
                    title="${escapeHtml(
                        firstName
                    )}">

                    ${escapeHtml(
                        firstName
                    )}

                </span>

                ${moreHtml}

            </div>

            ${hoverPanel}

        </div>

    `;

}


/* =========================================================
   BUILD HOTEL CELL
========================================================= */

function buildHotelCell(
    booking
) {

    const hotels =
        Array.isArray(
            booking.hotels
        )
            ? booking.hotels
            : [];


    if (hotels.length === 0) {

        return `
            <span class="text-muted">
                No Hotel
            </span>
        `;

    }


    /*
     * First hotel
     */

    const firstHotel =
        hotels[0];


    const firstName =
        firstHotel.hotel_name ||
        "Hotel";


    const firstStatus =
        firstHotel.hotel_status ||
        "Pending";


    const firstIcon =
        getServiceStatusIcon(
            "hotel",
            firstStatus
        );


    /*
     * Remaining
     */

    const remaining =
        hotels.length - 1;


    let moreHtml = "";


    if (remaining > 0) {

        moreHtml = `

            <button type="button" class="service-more" aria-expanded="false">

                +${remaining} more

            </button>

        `;

    }


    /*
     * Hover panel
     */

    const hoverPanel =
        buildHotelHoverPanel(
            hotels
        );


    return `

        <div class="service-hover-wrapper">

            <div class="service-summary">

                <span class="service-status-icon">

                    ${firstIcon}

                </span>

                <span
                    class="service-main-name"
                    title="${escapeHtml(
                        firstName
                    )}">

                    ${escapeHtml(
                        firstName
                    )}

                </span>

                ${moreHtml}

            </div>

            ${hoverPanel}

        </div>

    `;

}


/* =========================================================
   FLIGHT NAME
========================================================= */

function getFlightName(
    flight
) {

    const airline =
        flight.airline_code ||
        "";


    const flightNo =
        flight.flight_no ||
        "";


    const route =
        (
            flight.origin ||
            ""
        ) +
        " → " +
        (
            flight.destination ||
            ""
        );


    let name =
        (
            airline +
            " " +
            flightNo
        ).trim();


    if (!name) {

        name = "Flight";

    }


    if (route !== " → ") {

        name +=
            " (" +
            route +
            ")";

    }


    return name;

}


/* =========================================================
   FLIGHT HOVER PANEL
========================================================= */

function buildFlightHoverPanel(
    flights
) {

    let html = `

        <div class="service-hover-panel">

            <div class="service-hover-title">

                <i class="fas fa-plane"></i>

                Flights

            </div>

    `;


    flights.forEach(

        function (flight) {

            const name =
                getFlightName(
                    flight
                );


            html += `

                <div
                    class="service-item">

                    <div
                        class="service-item-info">

                        <div
                            class="service-item-name">

                            <i
                                class="fas fa-plane-departure">
                            </i>

                            ${escapeHtml(
                                name
                            )}

                        </div>

                        <small>

                            ${escapeHtml(
                                flight.dept_date ||
                                ""
                            )}

                            ${
                                flight.dept_time
                                ?
                                " • " +
                                escapeHtml(
                                    flight.dept_time
                                )
                                :
                                ""
                            }

                        </small>

                    </div>


                    <div
                        class="service-item-status">

                        ${getServiceStatusIcon(
                            "flight",
                            flight.flight_status
                        )}

                        <select
                            class="service-status-select"
                            data-service-type="flight"
                            data-service-id="${Number(
                                flight.id
                            )}"
                            data-original-status="${escapeHtml(
                                flight.flight_status ||
                                "Pending"
                            )}">

                            ${buildStatusOptions(
                                "flight",
                                flight.flight_status
                            )}

                        </select>

                    </div>

                </div>

            `;

        }

    );


    html += `

        </div>

    `;


    return html;

}


/* =========================================================
   HOTEL HOVER PANEL
========================================================= */

function buildHotelHoverPanel(
    hotels
) {

    let html = `

        <div class="service-hover-panel">

            <div class="service-hover-title">

                <i class="fas fa-hotel"></i>

                Hotels

            </div>

    `;


    hotels.forEach(

        function (hotel) {

            const name =
                hotel.hotel_name ||
                "Hotel";


            html += `

                <div
                    class="service-item">

                    <div
                        class="service-item-info">

                        <div
                            class="service-item-name">

                            <i
                                class="fas fa-bed">
                            </i>

                            ${escapeHtml(
                                name
                            )}

                        </div>

                        <small>

                            ${escapeHtml(
                                hotel.city ||
                                ""
                            )}

                            ${
                                hotel.check_in
                                ?
                                " • " +
                                escapeHtml(
                                    hotel.check_in
                                )
                                :
                                ""
                            }

                            ${
                                hotel.nights
                                ?
                                " • " +
                                escapeHtml(
                                    hotel.nights
                                ) +
                                " night(s)"
                                :
                                ""
                            }

                        </small>

                    </div>


                    <div
                        class="service-item-status">

                        ${getServiceStatusIcon(
                            "hotel",
                            hotel.hotel_status
                        )}

                        <select
                            class="service-status-select"
                            data-service-type="hotel"
                            data-service-id="${Number(
                                hotel.id
                            )}"
                            data-original-status="${escapeHtml(
                                hotel.hotel_status ||
                                "Pending"
                            )}">

                            ${buildStatusOptions(
                                "hotel",
                                hotel.hotel_status
                            )}

                        </select>

                    </div>

                </div>

            `;

        }

    );


    html += `

        </div>

    `;


    return html;

}


/* =========================================================
   STATUS OPTIONS
========================================================= */

function buildStatusOptions(
    type,
    currentStatus
) {

    let statuses = [];


    if (type === "flight") {

        statuses = [

            "Pending",

            "Booked",

            "Ticketed",

            "Cancelled"

        ];

    } else {

        statuses = [

            "Pending",

            "Reserved",

            "Tentative",

            "Definitive",

            "Cancelled"

        ];

    }


    let html = "";


    statuses.forEach(

        function (status) {

            const selected =
                status === currentStatus
                    ? "selected"
                    : "";


            html += `

                <option
                    value="${escapeHtml(
                        status
                    )}"
                    ${selected}>

                    ${escapeHtml(
                        status
                    )}

                </option>

            `;

        }

    );


    return html;

}


/* =========================================================
   STATUS ICON
========================================================= */

function getServiceStatusIcon(
    type,
    status
) {

    status =
        status || "Pending";


    let isGood = false;


    if (type === "flight") {

        /*
         * Booked and Ticketed
         * are considered confirmed.
         */

        isGood =
            status === "Booked" ||
            status === "Ticketed";

    }


    if (type === "hotel") {

        /*
         * Reserved and Definitive
         * are considered confirmed.
         */

        isGood =
            status === "Reserved" ||
            status === "Definitive";

    }


    if (isGood) {

        return `

            <span
                class="service-check-icon"
                title="${escapeHtml(
                    status
                )}">

                <i class="fas fa-check"></i>

            </span>

        `;

    }


    return `

        <span
            class="service-cross-icon"
            title="${escapeHtml(
                status
            )}">

            <i class="fas fa-times"></i>

        </span>

    `;

}


/* =========================================================
   SERVICE STATUS CHANGE
========================================================= */

$(document).on(
    "change",
    ".service-status-select",
    function (event) {

        /*
         * Prevent the table row from
         * receiving the click.
         */

        event.stopPropagation();


        const select =
            $(this);


        const serviceType =
            select.data(
                "service-type"
            );


        const serviceId =
            Number(
                select.data(
                    "service-id"
                )
            );


        const oldStatus =
            select.data(
                "original-status"
            );


        const newStatus =
            select.val();


        if (
            !serviceType ||
            !serviceId ||
            !newStatus
        ) {

            return;

        }


        /*
         * =====================================================
         * LOADING
         * =====================================================
         */

        select.prop(
            "disabled",
            true
        );


        select.addClass(
            "service-status-saving"
        );


        /*
         * =====================================================
         * REQUEST
         * =====================================================
         */

        const formData =
            new FormData();


        formData.append(
            "service_type",
            serviceType
        );


        formData.append(
            "service_id",
            serviceId
        );


        formData.append(
            "status",
            newStatus
        );


        fetch(
            "../actions/booking/update_booking_service_status.php",
            {

                method: "POST",

                body: formData

            }
        )

            .then(function (response) {

                return response.json();

            })

            .then(function (result) {

                if (!result.success) {

                    throw new Error(
                        result.message ||
                        "Unable to update status."
                    );

                }


                /*
                 * Update original status
                 */

                select.data(
                    "original-status",
                    newStatus
                );


                /*
                 * Small success animation
                 */

                select.addClass(
                    "service-status-success"
                );


                setTimeout(
                    function () {

                        select.removeClass(
                            "service-status-success"
                        );

                    },
                    1000
                );


                /*
                 * Reload bookings.
                 *
                 * This updates the check/cross
                 * in the main table as well.
                 */

                          setTimeout(
                        function () {
                    
                            // Close popup BEFORE DataTable is rebuilt
                            closeBookingPortals();
                    
                            // Now reload the table
                            loadBookings();
                    
                        },
                        300
                    );

            })

            .catch(function (error) {

                console.error(
                    "Service status update failed:",
                    error
                );


                alert(
                    error.message ||
                    "Unable to update status."
                );


                /*
                 * Restore old status
                 */

                select.val(
                    oldStatus
                );

            })

            .finally(function () {

                select.prop(
                    "disabled",
                    false
                );


                select.removeClass(
                    "service-status-saving"
                );

            });

    }
);


/* =========================================================
   STOP HOVER PANEL EVENTS
========================================================= */

function closeBookingPortals() {

    document.querySelectorAll(
        ".service-hover-panel.booking-service-portal, .invoice-menu-template.invoice-menu-portal"
    ).forEach(function (el) {

        /*
         * Restore popup to original parent only if
         * the original parent still exists in the DOM.
         */
        if (
            el._restoreParent &&
            el._restoreParent.isConnected
        ) {
            el._restoreParent.appendChild(el);
        }

        /*
         * Always hide the popup first.
         * This also handles orphaned popups.
         */
        el.style.setProperty(
            "display",
            "none",
            "important"
        );

        el.style.removeProperty("top");
        el.style.removeProperty("left");
        el.style.removeProperty("right");
        el.style.removeProperty("bottom");
        el.style.removeProperty("position");
        el.style.removeProperty("z-index");
        el.style.removeProperty("width");
        el.style.removeProperty("max-width");
        el.style.removeProperty("visibility");

        el.classList.remove(
            "booking-service-portal",
            "invoice-menu-portal"
        );

        if (
            el._trigger &&
            el._trigger.isConnected
        ) {
            el._trigger.setAttribute(
                "aria-expanded",
                "false"
            );
        }

        delete el._restoreParent;
        delete el._trigger;
    });

    /*
     * Close all expanded buttons.
     */
    document.querySelectorAll(
        ".service-more[aria-expanded='true'], " +
        ".invoice-menu-trigger[aria-expanded='true']"
    ).forEach(function (button) {

        button.setAttribute(
            "aria-expanded",
            "false"
        );

    });
}

function positionPortal(panel, trigger, preferredWidth) {
    const rect = trigger.getBoundingClientRect();
    const width = Math.min(preferredWidth || 390, window.innerWidth - 24);
    panel.style.position = "fixed";
    panel.style.width = width + "px";
    panel.style.maxWidth = "calc(100vw - 24px)";
    panel.style.zIndex = "2147483000";
    panel.style.visibility = "hidden";
    panel.style.display = "block";
    const measured = panel.getBoundingClientRect();
    let left = rect.left;
    if (left + measured.width > window.innerWidth - 12) left = window.innerWidth - measured.width - 12;
    if (left < 12) left = 12;
    const roomBelow = window.innerHeight - rect.bottom;
    const roomAbove = rect.top;
    let top;
    if (roomBelow >= measured.height + 10 || roomBelow >= roomAbove) {
        top = Math.min(rect.bottom + 8, window.innerHeight - measured.height - 12);
    } else {
        top = Math.max(12, rect.top - measured.height - 8);
    }
    panel.style.left = left + "px";
    panel.style.top = top + "px";
    panel.style.visibility = "visible";
}

$(document).on("click", ".service-more", function (event) {
    event.preventDefault();
    event.stopPropagation();
    closeBookingPortals();
    const trigger = this;
    const wrapper = trigger.closest(".service-hover-wrapper");
    const panel = wrapper ? wrapper.querySelector(".service-hover-panel") : null;
    if (!panel) return;
    panel._restoreParent = wrapper;
    panel._trigger = trigger;
    document.body.appendChild(panel);
    panel.classList.add("booking-service-portal");
    trigger.setAttribute("aria-expanded", "true");
    positionPortal(panel, trigger, 390);
});

$(document).on("click", ".invoice-menu-trigger", function (event) {
    event.preventDefault();
    event.stopPropagation();
    closeBookingPortals();
    const trigger = this;
    const template = trigger.parentElement ? trigger.parentElement.querySelector(".invoice-menu-template") : null;
    if (!template) return;
    template._restoreParent = template.parentElement;
    template._trigger = trigger;
    document.body.appendChild(template);
    template.classList.add("invoice-menu-portal");
    trigger.setAttribute("aria-expanded", "true");
    positionPortal(template, trigger, 320);
});

$(document).on("click", ".invoice-menu-close", function (event) {
    event.preventDefault();
    event.stopPropagation();
    closeBookingPortals();
});

$(document).on("click", ".service-hover-panel, .invoice-menu-template", function (event) {
    event.stopPropagation();
});

$(document).on("click", function () {
    closeBookingPortals();
});

$(window).on("resize scroll", function () {
    closeBookingPortals();
});

/* =========================================================
   UPDATE STATISTICS
========================================================= */

function updateBookingStatistics(
    statistics
) {

    statistics =
        statistics || {};


    const totalBookings =
        document.getElementById(
            "totalBookings"
        );


    const confirmedBookings =
        document.getElementById(
            "confirmedBookings"
        );


    const pendingBookings =
        document.getElementById(
            "pendingBookings"
        );


    const cancelledBookings =
        document.getElementById(
            "cancelledBookings"
        );


    const totalRevenue =
        document.getElementById(
            "totalRevenue"
        );


    const balanceDue =
        document.getElementById(
            "balancedue"
        );


    if (totalBookings) {

        totalBookings.textContent =
            statistics.totalBookings || 0;

    }


    if (confirmedBookings) {

        confirmedBookings.textContent =
            statistics.confirmedBookings || 0;

    }


    if (pendingBookings) {

        pendingBookings.textContent =
            statistics.pendingBookings || 0;

    }


    if (cancelledBookings) {

        cancelledBookings.textContent =
            statistics.cancelledBookings || 0;

    }


    if (totalRevenue) {

        totalRevenue.textContent =
            "£" +
            formatMoney(
                statistics.totalRevenue
            );

    }


    if (balanceDue) {

        balanceDue.textContent =
            "£" +
            formatMoney(
                statistics.balanceDue
            );

    }

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(date) {

    if (!date) {

        return "-";

    }


    const parts =
        String(date).split("-");


    if (parts.length !== 3) {

        return escapeHtml(date);

    }


    return (

        parts[2] +
        "-" +
        parts[1] +
        "-" +
        parts[0]

    );

}


/* =========================================================
   FORMAT MONEY
========================================================= */

function formatMoney(amount) {

    amount =
        parseFloat(amount || 0);


    return amount.toLocaleString(
        "en-GB",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    );

}


/* =========================================================
   BOOKING STATUS BADGE
========================================================= */

function getStatusBadge(status) {

    status =
        status || "New";


    let badgeClass =
        "bg-secondary";


    switch (status) {

        case "New":

            badgeClass =
                "bg-secondary";

            break;


        case "Confirmed":

            badgeClass =
                "bg-success";

            break;


        case "Departed":

            badgeClass =
                "bg-primary";

            break;


        case "In Makkah":

            badgeClass =
                "bg-info text-dark";

            break;


        case "In Madinah":

            badgeClass =
                "bg-info text-dark";

            break;


        case "Returning":

            badgeClass =
                "bg-warning text-dark";

            break;


        case "Completed":

            badgeClass =
                "bg-success";

            break;


        case "Cancelled":

            badgeClass =
                "bg-danger";

            break;

    }


    return `

        <span class="badge ${badgeClass}">

            ${escapeHtml(status)}

        </span>

    `;

}
/* =========================================================
   BOOKING EDIT MODULE
   Production-safe edit/populate implementation
========================================================= */

"use strict";

/*
 * This module deliberately uses the HTML `name` attributes from
 * the booking modal instead of assuming IDs such as invoiceNo.
 *
 * The booking modal fields are:
 * invoice_no, invoice_date, due_date, pnr, airline_pnr,
 * travel_date, status, client_name, client_mobile, client_email.
 *
 * Dynamic rows are populated through their row-scoped names.
 */

/* =========================================================
   VIEW BOOKING (READ ONLY)
========================================================= */

async function viewBooking(bookingId) {
    const id = Number(bookingId);
    if (!Number.isInteger(id) || id <= 0) { alert("Invalid booking ID."); return; }
    const modal = document.getElementById("bookingModal");
    if (!modal) { alert("Booking modal was not found."); return; }
    try {
        modal.classList.add("show");
        modal.style.display = "flex";
        modal.setAttribute("aria-hidden", "false");
        document.body.classList.add("modal-open");
        document.body.style.overflow = "hidden";
        const response = await fetch("../actions/booking/get_booking.php?booking_id=" + encodeURIComponent(id), {credentials:"same-origin", cache:"no-store"});
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.message || "Unable to load booking.");
        setBookingViewMode(id);
        populateBookingForEdit(result.data);
        setBookingViewMode(id);
    } catch (e) {
        alert(e.message || "Unable to load booking.");
        closeBookingModalSafely();
    }
}
window.viewBooking = viewBooking;

function setBookingViewMode(bookingId) {
    const modal = document.getElementById("bookingModal");
    if (!modal) return;
    modal.dataset.mode = "view";
    modal.dataset.bookingId = String(bookingId || "");
    const title = modal.querySelector(".booking-modal-title");
    if (title) title.innerHTML = '<i class="fas fa-eye me-2"></i> View Booking';
    const subtitle = modal.querySelector(".booking-modal-subtitle");
    if (subtitle) subtitle.textContent = "Booking details (read only)";
    const save = modal.querySelector(".btn-save");
    if (save) save.style.display = "none";
    const pdfButton = modal.querySelector("#exportBookingViewPdf");
    if (pdfButton) pdfButton.style.display = "inline-flex";
    modal.querySelectorAll("input, select, textarea, button").forEach(el => {
        if (el.id === "closeBookingModal" || el.id === "bookingCancelButton" || el.id === "exportBookingViewPdf") return;
        el.disabled = true;
    });
}

function enableBookingFormFields() {
    const modal = document.getElementById("bookingModal");
    if (!modal) return;
    modal.querySelectorAll("input, select, textarea, button").forEach(el => {
        if (el.id === "closeBookingModal" || el.id === "bookingCancelButton" || el.id === "exportBookingViewPdf") return;
        el.disabled = false;
    });
    const save = modal.querySelector(".btn-save");
    if (save) save.style.display = "";
    const pdfButton = modal.querySelector("#exportBookingViewPdf");
    if (pdfButton) pdfButton.style.display = "none";
}

/* =========================================================
   ASSIGN BOOKING TO AGENT
========================================================= */
async function assignBookingAgent(bookingId) {
    const role = String(document.getElementById("bookingFilterCard")?.dataset.role || "").toLowerCase();
    if (!["admin","manager","administrator","teamlead"].includes(role)) return alert("You are not authorized to assign bookings.");
    const id = Number(bookingId); if (!id) return alert("Invalid booking ID.");
    try {
        const r = await fetch("../actions/booking/get_assignable_agents.php?booking_id=" + encodeURIComponent(id), {credentials:"same-origin",cache:"no-store"});
        const j = await r.json(); if (!j.success) throw Error(j.message || "Unable to load agents.");
        const agents = Array.isArray(j.data) ? j.data : [];
        if (!agents.length) return alert("No assignable agents were found for this booking project.");
        const options = agents.map(a => `<option value="${Number(a.id)}">${escapeHtml(a.name)}${a.agent_code ? " ("+escapeHtml(a.agent_code)+")" : ""}</option>`).join("");
        const current = document.querySelector(`#bookingTable button[onclick*="assignBookingAgent(${id})"]`);
        const modal = document.createElement("div");
        modal.id="bookingAssignModal"; modal.className="booking-assign-modal";
        modal.innerHTML=`<div class="booking-assign-box"><h5 class="mb-3"><i class="fas fa-user-check me-2"></i>Assign Booking</h5><label class="form-label">Select Agent</label><select id="bookingAssignAgent" class="form-select">${options}</select><div class="d-flex justify-content-end gap-2 mt-4"><button type="button" class="btn btn-secondary" data-close>Cancel</button><button type="button" class="btn btn-primary" data-save>Assign</button></div></div>`;
        document.body.appendChild(modal);
        modal.querySelector("[data-close]").onclick=()=>modal.remove();
        modal.querySelector("[data-save]").onclick=async()=>{
            const agentId=Number(modal.querySelector("#bookingAssignAgent").value||0); const fd=new FormData(); fd.append("booking_id",id); fd.append("agent_id",agentId);
            try{const rr=await fetch("../actions/booking/assign_agent.php",{method:"POST",body:fd,credentials:"same-origin"});const jj=await rr.json();if(!jj.success)throw Error(jj.message||"Assignment failed.");alert(jj.message);modal.remove();if(typeof window.loadBookings==="function")window.loadBookings();}catch(e){alert(e.message||"Assignment failed.");}
        };
    } catch(e) { alert(e.message || "Unable to load agents."); }
}
window.assignBookingAgent=assignBookingAgent;

/* =========================================================
   BOOKING VIEW SNAPSHOT PDF
========================================================= */
async function exportBookingViewPdf(bookingId) {
    const modal = document.getElementById("bookingModal");
    if (!modal) return alert("Booking modal was not found.");
    const id = Number(bookingId || modal.dataset.bookingId || 0);
    if (!id) return alert("Invalid booking ID.");
    if (typeof html2canvas !== "function" || typeof window.jspdf === "undefined") {
        return alert("PDF library is still loading. Please try again in a moment.");
    }
    const previousMode = modal.dataset.mode || "view";
    const previousId = modal.dataset.bookingId || String(id);
    try {
        setBookingViewMode(id);
        const dialog = modal.querySelector(".booking-modal-dialog");
        if (!dialog) throw new Error("Booking modal content was not found.");
        await new Promise(r => setTimeout(r, 150));
        const canvas = await html2canvas(dialog, { scale: 2, useCORS: true, backgroundColor: "#ffffff", logging: false, windowWidth: Math.max(document.documentElement.clientWidth, dialog.scrollWidth) });
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF("p", "mm", "a4");
        const pageWidth = 210, pageHeight = 297, margin = 6;
        const imgWidth = pageWidth - margin * 2;
        const imgHeight = canvas.height * imgWidth / canvas.width;
        const usableHeight = pageHeight - margin * 2;
        let rendered = 0;
        while (rendered < imgHeight) {
            if (rendered > 0) pdf.addPage();
            const sliceMm = Math.min(usableHeight, imgHeight - rendered);
            const slicePx = Math.round(sliceMm * canvas.width / imgWidth);
            const sourceY = Math.round(rendered * canvas.width / imgWidth);
            const sliceCanvas = document.createElement("canvas");
            sliceCanvas.width = canvas.width; sliceCanvas.height = Math.min(slicePx, canvas.height - sourceY);
            sliceCanvas.getContext("2d").drawImage(canvas, 0, sourceY, canvas.width, sliceCanvas.height, 0, 0, canvas.width, sliceCanvas.height);
            const sliceData = sliceCanvas.toDataURL("image/jpeg", 0.92);
            const sliceHeightMm = sliceCanvas.height * imgWidth / canvas.width;
            pdf.addImage(sliceData, "JPEG", margin, margin, imgWidth, sliceHeightMm);
            rendered += usableHeight;
        }
        const invoice = String(modal.querySelector('[name="invoice_no"]')?.value || id).replace(/[^a-z0-9_-]+/gi, "-");
        pdf.save(`booking-${invoice}.pdf`);
    } catch (e) {
        console.error(e); alert(e.message || "Unable to export booking PDF.");
    } finally {
        if (previousMode === "edit") setBookingEditMode(previousId); else setBookingViewMode(previousId);
    }
}
window.exportBookingViewPdf = exportBookingViewPdf;

/* =========================================================
   DELETE BOOKING / AGENT APPROVAL WORKFLOW
========================================================= */

async function deleteBooking(bookingId) {
    const id = Number(bookingId);
    if (!Number.isInteger(id) || id <= 0) return alert("Invalid booking ID.");
    if (!confirm("Are you sure you want to delete this booking?")) return;
    try {
        const fd = new FormData(); fd.append("booking_id", id);
        const r = await fetch("../actions/booking/delete.php", {method:"POST", body:fd, credentials:"same-origin"});
        const j = await r.json();
        if (!j.success) throw new Error(j.message || "Unable to delete booking.");
        alert(j.message || "Booking deleted successfully.");
        if (typeof window.loadBookings === "function") window.loadBookings();
    } catch(e) { alert(e.message || "Delete request failed."); }
}
window.deleteBooking = deleteBooking;

async function requestBookingDeletion(bookingId) {
    const id = Number(bookingId);
    if (!Number.isInteger(id) || id <= 0) return;
    if (!confirm("Send a deletion request to Admin/Manager/Team Lead?")) return;
    try {
        const fd = new FormData(); fd.append("booking_id", id);
        const r = await fetch("../actions/booking/delete.php?action=request", {method:"POST", body:fd, credentials:"same-origin"});
        const j = await r.json();
        if (!j.success) throw new Error(j.message || "Unable to send request.");
        alert(j.message || "Deletion request sent.");
    } catch(e) { alert(e.message || "Unable to send request."); }
}
window.requestBookingDeletion = requestBookingDeletion;

/* =========================================================
   EDIT BOOKING
========================================================= */

async function editBooking(bookingId) {

    const id = Number(bookingId);

    if (!Number.isInteger(id) || id <= 0) {
        alert("Invalid booking ID.");
        return;
    }

    const modal =
        document.getElementById("bookingModal");

    if (!modal) {
        alert("Booking modal was not found.");
        return;
    }

    const role = String(document.getElementById("bookingFilterCard")?.dataset.role || "").toLowerCase();
    if (role === "agent") {
        try {
            const fd = new FormData();
            fd.append("action", "request");
            fd.append("booking_id", String(id));
            const approvalResponse = await fetch("../actions/booking/edit_request.php", { method:"POST", body:fd, credentials:"same-origin", cache:"no-store" });
            const approval = await approvalResponse.json();
            if (approval.success && approval.data?.status === "Approved") {
                // Continue into edit mode. The approval is consumed when the booking is saved.
            } else {
                alert(approval.message || "Edit approval is required before you can edit this booking.");
                return;
            }
        } catch (e) {
            alert(e.message || "Unable to request edit approval.");
            return;
        }
    }

    console.log("Opening booking for edit:", id);
    enableBookingFormFields();

    let loading = null;

    try {

        removeEditBookingLoading();

        /*
         * Open modal while loading.
         */
        modal.classList.add("show");
        modal.style.display = "flex";
        modal.setAttribute("aria-hidden", "false");

        document.body.classList.add("modal-open");
        document.body.style.overflow = "hidden";

        loading = createEditBookingLoading();
        loading.style.display = "flex";

        /*
         * Fetch complete booking.
         */
        const response = await fetch(
            "../actions/booking/get_booking.php?booking_id=" +
            encodeURIComponent(id),
            {
                method: "GET",
                headers: {
                    "Accept": "application/json"
                },
                credentials: "same-origin",
                cache: "no-store"
            }
        );

        const rawText =
            await response.text();

        let result;

        try {
            result = JSON.parse(rawText);
        } catch (jsonError) {
            console.error(
                "GET BOOKING INVALID JSON:",
                rawText
            );

            throw new Error(
                "Server returned invalid JSON while loading booking."
            );
        }

        console.log(
            "EDIT BOOKING RESPONSE:",
            result
        );

        if (!response.ok) {
            throw new Error(
                result?.message ||
                `Unable to load booking (HTTP ${response.status}).`
            );
        }

        if (
            !result ||
            result.success !== true
        ) {
            throw new Error(
                result?.message ||
                "Unable to load booking."
            );
        }

        const booking =
            result.data;

        if (!booking) {
            throw new Error(
                "Booking data is empty."
            );
        }

        console.log(
            "BOOKING DATA TO POPULATE:",
            booking
        );

        /*
         * Set edit state BEFORE populating.
         */
        setBookingEditMode(id);

        /*
         * Populate every section.
         */
        populateBookingForEdit(booking);

        if (loading) {
            loading.style.display = "none";
        }

        modal.classList.add("show");
        modal.style.display = "flex";
        modal.setAttribute("aria-hidden", "false");

    } catch (error) {

        console.error(
            "Edit booking error:",
            error
        );

        if (loading) {
            loading.style.display = "none";
        }

        alert(
            error?.message ||
            "Unable to load booking."
        );

        /*
         * Do not leave a broken modal open.
         */
        closeBookingModalSafely();

    } finally {

        setTimeout(
            removeEditBookingLoading,
            100
        );

    }
}

/*
 * Always expose the function globally because the booking table
 * uses inline onclick="editBooking(ID)".
 */
window.editBooking = editBooking;


/* =========================================================
   EDIT LOADING
========================================================= */

function createEditBookingLoading() {

    let loading =
        document.getElementById(
            "editBookingLoading"
        );

    if (loading) {
        loading.style.display = "flex";
        return loading;
    }

    loading =
        document.createElement("div");

    loading.id =
        "editBookingLoading";

    loading.innerHTML = `
        <div class="edit-booking-loading-content">
            <div
                class="spinner-border text-primary"
                role="status"
                aria-label="Loading">
            </div>

            <div class="mt-3">
                Loading booking...
            </div>
        </div>
    `;

    loading.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,.45);
        z-index: 99998;
        display: flex;
        align-items: center;
        justify-content: center;
    `;

    document.body.appendChild(loading);

    return loading;
}


function removeEditBookingLoading() {

    const loading =
        document.getElementById(
            "editBookingLoading"
        );

    if (loading) {
        loading.remove();
    }
}


/* =========================================================
   SAFE MODAL CLOSE
========================================================= */

function closeBookingModalSafely() {

    const modal =
        document.getElementById(
            "bookingModal"
        );

    if (!modal) {
        return;
    }

    if (
        typeof window.closeBookingModal ===
        "function"
    ) {
        window.closeBookingModal();
        return;
    }

    modal.classList.remove("show");
    modal.style.display = "none";
    modal.setAttribute("aria-hidden", "true");

    document.body.classList.remove("modal-open");
    document.body.style.overflow = "";
}


/* =========================================================
   SET EDIT MODE
========================================================= */

function setBookingEditMode(bookingId) {

    const modal =
        document.getElementById(
            "bookingModal"
        );

    if (!modal) {
        return;
    }

    const id =
        Number(bookingId);

    if (!Number.isInteger(id) || id <= 0) {
        return;
    }

    /*
     * Store edit state on modal.
     */
    modal.dataset.mode = "edit";
    modal.dataset.bookingId = String(id);
    enableBookingFormFields();

    // Booking status is not editable in Edit Booking.
    // Service statuses (flight/hotel) remain independently editable from See More.
    const bookingStatusField = modal.querySelector('[name="status"]');
    if (bookingStatusField) {
        bookingStatusField.disabled = true;
    }

    /*
     * Explicit hidden booking_id field.
     */
    let bookingIdInput =
        modal.querySelector(
            'input[name="booking_id"]'
        );

    if (!bookingIdInput) {

        bookingIdInput =
            document.createElement("input");

        bookingIdInput.type = "hidden";
        bookingIdInput.id = "editBookingId";
        bookingIdInput.name = "booking_id";

        modal.appendChild(
            bookingIdInput
        );
    }

    bookingIdInput.value = String(id);

    /*
     * Correct title selector.
     *
     * HTML uses .booking-modal-title,
     * NOT .modal-title.
     */
    const title =
        modal.querySelector(
            ".booking-modal-title"
        );

    if (title) {
        title.innerHTML = `
            <i class="fas fa-edit me-2"></i>
            Edit Booking
        `;
    }

    const subtitle =
        modal.querySelector(
            ".booking-modal-subtitle"
        );

    if (subtitle) {
        subtitle.textContent =
            "Update customer booking";
    }

    const saveButton =
        modal.querySelector(
            ".btn-save"
        );

    if (saveButton) {
        saveButton.innerHTML = `
            <i class="fas fa-save me-2"></i>
            Update Booking
        `;
    }
}


/* =========================================================
   CREATE MODE
========================================================= */

function setBookingCreateMode() {

    const modal =
        document.getElementById(
            "bookingModal"
        );

    if (!modal) {
        return;
    }

    delete modal.dataset.mode;
    delete modal.dataset.bookingId;
    enableBookingFormFields();

    const bookingStatusField = modal.querySelector('[name="status"]');
    if (bookingStatusField) {
        bookingStatusField.disabled = false;
    }

    const bookingIdInput =
        modal.querySelector(
            'input[name="booking_id"]'
        );

    if (bookingIdInput) {
        bookingIdInput.value = "";
    }

    const title =
        modal.querySelector(
            ".booking-modal-title"
        );

    if (title) {
        title.textContent =
            "Create New Booking";
    }

    const subtitle =
        modal.querySelector(
            ".booking-modal-subtitle"
        );

    if (subtitle) {
        subtitle.textContent =
            "Create a new customer booking";
    }

    const pdfButton = modal.querySelector("#exportBookingViewPdf");
    if (pdfButton) pdfButton.style.display = "none";

    const saveButton =
        modal.querySelector(
            ".btn-save"
        );

    if (saveButton) {
        saveButton.innerHTML =
            "💾 Save Booking";
    }
}

window.setBookingCreateMode =
    setBookingCreateMode;


/* =========================================================
   PROJECT CODE / INVOICE PREVIEW
========================================================= */

function syncProjectInvoicePreview() {
    const modal = document.getElementById("bookingModal");
    const project = modal?.querySelector("#project_id");
    const prefix = modal?.querySelector("#invoice_prefix");
    const invoice = modal?.querySelector("#invoice_no");
    if (!project || !prefix) return;

    const option = project.options[project.selectedIndex];
    const code = String(option?.dataset?.projectCode || "").trim().toUpperCase();
    if (code) {
        prefix.value = code;
        if (invoice && (!invoice.value || invoice.dataset.autoGenerated === "1")) {
            invoice.value = "Auto-generated on save";
            invoice.dataset.autoGenerated = "1";
        }
    }
}

document.addEventListener("change", function (event) {
    if (event.target?.id === "project_id") {
        syncProjectInvoicePreview();
    }
});

/* =========================================================
   POPULATE BOOKING
========================================================= */

function populateBookingForEdit(booking) {

    if (!booking || typeof booking !== "object") {
        throw new Error("Invalid booking data received.");
    }

    console.log("Populating booking:", booking);

    // ---------------------------------------------------------
    // Main booking fields. These names match booking_modal.php
    // and the actual bookings table columns.
    // ---------------------------------------------------------
    setBookingField("invoice_no", booking.invoice_no);
    const invoiceInput = document.querySelector("#bookingModal [name=\"invoice_no\"]");
    if (invoiceInput) invoiceInput.dataset.autoGenerated = "0";
    setBookingField("invoice_prefix", booking.invoice_prefix || booking.project_code || "");
    setBookingField("invoice_date", booking.invoice_date);
    setBookingField("due_date", booking.due_date);
    setBookingField("pnr", booking.gds_pnr ?? booking.pnr ?? "");
    setBookingField("airline_pnr", booking.airline_pnr);
    setBookingField("travel_date", booking.travel_date);
    setBookingField("status", booking.status);
    setBookingField("client_name", booking.client_name);
    setBookingField("client_mobile", booking.client_mobile);
    setBookingField("client_email", booking.client_email);

    // These three fields are ID-only inputs in booking_modal.php.
    // They are submitted manually by booking.js as atol_charges,
    // iata_charges and discount.
    setBookingElementValue(
        document.getElementById("atolCharges"),
        booking.atol_charges ?? 0
    );

    setBookingElementValue(
        document.getElementById("iataCharges"),
        booking.iata_charges ?? booking.safi_charges ?? 0
    );

    setBookingElementValue(
        document.getElementById("discount"),
        booking.discount ?? 0
    );

clearEditBookingRows();

    const passengers = Array.isArray(booking.passengers) ? booking.passengers : [];
    const flights = Array.isArray(booking.flights) ? booking.flights : [];
    const hotels = Array.isArray(booking.hotels) ? booking.hotels : [];
    const transports = Array.isArray(booking.transports) ? booking.transports : [];
    const products = Array.isArray(booking.products) ? booking.products : [];
    const costs = Array.isArray(booking.costs) ? booking.costs : [];
    const payments = Array.isArray(booking.payments) ? booking.payments : [];

    // ---------------------------------------------------------
    // PASSENGERS
    // DB title is uppercase (MR/MRS/MS/MISS/...).
    // ---------------------------------------------------------
    passengers.forEach(function (passenger) {
        addPassenger();
        const rows = document.querySelectorAll("#passengerRows tr");
        const row = rows[rows.length - 1];
        if (!row) return;

const passengerTitle = String(
    passenger.title ?? ""
).trim();

const titleMap = {
    "MR": "Mr",
    "MRS": "Mrs",
    "MS": "Ms",
    "MISS": "Miss",
    "CHILD": "Child"
};

setRowField(
    row,
    "title",
    titleMap[passengerTitle.toUpperCase()] || passengerTitle
);        setRowField(row, "surname", passenger.surname);
        setRowField(row, "firstname", passenger.firstname);
    });

    // ---------------------------------------------------------
    // FLIGHTS
    // Database names: airline_code, flight_no, dept_date,
    // dept_time, arr_time.
    // ---------------------------------------------------------
    flights.forEach(function (flight) {
        addFlight();
        const rows = document.querySelectorAll("#flightRows tr");
        const row = rows[rows.length - 1];
        if (!row) return;

        if (flight.id) {
            const field = row.querySelector('[name^="flights["]');
            const match = field?.name.match(/^flights\[(\d+)\]/);
            if (match) {
                const hidden = document.createElement("input");
                hidden.type = "hidden";
                hidden.name = `flights[${match[1]}][id]`;
                hidden.value = String(flight.id);
                row.appendChild(hidden);
            }
        }

        setRowField(row, ["airline", "airline_code"], flight.airline_code ?? flight.airline);
        setRowField(row, ["flight", "flight_no"], flight.flight_no ?? flight.flight);
        setRowField(row, ["departure_date", "dept_date"], flight.dept_date ?? flight.departure_date);
        setRowField(row, "origin", flight.origin);
        setRowField(row, "destination", flight.destination);
        setRowField(row, ["departure_time", "dept_time"], flight.dept_time ?? flight.departure_time);
        setRowField(row, ["arrival_time", "arr_time"], flight.arr_time ?? flight.arrival_time);
        setRowField(row, "baggage", flight.baggage);
        setRowField(row, "supplier", flight.supplier);
    });

    // ---------------------------------------------------------
    // HOTELS
    // Database names: hotel_name, meal_basis, room_view.
    // ---------------------------------------------------------
    hotels.forEach(function (hotel) {
        addHotel();
        const rows = document.querySelectorAll("#hotelRows tr");
        const row = rows[rows.length - 1];
        if (!row) return;

        if (hotel.id) {
            const field = row.querySelector('[name^="hotels["]');
            const match = field?.name.match(/^hotels\[(\d+)\]/);
            if (match) {
                const hidden = document.createElement("input");
                hidden.type = "hidden";
                hidden.name = `hotels[${match[1]}][id]`;
                hidden.value = String(hotel.id);
                row.appendChild(hidden);
            }
        }

        setRowField(row, ["name", "hotel_name"], hotel.hotel_name ?? hotel.name);
        setRowField(row, "city", hotel.city);
        setRowField(row, "room_type", hotel.room_type);
        setRowField(row, "rooms", hotel.rooms);
        setRowField(row, ["meal", "meal_basis"], hotel.meal_basis ?? hotel.meal);
        setRowField(row, ["view", "room_view"], hotel.room_view ?? hotel.view);
        setRowField(row, "check_in", hotel.check_in);
        setRowField(row, "nights", hotel.nights);
        setRowField(row, "check_out", hotel.check_out);
        setRowField(row, "remarks", hotel.remarks);
        setRowField(row, "supplier", hotel.hotel_supplier ?? hotel.supplier);
    });

    // ---------------------------------------------------------
    // TRANSPORT
    // Database name is vehicles_qty, while the form uses vehicles.
    // ---------------------------------------------------------
    transports.forEach(function (transport) {
        addTransport();
        const rows = document.querySelectorAll("#transportRows tr");
        const row = rows[rows.length - 1];
        if (!row) return;

        setRowField(row, "vehicle", transport.vehicle);
        setRowField(row, "journey", transport.journey);
        setRowField(row, ["vehicles", "vehicles_qty"], transport.vehicles_qty ?? transport.vehicles);
        setRowField(row, "pickup_date", transport.pickup_date);
        setRowField(row, "pickup_time", transport.pickup_time);
        setRowField(row, "notes", transport.notes);
        setRowField(row, "supplier", transport.supplier);
    });

    // ---------------------------------------------------------
    // PRODUCTS
    // Database name is product_name.
    // ---------------------------------------------------------
    products.forEach(function (product) {
        addProduct();
        const rows = document.querySelectorAll("#productRows .product-row");
        const row = rows[rows.length - 1];
        if (!row) return;

        const input = row.querySelector('input[name*="[name]"]') ||
                      row.querySelector('input[type="text"]');
        if (input) {
            setBookingElementValue(input, product.product_name ?? product.product ?? product.name ?? "");
        }
        setRowField(row, "supplier", product.supplier ?? "");
    });

    // ---------------------------------------------------------
    // COSTS
    // IMPORTANT: cost rows in your HTML use classes, not name="".
    // setRowField() below therefore supports class selectors too.
    // ---------------------------------------------------------
    costs.forEach(function (cost) {
        addCost();
        const rows = document.querySelectorAll("#costRows tr");
        const row = rows[rows.length - 1];
        if (!row) return;

        setRowField(row, "age", cost.age_category ?? cost.age);
        setRowField(row, "qty", cost.quantity ?? cost.qty);
        setRowField(row, "base-fare", cost.base_fare);
        setRowField(row, "tax", cost.tax);
        setRowField(row, "selling-price", cost.selling_price);
    });

    // ---------------------------------------------------------
    // PAYMENTS
    // Database names: payment_date and reference_no.
    // ---------------------------------------------------------
    payments.forEach(function (payment) {
        addPayment();
        const rows = document.querySelectorAll("#paymentRows tr");
        const row = rows[rows.length - 1];
        if (!row) return;

        setRowField(row, "payment_id", payment.id ?? payment.payment_id ?? "");
        setRowField(row, "receipt_id", payment.receipt_id);
        setRowField(row, "profile_id", payment.profile_id ?? "");
        setRowField(row, "payer_name", payment.payer_name ?? payment.customer_name ?? "");
        setRowField(row, "method", normalizePaymentMethod(payment.method));
        setRowField(row, "date", payment.payment_date ?? payment.date);
        setRowField(row, "payment_reference", payment.reference_no ?? payment.payment_reference);
        setRowField(row, "amount", payment.amount);
        setRowField(row, "remarks", payment.remarks);

        // Existing file cannot be assigned to a file input by JavaScript.
        // Show the existing attachment beside the input instead.
        if (payment.attachment) {
            const attachment = document.createElement("div");
            attachment.className = "existing-payment-attachment";
            attachment.style.marginTop = "4px";
            attachment.dataset.existingAttachment = String(payment.attachment);

            const link = document.createElement("a");
            link.href = "../" + String(payment.attachment).replace(/^\/+/, "");
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            link.textContent = "View existing attachment";

            const label = document.createElement("span");
            label.textContent = "Existing: ";

            const note = document.createElement("small");
            note.className = "d-block text-muted";
            note.textContent = "Choose a new file only if you want to replace this attachment.";

            attachment.appendChild(label);
            attachment.appendChild(link);
            attachment.appendChild(note);

            row.querySelector('input[type="file"]')?.parentElement?.appendChild(attachment);
        }
    });

    if (typeof attachCostEvents === "function") attachCostEvents();
    if (typeof attachPaymentEvents === "function") attachPaymentEvents();
    if (typeof calculateCosts === "function") calculateCosts();
    if (typeof calculateReceived === "function") calculateReceived();

    console.log("Booking form populated successfully.", {
        passengers: passengers.length,
        flights: flights.length,
        hotels: hotels.length,
        transports: transports.length,
        products: products.length,
        costs: costs.length,
        payments: payments.length
    });
}

function normalizePaymentMethod(method) {
    const value = String(method ?? "").trim();

    /*
     * IMPORTANT:
     * These values match the payment method options used by the
     * booking form/database. The function converts old/legacy
     * values into the current UI value.
     */
    const map = {
        "Natwest Bank": "Natwest Bank",
        "HBL Pakistan": "HBL Pakistan",
        "HBL PAKISTAN": "HBL Pakistan",
        "E Payment": "E Payment",
        "London Office Card Merchant": "London Office Card Merchant",
        "Cash - London Office": "Cash - London Office",
        "CASH - London Office": "Cash - London Office",
        "barclays Bank": "barclays Bank",
        "Barclays Bank": "barclays Bank",
        "Revolut Bank": "Revolut Bank",

        /* Legacy database values */
        "BANK PAY": "Natwest Bank",
        "BANK": "Natwest Bank",
        "BANK TRANSFER": "Natwest Bank",
        "ONLINE TRANSFER": "E Payment",
        "ONLINE": "E Payment",
        "ONLINE PAY": "E Payment",
        "CARD": "London Office Card Merchant",
        "CASH": "Cash - London Office",
        "CHEQUE": "Natwest Bank",
        "CHECK": "Natwest Bank"
    };

    return map[value] ?? "Natwest Bank";
}

function setBookingField(
    name,
    value
) {

    const modal =
        document.getElementById(
            "bookingModal"
        );

    if (!modal) {
        return false;
    }

    const field =
        modal.querySelector(
            `[name="${CSS.escape(name)}"]`
        );

    if (!field) {

        console.warn(
            "EDIT: Booking field not found:",
            name
        );

        return false;
    }

    return setBookingElementValue(
        field,
        value
    );
}


function setBookingElementValue(
    element,
    value
) {

    if (!element) {
        return false;
    }

    /*
     * File fields cannot be assigned.
     */
    if (
        element.type === "file"
    ) {
        return false;
    }

    const safeValue =
        value === null ||
        value === undefined
            ? ""
            : String(value);

    element.value =
        safeValue;

    element.dispatchEvent(
        new Event(
            "input",
            {
                bubbles: true
            }
        )
    );

    element.dispatchEvent(
        new Event(
            "change",
            {
                bubbles: true
            }
        )
    );

    return true;
}


/* =========================================================
   ROW FIELD HELPER
========================================================= */

function setRowField(row, names, value) {

    if (!row) return false;

    if (!Array.isArray(names)) {
        names = [names];
    }

    const fields = row.querySelectorAll("input, select, textarea");

    for (const field of fields) {
        const fieldName = field.getAttribute("name") || "";
        const fieldId = field.getAttribute("id") || "";
        const classes = Array.from(field.classList);

        for (const rawName of names) {
            const name = String(rawName);

            const matchesName =
                fieldName === name ||
                fieldName.endsWith(`[${name}]`) ||
                fieldName.includes(`[${name}]`);

            const matchesId = fieldId === name;
            const matchesClass = classes.includes(name);

            if (matchesName || matchesId || matchesClass) {
                return setBookingElementValue(field, value);
            }
        }
    }

    console.warn("EDIT: Row field not found:", names, "value:", value);
    return false;
}

/* =========================================================
   PRODUCT HELPER
========================================================= */

function setProductValue(
    row,
    value
) {

    if (!row) {
        return false;
    }

    const input =
        row.querySelector(
            'input[name*="[name]"]'
        ) ||
        row.querySelector(
            "input"
        );

    return setBookingElementValue(
        input,
        value
    );
}


/* =========================================================
   LAST ROW
========================================================= */

function getLastRow(selector) {

    const rows =
        document.querySelectorAll(
            selector
        );

    if (!rows.length) {
        return null;
    }

    return rows[
        rows.length - 1
    ];
}


/* =========================================================
   CLEAR EDIT ROWS
========================================================= */

function clearEditBookingRows() {

    const ids = [
        "passengerRows",
        "flightRows",
        "hotelRows",
        "transportRows",
        "productRows",
        "costRows",
        "paymentRows"
    ];

    ids.forEach(
        function (id) {

            const container =
                document.getElementById(
                    id
                );

            if (container) {
                container.innerHTML = "";
            }
        }
    );

    /*
     * Reset counters if those variables exist
     * in booking.js.
     */
    if (
        typeof passengerIndex !==
        "undefined"
    ) {
        passengerIndex = 0;
    }

    if (
        typeof flightIndex !==
        "undefined"
    ) {
        flightIndex = 0;
    }

    if (
        typeof hotelIndex !==
        "undefined"
    ) {
        hotelIndex = 0;
    }

    if (
        typeof transportIndex !==
        "undefined"
    ) {
        transportIndex = 0;
    }

    if (
        typeof productIndex !==
        "undefined"
    ) {
        productIndex = 0;
    }

    // costIndex is declared by booking.js and is required by addCost().
    if (typeof costIndex === "number") {
        costIndex = 0;
    }

    if (
        typeof paymentIndex !==
        "undefined"
    ) {
        paymentIndex = 0;
    }
}


/* =========================================================
   NORMALIZE HELPERS
========================================================= */

function asArray(value) {

    if (Array.isArray(value)) {
        return value;
    }

    /*
     * Some PHP responses may return an object keyed by ID.
     */
    if (
        value &&
        typeof value === "object"
    ) {
        return Object.values(value);
    }

    return [];
}


function firstValue() {

    for (
        let i = 0;
        i < arguments.length;
        i++
    ) {

        const value =
            arguments[i];

        if (
            value !== null &&
            value !== undefined &&
            String(value).trim() !== ""
        ) {
            return value;
        }
    }

    return "";
}


function normalizeDateValue(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {
        return "";
    }

    const stringValue =
        String(value).trim();

    /*
     * Already HTML date format.
     */
    if (
        /^\d{4}-\d{2}-\d{2}$/.test(
            stringValue
        )
    ) {
        return stringValue;
    }

    /*
     * ISO datetime.
     */
    if (
        /^\d{4}-\d{2}-\d{2}T/.test(
            stringValue
        )
    ) {
        return stringValue.substring(
            0,
            10
        );
    }

    /*
     * MySQL datetime.
     */
    if (
        /^\d{4}-\d{2}-\d{2}\s/.test(
            stringValue
        )
    ) {
        return stringValue.substring(
            0,
            10
        );
    }

    /*
     * DD/MM/YYYY
     */
    let match =
        stringValue.match(
            /^(\d{2})\/(\d{2})\/(\d{4})$/
        );

    if (match) {
        return (
            match[3] +
            "-" +
            match[2] +
            "-" +
            match[1]
        );
    }

    /*
     * Unknown date format: return unchanged rather than
     * silently swapping day and month.
     */
    return stringValue;
}


function normalizeTimeValue(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {
        return "";
    }

    let stringValue =
        String(value)
            .trim()
            .toUpperCase();

    /*
     * Strip seconds.
     */
    if (
        /^\d{2}:\d{2}:\d{2}$/.test(
            stringValue
        )
    ) {
        return stringValue.substring(
            0,
            5
        );
    }

    /*
     * Already HH:MM.
     */
    if (
        /^\d{2}:\d{2}$/.test(
            stringValue
        )
    ) {
        return stringValue;
    }

    /*
     * Sabre 0635
     */
    let match =
        stringValue.match(
            /^(\d{1,2})(\d{2})$/
        );

    if (match) {

        return (
            String(match[1])
                .padStart(2, "0") +
            ":" +
            match[2]
        );
    }

    /*
     * 0635A / 0635P
     */
    match =
        stringValue.match(
            /^(\d{1,2})(\d{2})(A|P)$/
        );

    if (match) {

        let hour =
            parseInt(
                match[1],
                10
            );

        const minute =
            match[2];

        if (
            match[3] === "P" &&
            hour < 12
        ) {
            hour += 12;
        }

        if (
            match[3] === "A" &&
            hour === 12
        ) {
            hour = 0;
        }

        return (
            String(hour)
                .padStart(2, "0") +
            ":" +
            minute
        );
    }

    /*
     * 06:35PM
     */
    match =
        stringValue.match(
            /^(\d{1,2}):(\d{2})\s*(AM|PM)$/
        );

    if (match) {

        let hour =
            parseInt(
                match[1],
                10
            );

        const minute =
            match[2];

        if (
            match[3] === "PM" &&
            hour < 12
        ) {
            hour += 12;
        }

        if (
            match[3] === "AM" &&
            hour === 12
        ) {
            hour = 0;
        }

        return (
            String(hour)
                .padStart(2, "0") +
            ":" +
            minute
        );
    }

    return "";
}


/* =========================================================
   EXPORT GLOBAL HELPERS
========================================================= */

window.populateBookingForEdit =
    populateBookingForEdit;

window.setBookingEditMode =
    setBookingEditMode;

window.setRowField =
    setRowField;



/* =========================================================
   RESET BOOKING FORM FOR NEW BOOKING
========================================================= */

function resetBookingFormForCreate() {

    const modal =
        document.getElementById(
            "bookingModal"
        );

    if (!modal) {
        return;
    }

    /*
     * Remove edit state.
     */
    setBookingCreateMode();

    /*
     * Reset all normal form controls.
     */
    modal.querySelectorAll(
        "input, select, textarea"
    ).forEach(
        function (field) {

            if (
                field.type === "file"
            ) {
                field.value = "";
                return;
            }

            if (
                field.type === "hidden" &&
                field.name === "booking_id"
            ) {
                field.value = "";
                return;
            }

            /*
             * Preserve generated/default invoice number.
             */
            if (
                field.name === "invoice_no"
            ) {
                return;
            }

            if (
                field.tagName === "SELECT"
            ) {
                field.selectedIndex = 0;
                return;
            }

            field.value = "";
        }
    );

    /*
     * Clear dynamic rows.
     */
    clearEditBookingRows();

    /*
     * Recreate one initial row in every dynamic section.
     * This matches the original Create Booking modal.
     */
    if (
        typeof addPassenger ===
        "function"
    ) {
        addPassenger();
    }

    if (
        typeof addFlight ===
        "function"
    ) {
        addFlight();
    }

    if (
        typeof addHotel ===
        "function"
    ) {
        addHotel();
    }

    if (
        typeof addTransport ===
        "function"
    ) {
        addTransport();
    }

    if (
        typeof addProduct ===
        "function"
    ) {
        addProduct();
    }

    if (
        typeof addCost ===
        "function"
    ) {
        addCost();
    }

    if (
        typeof addPayment ===
        "function"
    ) {
        addPayment();
    }

    /*
     * Recalculate UI.
     */
    if (
        typeof calculateCosts ===
        "function"
    ) {
        calculateCosts();
    }

    if (
        typeof calculateReceived ===
        "function"
    ) {
        calculateReceived();
    }
}

window.resetBookingFormForCreate =
    resetBookingFormForCreate;
