<?php

require_once "../includes/auth.php";
requireLogin();
require_once "../includes/permissions.php";

$pageTitle = "Staff & Roles";

include "../includes/header.php";
include "../includes/sidebar.php";
require_once "../includes/db.php";
?>
 <link rel="stylesheet" href="../assets/css/pages/staff.css">
<div class="container-fluid py-4">

    <!-- Page Header -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold mb-1">
                👨‍💼 Staff & Roles
            </h2>

            <p class="text-muted mb-0">
                Create and manage Managers, Admins, Team Leads and Agents.
            </p>

        </div>

        <div>
        </div>

    </div>

    <!-- Role Cards -->

    <div class="row g-3 mb-4">

        <div class="col-lg-3">

            <div class="staff-role-card manager-card">

                <div class="d-flex align-items-center">

                    <div class="role-icon">

                        👑

                    </div>

                    <div class="ms-3">

                        <h6 class="mb-1">

                            Manager

                        </h6>

                        <small>

                            Full system access

                        </small>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3">

            <div class="staff-role-card admin-card">

                <div class="d-flex align-items-center">

                    <div class="role-icon">

                        🔑

                    </div>

                    <div class="ms-3">

                        <h6 class="mb-1">

                            Admin

                        </h6>

                        <small>

                            Can manage staff & bookings

                        </small>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3">

            <div class="staff-role-card lead-card">

                <div class="d-flex align-items-center">

                    <div class="role-icon">

                        🏅

                    </div>

                    <div class="ms-3">

                        <h6 class="mb-1">

                            Team Lead

                        </h6>

                        <small>

                            Can manage assigned agents

                        </small>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3">

            <div class="staff-role-card agent-card">

                <div class="d-flex align-items-center">

                    <div class="role-icon">

                        👤

                    </div>

                    <div class="ms-3">

                        <h6 class="mb-1">

                            Agent

                        </h6>

                        <small>

                            Own bookings & leads

                        </small>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <?php if (canManageStaff()): ?>
    <!-- Add Staff Card -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-white">

            <h5 class="mb-0">

                <i class="fa-solid fa-user-plus me-2 text-success"></i>

                Add New Staff Member

            </h5>

        </div>

        <div class="card-body">

            <form id="staffForm" enctype="multipart/form-data">

                <div class="row">

                    <!-- Profile Image -->

                    <div class="col-lg-3 mb-4">

                        <label class="form-label fw-semibold">

                            Profile Image

                        </label>

                        <div class="text-center">

                            <img src="https://ui-avatars.com/api/?name=User&background=16284e&color=ffffff&size=200"
                                id="profilePreview" class="staff-preview">

                            <input type="file" class="form-control mt-3" name="profile_image" id="profileImage"
                                accept="image/*">

                        </div>

                    </div>

                    <div class="col-lg-9">

                        <div class="row">

                            <!-- Full Name -->

                            <div class="col-md-6 mb-3">

                                <label class="form-label">

                                    Full Name
                                    <span class="text-danger">*</span>

                                </label>

                                <input type="text" class="form-control" name="name" id="name" placeholder="Ahmed Khan">

                            </div>

                            <!-- Email -->

                            <div class="col-md-6 mb-3">

                                <label class="form-label">

                                    Email

                                </label>

                                <input type="email" class="form-control" name="email" id="email"
                                    placeholder="abc@email.com">

                            </div>

                            <!-- Phone -->

                            <div class="col-md-6 mb-3">

                                <label class="form-label">

                                    Phone

                                </label>

                                <input type="text" class="form-control" name="phone" id="phone"
                                    placeholder="+44 7700 000000">

                            </div>

                            <!-- Joining Date -->

                            <div class="col-md-6 mb-3">

                                <label class="form-label">

                                    Joining Date

                                </label>

                                <input type="date" class="form-control" name="joining_date" id="joining_date"
                                    value="<?= date('Y-m-d') ?>">

                            </div>

                            <!-- PIN -->

                            <div class="col-md-4 mb-3">

                                <label class="form-label">

                                    Login PIN

                                </label>

                                <input type="password" maxlength="4" class="form-control" name="pin" id="pin"
                                    placeholder="****">

                            </div>

                            <!-- Role -->

                            <div class="col-md-4 mb-3">

                                <label class="form-label">

                                    Role

                                </label>

                                <select class="form-select" name="role" id="role">

                                    <option value="">Select Role</option>

                                    <option value="manager">

                                        Manager

                                    </option>

                                    <option value="admin">

                                        Admin

                                    </option>

                                    <option value="teamlead">

                                        Team Lead

                                    </option>

                                    <option value="agent">

                                        Agent

                                    </option>

                                </select>

                            </div>

                            <!-- Designation -->

                            <div class="col-md-4 mb-3">

                                <label class="form-label">

                                    Designation

                                </label>

                                <input type="text" class="form-control" name="designation" id="designation"
                                    placeholder="CRM Executive">

                            </div>

                            <!-- Commission -->

                            <div class="col-md-4 mb-3">

                                <label class="form-label">

                                    Commission %

                                </label>

                                <input type="number" class="form-control" name="commission_pct" id="commission_pct"
                                    value="0" min="0" max="100">

                            </div>

                            <!-- Team -->

                            <div class="col-md-4 mb-3" id="teamAreaa" style="display:none;">

                                <label class="form-label">

                                    Team

                                </label>

                                <select class="form-select" name="team_id" id="team_id">

                                    <option value="">

                                        Select Team

                                    </option>

                                    <!-- Load From Database -->

                                </select>

                            </div>
                            
                            <div class="col-md-4" id="teamLeadArea" style="display:none;">

                                <label class="form-label">
                                    Assign Team Lead
                                </label>

                                <select
                                    class="form-select"
                                    id="team_lead_id"
                                    name="team_lead_id">

                                    <option value="">
                                        Select Team Lead
                                    </option>

                                    <?php

                                    $teamLeads = Database::select("
                                        SELECT id,name
                                        FROM agents
                                        WHERE role='teamlead'
                                        AND is_active=1
                                        ORDER BY name
                                    ");

                                    foreach($teamLeads as $lead){
                                    ?>

                                    <option value="<?= $lead['id']; ?>">
                                        <?= htmlspecialchars($lead['name']); ?>
                                    </option>

                                    <?php } ?>

                                </select>

                            </div>

                            <!-- Status -->

                            <div class="col-md-4 mb-3">

                                <label class="form-label">

                                    Status

                                </label>

                                <select class="form-select" name="is_active" id="is_active">

                                    <option value="1">

                                        Active

                                    </option>

                                    <option value="0">

                                        Inactive

                                    </option>

                                </select>

                            </div>

                        </div>

                    </div>

                </div>

                <hr class="my-4">

                <!-- PROJECT ASSIGNMENT -->

                <div id="projectArea" style="display:none;">

                    <div class="card mt-4">

                        <div class="card-header">

                            <h5>

                                <i class="fa-solid fa-layer-group me-2"></i>

                                Assign Projects

                            </h5>

                        </div>

                        <div class="card-body">

                            <div class="row" id="projectList">

                            </div>

                        </div>

                    </div>

                </div>

                <hr class="my-4">

                <!-- Hidden ID -->

                <input type="hidden" name="agent_id" id="agent_id">

                <!-- Buttons -->

                <div class="row">

                    <div class="col-lg-12">

                        <button type="submit" class="btn btn-success px-4" id="btnSave">

                            <i class="fa-solid fa-floppy-disk me-2"></i>

                            Save Member

                        </button>

                        <button type="reset" class="btn btn-secondary px-4 ms-2" id="btnReset">

                            <i class="fa-solid fa-rotate me-2"></i>

                            Reset

                        </button>

                        <button type="button" class="btn btn-danger px-4 ms-2" id="btnCancelForm">

                            <i class="fa-solid fa-xmark me-2"></i>

                            Cancel

                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>
    <?php else: ?>
    <div class="alert alert-info border-0 shadow-sm d-flex align-items-start gap-3">
        <i class="fa-solid fa-shield-halved fs-4 mt-1"></i>
        <div><strong>Team access</strong><br><span class="small">You can view the agents assigned to your team. Staff creation and role administration are restricted to Managers and Admins.</span></div>
    </div>
    <?php endif; ?>

    <br>

    <!-- STAFF LIST -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">

            <h5 class="mb-0">

                <i class="fa-solid fa-users me-2"></i>

                Staff Members

            </h5>

            <span class="badge bg-primary" id="totalStaff">

                0 Members

            </span>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="staffTable">

                    <thead class="table-light">

                        <tr>

                            <th width="70">
                                #
                            </th>

                            <th>
                                Staff Member
                            </th>

                            <th>
                                Role
                            </th>

                            <th>
                                Team
                            </th>

                            <th>
                                Projects
                            </th>

                            <th>
                                Contact
                            </th>

                            <th>
                                Commission
                            </th>

                            <th>
                                Status
                            </th>

                            <th width="160">
                                Actions
                            </th>

                        </tr>

                    </thead>

                    <tbody>
                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap5.js"></script>

<script src="../assets/js/pages/staff.js"></script>
<?php include "../includes/footer.php"; ?>