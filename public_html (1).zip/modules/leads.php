<?php
declare(strict_types=1);
require_once "../includes/auth.php";
requireLogin();
require_once "../includes/db.php";
require_once "../includes/permissions.php";

$role=authRole();
$uid=(int)authId();
$pageTitle="Leads CRM";
include "../includes/header.php";
include "../includes/sidebar.php";

$agents=[];
if(in_array($role,['manager','admin'],true)){
    $agents=Database::select("SELECT id,name FROM agents WHERE is_active=1 AND role='agent' ORDER BY name");
}elseif($role==='teamlead'){
    $agents=Database::select(
        "SELECT a.id,a.name FROM agents a
         LEFT JOIN teams t ON t.id=a.team_id
         WHERE a.is_active=1 AND a.role='agent'
         AND (a.team_lead_id=? OR t.team_lead_id=?)
         ORDER BY a.name",[$uid,$uid]
    );
}
?>
<style>
.leads-crm{padding:22px;background:#f8fafc;min-height:100%}
.leads-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap}
.leads-title{font-size:21px;font-weight:900;color:#0c2340;margin:0}
.leads-sub{font-size:11px;color:#64748b;margin:3px 0 0}
.lead-tabs{display:flex;gap:3px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:4px;margin-bottom:14px;width:max-content}
.lead-tab{border:0;background:transparent;color:#64748b;border-radius:6px;padding:7px 14px;font-size:12px;font-weight:700;cursor:pointer}
.lead-tab.active{background:#0c2340;color:#fff}
.lead-card{background:#fff;border:1px solid #e2e8f0;border-radius:10px}
.lead-kpi{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:14px 16px;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.lead-kpi-label{font-size:11px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
.lead-kpi-value{font-size:26px;font-weight:900;line-height:1;color:#1e3a5f}
.lead-filter{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;margin-bottom:10px}
.lead-input{width:100%;padding:7px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;outline:none;background:#fff}
.lead-table-wrap{background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden}
.lead-table{width:100%;border-collapse:collapse;font-size:11px;min-width:1150px}
.lead-table th{padding:10px 8px;background:#1e293b;color:#94a3b8;font-size:10px;font-weight:600;text-align:left;white-space:nowrap}
.lead-table td{padding:8px;border-bottom:1px solid #f8fafc;vertical-align:middle}
.lead-table tr:hover{background:#f8fafc}
.tag{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:700;white-space:nowrap}
.prio-hot{background:#fef2f2;color:#dc2626}.prio-warm{background:#fff7ed;color:#ea580c}.prio-cold{background:#eff6ff;color:#2563eb}
.src-tag{background:#eff6ff;color:#1d4ed8;font-weight:600}
.service-tag{background:#ede9fe;color:#7c3aed;font-weight:600}
.status-select{padding:3px 5px!important;font-size:10px!important;font-weight:700!important;border-radius:6px!important}
.lead-btn{border:0;border-radius:4px;padding:3px 7px;font-size:10px;font-weight:700;cursor:pointer}
.lead-empty{padding:40px;text-align:center;color:#94a3b8}
.lead-drawer{position:fixed;top:0;right:0;width:min(560px,100vw);height:100vh;background:#fff;z-index:1060;box-shadow:-8px 0 30px rgba(15,23,42,.18);transform:translateX(105%);transition:.22s;display:flex;flex-direction:column}
.lead-drawer.open{transform:translateX(0)}
.drawer-overlay{position:fixed;inset:0;background:rgba(15,23,42,.35);z-index:1055;display:none}
.drawer-overlay.open{display:block}
.drawer-head{padding:16px;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center}
.drawer-body{padding:16px;overflow:auto}
.drawer-tabs{display:flex;gap:4px;border-bottom:1px solid #e5e7eb;margin-bottom:14px}
.drawer-tab{border:0;background:none;padding:8px 12px;font-size:11px;font-weight:700;color:#64748b;border-bottom:2px solid transparent}
.drawer-tab.active{color:#0c2340;border-bottom-color:#c9a84c}
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.detail-box{background:#f8fafc;border:1px solid #e5e7eb;border-radius:7px;padding:9px}
.detail-label{font-size:9px;text-transform:uppercase;color:#94a3b8;font-weight:700}
.detail-value{font-size:11px;color:#1e293b;font-weight:600;margin-top:2px;word-break:break-word}
@media(max-width:768px){.leads-crm{padding:12px}.lead-tabs{width:100%;overflow:auto}.lead-tab{white-space:nowrap}.detail-grid{grid-template-columns:1fr}.lead-drawer{width:100%}}
</style>

<div class="main-content">
<div class="leads-crm">
  <div class="leads-head">
    <div>
      <h1 class="leads-title">📬 Leads CRM</h1>
      <p class="leads-sub">Capture, assign, follow up and convert enquiries with complete activity history.</p>
    </div>
    <div class="d-flex gap-2">
      <button class="lead-btn" style="background:#f1f5f9;color:#475569;padding:7px 12px" id="exportLeads">⬇ Export CSV</button>
      <button class="lead-btn" style="background:#059669;color:#fff;padding:7px 12px" id="newLead">＋ New Lead</button>
    </div>
  </div>

  <div class="lead-tabs">
    <button class="lead-tab active" data-view="dashboard">📊 Dashboard</button>
    <button class="lead-tab" data-view="leads">📋 All Leads</button>
    <button class="lead-tab" data-view="followups">🔔 Follow-ups</button>
    <?php if(in_array($role,['manager','admin'],true)): ?><button class="lead-tab" data-view="reports">📈 Reports</button><?php endif; ?>
  </div>

  <section id="leadDashboard" class="lead-view">
    <div class="row g-3 mb-3" id="leadStats"></div>
    <div class="row g-3">
      <div class="col-xl-7"><div class="lead-card p-3 h-100">
        <div style="font-weight:700;color:#0c2340;margin-bottom:12px">📡 Leads by Source</div>
        <div id="sourceBars"></div>
      </div></div>
      <div class="col-xl-5"><div class="lead-card p-3 h-100">
        <div style="font-weight:700;color:#0c2340;margin-bottom:12px">📊 Lead Status Breakdown</div>
        <div id="leadMiniStats"></div>
      </div></div>
    </div>
    <?php if(in_array($role,['manager','admin'],true)): ?>
    <div class="lead-card p-3 mt-3">
      <div style="font-weight:700;color:#0c2340;margin-bottom:12px">👥 Agent Performance</div>
      <div class="table-responsive"><table class="table table-sm mb-0" id="agentPerfTable"><thead><tr><th>Agent</th><th>Leads</th><th>Booked</th><th>Hot</th><th>Rate</th></tr></thead><tbody></tbody></table></div>
    </div>
    <?php endif; ?>
  </section>

  <section id="leadList" class="lead-view d-none">
    <div class="lead-filter">
      <div class="d-flex gap-2 flex-wrap align-items-center">
        <input id="leadSearch" class="lead-input" style="width:220px" placeholder="🔍 Search name, phone, lead ID...">
        <select id="leadStatus" class="lead-input" style="width:160px"><option value="">All Statuses</option><?php foreach(["New Lead","Attempted Contact","No Answer","Wrong Number","Invalid Lead","Interested","Wants Cheapest Package","Wants Family Package","Follow-up Later","Call Tomorrow","Not Ready Yet","Booked","Lost Lead","Duplicate"] as $v)echo '<option>'.htmlspecialchars($v).'</option>';?></select>
        <select id="leadSource" class="lead-input" style="width:150px"><option value="">All Sources</option><?php foreach(["Facebook Ads","Instagram Ads","Website Form","Google Ads","WhatsApp","Direct Call","Referral","Walk-in","Existing Customer"] as $v)echo '<option>'.htmlspecialchars($v).'</option>';?></select>
        <select id="leadPriority" class="lead-input" style="width:110px"><option value="">All Priority</option><option>Hot</option><option>Warm</option><option>Cold</option></select>
        <?php if(in_array($role,['manager','admin'],true)): ?>
        <select id="leadAgent" class="lead-input" style="width:140px"><option value="">All Agents</option><?php foreach($agents as $a): ?><option value="<?=$a['id']?>"><?=htmlspecialchars($a['name'])?></option><?php endforeach; ?></select>
        <?php endif; ?>
        <button id="clearFilters" class="lead-btn" style="background:#fee2e2;color:#dc2626;padding:7px 12px">✕ Clear</button>
        <span id="leadCount" style="margin-left:auto;font-size:11px;color:#64748b;font-weight:600">0 leads</span>
      </div>
      <div id="bulkBar" class="d-none align-items-center gap-2 mt-2 p-2" style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px">
        <span id="selectedCount" style="font-size:11px;color:#1d4ed8;font-weight:700">0 selected</span>
        <select id="bulkAgent" class="lead-input" style="width:160px"><option value="">— Assign to Agent —</option><?php foreach($agents as $a): ?><option value="<?=$a['id']?>"><?=htmlspecialchars($a['name'])?></option><?php endforeach; ?></select>
        <button id="bulkAssign" class="lead-btn" style="background:#0c2340;color:#fff">Assign</button>
        <button id="cancelSelect" class="lead-btn" style="background:#f1f5f9;color:#64748b">Cancel</button>
      </div>
    </div>
    <div id="priorityChips" class="d-flex gap-2 flex-wrap mb-2"></div>
    <div class="lead-table-wrap"><div style="overflow-x:auto">
      <table class="lead-table" id="leadsTable"><thead><tr>
        <?php if(in_array($role,['manager','admin'],true)): ?><th style="width:30px"><input type="checkbox" id="selectAll"></th><?php endif; ?>
        <th>Lead ID</th><th>Name & Contact</th><th>WhatsApp</th><th>Service</th><th>Source</th><th>Pax</th><th>Budget</th><th>Travel</th><th>Agent</th><th>Priority</th><th>Status</th><th>Follow-up</th><th>Actions</th>
      </tr></thead><tbody></tbody></table>
    </div></div>
  </section>

  <section id="leadFollowups" class="lead-view d-none"><div class="lead-card">
    <div class="p-3" style="font-weight:700;color:#0c2340;border-bottom:1px solid #e5e7eb">🔔 Follow-ups</div>
    <div class="p-3" id="followupList"></div>
  </div></section>

  <section id="leadReports" class="lead-view d-none"><div class="row g-3">
    <div class="col-xl-6"><div class="lead-card p-3"><div style="font-weight:700;color:#0c2340;margin-bottom:12px">📡 Leads by Source</div><div class="table-responsive"><table class="table table-sm" id="sourceReport"><thead><tr><th>Source</th><th>Leads</th><th>Booked</th><th>Rate</th></tr></thead><tbody></tbody></table></div></div></div>
    <div class="col-xl-6"><div class="lead-card p-3"><div style="font-weight:700;color:#0c2340;margin-bottom:12px">👥 Agent Conversion</div><div class="table-responsive"><table class="table table-sm" id="agentReport"><thead><tr><th>Agent</th><th>Leads</th><th>Booked</th><th>Hot</th><th>Rate</th></tr></thead><tbody></tbody></table></div></div></div>
  </div></section>
</div>
</div>

<!-- Reference-style lead drawer -->
<div id="drawerOverlay" class="drawer-overlay"></div>
<aside id="leadDrawer" class="lead-drawer">
  <div class="drawer-head"><div><div id="drawerName" style="font-weight:900;color:#0c2340;font-size:16px">Lead</div><div id="drawerMeta" style="font-size:10px;color:#64748b"></div></div><button id="drawerClose" class="lead-btn" style="background:#f1f5f9;color:#64748b;font-size:16px">×</button></div>
  <div class="drawer-body">
    <div class="drawer-tabs"><button class="drawer-tab active" data-dtab="profile">Profile</button><button class="drawer-tab" data-dtab="timeline">Timeline</button><button class="drawer-tab" data-dtab="notes">Notes</button><button class="drawer-tab" data-dtab="followup">Follow-up</button></div>
    <div id="drawerProfile"></div><div id="drawerTimeline" class="d-none"></div><div id="drawerNotes" class="d-none"></div><div id="drawerFollowup" class="d-none"></div>
  </div>
</aside>

<!-- Lead editor -->
<div class="modal fade" id="leadModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content overflow-scroll"><form id="leadForm">
<div class="modal-header"><h5 class="modal-title">Lead</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<div class="alert alert-light border d-flex flex-wrap align-items-center justify-content-between gap-2"><div><strong>⚡ Smart Lead Parser</strong><div class="small text-muted">Paste WhatsApp/Facebook/phone enquiry text and auto-fill the form.</div></div><button type="button" class="btn btn-sm btn-outline-primary" id="parseLeadBtn">Parse Text</button></div>
<textarea id="leadParserText" class="form-control mb-3 d-none" rows="5" placeholder="Name: Ahmed Khan&#10;Phone: +44...&#10;Adults: 2&#10;Budget: £4000"></textarea>
<input type="hidden" name="id" id="lead_id"><div class="row g-3">
<?php foreach([['name','Full Name','text'],['phone','Phone Number','text'],['whatsapp','WhatsApp','text'],['email','Email','email'],['campaign','Campaign Name','text'],['travel_month','Travel Month','text'],['budget','Budget (£)','number'],['follow_up_date','Follow-up Date','date']] as [$n,$l,$t]): ?><div class="col-md-3"><label class="form-label"><?=$l?></label><input class="form-control" type="<?=$t?>" name="<?=$n?>" id="lead_<?=$n?>"></div><?php endforeach; ?>
<div class="col-md-3"><label class="form-label">Service Type</label><select class="form-select" name="service_type" id="lead_service"><?php foreach(["Umrah","Hajj","Holiday Package","Flights Only","Hotel Only","Visa Only"] as $v)echo '<option>'.$v.'</option>';?></select></div>
<div class="col-md-3"><label class="form-label">Lead Source</label><select class="form-select" name="source" id="lead_source_edit"><?php foreach(["Facebook Ads","Instagram Ads","Website Form","Google Ads","WhatsApp","Direct Call","Referral","Walk-in","Existing Customer"] as $v)echo '<option>'.$v.'</option>';?></select></div>
<div class="col-md-3"><label class="form-label">Priority</label><select class="form-select" name="priority" id="lead_priority_edit"><option>Hot</option><option selected>Warm</option><option>Cold</option></select></div>
<div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status" id="lead_status_edit"><?php foreach(["New Lead","Attempted Contact","No Answer","Wrong Number","Invalid Lead","Interested","Wants Cheapest Package","Wants Family Package","Follow-up Later","Call Tomorrow","Not Ready Yet","Booked","Lost Lead","Duplicate"] as $v)echo '<option>'.$v.'</option>';?></select></div>
<div class="col-md-3"><label class="form-label">Adults</label><input class="form-control" name="adults" id="lead_adults" type="number" min="0" value="1"></div><div class="col-md-3"><label class="form-label">Youth</label><input class="form-control" name="youth" id="lead_youth" type="number" min="0" value="0"></div><div class="col-md-3"><label class="form-label">Children</label><input class="form-control" name="children" id="lead_children" type="number" min="0" value="0"></div><div class="col-md-3"><label class="form-label">Infants</label><input class="form-control" name="infants" id="lead_infants" type="number" min="0" value="0"></div>
<div class="col-md-4"><label class="form-label">Assign to Agent</label><select class="form-select" name="assigned_to" id="lead_assigned" <?= $role==='agent'?'disabled':'' ?>><option value="">Unassigned</option><?php foreach($agents as $a): ?><option value="<?=$a['id']?>"><?=htmlspecialchars($a['name'])?></option><?php endforeach; ?></select></div>
<div class="col-md-8"><label class="form-label">Enquiry Details</label><textarea class="form-control" name="message" id="lead_message" rows="2"></textarea></div>
<div class="col-md-6"><label class="form-label">Agent Notes</label><textarea class="form-control" name="notes" id="lead_notes" rows="2"></textarea></div><div class="col-md-3"><label class="form-label">Enquiry Date</label><input class="form-control" name="enquiry_date" id="lead_enquiry_date" type="date" value="<?=date('Y-m-d')?>"></div>
</div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" type="submit">Save Lead</button></div>
</form></div></div></div>

<script>
const leadApi='../actions/leads/api.php', currentRole=<?=json_encode($role)?>;
const isAdminOrManager=['admin','manager'].includes(currentRole);
let leadRows=[],selected=[],activeDrawerId=0,drawerTab='profile';
const statuses=["New Lead","Attempted Contact","No Answer","Wrong Number","Invalid Lead","Interested","Wants Cheapest Package","Wants Family Package","Follow-up Later","Call Tomorrow","Not Ready Yet","Booked","Lost Lead","Duplicate"];
const sources=["Facebook Ads","Instagram Ads","Website Form","Google Ads","WhatsApp","Direct Call","Referral","Walk-in","Existing Customer"];
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
async function req(d){
 const r=await fetch(leadApi,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(d)});
 let j; try{j=await r.json()}catch(e){throw Error('Lead API returned an invalid response. Check PHP/server errors.')}
 if(!j.success)throw Error(j.message||'Request failed'); return j;
}
function statusStyle(s){const m={"New Lead":"#dbeafe,#1d4ed8","Attempted Contact":"#fef3c7,#b45309","No Answer":"#f1f5f9,#475569","Wrong Number":"#fee2e2,#dc2626","Invalid Lead":"#fce7f3,#9d174d","Interested":"#d1fae5,#065f46","Wants Cheapest Package":"#ecfdf5,#047857","Wants Family Package":"#ede9fe,#6d28d9","Follow-up Later":"#fff7ed,#c2410c","Call Tomorrow":"#fef9c3,#854d0e","Not Ready Yet":"#f8fafc,#64748b","Booked":"#052e16,#86efac","Lost Lead":"#fef2f2,#b91c1c","Duplicate":"#f0f0f0,#6b7280"}[s]||"#f1f5f9,#64748b";let [bg,c]=m.split(',');return `background:${bg};color:${c}`;}
function prioTag(p){return `<span class="tag prio-${String(p||'Warm').toLowerCase()}">${p==='Hot'?'🔴':p==='Cold'?'🔵':'🟡'} ${esc(p||'Warm')}</span>`}
function loadFilters(){return {action:'list',search:$('#leadSearch').val()||'',status:$('#leadStatus').val()||'',priority:$('#leadPriority').val()||'',source:$('#leadSource').val()||'',agent:$('#leadAgent').val()||''}}
async function loadLeads(){
 try{
   let j=await req(loadFilters());
   leadRows=Array.isArray(j.data?.leads)?j.data.leads:[];
   selected=[];
   renderAll();
 }catch(e){
   console.error('Lead load error:',e);
   leadRows=[];
   selected=[];
   renderAll();
   const colspan=isAdminOrManager?14:13;
   $('#leadsTable tbody').html(`<tr><td colspan="${colspan}" class="lead-empty"><strong style="color:#dc2626">Unable to load leads</strong><br><small>${esc(e.message)}</small><br><button type="button" class="lead-btn mt-2" style="background:#0c2340;color:#fff" onclick="loadLeads()">Retry</button></td></tr>`);
   if(window.toastr) toastr.error(e.message);
 }
}
function renderAll(){
 const today=new Date().toISOString().slice(0,10), total=leadRows.length, hot=leadRows.filter(x=>x.priority==='Hot').length, booked=leadRows.filter(x=>x.status==='Booked').length, due=leadRows.filter(x=>x.follow_up_date&&x.follow_up_date<=today&&!['Booked','Lost Lead','Duplicate'].includes(x.status)).length, assigned=leadRows.filter(x=>x.assigned_to).length, invalid=leadRows.filter(x=>['Invalid Lead','Wrong Number','Duplicate','Lost Lead'].includes(x.status)).length;
 const cards=[['Total Leads',total,'#1e3a5f'],['New Today',leadRows.filter(x=>x.enquiry_date===today).length,'#059669'],['Hot Leads',hot,'#dc2626'],['Follow-up Due',due,due?'#d97706':'#059669'],['Assigned',assigned,'#2563eb'],['Booked',booked,'#059669'],['Invalid / Lost',invalid,'#64748b'],['Conversion',total?Math.round(booked/total*100)+'%':'0%','#059669']];
 $('#leadStats').html(cards.map(c=>`<div class="col-6 col-xl-3"><div class="lead-kpi"><div class="lead-kpi-label">${c[0]}</div><div class="lead-kpi-value" style="color:${c[2]}">${c[1]}</div></div></div>`).join(''));
 let src={};sources.forEach(s=>src[s]=leadRows.filter(x=>x.source===s).length);let srcRows=Object.entries(src).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]),max=Math.max(...srcRows.map(x=>x[1]),1);
 $('#sourceBars').html(srcRows.map(x=>`<div class="mb-2"><div class="d-flex justify-content-between" style="font-size:10px"><span style="font-weight:600;color:#475569">${esc(x[0])}</span><strong>${x[1]}</strong></div><div style="height:6px;background:#f1f5f9;border-radius:5px;overflow:hidden"><div style="height:100%;width:${x[1]/max*100}%;background:#c9a84c"></div></div></div>`).join('')||'<span style="font-size:11px;color:#94a3b8">No lead data</span>');
 let st={};leadRows.forEach(x=>st[x.status]=(st[x.status]||0)+1);$('#leadMiniStats').html(Object.entries(st).sort((a,b)=>b[1]-a[1]).map(x=>`<div class="d-flex justify-content-between py-2" style="border-bottom:1px solid #f1f5f9;font-size:11px"><span>${esc(x[0])}</span><strong>${x[1]}</strong></div>`).join('')||'<span style="font-size:11px;color:#94a3b8">No lead data</span>');
 let pc=['Hot','Warm','Cold'].map(p=>{let c=leadRows.filter(x=>x.priority===p).length;return c?`<span class="tag prio-${p.toLowerCase()}" data-prio="${p}" style="cursor:pointer">${p==='Hot'?'🔴':p==='Cold'?'🔵':'🟡'} ${p}: ${c}</span>`:''}).join(''); $('#priorityChips').html(pc);
 const agentData=<?=json_encode(array_map(fn($a)=>['id'=>(int)$a['id'],'name'=>$a['name']],$agents))?>;
 const perf=agentData.map(a=>{let rows=leadRows.filter(x=>String(x.assigned_to)===String(a.id)),bk=rows.filter(x=>x.status==='Booked').length,hotc=rows.filter(x=>x.priority==='Hot').length;return {...a,total:rows.length,booked:bk,hot:hotc,rate:rows.length?Math.round(bk/rows.length*100):0}});
 $('#agentPerfTable tbody,#agentReport tbody').html(perf.filter(x=>x.total>0).map(a=>`<tr><td>${esc(a.name)}</td><td>${a.total}</td><td style="color:#059669;font-weight:700">${a.booked}</td><td style="color:#dc2626;font-weight:700">${a.hot}</td><td>${a.rate}%</td></tr>`).join('')||'<tr><td colspan="5" class="text-muted">No assigned leads</td></tr>');
 const rows=leadRows.map(x=>{
   const pax=(+x.adults||0)+(+x.children||0)+(+x.youth||0)+(+x.infants||0), overdue=x.follow_up_date&&x.follow_up_date<today, agent=esc(x.assigned_name||'—');
   const check=isAdminOrManager?`<td><input type="checkbox" class="leadCheck" value="${x.id}" ${selected.includes(String(x.id))?'checked':''}></td>`:'';
   const agentCell=isAdminOrManager?`<select class="lead-input quickAssign" data-id="${x.id}" style="padding:3px 5px;font-size:10px;width:110px"><option value="">Unassigned</option>${agentData.map(a=>`<option value="${a.id}" ${String(x.assigned_to)===String(a.id)?'selected':''}>${esc(a.name)}</option>`).join('')}</select>`:agent;
   return `<tr>${check}<td><div style="font-family:monospace;font-size:10px;color:#64748b">${esc(x.lead_id)}</div><div style="font-size:9px;color:#94a3b8">${esc(x.enquiry_date||'')}</div></td><td><div style="font-weight:700;color:#1e293b">${esc(x.name||'—')}</div><div style="color:#64748b">${esc(x.phone||'')}</div><div style="font-size:10px;color:#94a3b8;max-width:130px;overflow:hidden;text-overflow:ellipsis">${esc(x.email||'')}</div></td><td>${x.whatsapp?'<span style="color:#059669;font-weight:700">✓</span>':'<span style="color:#e2e8f0">—</span>'}</td><td><span class="tag service-tag">${esc(x.service_type||'—')}</span></td><td><span class="tag src-tag">${esc(x.source||'—')}</span></td><td style="text-align:center;font-weight:700">${pax}<div style="font-size:9px;color:#94a3b8">${x.adults||0}A ${x.children?x.children+'C':''}</div></td><td style="color:#059669;font-weight:700">${x.budget?'£'+esc(x.budget):'—'}</td><td style="font-size:10px;color:#475569;white-space:nowrap">${esc(x.travel_month||'—')}</td><td>${agentCell}</td><td>${prioTag(x.priority)}</td><td><select class="lead-input status-select quickStatus" data-id="${x.id}" style="${statusStyle(x.status)};min-width:150px">${statuses.map(s=>`<option ${s===x.status?'selected':''}>${esc(s)}</option>`).join('')}</select></td><td style="font-size:10px;white-space:nowrap;color:${overdue?'#dc2626':'#64748b'};font-weight:${overdue?'700':'400'}">${x.follow_up_date?(overdue?'⚠ ':'')+esc(x.follow_up_date):'—'}</td><td class="text-nowrap"><button class="lead-btn viewLead" data-id="${x.id}" style="background:#dbeafe;color:#1d4ed8">👁</button> <button class="lead-btn editLead" data-id="${x.id}" style="background:#f0fdf4;color:#059669">✏</button> ${isAdminOrManager?`<button class="lead-btn delLead" data-id="${x.id}" style="background:#fee2e2;color:#dc2626">🗑</button>`:''}</td></tr>`;
 });
 $('#leadsTable tbody').html(rows.join('')||`<tr><td colspan="${isAdminOrManager?14:13}" class="lead-empty">No leads found</td></tr>`);
 $('#leadCount').text(`${leadRows.length} lead${leadRows.length===1?'':'s'}`);$('#selectedCount').text(`${selected.length} selected`);$('#bulkBar').toggleClass('d-none',!selected.length).toggleClass('d-flex',!!selected.length);
 renderFollowups();renderReports(perf);
}
function renderFollowups(){const today=new Date().toISOString().slice(0,10),rows=leadRows.filter(x=>x.follow_up_date&&x.follow_up_date<=today&&!['Booked','Lost Lead','Duplicate'].includes(x.status));$('#followupList').html(rows.map(x=>`<div class="d-flex justify-content-between py-3" style="border-bottom:1px solid #f1f5f9"><div><strong>${esc(x.name||'—')}</strong><div style="font-size:10px;color:#64748b">${esc(x.lead_id)} · ${esc(x.phone||'')}</div></div><div style="color:#dc2626;font-size:10px;font-weight:700">${esc(x.follow_up_date)}</div></div>`).join('')||'<div style="color:#94a3b8;font-size:11px">No follow-ups due today 🎉</div>')}
function renderReports(perf){let rows=sources.map(s=>{let a=leadRows.filter(x=>x.source===s),b=a.filter(x=>x.status==='Booked').length;return a.length?`<tr><td><span class="tag src-tag">${s}</span></td><td>${a.length}</td><td style="color:#059669;font-weight:700">${b}</td><td>${Math.round(b/a.length*100)}%</td></tr>`:''}).join('');$('#sourceReport tbody').html(rows||'<tr><td colspan="4">No data</td></tr>');}
function openDrawer(id){activeDrawerId=id;activeDrawerId=Number(id);loadDrawer(id)}
async function loadDrawer(id){try{let j=await req({action:'get',id});let l=j.data.lead;activeDrawerId=Number(l.id);$('#drawerName').text(l.name||l.lead_id);$('#drawerMeta').text(`${l.lead_id} · ${l.phone||''}`);renderDrawer(l,j.data.activity||[]);$('#leadDrawer,#drawerOverlay').addClass('open')}catch(e){toastr.error(e.message)}}
function renderDrawer(l,activity){
 const agent=l.assigned_name||'Unassigned';
 $('#drawerProfile').html(`<div class="detail-grid">${[['Lead ID',l.lead_id],['Full Name',l.name],['Phone',l.phone],['WhatsApp',l.whatsapp],['Email',l.email],['Service',l.service_type],['Source',l.source],['Campaign',l.campaign],['Travel Month',l.travel_month],['Adults',l.adults],['Children',l.children],['Youth',l.youth],['Infants',l.infants],['Budget',l.budget?'£'+l.budget:'—'],['Priority',l.priority],['Status',l.status],['Created',l.created_at],['Follow-up',l.follow_up_date||'—'],['Assigned',agent]].map(x=>`<div class="detail-box"><div class="detail-label">${x[0]}</div><div class="detail-value">${esc(x[1]??'—')}</div></div>`).join('')}</div><div class="d-flex gap-2 mt-3"><a class="lead-btn" style="background:#dbeafe;color:#1d4ed8;text-decoration:none" href="tel:${esc(l.phone||'')}">📞 Call</a><a class="lead-btn" style="background:#dcfce7;color:#059669;text-decoration:none" target="_blank" href="https://wa.me/${String(l.whatsapp||l.phone||'').replace(/\\D/g,'')}">💬 WhatsApp</a>${l.email?`<a class="lead-btn" style="background:#f1f5f9;color:#475569;text-decoration:none" href="mailto:${esc(l.email)}">✉ Email</a>`:''}<button class="lead-btn editFromDrawer" style="background:#fef3c7;color:#92400e">✏ Edit</button></div>`);
 $('#drawerTimeline').html(activity.map(a=>`<div style="display:flex;gap:10px;padding:10px 0;border-bottom:1px solid #f1f5f9"><div style="font-size:15px">${({call:'📞',note:'📝',status:'🔄',assign:'👤',visit:'🚶',booked:'✅',email:'✉',whatsapp:'💬'}[a.log_type]||'📝')}</div><div><div style="font-size:11px;font-weight:700">${esc(a.log_text)}</div><div style="font-size:9px;color:#94a3b8">${esc(a.created_at)} · ${esc(a.logged_by_name)}</div></div></div>`).join('')||'<div style="font-size:11px;color:#94a3b8">No activity yet.</div>');
 $('#drawerNotes').html(`<textarea id="drawerNote" class="lead-input" style="height:90px" placeholder="Add a note..."></textarea><button class="lead-btn mt-2" id="saveDrawerNote" style="background:#0c2340;color:#fff">Save Note</button>`);
 $('#drawerFollowup').html(`<div class="detail-box"><div class="detail-label">Follow-up Date</div><input id="drawerFollowupDate" class="lead-input mt-1" type="date" value="${esc(l.follow_up_date||'')}"><button class="lead-btn mt-2" id="saveDrawerFollowup" style="background:#059669;color:#fff">Save Follow-up</button></div><div class="d-flex gap-2 mt-3 flex-wrap">${statuses.slice(0,12).map(s=>`<button class="lead-btn drawerStatus" data-status="${esc(s)}" style="${statusStyle(s)}">${esc(s)}</button>`).join('')}</div>`);
}
function showDrawerTab(t){drawerTab=t;$('.drawer-tab').removeClass('active');$(`.drawer-tab[data-dtab="${t}"]`).addClass('active');['profile','timeline','notes','followup'].forEach(x=>$('#drawer'+x.charAt(0).toUpperCase()+x.slice(1)).toggleClass('d-none',x!==t))}
function openLead(x){const f=$('#leadForm')[0];f.reset();$('#lead_id').val(x?.id||'');if(x){Object.entries(x).forEach(([k,v])=>{let id=k==='service_type'?'#lead_service':k==='source'?'#lead_source_edit':k==='priority'?'#lead_priority_edit':k==='status'?'#lead_status_edit':`#lead_${k}`;let el=$(id);if(el.length)el.val(v??'')});}$('#lead_assigned').val(x?.assigned_to??'');new bootstrap.Modal('#leadModal').show()}
function smartParse(raw){let clean=s=>s.replace(/[*_~`]/g,'').trim(),get=p=>{for(let x of p){let m=raw.match(x);if(m)return clean(m[1]||m[0])}return''},num=(p,d=0)=>parseInt(get(p)||d,10);let phone=get([/(?:phone|mobile|tel|call|mob)[:\s]+([+\d][\d\s()\-+]{7,20})/i,/(\+44[\d\s]{9,14})/]);let email=get([/([\w.+-]+@[\w.-]+\.[A-Za-z]{2,})/]);let name=get([/(?:name|customer|full.?name)[:\s]+([A-Za-z][A-Za-z\s'.-]{2,50})/i]);let service=/hajj/i.test(raw)?'Hajj':/holiday|tour|dubai|turkey/i.test(raw)?'Holiday Package':/flight\s*only/i.test(raw)?'Flights Only':'Umrah';let budget=get([/(?:budget|price|cost|max|afford)[:\s£$]*([0-9,]+)/i,/£([0-9,]+)/]).replace(/,/g,'');let adults=num([/(?:adults?)[:\s=]+(\d+)/i,/(\d+)\s*x?\s*adults?/i],1),youth=num([/(?:youth|teenagers?)[:\s=]+(\d+)/i,/(\d+)\s*x?\s*youth/i]),children=num([/(?:child(?:ren)?|kids?)[:\s=]+(\d+)/i,/(\d+)\s*x?\s*child/i]),infants=num([/(?:infants?|babies|baby)[:\s=]+(\d+)/i,/(\d+)\s*x?\s*infants?/i]);let travelMonth=get([/(?:travel(?:ling)?|departure|going|month)[:\s]+([A-Za-z]+[\s,]*\d{0,4})/i]),campaign=get([/(?:campaign|ad.?set|ad.?name)[:\s]+([^\n,]{3,60})/i]);let source=/facebook|meta|fb/i.test(raw)?'Facebook Ads':/instagram|ig/i.test(raw)?'Instagram Ads':/whatsapp|wa/i.test(raw)?'WhatsApp':/google/i.test(raw)?'Google Ads':/referr/i.test(raw)?'Referral':/walk.?in|office visit/i.test(raw)?'Walk-in':'Website Form';return {name,phone,whatsapp:phone,email,service_type:service,budget,adults,youth,children,infants,travel_month:travelMonth,campaign,priority:/urgent|asap|hot|very\s+interested|ready\s+to\s+book/i.test(raw)?'Hot':/cold|not\s+sure|maybe/i.test(raw)?'Cold':'Warm',status:'New Lead',source}}
$('#newLead').click(()=>openLead());$('#exportLeads').click(()=>{let hdr='Lead ID,Name,Phone,WhatsApp,Email,Service,Source,Campaign,Travel Month,Adults,Youth,Children,Infants,Budget,Priority,Status,Assigned,Follow-up,Enquiry Date\n',rows=leadRows.map(x=>[x.lead_id,x.name,x.phone,x.whatsapp,x.email,x.service_type,x.source,x.campaign,x.travel_month,x.adults,x.youth,x.children,x.infants,x.budget,x.priority,x.status,x.assigned_name||'Unassigned',x.follow_up_date,x.enquiry_date].map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([hdr+rows],{type:'text/csv'}));a.download='leads.csv';a.click()});
$('#clearFilters').click(()=>{$('#leadSearch,#leadStatus,#leadPriority,#leadSource,#leadAgent').val('');loadLeads()});
$('#priorityChips').on('click','.tag',function(){$('#leadPriority').val($(this).data('prio'));loadLeads()});
$('#leadForm').submit(async e=>{e.preventDefault();let btn=e.target.querySelector('button[type=submit]');if(btn)btn.disabled=true;try{let d=Object.fromEntries(new FormData(e.target));d.action='save';let r=await req(d);bootstrap.Modal.getInstance($('#leadModal')[0]).hide();toastr.success(r.message||'Lead saved successfully');await loadLeads();$('#leadTabs button[data-view=leads]').click()}catch(x){toastr.error(x.message)}finally{if(btn)btn.disabled=false}});
$('#leadsTable').on('click','.viewLead',function(){openDrawer($(this).data('id'))});
$('#leadsTable').on('click','.editLead',function(){let x=leadRows.find(r=>String(r.id)===String($(this).data('id')));if(x)openLead(x)});
$('#leadsTable').on('click','.delLead',async function(){let id=$(this).data('id');if(!confirm('Delete lead?'))return;try{await req({action:'delete',id});await loadLeads();toastr.success('Lead deleted')}catch(e){toastr.error(e.message)}});
$('#leadsTable').on('change','.quickStatus',async function(){try{await req({action:'quick_update',id:$(this).data('id'),status:this.value});toastr.success('Status updated');loadLeads()}catch(e){toastr.error(e.message)}});
$('#leadsTable').on('change','.quickAssign',async function(){try{await req({action:'quick_update',id:$(this).data('id'),assigned_to:this.value});toastr.success('Lead assigned');loadLeads()}catch(e){toastr.error(e.message)}});
$('#leadsTable').on('change','.leadCheck',function(){let id=String($(this).val());selected=this.checked?[...new Set([...selected,id])]:selected.filter(x=>x!==id);renderAll()});
$('#selectAll').on('change',function(){selected=this.checked?leadRows.map(x=>String(x.id)):[];renderAll()});
$('#bulkAssign').click(async()=>{let a=$('#bulkAgent').val();if(!a||!selected.length)return;try{await req({action:'bulk_assign',ids:JSON.stringify(selected),assigned_to:a});selected=[];$('#bulkAgent').val('');await loadLeads();toastr.success('Leads assigned')}catch(e){toastr.error(e.message)}});
$('#cancelSelect').click(()=>{selected=[];renderAll()});
$('#drawerClose,#drawerOverlay').click(()=>$('#leadDrawer,#drawerOverlay').removeClass('open'));
$('.drawer-tab').click(function(){showDrawerTab($(this).data('dtab'))});
$('#leadDrawer').on('click','.editFromDrawer',function(){let x=leadRows.find(r=>Number(r.id)===activeDrawerId);if(x){$('#leadDrawer,#drawerOverlay').removeClass('open');openLead(x)}});
$('#leadDrawer').on('click','#saveDrawerNote',async function(){let t=$('#drawerNote').val().trim();if(!t)return;try{await req({action:'log',lead_id:activeDrawerId,log_text:t,log_type:'note'});await loadDrawer(activeDrawerId);showDrawerTab('notes');await loadLeads();toastr.success('Note saved')}catch(e){toastr.error(e.message)}});
$('#leadDrawer').on('click','#saveDrawerFollowup',async function(){try{await req({action:'quick_update',id:activeDrawerId,follow_up_date:$('#drawerFollowupDate').val()});await loadDrawer(activeDrawerId);showDrawerTab('followup');await loadLeads();toastr.success('Follow-up updated')}catch(e){toastr.error(e.message)}});
$('#leadDrawer').on('click','.drawerStatus',async function(){try{await req({action:'quick_update',id:activeDrawerId,status:$(this).data('status')});await loadDrawer(activeDrawerId);showDrawerTab('followup');await loadLeads();toastr.success('Status updated')}catch(e){toastr.error(e.message)}});
$('#parseLeadBtn').click(function(){let b=$('#leadParserText');if(b.hasClass('d-none')){b.removeClass('d-none').focus();return}let raw=b.val().trim();if(!raw){toastr.warning('Paste lead text first.');return}let x=smartParse(raw);Object.entries(x).forEach(([k,v])=>{let id=k==='service_type'?'#lead_service':k==='source'?'#lead_source_edit':k==='priority'?'#lead_priority_edit':k==='status'?'#lead_status_edit':`#lead_${k}`;let el=$(id);if(el.length)el.val(v)});toastr.success('Parser fields applied. Review and save.')});
$(document).on('click','.lead-tab',function(e){
 e.preventDefault();
 const $tab=$(this);
 const v=String($tab.data('view')||'').trim();
 const targetMap={dashboard:'#leadDashboard',leads:'#leadList',followups:'#leadFollowups',reports:'#leadReports'};
 const target=targetMap[v];
 if(!target || !$(target).length) return;
 $('.lead-tab').removeClass('active');
 $tab.addClass('active');
 $('.lead-view').addClass('d-none');
 $(target).removeClass('d-none');
 if(v==='followups') renderFollowups();
 if(v==='leads') {
   // Always show the latest DB-loaded rows when opening All Leads.
   $('#leadCount').text(`${leadRows.length} lead${leadRows.length===1?'':'s'}`);
 }
});
['leadSearch','leadStatus','leadPriority','leadSource','leadAgent'].forEach(id=>$('#'+id).on('input change',loadLeads));
loadLeads();
setInterval(loadLeads,30000);
</script>
<?php include "../includes/footer.php"; ?>
