<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../includes/db.php';

$user = Database::selectOne("SELECT id, agent_code, name, email, phone, profile_image, designation, joining_date, role, commission_pct, is_active, last_login FROM agents WHERE id=? LIMIT 1", [(int)authId()]);
if (!$user) { http_response_code(404); exit('Profile not found.'); }
$pageTitle = 'My Profile';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
$avatar = !empty($user['profile_image']) && file_exists(__DIR__ . '/../uploads/' . $user['profile_image'])
    ? '../uploads/' . $user['profile_image']
    : 'https://ui-avatars.com/api/?name=' . urlencode($user['name']) . '&background=16284e&color=ffffff&size=240';
?>
<link rel="stylesheet" href="../assets/css/pages/profile.css">
<div class="container-fluid py-4 profile-page">
  <div class="profile-hero mb-4">
    <div class="profile-cover"></div>
    <div class="profile-head">
      <div class="profile-avatar-wrap"><img id="profilePreview" src="<?= htmlspecialchars($avatar) ?>" alt="Profile"></div>
      <div class="profile-head-info">
        <h2><?= htmlspecialchars($user['name']) ?></h2>
        <p><?= htmlspecialchars($user['designation'] ?: ucfirst($user['role'])) ?> · <span class="profile-role"><?= htmlspecialchars(ucfirst($user['role'])) ?></span></p>
        <small>Agent Code: <?= htmlspecialchars($user['agent_code']) ?></small>
      </div>
      <div class="profile-status"><span class="status-dot"></span><?= (int)$user['is_active'] === 1 ? 'Active' : 'Inactive' ?></div>
    </div>
  </div>

  <div id="profileMessage"></div>
  <form id="profileForm" enctype="multipart/form-data">
    <div class="row g-4">
      <div class="col-xl-8">
        <div class="card profile-card border-0 shadow-sm">
          <div class="card-header"><h5><i class="fa-solid fa-user me-2"></i>Personal Information</h5><span>Update your account details</span></div>
          <div class="card-body"><div class="row g-3">
            <div class="col-md-6"><label class="form-label">Full Name</label><input class="form-control" name="name" value="<?= htmlspecialchars($user['name']) ?>" required></div>
            <div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input class="form-control" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>"></div>
            <div class="col-md-6"><label class="form-label">Designation</label><input class="form-control" name="designation" value="<?= htmlspecialchars($user['designation'] ?? '') ?>"></div>
            <div class="col-md-6"><label class="form-label">Joining Date</label><input type="date" class="form-control" value="<?= htmlspecialchars($user['joining_date'] ?? '') ?>" disabled></div>
            <div class="col-md-6"><label class="form-label">Profile Photo</label><input type="file" class="form-control" name="profile_image" id="profileImage" accept="image/jpeg,image/png,image/webp"><small class="text-muted">JPG, PNG or WEBP · max 2 MB</small></div>
          </div></div>
        </div>

        <div class="card profile-card border-0 shadow-sm mt-4">
          <div class="card-header"><h5><i class="fa-solid fa-lock me-2"></i>Change Password / Login PIN</h5><span>Leave blank if you do not want to change it</span></div>
          <div class="card-body"><div class="row g-3">
            <div class="col-md-4"><label class="form-label">Current PIN</label><input type="password" inputmode="numeric" maxlength="4" class="form-control" name="current_pin" placeholder="••••"></div>
            <div class="col-md-4"><label class="form-label">New PIN</label><input type="password" inputmode="numeric" maxlength="4" class="form-control" name="new_pin" placeholder="4 digits"></div>
            <div class="col-md-4"><label class="form-label">Confirm New PIN</label><input type="password" inputmode="numeric" maxlength="4" class="form-control" name="confirm_pin" placeholder="Repeat PIN"></div>
          </div></div>
        </div>
      </div>
      <div class="col-xl-4">
        <div class="card profile-card border-0 shadow-sm h-100"><div class="card-body profile-summary">
          <div class="summary-icon"><i class="fa-solid fa-id-badge"></i></div><h4><?= htmlspecialchars(ucfirst($user['role'])) ?></h4><p class="text-muted">Your role and system information</p>
          <div class="summary-row"><span>Agent Code</span><strong><?= htmlspecialchars($user['agent_code']) ?></strong></div>
          <div class="summary-row"><span>Commission</span><strong><?= number_format((float)$user['commission_pct'], 2) ?>%</strong></div>
          <div class="summary-row"><span>Last Login</span><strong><?= $user['last_login'] ? date('d M Y, h:i A', strtotime($user['last_login'])) : '—' ?></strong></div>
          <div class="summary-row"><span>Account</span><strong><?= (int)$user['is_active'] === 1 ? 'Active' : 'Inactive' ?></strong></div>
          <button type="submit" id="btnProfileSave" class="btn btn-primary w-100 mt-4"><i class="fa-solid fa-floppy-disk me-2"></i>Save Profile</button>
        </div></div>
      </div>
    </div>
  </form>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="../assets/js/pages/profile.js"></script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
