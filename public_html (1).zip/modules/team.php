<?php

require_once "../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager','admin'], true)) { http_response_code(403); exit('Permission denied.'); }

$pageTitle = "Team Management";

include "../includes/header.php";
include "../includes/sidebar.php";

require_once "../includes/db.php";

/*
|--------------------------------------------------------------------------
| Current Logged User
|--------------------------------------------------------------------------
*/

$userId   = $_SESSION['agent_id'];
$userRole = $_SESSION['role'];

?>

<link rel="stylesheet" href="../assets/css/pages/team.css">

<div class="page-content">

    <!-- =========================================
        PAGE HEADER
    ========================================== -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold mb-1">

                <i class="fa-solid fa-users text-primary me-2"></i>

                Team Management

            </h2>

            <p class="text-muted mb-0">

                Create, manage and monitor your sales teams.

            </p>

        </div>

        <div class="d-flex gap-2">

            <button
                class="btn btn-outline-primary"
                onclick="loadTeams()">

                <i class="fa fa-rotate-right me-2"></i>

                Refresh

            </button>

            <?php if(in_array($userRole,['admin','manager','teamlead'])){ ?>

            <button
                class="btn btn-success"
                id="btnCreateTeam">

                <i class="fa fa-plus me-2"></i>

                New Team

            </button>

            <?php } ?>

        </div>

    </div>

    <!-- =========================================
        STATISTICS
    ========================================== -->

    <div class="row g-4 mb-4">

        <div class="col-xl-3 col-md-6">

            <div class="team-stat-card">

                <div class="icon bg-primary">

                    <i class="fa-solid fa-layer-group"></i>

                </div>

                <div>

                    <small>Total Teams</small>

                    <h3 id="totalTeams">0</h3>

                </div>

            </div>

        </div>

        <div class="col-xl-3 col-md-6">

            <div class="team-stat-card">

                <div class="icon bg-success">

                    <i class="fa-solid fa-users"></i>

                </div>

                <div>

                    <small>Members</small>

                    <h3 id="totalAgents">0</h3>

                </div>

            </div>

        </div>

        <div class="col-xl-3 col-md-6">

            <div class="team-stat-card">

                <div class="icon bg-warning">

                    <i class="fa-solid fa-bullseye"></i>

                </div>

                <div>

                    <small>Monthly Target</small>

                    <h3 id="monthlyTarget">0</h3>

                </div>

            </div>

        </div>
        
        <div class="col-xl-3 col-md-6">

            <div class="team-stat-card">

                <div class="icon bg-info">

                    <i class="fa-solid fa-check-circle"></i>

                </div>

                <div>

                    <small>Active Teams</small>

                    <h3 id="bonusEarned">0</h3>

                </div>

            </div>

        </div>

    </div>

    <!--=========================================================
        TEAM LIST HEADER
    ==========================================================-->

        <!-- =========================================
        TEAM LIST HEADER
    ========================================== -->

    <div class="card border-0 shadow-sm mb-4">

        <div class="card-body">

            <div class="row align-items-center">

                <div class="col-lg-6">

                    <h4 class="fw-bold mb-1">

                        <i class="fa-solid fa-people-group text-primary me-2"></i>

                        Teams

                    </h4>

                    <p class="text-muted mb-0">

                        <?php if($userRole=="admin" || $userRole=="manager"){ ?>

                            You can view and manage all teams.

                        <?php }elseif($userRole=="teamlead"){ ?>

                            You can manage only your own teams.

                        <?php }else{ ?>

                            You can only view your assigned team.

                        <?php } ?>

                    </p>

                </div>

                <div class="col-lg-6">

                    <div class="d-flex justify-content-lg-end mt-3 mt-lg-0">

                        <div class="input-group" style="max-width:350px;">

                            <span class="input-group-text bg-white">

                                <i class="fa fa-search"></i>

                            </span>

                            <input

                                type="text"

                                class="form-control"

                                id="teamSearch"

                                placeholder="Search Team...">

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =========================================
        TEAM CARDS
    ========================================== -->

    <div

        class="row"

        id="teamContainer">

    </div>


    <!-- =========================================
        EMPTY STATE
    ========================================== -->

    <div

        id="emptyTeams"

        class="text-center py-5"

        style="display:none;">

        <div class="card border-0 shadow-sm">

            <div class="card-body py-5">

                <i

                    class="fa-solid fa-users-slash"

                    style="font-size:70px;color:#d6d6d6;"></i>

                <h3 class="mt-4 fw-bold">

                    No Teams Found

                </h3>

                <p class="text-muted mb-4">

                    It looks like there are no teams available yet.

                </p>

                <?php if(in_array($userRole,['admin','manager','teamlead'])){ ?>

                <button

                    class="btn btn-success"

                    id="btnEmptyCreate">

                    <i class="fa fa-plus me-2"></i>

                    Create First Team

                </button>

                <?php } ?>

            </div>

        </div>

    </div>

</div>
<!-- =========================================================
TEAM MODAL
========================================================= -->

<!-- =========================================================
TEAM MODAL
========================================================= -->

<div
    class="modal fade"
    id="teamModal"
    tabindex="-1">

    <div class="modal-dialog modal-xl modal-dialog-scrollable">

        <div class="modal-content border-0 shadow-lg">

            <div class="modal-header bg-primary text-white">

                <h5
                    class="modal-title"
                    id="modalTitle">

                    <i class="fa-solid fa-users me-2"></i>

                    Create Team

                </h5>

                <button
                    type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">

                </button>

            </div>

            <form id="teamForm">

                <input
                    type="hidden"
                    id="team_id"
                    name="team_id">

                <div class="modal-body">

                    <div class="row">

                        <!-- LEFT -->

                        <div class="col-lg-4">

                            <div class="card border-0 shadow-sm mb-4">

                                <div class="card-header bg-light fw-bold">

                                    Team Information

                                </div>

                                <div class="card-body">

                                    <div class="mb-3">

                                        <label class="form-label">

                                            Team Name

                                        </label>

                                        <input

                                            type="text"

                                            class="form-control"

                                            id="team_name"

                                            name="team_name"

                                            placeholder="Follow Up Team">

                                    </div>

                                    <div class="mb-3">

                                        <label class="form-label">

                                            Monthly Target

                                        </label>

                                        <input

                                            type="number"

                                            class="form-control"

                                            id="monthly_target"

                                            name="monthly_target"

                                            value="0">

                                    </div>
                                    <div class="mb-3">

                                        <label class="form-label">

                                            Work Type

                                        </label>

                                        <select
                                            class="form-select"
                                            id="work_type"
                                            name="work_type">

                                            <option value="followup">

                                                Follow Up

                                            </option>

                                            <option value="booking">

                                                Booking

                                            </option>

                                            <option value="both" selected>

                                                Both

                                            </option>

                                        </select>

                                    </div>
                                    <?php if($userRole=="admin" || $userRole=="manager"){ ?>

                                    <div class="mb-3">

                                        <label class="form-label">

                                            Team Lead

                                        </label>

                                        <select

                                            class="form-select"

                                            id="team_lead_id"

                                            name="team_lead_id">

                                            <option value="">

                                                Select Team Lead

                                            </option>

                                        </select>

                                    </div>

                                    <?php } ?>

                                </div>

                            </div>

                        </div>

                        <!-- RIGHT -->

                        <div class="col-lg-8">

                            <div class="card border-0 shadow-sm">

                                <div class="card-header d-flex justify-content-between align-items-center">

                                    <span class="fw-bold">

                                        Team Members

                                    </span>

                                    <span
                                        class="badge bg-primary"
                                        id="selectedCount">

                                        0 Selected

                                    </span>

                                </div>

                                <div class="card-body">

                                    <div class="mb-3">

                                        <input

                                            type="text"

                                            class="form-control"

                                            id="searchAgent"

                                            placeholder="Search Agent...">

                                    </div>

                                    <div
                                        class="row"

                                        id="agentContainer">

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">

                        Cancel

                    </button>


                    <button
                        type="submit"
                        class="btn btn-success"
                        id="btnSaveTeam">

                        <i class="fa fa-save me-2"></i>

                        Save Team

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>
<!-- =========================================================
DELETE TEAM
========================================================= -->

<div class="modal fade"
     id="deleteTeamModal"
     tabindex="-1">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">

                    Delete Team

                </h5>

            </div>

            <div class="modal-body">

                Are you sure you want to delete this team?

            </div>

            <div class="modal-footer">

                <input
                    type="hidden"
                    id="delete_team_id">

                <button
                    class="btn btn-secondary"
                    data-bs-dismiss="modal">

                    Cancel

                </button>

                <button
                    class="btn btn-danger"
                    id="btnDeleteTeam">

                    Delete

                </button>

            </div>

        </div>

    </div>

</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap5.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/pages/team.js"></script>
<?php include "../includes/footer.php"; ?>