<?php
declare(strict_types=1);
require_once '../includes/auth.php';
requireLogin();
include "../includes/header.php";
include "../includes/sidebar.php";
require_once '../includes/db.php';
require_once '../includes/permissions.php';

$role = authRole();
$uid  = (int) authId();
$pageTitle = 'Performances';
$isAdmin = in_array($role, ['manager','admin'], true);

/* Reference Performance page constants */
$bonusTypes = [
    'call30'=>'30+ Minute Client Call','sameday'=>'Same Day Booking','saturday'=>'Saturday Booking',
    'sunday'=>'Sunday Booking','followup'=>'Follow-up Converted Booking','review'=>'Customer Review Received',
    'videoreview'=>'Video Review Received','weekly3'=>'Weekly Target — 3 Bookings','weekly4'=>'Weekly Target — 4 Bookings',
    'weekly5'=>'Weekly Target — 5 Bookings','monthly12'=>'Monthly Target — 12 Bookings',
    'special'=>'Special Performance Bonus','custom'=>'Custom Bonus Claim'
];
$bonusValues = [
    'call30'=>500,'sameday'=>1000,'saturday'=>1000,'sunday'=>1000,'followup'=>1000,'review'=>300,
    'videoreview'=>500,'weekly3'=>1000,'weekly4'=>2000,'weekly5'=>5000,'monthly12'=>10000,'special'=>0,'custom'=>0
];

function pRows(string $sql, array $params=[]): array {
    try { return Database::select($sql, $params); } catch (Throwable $e) { return []; }
}
function pOne(string $sql, array $params=[]): array {
    try { return Database::selectOne($sql, $params) ?: []; } catch (Throwable $e) { return []; }
}
function pMoney(array $bks): array {
    $sales=0; $margin=0;
    foreach($bks as $b){
        $sales += (float)($b['gross_total'] ?? 0);
        $r = pOne('SELECT COALESCE(SUM(margin),0) AS margin FROM booking_cost_rows WHERE booking_id=?',[(int)$b['id']]);
        $margin += (float)($r['margin'] ?? 0);
    }
    return [$sales,$margin];
}
function pPeriodWhere(string $period, string $dateField='b.invoice_date'): string {
    return match($period) {
        'today' => "$dateField = CURDATE()",
        'week'  => "$dateField >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)",
        'month' => "$dateField >= DATE_FORMAT(CURDATE(), '%Y-%m-01')",
        default => '1=1'
    };
}

$allAgents = pRows("SELECT a.id,a.name,a.email,a.role,a.commission_pct,a.team_id,t.name AS team_name
                    FROM agents a LEFT JOIN teams t ON t.id=a.team_id
                    WHERE a.is_active=1 AND a.role IN ('agent','teamlead') ORDER BY a.name");

$scopeIds = [];
if($role==='agent') {
    $scopeIds=[$uid];
} elseif($role==='teamlead') {
    $scopeIds=array_values(array_unique(array_merge([$uid], array_map('intval', teamAgentIds($uid)))));
} else {
    $scopeIds=array_map(fn($a)=>(int)$a['id'],$allAgents);
}
$agents=array_values(array_filter($allAgents,fn($a)=>in_array((int)$a['id'],$scopeIds,true)));
$selected=(int)($_GET['agent_id']??($uid?:($agents[0]['id']??0)));
if(!$isAdmin || !in_array($selected,$scopeIds,true)) $selected=$uid?:($agents[0]['id']??0);
$agent=pOne("SELECT a.*,t.name AS team_name FROM agents a LEFT JOIN teams t ON t.id=a.team_id WHERE a.id=?",[$selected]);
if(!$agent) $agent=$agents[0]??['id'=>$selected,'name'=>'Agent','role'=>'agent','team_name'=>''];

$allBks=pRows("SELECT b.id,b.invoice_no,b.client_name,b.destination,b.travel_date,b.invoice_date,b.status,b.gross_total,b.total_received,b.balance_due
               FROM bookings b WHERE b.agent_id=? ORDER BY b.id DESC",[$selected]);
$todayBks=pRows("SELECT b.id,b.invoice_no,b.client_name,b.destination,b.travel_date,b.invoice_date,b.status,b.gross_total,b.total_received,b.balance_due
                 FROM bookings b WHERE b.agent_id=? AND ".pPeriodWhere('today')." ORDER BY b.id DESC",[$selected]);
$weekBks=pRows("SELECT b.id,b.invoice_no,b.client_name,b.destination,b.travel_date,b.invoice_date,b.status,b.gross_total,b.total_received,b.balance_due
                FROM bookings b WHERE b.agent_id=? AND ".pPeriodWhere('week')." ORDER BY b.id DESC",[$selected]);
$monthBks=pRows("SELECT b.id,b.invoice_no,b.client_name,b.destination,b.travel_date,b.invoice_date,b.status,b.gross_total,b.total_received,b.balance_due
                 FROM bookings b WHERE b.agent_id=? AND ".pPeriodWhere('month')." ORDER BY b.id DESC",[$selected]);

[$totalRev,$totalMar]=pMoney($allBks);
[$monthRev,$monthMar]=pMoney($monthBks);
$confirmed=count(array_filter($allBks,fn($b)=>($b['status']??'')==='Confirmed'));
$approved=(float)(pOne("SELECT COALESCE(SUM(amount),0) v FROM bonus_claims WHERE agent_id=? AND status='Approved'",[$selected])['v']??0);
$pendingB=(int)(pOne("SELECT COUNT(*) v FROM bonus_claims WHERE agent_id=? AND status='Pending'",[$selected])['v']??0);
$pkgCount=[];
foreach($allBks as $b){$k=trim((string)($b['destination']??'')) ?: 'Umrah'; $pkgCount[$k]=($pkgCount[$k]??0)+1;}
arsort($pkgCount); $bestPkg=$pkgCount ? [array_key_first($pkgCount),reset($pkgCount)] : null;
$monthTarget=12; $monthProg=min(($monthTarget?count($monthBks)/$monthTarget*100:0),100);
$nextWeekly = count($weekBks)<3 ? ['need'=>3-count($weekBks),'val'=>1000] : (count($weekBks)<4 ? ['need'=>4-count($weekBks),'val'=>2000] : (count($weekBks)<5 ? ['need'=>5-count($weekBks),'val'=>5000] : null));

$teams=pRows("SELECT t.id,t.name,t.team_lead_id,t.monthly_target FROM teams t ORDER BY t.name");
$bonusWhere='1=1'; $bonusParams=[];
if($role==='agent'){ $bonusWhere='bc.agent_id=?'; $bonusParams=[$uid]; }
elseif($role==='teamlead'){
    if($scopeIds){$ph=implode(',',array_fill(0,count($scopeIds),'?'));$bonusWhere="bc.agent_id IN ($ph)";$bonusParams=$scopeIds;}
    else $bonusWhere='0=1';
}
$bonuses=pRows("SELECT bc.*,a.name AS agent_name FROM bonus_claims bc JOIN agents a ON a.id=bc.agent_id
                WHERE $bonusWhere ORDER BY bc.id DESC LIMIT 300",$bonusParams);
$myBonusSet=$isAdmin?$bonuses:array_values(array_filter($bonuses,fn($b)=>(int)$b['agent_id']===$uid));

$leaderPeriod=$_GET['lb_period']??'month';
if(!in_array($leaderPeriod,['today','week','month','all'],true))$leaderPeriod='month';
$leader=[];
foreach($agents as $a){
    $bs=pRows("SELECT b.id,b.gross_total FROM bookings b WHERE b.agent_id=? AND ".pPeriodWhere($leaderPeriod),[(int)$a['id']]);
    [$rv,$mr]=pMoney($bs);
    $bn=(float)(pOne("SELECT COALESCE(SUM(amount),0) v FROM bonus_claims WHERE agent_id=? AND status='Approved'",[(int)$a['id']])['v']??0);
    $leader[]=['a'=>$a,'count'=>count($bs),'rev'=>$rv,'margin'=>$mr,'bon'=>$bn];
}
usort($leader,fn($x,$y)=>$y['count']<=>$x['count'] ?: $y['rev']<=>$x['rev']);

function pTeamCount(int $teamId,string $period): int {
    $cond=pPeriodWhere($period);
    $r=pOne("SELECT COUNT(*) c FROM bookings b WHERE b.agent_id IN
             (SELECT tm.agent_id FROM team_members tm WHERE tm.team_id=? UNION SELECT a.id FROM agents a WHERE a.team_id=?)
             AND $cond",[$teamId,$teamId]);
    return (int)($r['c']??0);
}
$teamStats=[];
foreach($teams as $t){
    $lead=pOne('SELECT name FROM agents WHERE id=?',[(int)$t['team_lead_id']]);
    $teamStats[]=['team'=>$t,'lead'=>$lead['name']??'None','count'=>pTeamCount((int)$t['id'],$leaderPeriod)];
}
usort($teamStats,fn($x,$y)=>$y['count']<=>$x['count']);

function esc($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function statusStyle(string $s): string {
    return match($s){
        'Approved'=>'background:#d1fae5;color:#065f46;',
        'Rejected'=>'background:#fee2e2;color:#dc2626;',
        default=>'background:#fef3c7;color:#92400e;'
    };
}
?>
<style>
.perf-page{padding:22px;background:#f8fafc;min-height:100%;font-family:system-ui,-apple-system,sans-serif;color:#1e293b}
.perf-page *{box-sizing:border-box}
.perf-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px}
.perf-head h1{font-size:21px;font-weight:900;color:#0c2340;margin:0}
.perf-head p{color:#6b7280;font-size:11px;margin:3px 0 0}
.perf-agent-select{width:170px;padding:7px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;background:#fff;font-weight:600}
.perf-tabs{display:flex;gap:3px;margin-bottom:16px;background:#fff;padding:4px;border-radius:8px;border:1px solid #e2e8f0;width:max-content}
.perf-tab{background:transparent;color:#64748b;border:0;border-radius:6px;padding:7px 16px;cursor:pointer;font-size:12px;font-weight:700}
.perf-tab.active{background:#0c2340;color:#fff}
.perf-hero{background:#0c2340;border-radius:14px;padding:18px 22px;margin-bottom:16px;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.perf-avatar{width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#c9a84c,#f0c040);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:900;color:#0c2340;flex-shrink:0}
.perf-hero-name{color:#fff;font-weight:800;font-size:17px}.perf-hero-role{color:rgba(255,255,255,.6);font-size:10px;margin-top:1px}
.perf-hero-bonus{text-align:right;margin-left:auto}.perf-hero-bonus strong{color:#c9a84c;font-size:26px;font-weight:900}.perf-hero-bonus div{color:rgba(255,255,255,.6);font-size:9px}.perf-hero-bonus .pending{color:#fbbf24;margin-top:1px}
.perf-grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px}
.perf-card{background:#fff;border-radius:12px;padding:14px 16px;border:1px solid #e5e7eb;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.perf-card-top{display:flex;justify-content:space-between;align-items:flex-start}.perf-card-label{font-size:10px;color:#9ca3af;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px}.perf-card-value{font-size:24px;font-weight:900;line-height:1}.perf-card-sub{font-size:10px;color:#6b7280;margin-top:3px}.perf-card-icon{font-size:22px;opacity:.7}
.perf-two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.perf-panel{background:#fff;border-radius:12px;padding:16px;border:1px solid #e5e7eb}.perf-panel-title{font-weight:700;color:#0c2340;margin-bottom:10px;font-size:13px}
.perf-progress-head{display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px}.perf-progress{background:#f1f5f9;border-radius:8px;height:12px;overflow:hidden;margin-bottom:8px}.perf-progress>div{background:linear-gradient(90deg,#0c2340,#3b82f6);height:100%;border-radius:8px;transition:width .6s}
.perf-next{background:#fffbeb;border:1px solid #fde68a;border-radius:7px;padding:8px 10px;margin-top:10px;font-size:10px;color:#92400e}
.perf-booking-row{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px dotted #f1f5f9;font-size:11px}.perf-booking-name{font-weight:600}.perf-status{padding:1px 6px;border-radius:6px;font-size:9px;font-weight:700;display:inline-block}
.perf-period-wrap{display:flex;justify-content:flex-end;margin-bottom:12px}.perf-period{display:flex;background:#fff;border-radius:7px;border:1px solid #e2e8f0;padding:3px;gap:2px}.perf-period button{background:transparent;color:#64748b;border:0;border-radius:5px;padding:4px 12px;cursor:pointer;font-size:11px;font-weight:700}.perf-period button.active{background:#0c2340;color:#fff}
.perf-rank-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}.perf-rank-panel{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden}.perf-rank-title{padding:11px 14px;color:#fff;font-weight:800;font-size:13px;background:#0c2340}.perf-rank-title.green{background:#059669}.perf-rank-body{padding:12px}
.perf-rank-item{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:9px;margin-bottom:6px;background:#fafafa;border:1px solid #f1f5f9}.perf-rank-item.first{background:linear-gradient(90deg,#fef9c3,#fff);border-color:#fde68a}.perf-rank-item.second{background:#f8fafc;border-color:#e2e8f0}.perf-rank-item.third{background:#fff5f5;border-color:#fecaca}.perf-medal{font-size:20px;width:28px;text-align:center}.perf-rank-avatar{width:34px;height:34px;border-radius:50%;background:#0c2340;display:flex;align-items:center;justify-content:center;color:#c9a84c;font-weight:900;font-size:14px;flex-shrink:0}.perf-rank-main{flex:1}.perf-rank-name{font-weight:700;color:#1e293b;font-size:12px}.perf-rank-meta{font-size:9px;color:#6b7280}.perf-rank-score{text-align:right}.perf-rank-score strong{font-weight:900;font-size:15px;color:#0c2340}.perf-rank-score small{display:block;font-size:9px;color:#059669;font-weight:700}
.perf-bonus-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:8px;flex-wrap:wrap}.perf-filters{display:flex;gap:8px;flex-wrap:wrap}.perf-input{width:130px;padding:7px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;background:#fff}.perf-input.agent{width:150px}.perf-claim{background:#059669;color:#fff;border:0;border-radius:7px;padding:8px 16px;cursor:pointer;font-weight:700;font-size:12px}
.perf-bonus-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px}.perf-bonus-card{background:#fff;border-radius:9px;padding:12px 14px;border:1px solid #e5e7eb}.perf-bonus-label{font-size:9px;color:#9ca3af;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}.perf-bonus-value{font-size:20px;font-weight:900}
.perf-table-wrap{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden}.perf-table-scroll{overflow-x:auto}.perf-table{width:100%;border-collapse:collapse;font-size:11px}.perf-table th{padding:8px;color:#94a3b8;font-weight:600;font-size:10px;text-align:left;white-space:nowrap;background:#1e293b}.perf-table td{padding:8px;border-bottom:1px solid #f9fafb;vertical-align:middle}.perf-table .proof{max-width:160px;font-size:10px;color:#374151}.perf-table .amount{font-weight:700;color:#059669}.perf-table input[type=number]{width:70px;padding:3px 5px;border:1px solid #d1d5db;border-radius:6px;font-size:10px}.perf-action{border:0;border-radius:4px;padding:3px 8px;cursor:pointer;font-size:10px;font-weight:700}.perf-approve{background:#d1fae5;color:#065f46}.perf-reject{background:#fee2e2;color:#dc2626}.perf-bulk{background:#d1fae5;color:#065f46;border:0;border-radius:6px;padding:6px 14px;cursor:pointer;font-weight:700;font-size:11px}
.perf-rules{margin-top:14px}.perf-rules-title{font-weight:700;color:#0c2340;margin-bottom:10px;font-size:13px}.perf-rule-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.perf-rule{background:#fff;border-radius:10px;border:1px solid #e5e7eb;overflow:hidden}.perf-rule-head{background:#0c2340;padding:8px 12px;color:#fff;font-weight:800;font-size:12px}.perf-rule-body{padding:10px 12px}.perf-rule-row{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px dotted #f1f5f9;font-size:11px}.perf-rule-row span:last-child{font-weight:800;color:#059669}
.perf-modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:400;display:flex;align-items:center;justify-content:center}.perf-modal{background:#fff;border-radius:14px;width:480px;max-width:96%;overflow:hidden}.perf-modal-head{background:#059669;padding:13px 18px;display:flex;justify-content:space-between;align-items:center;color:#fff;font-weight:800;font-size:14px}.perf-modal-close{background:rgba(255,255,255,.2);color:#fff;border:0;border-radius:5px;padding:4px 10px;cursor:pointer}.perf-modal-body{padding:16px}.perf-info{background:#fef9c3;border:1px solid #fde68a;border-radius:7px;padding:9px 12px;margin-bottom:12px;font-size:11px;color:#92400e}.perf-field{margin-bottom:8px}.perf-field label{font-size:11px;color:#64748b;display:block;margin-bottom:3px;font-weight:600}.perf-field input,.perf-field select,.perf-field textarea{width:100%;padding:7px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;outline:0;background:#fff}.perf-field textarea{resize:vertical}.perf-modal-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:14px}.perf-cancel,.perf-submit{border:0;border-radius:6px;padding:7px 12px;cursor:pointer;font-size:11px;font-weight:700}.perf-cancel{background:#64748b;color:#fff}.perf-submit{background:#059669;color:#fff}
@media(max-width:1000px){.perf-grid4{grid-template-columns:repeat(2,1fr)}.perf-rank-grid,.perf-two{grid-template-columns:1fr}.perf-bonus-cards{grid-template-columns:repeat(2,1fr)}.perf-rule-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.perf-page{padding:14px}.perf-tabs{width:100%;overflow:auto}.perf-tab{flex:1;white-space:nowrap;padding:7px 10px}.perf-grid4,.perf-bonus-cards,.perf-rule-grid{grid-template-columns:1fr}.perf-hero-bonus{margin-left:0;text-align:left}.perf-head{align-items:flex-start}.perf-agent-select{width:100%}}
</style>

<div class="perf-page">
  <div class="perf-head">
    <div><h1>🏆 Performances</h1><p>Stats · Rankings · Bonuses · Rewards</p></div>
    <?php if($isAdmin): ?>
      <select class="perf-agent-select" onchange="location.href='performance.php?agent_id='+encodeURIComponent(this.value)">
        <?php foreach($agents as $a): ?><option value="<?=esc($a['id'])?>" <?=$selected===(int)$a['id']?'selected':''?>><?=esc($a['name'])?></option><?php endforeach; ?>
      </select>
    <?php endif; ?>
  </div>

  <div class="perf-tabs">
    <button class="perf-tab active" data-perf-tab="bench">📊 My Stats</button>
    <button class="perf-tab" data-perf-tab="leaderboard">🥇 Leaderboard</button>
    <button class="perf-tab" data-perf-tab="bonuses">💰 <?=$isAdmin?'Bonus Control':'My Bonuses'?></button>
  </div>

  <section id="perf-bench">
    <div class="perf-hero">
      <div class="perf-avatar"><?=esc(strtoupper(substr((string)($agent['name']??'A'),0,1)))?></div>
      <div style="flex:1">
        <div class="perf-hero-name"><?=esc($agent['name']??'Agent')?></div>
        <div class="perf-hero-role">
          <?=esc(['manager'=>'👑 Manager','admin'=>'🔧 Admin','teamlead'=>'🏅 Team Lead','agent'=>'👤 Agent'][$agent['role']??'agent']??'Agent')?> · 
        </div>
      </div>
      <div class="perf-hero-bonus">
        <strong>£<?=number_format($approved,0)?></strong>
        <div>Total Approved Bonuses</div>
        <?php if($pendingB>0): ?><div class="pending">⏳ <?=$pendingB?> pending</div><?php endif; ?>
      </div>
    </div>

    <div class="perf-grid4">
      <?php
      $cards=[
        ['Total Bookings',count($allBks),'#1e3a5f','📋',''],
        ['Confirmed',$confirmed,'#059669','✅',''],
        ['This Week',count($weekBks),'#1e3a5f','📆',''],
        ['This Month',count($monthBks),'#1e3a5f','🗓','/ '.$monthTarget.' target'],
        ['Total Sales','£'.number_format($totalRev,0),'#1d4ed8','💷',''],
        ['Total Margin','£'.number_format($totalMar,0),'#7c3aed','📈',''],
        ['Month Margin','£'.number_format($monthMar,0),'#059669','💹',''],
        ['Best Package',$bestPkg?esc($bestPkg[0]):'—','#1e3a5f','🏅',$bestPkg?'×'.$bestPkg[1].' sold':'']
      ];
      foreach($cards as $c): ?>
        <div class="perf-card"><div class="perf-card-top"><div><div class="perf-card-label"><?=esc($c[0])?></div><div class="perf-card-value" style="color:<?=$c[2]?>"><?=esc($c[1])?></div><?php if($c[4]):?><div class="perf-card-sub"><?=esc($c[4])?></div><?php endif;?></div><div class="perf-card-icon"><?=$c[3]?></div></div></div>
      <?php endforeach; ?>
    </div>

    <div class="perf-two">
      <div class="perf-panel">
        <div class="perf-panel-title">🎯 Monthly Target Progress</div>
        <div class="perf-progress-head"><span style="font-weight:600"><?=count($monthBks)?> / <?=$monthTarget?> bookings</span><span style="color:<?=$monthProg>=100?'#059669':'#ea580c'?>;font-weight:700"><?=round($monthProg)?>%</span></div>
        <div class="perf-progress"><div style="width:<?=$monthProg?>%"></div></div>
        <?php if(count($monthBks)<$monthTarget): ?><div style="font-size:10px;color:#6b7280"><?=$monthTarget-count($monthBks)?> more to unlock £10,000 monthly bonus</div><?php else: ?><div style="font-size:11px;color:#059669;font-weight:700">✅ Monthly target hit! Submit your bonus claim.</div><?php endif; ?>
        <?php if($nextWeekly): ?><div class="perf-next">⚡ <?=$nextWeekly['need']?> more booking<?=($nextWeekly['need']!==1?'s':'')?> this week → £<?=number_format($nextWeekly['val'])?> bonus</div><?php endif; ?>
      </div>
      <div class="perf-panel">
        <div class="perf-panel-title">📋 Recent Bookings</div>
        <?php if(!$allBks): ?><div style="color:#9ca3af;font-size:11px;text-align:center;padding:16px">No bookings yet</div><?php endif; ?>
        <?php foreach(array_slice($allBks,0,5) as $b):
          $s=(string)($b['status']??''); $st=match($s){'Confirmed'=>['#d1fae5','#065f46'],'New'=>['#dbeafe','#1e40af'],'Cancelled'=>['#fee2e2','#dc2626'],'Completed'=>['#f0fdf4','#166534'],default=>['#f1f5f9','#64748b']};
        ?>
          <div class="perf-booking-row"><div><div class="perf-booking-name"><?=esc($b['client_name']?:$b['invoice_no'])?></div><span class="perf-status" style="background:<?=$st[0]?>;color:<?=$st[1]?>"><?=esc($s)?></span></div><div style="font-weight:700;color:#059669">£<?=number_format((float)($b['gross_total']??0),0)?></div></div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section id="perf-leaderboard" style="display:none">
    <div class="perf-period-wrap"><div class="perf-period">
      <?php foreach(['today'=>'Today','week'=>'Week','month'=>'Month','all'=>'All Time'] as $k=>$v): ?>
        <button class="<?=$leaderPeriod===$k?'active':''?>" data-lb-period="<?=$k?>"><?=$v?></button>
      <?php endforeach; ?>
    </div></div>
    <div class="perf-rank-grid">
      <div class="perf-rank-panel"><div class="perf-rank-title">👤 Individual Rankings</div><div class="perf-rank-body">
        <?php if(!$leader): ?><div style="color:#9ca3af;text-align:center;padding:20px;font-size:11px">No data for this period</div><?php endif; ?>
        <?php foreach($leader as $i=>$x): $cls=$i===0?'first':($i===1?'second':($i===2?'third':'')); ?>
          <div class="perf-rank-item <?=$cls?>">
            <div class="perf-medal"><?=['🥇','🥈','🥉'][$i]??'<span style="font-size:11px;color:#9ca3af">#'.($i+1).'</span>'?></div>
            <div class="perf-rank-avatar"><?=esc(strtoupper(substr((string)$x['a']['name'],0,1)))?></div>
            <div class="perf-rank-main"><div class="perf-rank-name"><?=esc($x['a']['name'])?></div><div class="perf-rank-meta"><?=$x['count']?> bookings · £<?=number_format($x['rev'],0)?></div></div>
            <div class="perf-rank-score"><strong><?=$x['count']?></strong><?php if($x['bon']>0): ?><small>£<?=number_format($x['bon'],0)?></small><?php endif; ?></div>
          </div>
        <?php endforeach; ?>
      </div></div>
      <div class="perf-rank-panel"><div class="perf-rank-title green">👥 Team Rankings</div><div class="perf-rank-body">
        <?php if(!$teamStats): ?><div style="color:#9ca3af;text-align:center;padding:20px;font-size:11px">No teams set up</div><?php endif; ?>
        <?php foreach($teamStats as $i=>$x): $pct=min(100,$x['count']/max(1,(int)($x['team']['monthly_target']??20))*100); ?>
          <div class="perf-rank-item" style="<?=$i===0?'background:linear-gradient(90deg,#f0fdf4,#fff);border-color:#86efac':''?>">
            <div class="perf-medal"><?=['🥇','🥈','🥉'][$i]??'#'.($i+1)?></div>
            <div class="perf-rank-main"><div class="perf-rank-name"><?=esc($x['team']['name'])?></div><div class="perf-rank-meta">Lead: <?=esc($x['lead'])?> · <?=$x['count']?>/<?=esc($x['team']['monthly_target']??20)?></div><div style="background:#e5e7eb;border-radius:3px;height:4px;margin-top:4px;overflow:hidden"><div style="background:#059669;height:100%;width:<?=$pct?>%"></div></div></div>
            <div class="perf-rank-score"><strong style="color:#059669"><?=$x['count']?></strong></div>
          </div>
        <?php endforeach; ?>
      </div></div>
    </div>
  </section>

  <section id="perf-bonuses" style="display:none">
    <div class="perf-bonus-top">
      <div class="perf-filters">
        <select id="bonusStatusFilter" class="perf-input"><option value="">All Status</option><option>Pending</option><option>Approved</option><option>Rejected</option></select>
        <?php if($isAdmin): ?><select id="bonusAgentFilter" class="perf-input agent"><option value="">All Agents</option><?php foreach($agents as $a): ?><option value="<?=esc($a['id'])?>"><?=esc($a['name'])?></option><?php endforeach; ?></select><?php endif; ?>
        <?php if($isAdmin): ?><button id="bulkApproveBtn" class="perf-bulk" style="display:none">✅ Bulk Approve (<span id="bulkCount">0</span>)</button><?php endif; ?>
      </div>
      <?php if(!$isAdmin): ?><button class="perf-claim" id="openBonusClaim">+ Claim Bonus</button><?php endif; ?>
    </div>

    <div class="perf-bonus-cards">
      <?php
      $paid=array_sum(array_map(fn($b)=>(float)$b['amount'],array_filter($myBonusSet,fn($b)=>$b['status']==='Approved')));
      $bcards=[['Total Claims',count($myBonusSet),'#1e3a5f'],['Pending',count(array_filter($myBonusSet,fn($b)=>$b['status']==='Pending')),'#ea580c'],['Approved',count(array_filter($myBonusSet,fn($b)=>$b['status']==='Approved')),'#059669'],['Total Paid','£'.number_format($paid,0),'#1d4ed8']];
      foreach($bcards as $x): ?><div class="perf-bonus-card"><div class="perf-bonus-label"><?=esc($x[0])?></div><div class="perf-bonus-value" style="color:<?=$x[2]?>"><?=esc($x[1])?></div></div><?php endforeach; ?>
    </div>

    <div class="perf-table-wrap"><div class="perf-table-scroll"><table class="perf-table" id="bonusTable">
      <thead><tr>
        <?php if($isAdmin): ?><th style="width:30px"><input type="checkbox" id="selectAllBonuses"></th><th>Agent</th><?php endif; ?>
        <th>Bonus Type</th><th>Booking</th><th>Submitted</th><th><?= $isAdmin?'Proof':'Notes' ?></th><th>Status</th>
        <?php if($isAdmin): ?><th>Amount</th><th>Actions</th><?php endif; ?>
      </tr></thead>
      <tbody>
      <?php if(!$bonuses): ?><tr><td colspan="<?=$isAdmin?9:5?>" style="padding:30px;text-align:center;color:#9ca3af">No bonus claims found</td></tr><?php endif; ?>
      <?php foreach($bonuses as $b):
        $type=(string)($b['bonus_type']??''); $status=(string)($b['status']??'Pending'); $default=(float)($bonusValues[$type]??0);
      ?>
        <tr data-status="<?=esc($status)?>" data-agent="<?=esc($b['agent_id'])?>">
          <?php if($isAdmin): ?><td><input class="bonus-check" type="checkbox" value="<?=esc($b['id'])?>" <?=$status!=='Pending'?'disabled':''?>></td><td style="font-weight:600"><?=esc($b['agent_name']??'—')?></td><?php endif; ?>
          <td><div style="font-weight:600;color:#1e293b;font-size:11px"><?=esc($bonusTypes[$type]??$type)?></div><?php if(!empty($b['admin_note'])):?><div style="font-size:9px;color:#6b7280">Admin: <?=esc($b['admin_note'])?></div><?php endif; ?></td>
          <td style="font-family:monospace;color:#475569;font-size:10px"><?=esc($b['booking_ref']?:'—')?></td>
          <td style="color:#6b7280;font-size:10px"><?=esc($b['submitted_at']??'')?></td>
          <td class="proof"><?=esc($b['proof_note']?:$b['notes']?:'—')?></td>
          <td><span class="perf-status" style="<?=statusStyle($status)?>"><?=esc($status)?></span></td>
          <?php if($isAdmin): ?>
            <td class="amount"><?php if($status==='Approved'): ?>£<?=number_format((float)$b['amount'],0)?><?php else: ?><input type="number" min="0" step="1" id="amt-<?=esc($b['id'])?>" value="<?=esc($default)?>"><?php endif; ?></td>
            <td><?php if($status==='Pending'): ?><div style="display:flex;gap:4px"><button class="perf-action perf-approve" onclick="approveBonus(<?=esc($b['id'])?>)">✅</button><button class="perf-action perf-reject" onclick="rejectBonus(<?=esc($b['id'])?>)">❌</button></div><?php else: ?><span style="font-size:9px;color:#6b7280"><?=esc($b['reviewed_at']??'')?></span><?php endif; ?></td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>

    <div class="perf-rules">
      <div class="perf-rules-title">📖 Reward Rules</div>
      <div class="perf-rule-grid">
        <div class="perf-rule"><div class="perf-rule-head">Individual</div><div class="perf-rule-body">
          <?php foreach([['30+ Min Call','£500'],['Same Day Booking','£1,000'],['Sat/Sun Booking','£1,000'],['Follow-up Convert','£1,000'],['Customer Review','£300'],['Video Review','£500']] as $r): ?><div class="perf-rule-row"><span><?=esc($r[0])?></span><span><?=esc($r[1])?></span></div><?php endforeach; ?>
        </div></div>
        <div class="perf-rule"><div class="perf-rule-head">Weekly</div><div class="perf-rule-body">
          <?php foreach([['3 Bookings','£1,000'],['4 Bookings','£2,000'],['5 Bookings','£5,000']] as $r): ?><div class="perf-rule-row"><span><?=esc($r[0])?></span><span><?=esc($r[1])?></span></div><?php endforeach; ?>
        </div></div>
        <div class="perf-rule"><div class="perf-rule-head">Monthly</div><div class="perf-rule-body"><div class="perf-rule-row"><span>12 Bookings</span><span>£10,000</span></div></div></div>
      </div>
    </div>
  </section>
</div>

<?php if(!$isAdmin): ?>
<div id="bonusClaimModal" class="perf-modal-backdrop" style="display:none">
  <div class="perf-modal">
    <div class="perf-modal-head"><div>💰 Submit Bonus Claim</div><button class="perf-modal-close" id="closeBonusClaim">✕</button></div>
    <div class="perf-modal-body">
      <div class="perf-info">ℹ️ Reward value is set by admin after review. Just describe what happened and provide proof.</div>
      <form id="bonusClaimForm">
        <div class="perf-field"><label>Bonus Type</label><select name="bonus_type"><?php foreach($bonusTypes as $k=>$v): ?><option value="<?=esc($k)?>"><?=esc($v)?></option><?php endforeach; ?></select></div>
        <div class="perf-field"><label>Related Booking ID (optional)</label><input name="booking_ref" placeholder="e.g. AMT14074"></div>
        <div class="perf-field"><label>Details / Notes</label><textarea name="notes" style="height:65px" placeholder="Describe the bonus situation..."></textarea></div>
        <div class="perf-field"><label>Proof (link / description)</label><textarea name="proof_note" style="height:44px" placeholder="Screenshot saved / recording / review link..."></textarea></div>
        <div class="perf-modal-actions"><button type="button" class="perf-cancel" id="cancelBonusClaim">Cancel</button><button class="perf-submit">📤 Submit</button></div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
(function(){
  const tabs=document.querySelectorAll('.perf-tab');
  const sections={bench:document.getElementById('perf-bench'),leaderboard:document.getElementById('perf-leaderboard'),bonuses:document.getElementById('perf-bonuses')};
  tabs.forEach(btn=>btn.addEventListener('click',()=>{
    tabs.forEach(x=>x.classList.remove('active')); btn.classList.add('active');
    Object.values(sections).forEach(x=>{if(x)x.style.display='none'});
    sections[btn.dataset.perfTab].style.display='block';
  }));

  document.querySelectorAll('[data-lb-period]').forEach(btn=>btn.addEventListener('click',()=>{
    const u=new URL(window.location.href); u.searchParams.set('lb_period',btn.dataset.lbPeriod);
    if(!u.searchParams.get('agent_id') && <?=$isAdmin?'true':'false'?>) u.searchParams.set('agent_id','<?=esc($selected)?>');
    window.location.href=u.toString();
  }));

  function filterBonuses(){
    const s=document.getElementById('bonusStatusFilter')?.value||'';
    const a=document.getElementById('bonusAgentFilter')?.value||'';
    document.querySelectorAll('#bonusTable tbody tr').forEach(r=>{
      r.style.display=(!s||r.dataset.status===s)&&(!a||r.dataset.agent===a)?'':'none';
    });
  }
  document.getElementById('bonusStatusFilter')?.addEventListener('change',filterBonuses);
  document.getElementById('bonusAgentFilter')?.addEventListener('change',filterBonuses);

  async function req(data){
    const r=await fetch('../actions/performance.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)});
    const j=await r.json(); if(!j.success) throw new Error(j.message||'Request failed'); return j;
  }
  window.approveBonus=async function(id){
    const el=document.getElementById('amt-'+id); const amount=el?el.value:0;
    if(!confirm('Approve this bonus claim?')) return;
    try{await req({action:'bonus_review',id,status:'Approved',amount,admin_note:''});location.reload()}catch(e){alert(e.message)}
  };
  window.rejectBonus=async function(id){
    const note=prompt('Rejection reason:',''); if(note===null)return;
    try{await req({action:'bonus_review',id,status:'Rejected',amount:0,admin_note:note});location.reload()}catch(e){alert(e.message)}
  };

  const selectAll=document.getElementById('selectAllBonuses'), bulkBtn=document.getElementById('bulkApproveBtn'), bulkCount=document.getElementById('bulkCount');
  function syncBulk(){
    const checks=[...document.querySelectorAll('.bonus-check:not(:disabled)')], sel=checks.filter(x=>x.checked);
    if(bulkBtn){bulkBtn.style.display=sel.length?'inline-block':'none';bulkCount.textContent=sel.length}
    if(selectAll)selectAll.checked=checks.length>0&&sel.length===checks.length;
  }
  selectAll?.addEventListener('change',()=>{document.querySelectorAll('.bonus-check:not(:disabled)').forEach(x=>x.checked=selectAll.checked);syncBulk()});
  document.querySelectorAll('.bonus-check').forEach(x=>x.addEventListener('change',syncBulk));
  bulkBtn?.addEventListener('click',async()=>{
    const ids=[...document.querySelectorAll('.bonus-check:checked')].map(x=>x.value);
    if(!ids.length)return;
    if(!confirm('Approve '+ids.length+' selected bonus claims?'))return;
    try{for(const id of ids){const el=document.getElementById('amt-'+id);await req({action:'bonus_review',id,status:'Approved',amount:el?el.value:0,admin_note:''})}location.reload()}catch(e){alert(e.message)}
  });

  const modal=document.getElementById('bonusClaimModal');
  document.getElementById('openBonusClaim')?.addEventListener('click',()=>modal.style.display='flex');
  document.getElementById('closeBonusClaim')?.addEventListener('click',()=>modal.style.display='none');
  document.getElementById('cancelBonusClaim')?.addEventListener('click',()=>modal.style.display='none');
  document.getElementById('bonusClaimForm')?.addEventListener('submit',async e=>{
    e.preventDefault(); const btn=e.target.querySelector('button[type=submit]'); btn.disabled=true;
    try{const d=Object.fromEntries(new FormData(e.target));d.action='bonus_submit';await req(d);alert('Bonus claim submitted successfully.');location.reload()}catch(x){alert(x.message);btn.disabled=false}
  });
})();
</script>
<?php include '../includes/footer.php'; ?>
