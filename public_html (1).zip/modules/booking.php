<?php

require_once "../includes/auth.php";
requireLogin();

$pageTitle = "Booking Management";

include "../includes/header.php";
include "../includes/sidebar.php";
require_once "../includes/db.php";

$currentBookingRole = strtolower((string) (authRole() ?? ""));
$isBookingAdminManager = in_array($currentBookingRole, ["admin", "manager"], true);
$isBookingAgent = ($currentBookingRole === "agent");

?>
<link
    rel="stylesheet"
    href="https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css"
>
<link rel="stylesheet" href="../assets/css/pages/booking.css">


    <!-- Page Header -->
    <div class="page-header booking-header">

        <div class="page-title">

            <h2>Booking Management</h2>

            <p>Manage customer bookings, quotations, invoices and payments.</p>

        </div>

        <div class="page-actions">

            <button class="btn btn-light" id="refreshBookings">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>

            <button class="btn btn-success" id="exportBookings">
                <i class="fas fa-file-excel"></i> Export
            </button>

            <button class="btn btn-primary" id="newBooking">
                <i class="fas fa-plus-circle"></i> New Booking
            </button>

        </div>

    </div>


    <!-- Statistics -->
    <div class="booking-stats">

        <div class="stat-card">
            <span>Total Bookings</span>
            <h3 id="totalBookings">0</h3>
        </div>

        <div class="stat-card">
            <span>Confirmed</span>
            <h3 id="confirmedBookings">0</h3>
        </div>

        <div class="stat-card">
            <span>Pending</span>
            <h3 id="pendingBookings">0</h3>
        </div>

        <div class="stat-card">
            <span>Cancelled</span>
            <h3 id="cancelledBookings">0</h3>
        </div>

        <div class="stat-card">
            <span>Total Revenue</span>
            <h3 id="totalRevenue">£0.00</h3>
        </div>

        <div class="stat-card">
            <span>Balance Due</span>
            <h3 id="balancedue">£0.00</h3>
        </div>

    </div>


    <!-- Filters -->
    <div class="booking-filter-card" id="bookingFilterCard" data-role="<?= htmlspecialchars($currentBookingRole, ENT_QUOTES, "UTF-8") ?>">

        <div class="row">

            <div class="col-md-3">

                <label>Search</label>

                <input
                    type="text"
                    class="form-control"
                    id="searchBooking"
                    placeholder="Invoice, Client, Mobile">

            </div>

            <div class="col-md-2">

                <label>Status</label>

                <select class="form-control" id="statusFilter">

                    <option value="">All Statuses</option>
                    <option value="New">New</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Departed">Departed</option>
                    <option value="In Makkah">In Makkah</option>
                    <option value="In Madinah">In Madinah</option>
                    <option value="Returning">Returning</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>

                </select>

            </div>

            <div class="col-md-2">

                <label>Project</label>

                <select class="form-control" id="projectFilter">

                    <option value="">All Projects</option>

                </select>

            </div>

            <div class="col-md-2" id="agentFilterWrap"<?= $isBookingAgent ? ' style="display:none;"' : '' ?>>

                <label>Agent</label>

                <select class="form-control" id="agentFilter"<?= $isBookingAgent ? ' disabled' : '' ?>>

                    <option value="">All Agents</option>

                </select>

            </div>

            <div class="col-md-2">

                <label>Travel Date</label>

                <input
                    type="date"
                    class="form-control"
                    id="travelDate">

            </div>

            <div class="col-md-1 d-flex align-items-end">

                <button class="btn btn-primary w-100" id="filterBtn">

                    Search

                </button>

            </div>

        </div>

    </div>


    <!-- DataTable -->

    <!-- DataTable -->

<div class="card booking-table-card">

    <div class="card-body">

        <div class="booking-table-scroll">
        <table id="bookingTable" class="table table-bordered table-hover align-middle">

            <thead>

                <tr>

                    <th style="width:4%">#</th>

                    <th style="width:8%">Invoice</th>

                    <th style="width:10%">Client</th>

                    <th style="width:8%">Travel Date</th>

                    <th style="width:14%">Hotels</th>

                    <th style="width:14%">Flights</th>

                    <th style="width:8%">Status</th>

                    <th style="width:8%">Gross</th>

                    <th style="width:8%">Received</th>

                    <th style="width:8%">Balance</th>

                    <th style="width:10%">Actions</th>

                </tr>

            </thead>

            <tbody id="bookingTableBody">

            </tbody>

        </table>
        </div>

    </div>

</div>

    <?php include "../includes/booking/wizard.php"; ?>
   
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap5.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="../assets/js/pages/booking.js"></script>
<script src="../assets/js/pages/viewBooking.js"></script>


<?php include "../includes/footer.php"; ?>