<?php
declare(strict_types=1);
require_once "../includes/auth.php";
requireLogin();
require_once "../includes/db.php";
require_once "../includes/permissions.php";
require_once "../includes/notifications.php";

$pageTitle = "Alerts";
include "../includes/header.php";
include "../includes/sidebar.php";

$uid  = (int) authId();
$role = strtolower((string) authRole());
syncSystemNotifications($uid, $role);
$initialUnread = notificationsUnreadCount($uid);
?>

<div class="main-content notifications-page">
    <section class="notifications-hero">
        <div class="notifications-hero-copy">
            <div class="notification-eyebrow"><span class="live-dot"></span> Live notification center</div>
            <h2>Alerts &amp; Notifications</h2>
            <p>Stay on top of approvals, bookings, leads, finance and operational tasks from one central workspace.</p>
        </div>
        <div class="notifications-hero-actions">
            <button class="btn btn-light" id="markAllRead"><i class="fa-solid fa-check-double me-2"></i>Mark all read</button>
            <button class="btn btn-outline-light" id="refreshNotifications"><i class="fa-solid fa-rotate me-2"></i>Refresh</button>
        </div>
    </section>

    <section class="notification-stats row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <div class="notification-stat stat-unread">
                <div class="stat-icon primary"><i class="fa-solid fa-bell"></i></div>
                <div><small>Unread</small><strong id="statUnread"><?= $initialUnread ?></strong><span>Needs your attention</span></div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="notification-stat stat-approval">
                <div class="stat-icon danger"><i class="fa-solid fa-shield-halved"></i></div>
                <div><small>Approvals</small><strong id="statApprovals">0</strong><span>Requests in view</span></div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="notification-stat stat-booking">
                <div class="stat-icon warning"><i class="fa-solid fa-calendar-check"></i></div>
                <div><small>Bookings</small><strong id="statBookings">0</strong><span>Travel &amp; payment alerts</span></div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="notification-stat stat-total">
                <div class="stat-icon success"><i class="fa-solid fa-layer-group"></i></div>
                <div><small>Visible</small><strong id="statAll">0</strong><span>Matching notifications</span></div>
            </div>
        </div>
    </section>

    <section class="notification-toolbar card border-0 shadow-sm mb-3">
        <div class="card-body">
            <div class="notification-toolbar-top">
                <div>
                    <h5><i class="fa-solid fa-sliders me-2"></i>Notification queue</h5>
                    <span>Filter your workspace without leaving this page.</span>
                </div>
                <button class="btn btn-sm btn-light border" id="clearNotificationFilters"><i class="fa-solid fa-rotate-left me-1"></i>Reset</button>
            </div>
            <div class="row g-2 align-items-center mt-1">
                <div class="col-lg-5">
                    <div class="notification-search">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input id="notificationSearch" class="form-control" autocomplete="off" placeholder="Search title, booking, client or message...">
                        <button type="button" class="search-clear d-none" id="clearNotificationSearch" aria-label="Clear search"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <select id="notificationCategory" class="form-select">
                        <option value="all">All categories</option>
                        <option value="approvals">Approvals</option>
                        <option value="bookings">Bookings</option>
                        <option value="leads">Leads</option>
                        <option value="finance">Finance</option>
                        <option value="documents">Documents</option>
                        <option value="system">System</option>
                    </select>
                </div>
                <div class="col-sm-6 col-lg-2">
                    <select id="notificationState" class="form-select">
                        <option value="0">All notifications</option>
                        <option value="1">Unread only</option>
                    </select>
                </div>
                <div class="col-lg-2">
                    <button class="btn btn-primary w-100" id="applyNotificationFilter"><i class="fa-solid fa-filter me-2"></i>Apply</button>
                </div>
            </div>
        </div>
    </section>

    <div class="notification-tabs-wrap mb-3">
        <div class="notification-tabs" role="tablist">
            <button class="notification-tab active" data-category="all"><i class="fa-solid fa-inbox"></i> All</button>
            <button class="notification-tab" data-category="approvals"><i class="fa-solid fa-shield-halved"></i> Approvals</button>
            <button class="notification-tab" data-category="bookings"><i class="fa-solid fa-calendar-check"></i> Bookings</button>
            <button class="notification-tab" data-category="leads"><i class="fa-solid fa-user-group"></i> Leads</button>
            <button class="notification-tab" data-category="finance"><i class="fa-solid fa-sterling-sign"></i> Finance</button>
            <button class="notification-tab" data-category="documents"><i class="fa-solid fa-file-shield"></i> Documents</button>
            <button class="notification-tab" data-category="system"><i class="fa-solid fa-gear"></i> System</button>
        </div>
    </div>

    <div class="notification-queue-head">
        <div><strong id="queueTitle">All notifications</strong><span id="queueSubtitle">Latest activity first</span></div>
        <span class="queue-live"><span class="live-dot"></span> Auto-updates every 15 sec</span>
    </div>

    <div id="notificationList" class="notification-list"></div>

    <div id="notificationEmpty" class="notification-empty d-none">
        <div class="empty-icon"><i class="fa-regular fa-circle-check"></i></div>
        <h5>You're all caught up</h5>
        <p>There are no notifications matching your current filters.</p>
        <button class="btn btn-sm btn-outline-primary" id="emptyReset"><i class="fa-solid fa-rotate-left me-1"></i>Clear filters</button>
    </div>

    <div class="notification-pagination card border-0 shadow-sm mt-3 d-none" id="notificationPagination">
        <div class="card-body py-2 d-flex justify-content-between align-items-center gap-2">
            <span class="text-muted small" id="paginationInfo"></span>
            <div class="btn-group">
                <button class="btn btn-sm btn-light border" id="prevPage"><i class="fa-solid fa-chevron-left me-1"></i>Previous</button>
                <button class="btn btn-sm btn-light border" id="nextPage">Next<i class="fa-solid fa-chevron-right ms-1"></i></button>
            </div>
        </div>
    </div>
</div>

<!-- Rejection reason modal -->
<div class="modal fade" id="notificationRejectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content notification-modal">
            <div class="modal-header">
                <div><span class="modal-kicker">Approval action</span><h5 class="modal-title">Reject request</h5></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted small mb-2">Please provide a reason. The requester will receive this explanation in their notifications.</p>
                <textarea id="notificationRejectReason" class="form-control" rows="4" maxlength="1000" placeholder="Enter rejection reason..."></textarea>
                <div class="text-end small text-muted mt-1"><span id="rejectCharCount">0</span>/1000</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmNotificationReject"><i class="fa-solid fa-xmark me-1"></i>Reject request</button>
            </div>
        </div>
    </div>
</div>

<script>
(() => {
    'use strict';

    const endpoint = '../actions/notifications.php';
    // Only Admin, Manager and Team Lead can review booking approval requests.
    // Agents can still see the approval result notifications, but never the
    // Approve / Reject controls.
    const canReviewApprovals = <?= in_array($role, ['admin', 'manager', 'teamlead'], true) ? 'true' : 'false' ?>;
    const state = { page: 1, category: 'all', unread: 0, search: '' };
    let rejectPayload = null;
    let loading = false;

    const $ = (id) => document.getElementById(id);
    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    }[char]));

    const categoryIcon = (category) => ({
        approvals: 'fa-shield-halved',
        bookings: 'fa-calendar-check',
        leads: 'fa-user-group',
        finance: 'fa-sterling-sign',
        documents: 'fa-file-shield',
        system: 'fa-gear'
    }[category] || 'fa-bell');

    const priorityClass = (priority) => ({
        critical: 'critical', high: 'high', normal: 'normal', low: 'low'
    }[priority] || 'normal');

    const categoryLabel = (category) => ({
        approvals: 'Approvals', bookings: 'Bookings', leads: 'Leads', finance: 'Finance',
        documents: 'Documents', system: 'System'
    }[category] || 'Notification');

    function timeAgo(value) {
        const date = new Date(String(value || '').replace(' ', 'T'));
        if (Number.isNaN(date.getTime())) return '';
        const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
        if (seconds < 60) return 'Just now';
        if (seconds < 3600) return Math.floor(seconds / 60) + ' min ago';
        if (seconds < 86400) return Math.floor(seconds / 3600) + ' hr ago';
        if (seconds < 604800) return Math.floor(seconds / 86400) + ' day' + (Math.floor(seconds / 86400) === 1 ? '' : 's') + ' ago';
        return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    function relativeActionText(n) {
        if (n.entity_type === 'booking_edit_request') return 'Edit approval';
        if (n.entity_type === 'booking_delete_request') return 'Delete approval';
        if (n.entity_type === 'booking') return 'Booking';
        if (n.entity_type === 'lead') return 'Lead';
        return categoryLabel(n.category);
    }

    function actionButtons(n) {
        const isEdit = n.entity_type === 'booking_edit_request';
        const isDelete = n.entity_type === 'booking_delete_request';
        const safeUrl = esc(n.action_url || 'alerts.php');

        if (isEdit || isDelete) {
            const reviewType = isEdit ? 'edit' : 'delete';
            const reviewControls = canReviewApprovals ? `
                    <button class="btn btn-sm btn-success" onclick="crmReviewNotification(${Number(n.id)},${Number(n.entity_id || 0)},'${reviewType}','Approved')">
                        <i class="fa-solid fa-check me-1"></i>Approve
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="crmOpenReject(${Number(n.id)},${Number(n.entity_id || 0)},'${reviewType}')">
                        <i class="fa-solid fa-xmark me-1"></i>Reject
                    </button>` : '';
            return `
                <div class="notification-actions">
                    <a class="btn btn-sm btn-light border" href="${safeUrl}">
                        <i class="fa-regular fa-eye me-1"></i>View booking
                    </a>
                    ${reviewControls}
                </div>`;
        }

        if (n.action_url) {
            return `<div class="notification-actions"><a class="btn btn-sm btn-light border" href="${safeUrl}">Open ${esc(relativeActionText(n))}<i class="fa-solid fa-arrow-right ms-1"></i></a></div>`;
        }
        return '';
    }

    function render(rows) {
        const list = $('notificationList');
        $('notificationEmpty').classList.toggle('d-none', rows.length > 0);

        if (!rows.length) {
            list.innerHTML = '';
            return;
        }

        list.innerHTML = rows.map((n) => {
            const pClass = priorityClass(n.priority);
            const unreadClass = Number(n.is_read) === 1 ? '' : 'unread';
            const readAction = Number(n.is_read) === 1 ? 'unread' : 'read';
            const readLabel = Number(n.is_read) === 1 ? 'Mark unread' : 'Mark read';
            const title = esc(n.title);
            const message = esc(n.message);

            return `
                <article class="notification-item ${unreadClass} ${pClass}" data-id="${Number(n.id)}">
                    <div class="notification-severity"></div>
                    <div class="notification-icon ${pClass}"><i class="fa-solid ${categoryIcon(n.category)}"></i></div>
                    <div class="notification-content">
                        <div class="notification-top">
                            <div class="notification-meta">
                                <span class="notification-category"><i class="fa-solid ${categoryIcon(n.category)}"></i>${esc(categoryLabel(n.category))}</span>
                                <span class="notification-dot">•</span>
                                <span class="notification-time">${esc(timeAgo(n.created_at))}</span>
                            </div>
                            <div class="notification-top-right">
                                ${Number(n.is_read) === 1 ? '' : '<span class="unread-pill"><span></span>NEW</span>'}
                                <span class="priority-pill ${pClass}">${esc(n.priority)}</span>
                            </div>
                        </div>
                        <h5>${title}</h5>
                        <p>${message}</p>
                        ${actionButtons(n)}
                    </div>
                    <div class="notification-menu">
                        <button class="notification-menu-btn" onclick="crmToggleMenu(event,${Number(n.id)})" aria-label="Notification actions"><i class="fa-solid fa-ellipsis-vertical"></i></button>
                        <div class="notification-menu-pop" id="nm-${Number(n.id)}">
                            <button onclick="crmMarkNotification(${Number(n.id)},'${readAction}')"><i class="fa-regular fa-envelope me-2"></i>${readLabel}</button>
                            <button class="danger-action" onclick="crmArchiveNotification(${Number(n.id)})"><i class="fa-regular fa-trash-can me-2"></i>Archive</button>
                        </div>
                    </div>
                </article>`;
        }).join('');
    }

    function updateStats(rows, total, unread) {
        $('statUnread').textContent = Number(unread || 0);
        $('statAll').textContent = Number(total || 0);
        $('statApprovals').textContent = rows.filter((item) => item.category === 'approvals').length;
        $('statBookings').textContent = rows.filter((item) => item.category === 'bookings' || item.entity_type === 'booking').length;
    }

    function updateQueueHeading() {
        const names = { all: 'All notifications', approvals: 'Approval queue', bookings: 'Booking activity', leads: 'Lead activity', finance: 'Finance alerts', documents: 'Document alerts', system: 'System alerts' };
        $('queueTitle').textContent = names[state.category] || 'Notifications';
        $('queueSubtitle').textContent = state.unread ? 'Showing unread items only' : (state.search ? `Results for “${state.search}”` : 'Latest activity first');
    }

    async function load() {
        if (loading) return;
        loading = true;
        updateQueueHeading();
        const list = $('notificationList');
        list.classList.add('is-loading');
        list.innerHTML = `<div class="notification-loading"><span class="loading-ring"></span><div><strong>Loading your notifications</strong><small>Checking the latest CRM activity...</small></div></div>`;

        const query = new URLSearchParams({
            action: 'list', page: String(state.page), category: state.category,
            unread: String(state.unread), search: state.search, per_page: '20'
        });

        try {
            const response = await fetch(endpoint + '?' + query.toString(), {
                cache: 'no-store', credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to load notifications.');

            const payload = data.data || {};
            render(payload.notifications || []);
            updateStats(payload.notifications || [], payload.pagination?.total || 0, payload.unread || 0);

            const pagination = payload.pagination || {};
            $('notificationPagination').classList.toggle('d-none', !pagination.pages || pagination.pages <= 1);
            $('paginationInfo').textContent = pagination.total
                ? `Page ${pagination.page} of ${pagination.pages} • ${pagination.total} notification${pagination.total === 1 ? '' : 's'}`
                : 'No notifications';
            $('prevPage').disabled = Number(pagination.page || 1) <= 1;
            $('nextPage').disabled = Number(pagination.page || 1) >= Number(pagination.pages || 1);

            document.querySelectorAll('.notification-count').forEach((badge) => {
                const count = Number(payload.unread || 0);
                badge.textContent = count > 99 ? '99+' : String(count);
                badge.style.display = count > 0 ? 'inline-block' : 'none';
            });
        } catch (error) {
            list.innerHTML = `<div class="notification-error"><div class="error-icon"><i class="fa-solid fa-triangle-exclamation"></i></div><div><strong>Unable to load notifications</strong><p>${esc(error.message)}</p><button class="btn btn-sm btn-outline-danger" onclick="crmLoadNotifications()">Try again</button></div></div>`;
        } finally {
            list.classList.remove('is-loading');
            loading = false;
        }
    }

    async function postAction(action, id = 0) {
        const form = new FormData();
        form.append('action', action);
        if (id) form.append('id', String(id));
        const response = await fetch(endpoint, { method: 'POST', body: form, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Action failed.');
        return data;
    }

    window.crmToggleMenu = (event, id) => {
        event.stopPropagation();
        document.querySelectorAll('.notification-menu-pop.show').forEach((menu) => menu.classList.remove('show'));
        document.getElementById('nm-' + id)?.classList.toggle('show');
    };

    window.crmMarkNotification = async (id, action) => {
        try {
            await postAction(action, id);
            if (window.toastr) toastr.success(action === 'read' ? 'Notification marked as read.' : 'Notification marked as unread.');
            load();
            if (window.crmLoadNotificationHeader) window.crmLoadNotificationHeader();
        } catch (error) {
            if (window.toastr) toastr.error(error.message);
        }
    };

    window.crmArchiveNotification = async (id) => {
        try {
            await postAction('archive', id);
            if (window.toastr) toastr.success('Notification archived.');
            load();
            if (window.crmLoadNotificationHeader) window.crmLoadNotificationHeader();
        } catch (error) {
            if (window.toastr) toastr.error(error.message);
        }
    };

    window.crmReviewNotification = async (notificationId, requestId, type, status, reason = '') => {
        const url = type === 'edit' ? '../actions/booking/edit_request.php' : '../actions/booking/delete_request.php';
        const form = new FormData();
        form.append('action', 'status');
        form.append('id', String(requestId));
        form.append('status', status);
        form.append('reason', reason);

        const button = document.querySelector(`[data-id="${Number(notificationId)}"] .btn-success`);
        if (button) {
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Processing';
        }

        try {
            const response = await fetch(url, { method: 'POST', body: form, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Review failed.');
            await postAction('archive', notificationId);
            if (window.toastr) toastr.success(data.message || 'Request updated successfully.');
            load();
            if (window.crmLoadNotificationHeader) window.crmLoadNotificationHeader();
        } catch (error) {
            if (button) {
                button.disabled = false;
                button.innerHTML = button.dataset.originalText || 'Approve';
            }
            if (window.toastr) toastr.error(error.message);
            else alert(error.message);
        }
    };

    window.crmOpenReject = (notificationId, requestId, type) => {
        rejectPayload = { notificationId, requestId, type };
        $('notificationRejectReason').value = '';
        $('rejectCharCount').textContent = '0';
        const modal = bootstrap.Modal.getOrCreateInstance($('notificationRejectModal'));
        modal.show();
        setTimeout(() => $('notificationRejectReason').focus(), 250);
    };

    async function confirmReject() {
        if (!rejectPayload) return;
        const reason = $('notificationRejectReason').value.trim();
        if (!reason) {
            $('notificationRejectReason').classList.add('is-invalid');
            $('notificationRejectReason').focus();
            return;
        }
        $('notificationRejectReason').classList.remove('is-invalid');
        const payload = rejectPayload;
        const button = $('confirmNotificationReject');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Rejecting...';
        try {
            await crmReviewNotification(payload.notificationId, payload.requestId, payload.type, 'Rejected', reason);
            bootstrap.Modal.getOrCreateInstance($('notificationRejectModal')).hide();
            rejectPayload = null;
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fa-solid fa-xmark me-1"></i>Reject request';
        }
    }

    $('confirmNotificationReject').addEventListener('click', confirmReject);
    $('notificationRejectReason').addEventListener('input', (event) => {
        $('rejectCharCount').textContent = String(event.target.value.length);
        event.target.classList.remove('is-invalid');
    });

    $('markAllRead').addEventListener('click', async () => {
        try {
            await postAction('mark_all_read');
            if (window.toastr) toastr.success('All notifications marked as read.');
            load();
            if (window.crmLoadNotificationHeader) window.crmLoadNotificationHeader();
        } catch (error) { if (window.toastr) toastr.error(error.message); }
    });

    $('refreshNotifications').addEventListener('click', () => load());
    $('applyNotificationFilter').addEventListener('click', () => {
        state.page = 1;
        state.category = $('notificationCategory').value;
        state.unread = Number($('notificationState').value);
        state.search = $('notificationSearch').value.trim();
        $('clearNotificationSearch').classList.toggle('d-none', !state.search);
        document.querySelectorAll('.notification-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.category === state.category));
        load();
    });

    function resetFilters() {
        state.page = 1; state.category = 'all'; state.unread = 0; state.search = '';
        $('notificationCategory').value = 'all'; $('notificationState').value = '0'; $('notificationSearch').value = '';
        $('clearNotificationSearch').classList.add('d-none');
        document.querySelectorAll('.notification-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.category === 'all'));
        load();
    }

    $('clearNotificationFilters').addEventListener('click', resetFilters);
    $('emptyReset').addEventListener('click', resetFilters);
    $('clearNotificationSearch').addEventListener('click', () => { $('notificationSearch').value = ''; state.search = ''; $('clearNotificationSearch').classList.add('d-none'); state.page = 1; load(); });
    $('notificationSearch').addEventListener('input', () => $('clearNotificationSearch').classList.toggle('d-none', !$('notificationSearch').value));
    $('notificationSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') $('applyNotificationFilter').click(); });

    document.querySelectorAll('.notification-tab').forEach((tab) => tab.addEventListener('click', () => {
        document.querySelectorAll('.notification-tab').forEach((item) => item.classList.remove('active'));
        tab.classList.add('active');
        state.page = 1; state.category = tab.dataset.category;
        $('notificationCategory').value = state.category;
        load();
    }));

    $('prevPage').addEventListener('click', () => { if (state.page > 1) { state.page -= 1; load(); } });
    $('nextPage').addEventListener('click', () => { state.page += 1; load(); });
    document.addEventListener('click', () => document.querySelectorAll('.notification-menu-pop.show').forEach((menu) => menu.classList.remove('show')));
    window.crmLoadNotifications = load;
    load();
})();
</script>

<?php include "../includes/footer.php"; ?>
