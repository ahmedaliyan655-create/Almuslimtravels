<?php

require_once "../includes/auth.php";
requireLogin();
if (!in_array(authRole(), ['manager', 'admin'], true)) { http_response_code(403); exit('Permission denied.'); }

$pageTitle = "Projects";

include "../includes/header.php";
include "../includes/sidebar.php";

?>

<link rel="stylesheet" href="../assets/css/pages/projects.css">

<div class="main-content">

    <!--==================================================
        PAGE HEADER
    ==================================================-->

    <div class="page-header d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="page-title">
                <i class="fa-solid fa-diagram-project text-primary me-2"></i>
                Projects
            </h2>

            <p class="page-subtitle">
                Manage all company projects, websites and project assignments.
            </p>

        </div>

        <!-- <button class="btn btn-danger" id="btnCancel">

            <i class="fa-solid fa-xmark me-2"></i>

            Cancel

        </button> -->

    </div>


    <!--==================================================
        STATISTICS
    ==================================================-->

    <div class="row g-3 mb-4">

        <div class="col-lg-3 col-md-6">

            <div class="project-stat-card card-total">

                <div class="stat-icon">

                    <i class="fa-solid fa-diagram-project"></i>

                </div>

                <div>

                    <div class="stat-number" id="totalProjects">
                        0
                    </div>

                    <div class="stat-text">
                        Total Projects
                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6">

            <div class="project-stat-card card-active">

                <div class="stat-icon">

                    <i class="fa-solid fa-circle-check"></i>

                </div>

                <div>

                    <div class="stat-number" id="activeProjects">
                        0
                    </div>

                    <div class="stat-text">
                        Active Projects
                    </div>

                </div>

            </div>

        </div>

        <!-- <div class="col-lg-3 col-md-6">

            <div class="project-stat-card card-website">

                <div class="stat-icon">

                    <i class="fa-solid fa-globe"></i>

                </div>

                <div>

                    <div class="stat-number" id="websiteProjects">
                        0
                    </div>

                    <div class="stat-text">
                        Websites
                    </div>

                </div>

            </div>

        </div> -->

        <!-- <div class="col-lg-3 col-md-6">

            <div class="project-stat-card card-income">

                <div class="stat-icon">

                    <i class="fa-solid fa-chart-line"></i>

                </div>

                <div>

                    <div class="stat-number" id="projectRevenue">
                        £0
                    </div>

                    <div class="stat-text">
                        Total Revenue
                    </div>

                </div>

            </div>

        </div> -->

    </div>


    <!--==================================================
        FORM
    ==================================================-->

    <div class="card project-card">

        <div class="card-header">

            <h4>

                <i class="fa-solid fa-folder-plus text-success me-2"></i>

                Add New Project

            </h4>

        </div>

        <div class="card-body">

            <form id="projectForm" enctype="multipart/form-data">

                <input
                    type="hidden"
                    id="project_id"
                    name="project_id">

                <div class="row">

                    <!--==================================
                        LOGO
                    ==================================-->

                    <div class="col-lg-3">

                        <label class="form-label">

                            Project Logo

                        </label>

                        <div class="logo-upload-box">

                            <img
                                src="https://placehold.co/180x180?text=Logo"
                                id="logoPreview"
                                class="project-logo-preview">

                        </div>

                        <input
                            type="file"
                            class="form-control mt-3"
                            id="projectLogo"
                            name="project_logo"
                            accept="image/*">

                    </div>

                    <!--==================================
                        DETAILS
                    ==================================-->

                    <div class="col-lg-9">

                        <div class="row">

                            <div class="col-md-6 mb-3">

                                <label class="form-label">

                                    Project Name *

                                </label>

                                <input
                                    type="text"
                                    class="form-control"
                                    id="project_name"
                                    name="project_name"
                                    placeholder="e.g. Aqua Safe">

                            </div>

                            <div class="col-md-6 mb-3">

                                <label class="form-label">

                                    Project Code *

                                </label>

                                <input
                                    type="text"
                                    class="form-control"
                                    id="project_code"
                                    name="project_code"
                                    placeholder="AQSAFE">

                            </div>

                            <div class="col-md-8 mb-3">

                                <label class="form-label">

                                    Website

                                </label>

                                <input
                                    type="url"
                                    class="form-control"
                                    id="website"
                                    name="website"
                                    placeholder="https://example.com">

                            </div>

                            <div class="col-md-4 mb-3">

                                <label class="form-label">

                                    Status

                                </label>

                                <select
                                    class="form-select"
                                    id="status"
                                    name="status">

                                    <option value="1">

                                        Active

                                    </option>

                                    <option value="0">

                                        Inactive

                                    </option>

                                </select>

                            </div>

                            <div class="col-12">

                                <label class="form-label">

                                    Notes

                                </label>

                                <textarea
                                    class="form-control"
                                    rows="4"
                                    id="notes"
                                    name="notes"
                                    placeholder="Optional notes about this project..."></textarea>

                            </div>

                        </div>

                    </div>

                </div>

                <hr class="my-4">

                <button
                    type="submit"
                    class="btn btn-success px-4"
                    id="btnSaveProject">

                    <i class="fa-solid fa-floppy-disk me-2"></i>

                    Save Project

                </button>

                <button
                    type="reset"
                    class="btn btn-secondary px-4 ms-2"
                    id="btnResetProject">

                    <i class="fa-solid fa-rotate me-2"></i>

                    Reset

                </button>

            </form>

        </div>

    </div>
        <!--==================================================
        PROJECT LIST
    ==================================================-->

    <div class="card project-table-card mt-4">

        <div class="card-header d-flex justify-content-between align-items-center">

            <h4 class="mb-0">

                <i class="fa-solid fa-table-list me-2"></i>

                All Projects

            </h4>

            <span class="badge bg-primary fs-6" id="totalProjectBadge">

                0 Projects

            </span>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table
                    class="table table-hover align-middle"
                    id="projectsTable"
                    width="100%">

                    <thead>

                        <tr>

                            <th width="50">#</th>

                            <th width="90">Logo</th>

                            <th>Project</th>

                            <th>Project Code</th>

                            <th>Website</th>

                            <th class="text-center">Status</th>

                            <th width="150" class="text-center">Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap5.js"></script>

<script src="../assets/js/pages/projects.js"></script>

<?php include "../includes/footer.php"; ?>