<?php

require_once "includes/session.php";

if (isset($_SESSION['agent_id'])) {

    header("Location: modules/dashboard.php");
    exit;
}

header("Location: login.php");
exit;