# Al Muslim Travel CRM

Core PHP / MySQL CRM for bookings, leads, staff, projects, teams, payments and alerts.

## Clean installation (XAMPP)

1. Make sure Apache, MySQL/MariaDB and PHP 8.2+ are running.
2. Open `includes/config.php` and confirm `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASS`.
3. Open `install.php` in the browser. The installer creates the configured database and imports the clean `amt_crm.sql` schema.
4. The installer creates the initial sample accounts only when the `agents` table is empty.
5. Log in through `login.php`.
6. Delete `install.php` and `upgrade.php` from production after setup.

## Existing database

Use `upgrade.php` while logged in as Manager/Admin. It checks the schema before adding missing booking workflow tables/columns, including:

- Booking edit approval requests
- Booking delete approval requests
- Booking alert reminders
- Flight supplier
- Hotel supplier
- Visa supplier
- Transport supplier
- `agents.is_active` compatibility

## Booking workflow

- View opens the existing booking modal in read-only mode.
- The booking modal closes only through its Close/X or Cancel controls; clicking the backdrop does not close it.
- View mode provides a PDF snapshot button.
- Manager/Admin/Administrator can edit existing bookings without requiring their own account to have a project assignment. The existing booking project is preserved.
- Agents require approval from Manager/Admin/Team Lead before editing or deleting their own booking.
- Manager/Admin can assign a booking to an active agent in the booking project; Team Lead is restricted to their team.
- Supplier fields are available for flight, hotel, visa and transport services.
- Alert Reminder allows users to schedule one-time booking reminders scoped to their permissions.


Save booking fix: booking_payments now stores profile_id/payer_name and binds payment_status correctly; passenger title enum includes Child/Infant. Existing installations receive compatibility migrations automatically.
