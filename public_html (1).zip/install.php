<?php

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once __DIR__ . '/includes/config.php';

$messages = [];
$error = null;
function h($s)
{
  return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
try {
  if (!extension_loaded('pdo')) throw new RuntimeException('PHP PDO extension is not enabled.');
  if (!extension_loaded('pdo_mysql')) throw new RuntimeException('PHP pdo_mysql extension is not enabled. Enable it in php.ini and restart Apache.');
  $server = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
  $safeDb = preg_replace('/[^a-zA-Z0-9_]/', '', DB_NAME);
  $server->exec("CREATE DATABASE IF NOT EXISTS `$safeDb` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  $db = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
  $sql = file_get_contents(__DIR__ . '/amt_crm.sql');
  if ($sql === false) throw new RuntimeException('amt_crm.sql could not be read.');
  $existing = $db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
  $existing = array_map('strtolower', $existing);
  if (!$existing) {
    $db->exec($sql);
    $messages[] = 'Fresh database schema and seed data imported successfully.';
  } else {
    // Upgrade mode: never re-run INSERT/DELETE/TRUNCATE against an existing database.
    // Only CREATE TABLE blocks for genuinely missing tables are executed.
    preg_match_all('/CREATE TABLE\s+`([^`]+)`\s*\((.*?)\)\s*ENGINE=.*?;/is', $sql, $matches, PREG_SET_ORDER);
    $created = 0;
    $skipped = 0;
    foreach ($matches as $m) {
      $table = $m[1];
      if (in_array(strtolower($table), $existing, true)) {
        $skipped++;
        continue;
      }
      $stmt = $m[0];
      $stmt = preg_replace('/^CREATE TABLE\s+`[^`]+`/i', 'CREATE TABLE IF NOT EXISTS `' . $table . '`', $stmt, 1);
      $db->exec($stmt);
      $created++;
    }
    $messages[] = "Existing database detected. Preserved all existing data; created $created missing table(s) and skipped $skipped existing table(s).";
    $messages[] = 'No seed INSERTs, DELETEs, TRUNCATEs or destructive schema operations were executed in upgrade mode.';
  }
  // Fresh schema already contains all booking workflow tables/columns. The upgrade script is available for older databases.
  $check = (int)$db->query('SELECT COUNT(*) FROM agents')->fetchColumn();
  if ($check === 0) {
    $stmt = $db->prepare("INSERT INTO agents(agent_code,name,email,phone,pin_hash,role,commission_pct,is_active) VALUES(?,?,?,?,?,?,?,1)");
    $seed = [['ADMIN001', 'Administrator', 'admin@almuslimtravel.com', '03001234567', '9999', 'manager', 0], ['AG10001', 'Sara Khan', 'sara@almuslimtravel.co.uk', '+44 7700 900555', '5555', 'teamlead', 20], ['AG10002', 'Ahmed Khan', 'ahmed@almuslimtravel.co.uk', '+44 7700 900111', '1111', 'agent', 5], ['AG10003', 'Bilal Hussain', 'bilal@almuslimtravel.co.uk', '+44 7700 900222', '2222', 'agent', 5], ['AG10004', 'Tariq Mahmood', 'tariq@almuslimtravel.co.uk', '+44 7811 223344', '3333', 'agent', 4]];
    foreach ($seed as $u) $stmt->execute([$u[0], $u[1], $u[2], $u[3], password_hash($u[4], PASSWORD_DEFAULT), $u[5], $u[6]]);
    $messages[] = 'No agents existed, so initial Manager/Admin/Team Lead/Agent users were created.';
  } else $messages[] = 'Existing agents preserved.';

  // Ensure a usable default project/team exists on a fresh install.
  $manager = (int)$db->query("SELECT id FROM agents WHERE role='manager' AND is_active=1 ORDER BY id LIMIT 1")->fetchColumn();
  $lead = (int)$db->query("SELECT id FROM agents WHERE role='teamlead' AND is_active=1 ORDER BY id LIMIT 1")->fetchColumn();
  $project = (int)$db->query("SELECT id FROM projects ORDER BY id LIMIT 1")->fetchColumn();
  if (!$project) {
    $st = $db->prepare("INSERT INTO projects(project_name,project_code,website,notes,monthly_target,is_active,status) VALUES(?,?,?,?,?,?,?)");
    $st->execute(['Al Muslim Travel', 'AMT', 'https://example.com', 'Default CRM project', 20, 1, 1]);
    $project = (int)$db->lastInsertId();
    $messages[] = 'Default CRM project created.';
  }
  if ($lead && !$db->query("SELECT id FROM teams ORDER BY id LIMIT 1")->fetchColumn()) {
    $st = $db->prepare("INSERT INTO teams(name,team_lead_id,monthly_target,created_by,work_type) VALUES(?,?,?,?,?)");
    $st->execute(['Operations Team', $lead, 20, $manager ?: $lead, 'both']);
    $team = (int)$db->lastInsertId();
    $agentIds = $db->query("SELECT id FROM agents WHERE role='agent' AND is_active=1 ORDER BY id LIMIT 10")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($agentIds as $aid) {
      $db->prepare("INSERT IGNORE INTO team_members(team_id,agent_id) VALUES(?,?)")->execute([$team, (int)$aid]);
      $db->prepare("UPDATE agents SET team_id=?, team_lead_id=?, default_project_id=? WHERE id=?")->execute([$team, $lead, $project, (int)$aid]);
    }
    $db->prepare("UPDATE agents SET default_project_id=? WHERE id IN (?,?)")->execute([$project, $lead, $manager]);
    $messages[] = 'Default Operations Team created and linked to sample agents.';
  }
} catch (Throwable $e) {
  $error = $e->getMessage();
}
?>
<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Al Muslim CRM Installer</title>
  <style>
    body {
      margin: 0;
      background: #f1f5f9;
      font-family: Inter, system-ui;
      padding: 40px
    }

    .box {
      max-width: 720px;
      margin: auto;
      background: #fff;
      border-radius: 18px;
      padding: 35px;
      box-shadow: 0 20px 60px #0c234020
    }

    h1 {
      color: #0c2340
    }

    .ok {
      background: #ecfdf5;
      color: #065f46;
      padding: 14px;
      border-radius: 10px;
      margin: 10px 0
    }

    .err {
      background: #fef2f2;
      color: #991b1b;
      padding: 16px;
      border-radius: 10px;
      white-space: pre-wrap
    }

    .btn {
      display: inline-block;
      background: #0c2340;
      color: #fff;
      padding: 12px 18px;
      border-radius: 9px;
      text-decoration: none;
      margin-top: 15px
    }
  </style>
</head>

<body>
  <div class="box">
    <h1>Al Muslim Travel CRM</h1>
    <p>Production installer & database setup</p><?php if ($error): ?><div class="err"><strong>Installation failed</strong><br><?= h($error) ?><br><br>Check DB_HOST, DB_NAME, DB_USER and DB_PASS in includes/config.php and confirm MySQL is running.</div><?php else: foreach ($messages as $m): ?><div class="ok"><?= h($m) ?></div><?php endforeach; ?><div class="ok"><strong>Installation/upgrade complete.</strong><br>Delete <code>install.php</code> from the server before going live.</div><a class="btn" href="login.php">Open CRM Login</a><?php endif; ?>
  </div>
</body>

</html>