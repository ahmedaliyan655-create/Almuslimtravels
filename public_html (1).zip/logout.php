<?php

require_once "includes/db.php";
require_once "includes/session.php";

if (isset($_SESSION['agent_id'])) {

   Database::update(

    "UPDATE agents
     SET
        login_status = 'Offline',
        last_logout = NOW()
     WHERE id = ?",

    [$_SESSION['agent_id']]

);

}

session_unset();
session_destroy();

header("Location: login.php");
exit;