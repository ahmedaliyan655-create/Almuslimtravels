<?php
declare(strict_types=1);

/**
 * Al Muslim Travel CRM - production configuration.
 * Prefer environment variables on live hosting; defaults are suitable for XAMPP.
 */
define('DB_HOST', getenv('AMT_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('AMT_DB_NAME') ?: 'u386843596_cornex_crm');
define('DB_USER', getenv('AMT_DB_USER') ?: 'u386843596_cornex');
define('DB_PASS', getenv('AMT_DB_PASS') ?: 'F^d9|hrzM2#^');

$base = rtrim((string)(getenv('AMT_BASE_URL') ?: ''), '/');
if ($base === '') {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $base = $scheme . '://' . $host . preg_replace('#/(modules|actions)$#', '', $script);
}
define('BASE_URL', rtrim($base, '/'));

define('SITE_NAME', 'Al Muslim Travel CRM');
define('APP_VERSION', '2.0.0');

/*
 * Public integration/webhook secret.
 * Set AMT_INTEGRATION_SECRET in the server environment in production.
 * Never commit a real secret to source control.
 */
define('INTEGRATION_SECRET', 'AMT-CRM-2026-SECRET');
date_default_timezone_set(getenv('AMT_TIMEZONE') ?: 'Asia/Karachi');

// Session INI options must be configured before session_start().
// Some existing CRM entry points start the session before loading config.php,
// so guard these settings to prevent PHP 7.2+ warnings/notices.
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', '28800');

    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }
}
