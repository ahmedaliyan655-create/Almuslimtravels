<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Al Muslim Travel CRM</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery (required by Leads CRM, Toastr and legacy CRM modules) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Toastr (must load before page-level CRM scripts) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <!-- Page-level dependencies: modules execute before footer.php, so load these here. -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
<link rel="stylesheet"
href="https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.css">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css?v=2.1.0">
<link rel="stylesheet" href="../assets/css/production.css?v=2.1.0">
</head>

<body>

    <div class="wrapper">

        <header class="main-header">

            <div class="header-left">

                <button id="sidebarToggle" class="menu-btn">

                    <i class="fas fa-bars"></i>

                </button>

                <h4 class="page-title mb-0"><?= htmlspecialchars($pageTitle ?? "Dashboard") ?></h4>

            </div>

            <div class="header-center">

            </div>

            <div class="header-right">

                <div class="welcome-text">

                    <span>Welcome,</span>

                    <strong><?= htmlspecialchars(authName()); ?></strong>

                </div>

                <div class="current-date">

                    <?php echo date('d M Y'); ?>

                </div>

                <div class="header-notification position-relative">
                    <button type="button" class="header-icon notification-bell-btn" id="notificationBell" aria-label="Notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger rounded-pill notification-count" style="display:none">0</span>
                    </button>
                    <div class="notification-dropdown" id="notificationDropdown">
                        <div class="notification-dropdown-head">
                            <div><strong>Notifications</strong><span id="headerUnreadText">0 unread</span></div>
                            <button type="button" id="headerMarkRead">Mark all read</button>
                        </div>
                        <div id="headerNotificationList" class="notification-dropdown-list">
                            <div class="notification-dropdown-loading"><i class="fa-solid fa-spinner fa-spin"></i></div>
                        </div>
                        <a class="notification-dropdown-footer" href="alerts.php">View all notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>

                <div class="dropdown">

                    <a href="profile.php" class="profile-dropdown dropdown-toggle" data-bs-toggle="dropdown">

                       <?php
                            $image = authImage();

                            if (!empty($image) && file_exists("../uploads/" . $image)) {
                                $avatar = "../uploads/" . $image;
                            } else {
                                $avatar = "https://ui-avatars.com/api/?name=" . urlencode(authName()) . "&background=16284e&color=ffffff";
                            }
                            ?>

                            <img src="<?= $avatar; ?>"
                                class="rounded-circle"
                                width="40"
                                height="40"
                                style="object-fit:cover;">

                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow">

                        <li>

                            <h6 class="dropdown-header">

                                <?= htmlspecialchars(authName()); ?>

                            </h6>

                        </li>

                        <li>

                            <a class="dropdown-item" href="profile.php">

                                <i class="fas fa-user me-2"></i>

                                Profile

                            </a>

                        </li>

                        <li>

                            <a class="dropdown-item" href="profile.php">

                                <i class="fas fa-cog me-2"></i>

                                Account Settings

                            </a>

                        </li>

                        <li>

                            <hr class="dropdown-divider">

                        </li>

                        <li>

                            <a class="dropdown-item text-danger" href="../logout.php">

                                <i class="fas fa-sign-out-alt me-2"></i>

                                Logout

                            </a>

                        </li>

                    </ul>

                </div>

            </div>

        </header>

        <div class="main-container">