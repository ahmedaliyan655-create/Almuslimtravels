 <div class="wizard-footer">

            <button class="btn btn-secondary" id="wizardPrevious">

                Previous

            </button>

            <button class="btn btn-primary" id="wizardNext">

                Next

            </button>

        </div>