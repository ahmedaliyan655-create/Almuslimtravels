<div class="booking-wizard-header">

            <div>

                <h3>New Booking</h3>

                <small>Create Customer Booking</small>

            </div>
            <div class="justify-content-end">
             <button

                        type="button"

                        class="btn btn-primary"

                        id="openSabreParser">

                        ✈ Sabre PNR

             </button>
            <button

            type="button"

            class="btn btn-success"

            id="packageImport">

            📦 Package Import

            </button>
            <button class="wizard-close" id="closeBookingWizard">

                <i class="fas fa-times"></i>

                Close

            </button>
            </div>
</div>