<div class="wizard-page" id="step6">

    <!-- =======================================================
        COST & MARGIN
    ======================================================== -->

    <div class="card shadow-sm mb-4">

        <div class="card-header text-center fw-bold">

            Cost and Margin

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table align-middle">

                    <thead class="table-dark">

                        <tr>

                            <th style="width:140px;">Age</th>

                            <th style="width:70px;">No</th>

                            <th style="width:110px;">Base Fare</th>

                            <th style="width:110px;">Tax</th>

                            <th>Net Cost</th>

                            <th>Total Net</th>

                            <th style="width:120px;">Selling Price</th>

                            <th>Selling Total</th>

                            <th>Margin</th>

                            <th style="width:80px;"></th>

                        </tr>

                    </thead>

                    <tbody id="costRows">

                    </tbody>

                    <tfoot>

                        <tr class="fw-bold">

                            <td colspan="5">

                                Grand Total

                            </td>

                            <td id="grandNet">0.00</td>

                            <td></td>

                            <td id="grandSelling">0.00</td>

                            <td id="grandMargin">0.00</td>

                            <td></td>

                        </tr>

                    </tfoot>

                </table>

            </div>

            <button

                class="btn btn-success btn-sm"

                id="addCost">

                + Add Cost

            </button>

            <div class="row mt-4">

                <div class="col-md-4">

                    <label>ATOL Charges (£)</label>

                    <input

                        type="number"

                        id="atolCharge"

                        class="form-control"

                        value="0">

                </div>

                <div class="col-md-4">

                    <label>SAFI Charges (£)</label>

                    <input

                        type="number"

                        id="safiCharge"

                        class="form-control"

                        value="0">

                </div>

                <div class="col-md-4">

                    <label>Discount (£)</label>

                    <input

                        type="number"

                        id="discount"

                        class="form-control"

                        value="0">

                </div>

            </div>

            <div class="row text-center mt-4">

                <div class="col">

                    <small>Gross Total</small>

                    <h5 id="grossTotal">£0.00</h5>

                </div>

                <div class="col">

                    <small>ATOL</small>

                    <h5 id="atolTotal">£0.00</h5>

                </div>

                <div class="col">

                    <small>Discount</small>

                    <h5 id="discountTotal">£0.00</h5>

                </div>

                <div class="col">

                    <small>Total Payable</small>

                    <h5 id="totalPayable">£0.00</h5>

                </div>

                <div class="col">

                    <small>Balance Due</small>

                    <h5 id="balanceDue">£0.00</h5>

                </div>

            </div>

        </div>

    </div>


    <!-- =======================================================
        PAYMENTS
    ======================================================== -->

    <div class="card shadow-sm">

        <div class="card-header text-center fw-bold">

            Payment(s) Received

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table">

                    <thead class="table-dark">

                        <tr>

                            <th>Receipt ID</th>

                            <th>Date</th>

                            <th>Pay Method</th>

                            <th>CR/DR</th>

                            <th>Amount (£)</th>

                            <th>Remarks</th>

                            <th></th>

                        </tr>

                    </thead>

                    <tbody id="paymentRows">

                    </tbody>

                </table>

            </div>

            <button

                class="btn btn-success btn-sm"

                id="addPayment">

                + Add Payment

            </button>

            <div class="text-end mt-3">

                <strong>

                    Total Received :

                    £<span id="totalReceived">0.00</span>

                </strong>

            </div>

        </div>

    </div>

</div>