<div class="wizard-page" id="step2">

    <div class="wizard-card mb-4">

        <div class="wizard-card-header">

            <h5>
                <i class="fas fa-user"></i>
                Customer Information
            </h5>

        </div>

        <div class="wizard-card-body">

            <div class="row">

                <!-- Client Name -->
                <div class="col-lg-4 mb-3">

                    <label class="form-label">

                        Client Full Name
                        <span class="text-danger">*</span>

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="customer_name"
                        name="customer_name"
                        placeholder="Mr Raja Adil Zeb">

                </div>

                <!-- Mobile -->
                <div class="col-lg-4 mb-3">

                    <label class="form-label">

                        Client Mobile
                        <span class="text-danger">*</span>

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="customer_mobile"
                        name="customer_mobile"
                        placeholder="+44 7700 900000">

                </div>

                <!-- Email -->
                <div class="col-lg-4 mb-3">

                    <label class="form-label">

                        Client Email

                    </label>

                    <input
                        type="email"
                        class="form-control"
                        id="customer_email"
                        name="customer_email"
                        placeholder="client@email.com">

                </div>

                <!-- Address -->
                <div class="col-lg-6 mb-3">

                    <label class="form-label">

                        Address

                    </label>

                    <textarea
                        class="form-control"
                        id="customer_address"
                        rows="3"></textarea>

                </div>

                <!-- City -->
                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        City

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="customer_city">

                </div>

                <!-- Country -->
                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        Country

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="customer_country">

                </div>

                <!-- Notes -->
                <div class="col-lg-12">

                    <label class="form-label">

                        Notes

                    </label>

                    <textarea
                        class="form-control"
                        id="customer_notes"
                        rows="4"
                        placeholder="Additional customer notes..."></textarea>

                </div>

            </div>

        </div>

    </div>

</div>