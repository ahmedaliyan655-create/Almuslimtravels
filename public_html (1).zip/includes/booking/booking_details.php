<div class="wizard-page active" id="step1">

    <div class="wizard-card mb-4">

        <div class="wizard-card-header">
            <h5>
                <i class="fas fa-file-alt"></i>
                Booking Information
            </h5>
        </div>

        <div class="wizard-card-body">

            <div class="row">

                <!-- Invoice No -->
               <div class="col-lg-3 mb-3">

                    <label class="form-label">
                        Invoice No
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="invoice_no"
                        name="invoice_no"
                        readonly>

                </div>

                <div class="col-lg-3 mb-3">

                    <label class="form-label">
                        Project Code
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="invoice_prefix"
                        name="invoice_prefix"
                        readonly>

                </div>

                <!-- Invoice Date -->

                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        Invoice Date

                    </label>

                    <input
                        type="date"
                        class="form-control"
                        id="invoice_date"
                        name="invoice_date"
                        value="<?= date('Y-m-d') ?>">

                </div>

                <!-- Due Date -->

                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        Due Date

                    </label>

                    <input
                        type="date"
                        class="form-control"
                        id="due_date"
                        name="due_date">

                </div>

            </div>

        </div>

    </div>
    <div class="wizard-card mb-4">

        <div class="wizard-card-header">

            <h5>

                <i class="fas fa-suitcase"></i>

                Booking Details

            </h5>

        </div>

        <div class="wizard-card-body">

            <div class="row">

                <!-- Travel Date -->

                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        Travel Date

                    </label>

                    <input
                        type="date"
                        class="form-control"
                        id="travel_date"
                        name="travel_date">

                </div>

                <!-- Status -->

                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        Status

                    </label>

                    <select
                        class="form-select"
                        id="status"
                        name="status">

                        <option value="New">New</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Departed">Departed</option>
                        <option value="In Makkah">In Makkah</option>
                        <option value="In Madinah">In Madinah</option>
                        <option value="Returning">Returning</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>

                    </select>

                </div>

                <!-- Booking Source -->

                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        GDS PNR

                    </label>

                     <input
                        type="text"
                        class="form-control"
                        id="GDS_PNR"
                        name="booking_type">

                </div>

                <!-- Booking Type -->

                <div class="col-lg-3 mb-3">

                    <label class="form-label">

                        Airline PNR

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="Airline_PNR"
                        name="Airline_PNR">

                </div>

            </div>

        </div>

    </div>
    <div class="wizard-card mb-4">

        <div class="wizard-card-header">

            <h5>

                <i class="fas fa-suitcase"></i>

                Book By

            </h5>

        </div>

        <div class="wizard-card-body">

            <div class="row">

    


                <?php

                $loginRole = $_SESSION['role'];
                $loginId   = $_SESSION['agent_id'];

                ?>

                <div class="col-lg-4 mb-3">

                    <label class="form-label">
                        Agent
                    </label>

                        <?php

                        /*--------------------------------------
                        Admin / Manager
                        --------------------------------------*/

                        if($loginRole=="admin" || $loginRole=="manager"){

                            $agents = Database::select("
                                SELECT id,name
                                FROM agents
                                WHERE is_active=1
                                ORDER BY name ASC
                            ");

                        ?>

                        <select
                            class="form-select"
                            id="agent_id"
                            name="agent_id">

                            <?php foreach($agents as $agent){ ?>

                                <option value="<?= $agent['id']; ?>">

                                    <?= htmlspecialchars($agent['name']); ?>

                                </option>

                            <?php } ?>

                        </select>

                        <?php

                        }else{

                            $agent = Database::selectOne("
                                SELECT id,name
                                FROM agents
                                WHERE id=?
                            ",[$loginId]);

                        ?>

                    <input
                        type="text"
                        class="form-control"
                        value="<?= htmlspecialchars($agent['name']); ?>"
                        disabled>

                    <input
                        type="hidden"
                        name="agent_id"
                        value="<?= $agent['id']; ?>">

                    <?php } ?>

                </div>

                <!-- Status -->

                <div class="col-lg-4 mb-3">

                <label class="form-label">

                Project

                </label>

                <?php

                if($loginRole=="admin" || $loginRole=="manager"){

                    $projects = Database::select("
                        SELECT id,project_name,project_code
                        FROM projects
                        WHERE is_active=1
                        ORDER BY project_name
                    ");

                ?>

                <select
                    class="form-select"
                    id="project_id"
                    name="project_id">

                <?php foreach($projects as $project){ ?>

                <option value="<?= $project['id']; ?>" data-project-code="<?= htmlspecialchars(strtoupper((string)($project['project_code'] ?? "")), ENT_QUOTES, "UTF-8"); ?>">

                <?= htmlspecialchars($project['project_name']); ?>

                </option>

                <?php } ?>

                </select>

                <?php

                }else{

                    $projects = Database::select("

                        SELECT

                            p.id,
                            p.project_name,
                            p.project_code

                        FROM agent_projects ap

                        INNER JOIN projects p

                            ON p.id=ap.project_id

                        WHERE ap.agent_id=?

                        ORDER BY p.project_name

                    ",[$loginId]);

                ?>

                <select
                    class="form-select"
                    id="project_id"
                    name="project_id"

                <?= count($projects)==1 ? 'disabled' : '' ?>

                >

                <?php foreach($projects as $project){ ?>

                <option value="<?= $project['id']; ?>" data-project-code="<?= htmlspecialchars(strtoupper((string)($project['project_code'] ?? "")), ENT_QUOTES, "UTF-8"); ?>">

                <?= htmlspecialchars($project['project_name']); ?>

                </option>

                <?php } ?>

                </select>

                <?php

                if(count($projects)==1){

                ?>

                <input
                    type="hidden"
                    id="project_id_hidden"
                    value="<?= $projects[0]['id']; ?>">

                <?php

                }

                }

                ?>

                </div>

                <!-- Booking Source -->

               <div class="col-lg-4 mb-3">

                <label class="form-label">

                Currency

                </label>

                <input
                    type="text"
                    class="form-control"
                    name="currency"
                    value="GBP"
                    readonly>

                </div>

            </div>

        </div>

    </div>
</div>