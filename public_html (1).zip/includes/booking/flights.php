<div class="wizard-page" id="step4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">
                <i class="fas fa-plane text-primary me-2"></i>
                Flight Information
            </h3>

            <p class="text-muted mb-0">
                Add one or more flight sectors for this booking.
            </p>

        </div>

        <button
            type="button"
            class="btn btn-success"
            id="addFlight">

            <i class="fas fa-plus me-2"></i>

            Add Flight Leg

        </button>

    </div>

    <div id="flightContainer">

    </div>

</div>