<div class="wizard-page" id="step3">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">
                <i class="fas fa-users text-primary me-2"></i>
                Passenger Information
            </h3>

            <p class="text-muted mb-0">
                Add or manage all passengers travelling in this booking.
            </p>

        </div>

        <button
            type="button"
            class="btn btn-success"
            id="addPassenger">

            <i class="fas fa-plus me-2"></i>

            Add Passenger

        </button>

    </div>

    <div id="passengerContainer">

    </div>

</div>