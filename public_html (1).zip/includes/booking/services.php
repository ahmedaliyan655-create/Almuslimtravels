<div class="wizard-page" id="step5">

    <h4>Services</h4>

    <div class="card mb-4">

        <div class="card-header text-center fw-bold">

            Hotel Details

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table align-middle" id="hotelTable">

                    <thead class="table-dark">

                        <tr>

                            <th>Hotel Name</th>

                            <th>City</th>

                            <th>Room Type</th>

                            <th>Rooms</th>

                            <th>Meal</th>

                            <th>View</th>

                            <th>Check In</th>

                            <th>Nights</th>

                            <th>Check Out</th>

                            <th>Reservation No</th>

                            <th>Supplier</th>

                            <th width="50"></th>

                        </tr>

                    </thead>

                    <tbody>

                        <tr>

                            <td>

                                <input type="text"
                                    class="form-control hotel-name">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control hotel-city">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control hotel-room-type">

                            </td>

                            <td>

                                <input type="number"
                                    class="form-control hotel-rooms"
                                    value="1">

                            </td>

                            <td>

                                <select class="form-select hotel-meal">

                                    <option>R/O</option>

                                    <option>B/B</option>

                                    <option>H/B</option>

                                    <option>F/B</option>

                                </select>

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control hotel-view">

                            </td>

                            <td>

                                <input type="date"
                                    class="form-control hotel-checkin">

                            </td>

                            <td>

                                <input type="number"
                                    class="form-control hotel-nights">

                            </td>

                            <td>

                                <input type="date"
                                    class="form-control hotel-checkout">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control hotel-reservation">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control hotel-supplier"
                                    placeholder="Supplier">

                            </td>

                            <td>

                                <button class="btn btn-danger btn-sm removeHotel">

                                    ×

                                </button>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

            <button
                class="btn btn-success btn-sm"
                id="addHotel">

                + Add Hotel

            </button>

        </div>

    </div>

    <div class="card mb-4">

        <div class="card-header text-center fw-bold">

            Transport Details

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table" id="transportTable">

                    <thead class="table-dark">

                        <tr>

                            <th>Vehicle</th>

                            <th>Journey</th>

                            <th>Vehicles</th>

                            <th>Pickup Date</th>

                            <th>Pickup Time</th>

                            <th>Notes</th>

                            <th>Supplier</th>

                            <th width="50"></th>

                        </tr>

                    </thead>

                    <tbody>

                        <tr>

                            <td>

                                <input type="text"
                                    class="form-control transport-vehicle">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control transport-journey">

                            </td>

                            <td>

                                <input type="number"
                                    class="form-control transport-vehicles"
                                    value="1">

                            </td>

                            <td>

                                <input type="date"
                                    class="form-control transport-date">

                            </td>

                            <td>

                                <input type="time"
                                    class="form-control transport-time">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control transport-notes">

                            </td>

                            <td>

                                <input type="text"
                                    class="form-control transport-supplier"
                                    placeholder="Supplier">

                            </td>

                            <td>

                                <button class="btn btn-danger btn-sm removeTransport">

                                    ×

                                </button>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

            <button
                class="btn btn-success btn-sm"
                id="addTransport">

                + Add Transport

            </button>

        </div>

    </div>

    <div class="card">

        <div class="card-header text-center fw-bold">

            Additional Products

        </div>

        <div class="card-body">

            <table class="table" id="productTable">

                <tbody>

                    <tr>

                        <td>

                            <input type="text"
                                class="form-control product-name">

                        </td>

                        <td>

                            <input type="text"
                                class="form-control product-supplier"
                                placeholder="Supplier">

                        </td>

                        <td width="50">

                            <button class="btn btn-danger btn-sm removeProduct">

                                ×

                            </button>

                        </td>

                    </tr>

                </tbody>

            </table>

            <button
                class="btn btn-success btn-sm"
                id="addProduct">

                + Add Product

            </button>

        </div>

    </div>

</div>