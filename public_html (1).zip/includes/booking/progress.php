<div class="wizard-progress">

            <div class="wizard-step active" data-step="1">

                <span>1</span>

                <p>Booking</p>

            </div>

            <div class="wizard-step" data-step="2">

                <span>2</span>

                <p>Customer</p>

            </div>

            <div class="wizard-step" data-step="3">

                <span>3</span>

                <p>Passengers</p>

            </div>

            <div class="wizard-step" data-step="4">

                <span>4</span>

                <p>Flights</p>

            </div>

            <div class="wizard-step" data-step="5">

                <span>5</span>

                <p>Services</p>

            </div>

            <div class="wizard-step" data-step="6">

                <span>6</span>

                <p>Costing</p>

            </div>

        </div>
