
<!-- =========================================================
     CREATE NEW BOOKING MODAL
========================================================= -->

<div id="bookingModal" class="booking-modal">
        <input
        type="hidden"
        id="editBookingId"
        name="booking_id"
        value=""
    >

    <div class="booking-modal-dialog">

        <!-- =====================================================
             MODAL HEADER
        ====================================================== -->

       <div class="booking-modal-header">

    <div class="booking-modal-header-content">
        <div class="booking-modal-title">
            Create New Booking
        </div>

        <div class="booking-modal-subtitle">
            Create a new customer booking
        </div>
    </div>

    <div class="booking-header-actions">

        <button type="button"
                class="btn btn-danger btn-sm booking-export-view-pdf"
                id="exportBookingViewPdf"
                style="display:none;"
                title="Export current booking view as PDF"
                onclick="exportBookingViewPdf(this.closest('#bookingModal')?.dataset.bookingId)">
            <i class="fas fa-file-pdf me-1"></i> PDF
        </button>

        <button type="button"
                class="btn-sabre-pnr"
                id="openSabrePNR">
            ✈ Sabre PNR
        </button>

        <button
            type="button"
            id="openPackageImport"
            class="package-btn"
        >
            📦 Package Import
        </button>

        <button type="button"
                class="booking-modal-close"
                id="closeBookingModal">
            &times;
        </button>

    </div>

</div>


        <!-- =====================================================
             MODAL BODY
        ====================================================== -->

        <div class="booking-modal-body">

            <div class="booking-container">


                <!-- =====================================================
                     BOOKING DETAILS
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        📋 Booking Details
                    </div>

                    <div class="form-grid grid-5">

                        <div class="field">

                            <label>Invoice No</label>

                            <input type="text"
                                   name="invoice_no"
                                   value="AMT1537">

                        </div>


                        <div class="field">

                            <label>Invoice Date</label>

                            <input type="date"
                                   name="invoice_date">

                        </div>


                        <div class="field">

                            <label>Due Date</label>

                            <input type="date"
                                   name="due_date">

                        </div>


                        <div class="field">

                            <label>GDS PNR</label>

                            <input type="text"
                                   name="pnr">

                        </div>


                        <div class="field">

                            <label>Airline PNR</label>

                            <input type="text"
                                   name="airline_pnr">

                        </div>


                        <div class="field">

                            <label>Travel Date</label>

                            <input type="date"
                                   name="travel_date">

                        </div>


                        <div class="field">

                            <label>Status</label>

                            <select name="status">

                                <option value="New">
                                    New
                                </option>

                                <option value="Confirmed">
                                    Confirmed
                                </option>

                                <option value="Pending">
                                    Pending
                                </option>

                                <option value="Cancelled">
                                    Cancelled
                                </option>

                                <option value="Completed">
                                    Completed
                                </option>

                            </select>

                        </div>


                        <div class="field">

                            <label>Client Name</label>

                            <input type="text"
                                   name="client_name"
                                   value="">

                        </div>


                        <div class="field">

                            <label>Client Mobile</label>

                            <input type="text"
                                   name="client_mobile">

                        </div>


                        <div class="field">

                            <label>Client Email</label>

                            <input type="email"
                                   name="client_email">

                        </div>

                    </div>

                </div>


                <!-- =====================================================
                     PASSENGERS
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        Passengers
                    </div>

                    <div class="table-wrapper">

                        <table class="booking-table">

                            <thead>

                                <tr>

                                    <th style="width:90px;">
                                        Title
                                    </th>

                                    <th>
                                        Surname
                                    </th>

                                    <th>
                                        First Name
                                    </th>

                                    <th style="width:50px;">
                                        Action
                                    </th>

                                </tr>

                            </thead>


                            <tbody id="passengerRows">

                                <tr>

                                    <td>

                                        <select name="passengers[0][title]">

                                            <option value="Mr">
                                                Mr
                                            </option>

                                            <option value="Mrs">
                                                Mrs
                                            </option>

                                            <option value="Ms">
                                                Ms
                                            </option>

                                            <option value="Miss">
                                                Miss
                                            </option>

                                            <option value="Child">
                                                Child
                                            </option>

                                        </select>

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="passengers[0][surname]"
                                               placeholder="SURNAME">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="passengers[0][firstname]"
                                               placeholder="FIRSTNAME">

                                    </td>


                                    <td>

                                        <button type="button"
                                                class="btn-delete"
                                                onclick="deleteRow(this)">

                                            ×

                                        </button>

                                    </td>

                                </tr>

                            </tbody>

                        </table>

                    </div>


                    <button type="button"
                            class="btn-add"
                            onclick="addPassenger()">

                        + Add Passenger

                    </button>

                </div>


                <!-- =====================================================
                     FLIGHT INFORMATION
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        Flight Information
                    </div>


                    <div class="table-wrapper">

                        <table class="booking-table">

                            <thead>

                                <tr>

                                    <th>
                                        Air
                                    </th>

                                    <th>
                                        Flight
                                    </th>

                                    <th>
                                        Departure Date
                                    </th>

                                    <th>
                                        Origin
                                    </th>

                                    <th>
                                        Destination
                                    </th>

                                    <th>
                                        Dep Time
                                    </th>

                                    <th>
                                        Arr Time
                                    </th>

                                    <th>
                                        Baggage
                                    </th>

                                    <th>
                                        Supplier
                                    </th>

                                    <th>
                                        Action
                                    </th>

                                </tr>

                            </thead>


                            <tbody id="flightRows">

                                <tr>

                                    <td>

                                        <input type="text"
                                               name="flights[0][airline]">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="flights[0][flight]">

                                    </td>


                                    <td>

                                        <input type="date"
                                               name="flights[0][departure_date]">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="flights[0][origin]"
                                               placeholder="LHR">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="flights[0][destination]"
                                               placeholder="DXB">

                                    </td>


                                    <td>

                                        <input type="time"
                                               name="flights[0][departure_time]">

                                    </td>


                                    <td>

                                        <input type="time"
                                               name="flights[0][arrival_time]">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="flights[0][baggage]">

                                    </td>

                                    <td>

                                        <input type="text"
                                               name="flights[0][supplier]"
                                               placeholder="Supplier">

                                    </td>


                                    <td>

                                        <button type="button"
                                                class="btn-delete"
                                                onclick="deleteRow(this)">

                                            ×

                                        </button>

                                    </td>

                                </tr>

                            </tbody>

                        </table>

                    </div>


                    <button type="button"
                            class="btn-add"
                            onclick="addFlight()">

                        + Add Flight

                    </button>

                </div>


                <!-- =====================================================
                     HOTEL DETAILS
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        Hotel Details
                    </div>


                    <div class="table-wrapper">

                        <table class="booking-table">

                            <thead>

                                <tr>

                                    <th>
                                        Hotel Name
                                    </th>

                                    <th>
                                        City
                                    </th>

                                    <th>
                                        Room Type
                                    </th>

                                    <th>
                                        Rooms
                                    </th>

                                    <th>
                                        Meal
                                    </th>

                                    <th>
                                        View
                                    </th>

                                    <th>
                                        Check In
                                    </th>

                                    <th>
                                        Nights
                                    </th>

                                    <th>
                                        Check Out
                                    </th>

                                    <th>
                                        Remarks
                                    </th>

                                    <th>
                                        Supplier
                                    </th>

                                    <th>
                                        Action
                                    </th>

                                </tr>

                            </thead>


                            <tbody id="hotelRows">

                                <tr>

                                    <td>

                                        <input type="text"
                                               name="hotels[0][name]">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="hotels[0][city]">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="hotels[0][room_type]">

                                    </td>


                                    <td>

                                        <input type="number"
                                               name="hotels[0][rooms]"
                                               value="1"
                                               min="1">

                                    </td>


                                    <td>

                                        <select name="hotels[0][meal]">

                                            <option value="RO">
                                                RO
                                            </option>

                                            <option value="BB">
                                                BB
                                            </option>

                                            <option value="HB">
                                                HB
                                            </option>

                                            <option value="FB">
                                                FB
                                            </option>

                                        </select>

                                    </td>


                                    <td>

                                        <select name="hotels[0][view]">
                                    <option value="No View">No view</option>
                                    <option value="City View">City View</option>
                                    <option value="Patio View">Patio View</option>
                                    <option value="Haram View">Haram View</option>
                                    <option value="Partial Kaba View">Partial Kaaba View</option>
                                    <option value="Kaaba View">Kaaba View</option>

                                </select>

                                    </td>


                                    <td>

                                        <input type="date"
                                               name="hotels[0][check_in]"
                                               style="max-width: 119px;">
                                    </td>


                                    <td>

                                        <input type="number"
                                               name="hotels[0][nights]"
                                               value="1"
                                               min="1">

                                    </td>


                                    <td>

                                        <input type="date"
                                               name="hotels[0][check_out]"
                                               style="max-width: 119px;">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="hotels[0][remarks]">

                                    </td>

                                    <td>

                                        <input type="text"
                                               name="hotels[0][supplier]"
                                               placeholder="Supplier">

                                    </td>


                                    <td>

                                        <button type="button"
                                                class="btn-delete"
                                                onclick="deleteRow(this)">

                                            ×

                                        </button>

                                    </td>

                                </tr>

                            </tbody>

                        </table>

                    </div>


                    <button type="button"
                            class="btn-add"
                            onclick="addHotel()">

                        + Add Hotel

                    </button>

                </div>


                <!-- =====================================================
                     TRANSPORT
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        Transport Details
                    </div>


                    <div class="table-wrapper">

                        <table class="booking-table">

                            <thead>

                                <tr>

                                    <th>
                                        Vehicle
                                    </th>

                                    <th>
                                        Journey
                                    </th>

                                    <th>
                                        Vehicles
                                    </th>

                                    <th>
                                        Pickup Date
                                    </th>

                                    <th>
                                        Pickup Time
                                    </th>

                                    <th>
                                        Notes
                                    </th>

                                    <th>
                                        Supplier
                                    </th>

                                    <th>
                                        Action
                                    </th>

                                </tr>

                            </thead>


                            <tbody id="transportRows">

                                <tr>

                                    <td>

                                        <input type="text"
                                               name="transport[0][vehicle]"
                                               value="Car/Bus">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="transport[0][journey]">

                                    </td>


                                    <td>

                                        <input type="number"
                                               name="transport[0][vehicles]"
                                               value="1"
                                               min="1">

                                    </td>


                                    <td>

                                        <input type="date"
                                               name="transport[0][pickup_date]">

                                    </td>


                                    <td>

                                        <input type="time"
                                               name="transport[0][pickup_time]">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="transport[0][notes]">

                                    </td>

                                    <td>

                                        <input type="text"
                                               name="transport[0][supplier]"
                                               placeholder="Supplier">

                                    </td>


                                    <td>

                                        <button type="button"
                                                class="btn-delete"
                                                onclick="deleteRow(this)">

                                            ×

                                        </button>

                                    </td>

                                </tr>

                            </tbody>

                        </table>

                    </div>


                    <button type="button"
                            class="btn-add"
                            onclick="addTransport()">

                        + Add Transport

                    </button>

                </div>


                <!-- =====================================================
                     ADDITIONAL PRODUCTS
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        Additional Products
                    </div>


                  <div id="productRows">

                        <div class="product-row">

                            <input
                                type="text"
                                name="products[0][name]"
                                placeholder="e.g. ETA VISA / Tourist Visa / Umrah Visa / Others"
                            >

                            <input
                                type="text"
                                name="products[0][supplier]"
                                placeholder="Supplier"
                            >

                            <button
                                type="button"
                                class="btn-delete"
                                onclick="deleteProduct(this)">
                                ×
                            </button>

                        </div>

                    </div>


                    <button type="button"
                            class="btn-add"
                            onclick="addProduct()">

                        + Add Product

                    </button>

                </div>


                <!-- =====================================================
                     COST AND MARGIN
                ====================================================== -->

<!-- =====================================================
     COST AND MARGIN
====================================================== -->

<div class="form-section">

    <div class="section-title">
        Cost and Margin
    </div>

    <div class="table-wrapper">

        <table class="cost-table">

            <thead>
                <tr>
                    <th>Age</th>
                    <th>No</th>
                    <th>Base Fare</th>
                    <th>Tax</th>
                    <th>Net Cost</th>
                    <th>Total Net</th>
                    <th>Selling Price</th>
                    <th>Selling Total</th>
                    <th>Margin</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody id="costRows">

                <tr>

                    <!-- AGE -->
                    <td>
                                        <select
                        class="cost-input age"
                        name="costs[0][age_category]"
                    >
                        <option value="ADULT">ADULT</option>

                        <option value="CHILD">CHILD</option>

                        <option value="INFANT">INFANT</option>

                        <option value="MAK HOTEL">MAKKAH HOTEL</option>

                        <option value="MED HOTEL">MADINA HOTEL</option>

                        <option value="VISA">VISA</option>

                        <option value="TRANSPORT">TRANSPORT</option>

                        <option value="OTHER">OTHER</option>
                    </select>
                    </td>


                    <!-- NUMBER OF PEOPLE -->
                    <td>
                        <input
                            class="cost-input qty"
                            type="number"
                            value="1"
                            min="1">
                    </td>


                    <!-- BASE FARE PER PERSON -->
                    <td>
                        <input
                            class="cost-input base-fare"
                            type="number"
                            value="0"
                            min="0"
                            step="0.01"
                            placeholder="0.00">
                    </td>


                    <!-- TAX PER PERSON -->
                    <td>
                        <input
                            class="cost-input tax"
                            type="number"
                            value="0"
                            min="0"
                            step="0.01"
                            placeholder="0.00">
                    </td>


                    <!-- NET COST PER PERSON -->
                    <td class="net-cost">
                        0.00
                    </td>


                    <!-- TOTAL NET -->
                    <td class="total-net">
                        0.00
                    </td>


                    <!-- SELLING PRICE PER PERSON -->
                    <td>
                        <input
                            class="cost-input selling-price"
                            type="number"
                            value="0"
                            min="0"
                            step="0.01"
                            placeholder="0.00">
                    </td>


                    <!-- SELLING TOTAL -->
                    <td class="selling-total">
                        0.00
                    </td>


                    <!-- MARGIN -->
                    <td class="margin green-text">
                        0.00
                    </td>


                    <!-- ACTION -->
                    <td>
                        <button
                            type="button"
                            class="btn-delete"
                            onclick="deleteCostRow(this)">    ×

                                        

                        </button>
                    </td>

                </tr>

            </tbody>


            <!-- GRAND TOTAL -->
            <tfoot>

                <tr>

                    <td colspan="5">
                        <strong>Grand Total</strong>
                    </td>

                    <td id="totalNet">
                        0.00
                    </td>

                    <td></td>

                    <td id="totalSelling">
                        0.00
                    </td>

                    <td id="totalMargin"
                        class="green-text">

                        0.00

                    </td>

                    <td></td>

                </tr>

            </tfoot>

        </table>

    </div>


    <!-- ADD COST -->
    <button
        type="button"
        class="btn-add"
        onclick="addCost()">

        + Add Cost

    </button>


    <!-- EXTRA CHARGES -->

    <div class="form-grid grid-3"
         style="margin-top:8px;">

        <div class="field">

            <label>
                ATOL Charges (£)
            </label>

            <input
                type="number"
                id="atolCharges"
                value="0"
                step="0.01">

        </div>


        <div class="field">

            <label>
                Safi Charges (£)
            </label>

            <input
                type="number"
                id="iataCharges"
                value="0"
                step="0.01">

        </div>


        <div class="field">

            <label>
                Discount (£)
            </label>

            <input
                type="number"
                id="discount"
                value="0"
                step="0.01">

        </div>

    </div>


    <!-- TOTALS -->

   

</div>


                <!-- =====================================================
                     PAYMENTS
                ====================================================== -->

                <div class="form-section">

                    <div class="section-title">
                        Payment(s) Received
                    </div>


                    <div class="table-wrapper">

                        <table class="booking-table">

                            <thead>

                                <tr>
                                    
                                         <th>
                                            Invoice No
                                         </th>

                                    <th>
                                        Profile No
                                    </th>

                                     <th>
                                        Payee Name
                                    </th>

                                    <th>
                                        Mode of Payment
                                    </th>

                                      <th>
                                        Date
                                    </th>

                                    <th>
                                        Payment Reference
                                    </th>

                                    <th>
                                        Amount (£)
                                    </th>

                                    <th>
                                        Remarks
                                    </th>

                                     <th>
                                        Attachement
                                    </th>

                                    <th>
                                        Action
                                    </th>

                                </tr>

                            </thead>


                            <tbody id="paymentRows">

                                <tr>

                                    <td>

                                        <input type="hidden" name="payments[0][payment_id]" value="">

                                        <input type="text"
                                               name="payments[0][receipt_id]">

                                    </td>

                                       <td>

                                        <input type="text"
                                               name="payments[0][profile_id]">

                                    </td>

                                      

                                     <td>

                                        <input type="text"
                                               name="payments[0][payer_name]">

                                    </td>


                                  


                                    <td>

                                    <select name="payments[0][method]">
                            <option value="Natwest Bank" selected>
                                Natwest Bank
                            </option>

                            <option value="HBL Pakistan">
                                HBL Pakistan
                            </option>

                            <option value="E Payment">
                                E Payment
                            </option>

                            <option value="London Office Card Merchant">
                                London Office Card Merchant
                            </option>

                            <option value="Cash - London Office">
                                Cash - London Office
                            </option>

                            <option value="barclays Bank">
                                barclays Bank
                            </option>

                            <option value="Revolut Bank">
                                Revolut Bank
                            </option>
                        </select>

                                    </td>

                                        <td>

                                        <input type="date"
                                               name="payments[0][date]">

                                    </td>

                                    <td>

                                        <input type="text"
                                               name="payments[0][payment_reference]">

                                    </td>

                                    <td>

                                        <input type="number"
                                               class="payment-amount"
                                               name="payments[0][amount]"
                                               value="0"
                                               step="0.01">

                                    </td>


                                    <td>

                                        <input type="text"
                                               name="payments[0][remarks]">

                                    </td>

                                     <td>

                                        <input type="file"
                                               name="payments[0][attachment]">

                                    </td>


                                    <td>

                                        <button type="button"
                                                class="btn-delete"
                                                onclick="deleteRow(this)">

                                            ×

                                        </button>

                                    </td>

                                </tr>

                            </tbody>

                        </table>

                    </div>


                    <button type="button"
                            class="btn-add"
                            onclick="addPayment()">

                        + Add Payment

                    </button>


                    <div class="received-total">

                        Total Received:
                        £<span id="totalReceived">0.00</span>

                    </div>

                </div>

                 <div class="cost-totals">

        <div class="cost-total">

            <div class="cost-total-title">
                Gross Total
            </div>

            <div class="cost-total-value">
                £<span id="grossTotal">0.00</span>
            </div>

        </div>


        <div class="cost-total">

            <div class="cost-total-title">
                VAT
            </div>

            <div class="cost-total-value">
                £<span id="vatTotal">0.00</span>
            </div>

        </div>


        <div class="cost-total">

            <div class="cost-total-title">
                Discount
            </div>

            <div class="cost-total-value">
                £<span id="discountTotal">0.00</span>
            </div>

        </div>


        <div class="cost-total">

            <div class="cost-total-title">
                Total Payable
            </div>

            <div class="cost-total-value">
                £<span id="payableTotal">0.00</span>
            </div>

        </div>


        <div class="cost-total">

            <div class="cost-total-title">
                Balance Due
            </div>

            <div class="cost-total-value">
                £<span id="balanceTotal">0.00</span>
            </div>

        </div>

    </div>


                <!-- =====================================================
                     ACTIONS
                ====================================================== -->

                <div class="form-actions">

                    <button type="button"
                            class="btn-cancel"
                            id="bookingCancelButton">

                        Cancel

                    </button>


                    <button type="button"
                            class="btn-save"
                            onclick="saveBooking()">

                        💾 Save Booking

                    </button>

                </div>


            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     SABRE PNR PARSER MODAL
========================================================= -->

<div id="sabrePnrModal" class="sabre-pnr-modal">

    <div class="sabre-pnr-dialog">

        <!-- HEADER -->
        <div class="sabre-pnr-header">

            <div>
                <div class="sabre-pnr-title">
                    ✈ Multi-PNR Parser
                </div>

                <div class="sabre-pnr-subtitle">
                    Paste one or multiple Sabre PNRs
                </div>
            </div>

            <button type="button"
                    class="sabre-close"
                    id="closeSabrePNR">
                &times;
            </button>

        </div>


        <!-- BODY -->
        <div class="sabre-pnr-body">

            <!-- INPUT -->
            <div class="sabre-input-section">

                <div class="sabre-input-label-row">

                    <label>
                        Paste PNR(s)
                    </label>

                    <span>
                        Supports Sabre Format A, Format B & mixed
                    </span>

                </div>

                <textarea
                    id="sabrePnrInput"
                    class="sabre-pnr-textarea"
                    placeholder="Paste Sabre PNR here.

Example:

1.KHAN/ZAKIR MR 2.KHAN/AMINA MRS
1 QR 103 Y 15MAY 3 MANCHL HK2 0635 1840
2 QR 1143 Y 15MAY 3 DOHJED HK2 2015 2205
3 QR 1142 Y 29MAY 3 JEDDOH HK2 0110 0420
4 QR 102 Y 29MAY 3 DOHMAN HK2 0600 1250

---

1.AHMED/BILAL MR 2.AHMED/SARA MRS
1 SV 118 Y 20MAY 4 LHRJED HK3 0930 2015
2 SV 117 Y 03JUN 6 JEDLHR HK3 0830 1345"></textarea>


                <div class="sabre-toolbar">

                    <button type="button"
                            class="sabre-btn sabre-btn-parse"
                            id="parseSabrePNR">
                        🔍 Parse PNR(s)
                    </button>

                    <button type="button"
                            class="sabre-btn sabre-btn-sample"
                            id="loadSabreSample">
                        📋 Load Sample
                    </button>

                    <button type="button"
                            class="sabre-btn sabre-btn-clear"
                            id="clearSabrePNR">
                        Clear
                    </button>

                    <button type="button"
                            class="sabre-btn sabre-btn-apply-all"
                            id="applyAllSabrePNR"
                            style="display:none;">
                        ✓ Apply All to Booking
                    </button>

                </div>

            </div>


            <!-- HELP -->
            <div class="sabre-help">

                <strong>How to add multiple PNRs:</strong>

                Paste all PNRs in the box above.

                Separate them with
                <code>---</code>
                on its own line,

                or leave 3+ blank lines between PNRs.

            </div>


            <!-- ERROR -->
            <div id="sabrePnrError"
                 class="sabre-error"
                 style="display:none;">
            </div>


            <!-- RESULTS -->
            <div id="sabrePnrResults"></div>

        </div>

    </div>

</div>


<!-- package import modal -->

<div
    id="packageImportModal"
    class="package-import-modal"
>

    <div class="package-modal-box">

        <div class="package-modal-header">

            <div>
                <h2>📦 Smart Package Parser</h2>
                <p>
                    Import a complete holiday package
                    directly into your booking.
                </p>
            </div>

            <button
                type="button"
                id="closePackageImport"
            >
                ✕
            </button>

        </div>


        <div class="package-modal-body">

            <textarea
                id="packageText"
                placeholder="Paste package information here..."
            ></textarea>


            <div class="package-actions">

                <button
                    type="button"
                    id="parsePackageBtn"
                >
                    🔍 Parse Package
                </button>

                <button
                    type="button"
                    id="loadPackageSample"
                >
                    🧪 Load Sample
                </button>

                <button
                    type="button"
                    id="clearPackageText"
                >
                    🗑 Clear
                </button>

            </div>


            <div
                id="packageResult"
                class="package-result"
            ></div>

        </div>


        <div class="package-modal-footer">

            <button
                type="button"
                id="applyPackageToBooking"
                class="package-apply-btn"
            >
                ✓ Apply to Booking
            </button>

        </div>

    </div>

</div>





