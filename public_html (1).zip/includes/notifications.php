<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/permissions.php';

function notificationsEnsureSchema(): void
{
    static $done = false;
    if ($done) return;
    $pdo = Database::connection();
    $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(50) NOT NULL DEFAULT 'system',
        category VARCHAR(50) NOT NULL DEFAULT 'system',
        title VARCHAR(180) NOT NULL,
        message TEXT NOT NULL,
        priority ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',
        entity_type VARCHAR(50) NULL,
        entity_id INT UNSIGNED NULL,
        action_url VARCHAR(500) NULL,
        dedupe_key VARCHAR(191) NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        read_at DATETIME NULL,
        archived_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_notifications_user_read (user_id,is_read,created_at),
        INDEX idx_notifications_category (user_id,category,created_at),
        INDEX idx_notifications_entity (entity_type,entity_id),
        UNIQUE KEY uq_notifications_dedupe (dedupe_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    $done = true;
}

function notificationCreate(int $userId, string $type, string $category, string $title, string $message, string $priority='normal', ?string $entityType=null, ?int $entityId=null, ?string $actionUrl=null, ?string $dedupeKey=null): int
{
    notificationsEnsureSchema();
    if ($userId <= 0 || trim($title)==='') return 0;
    $sql = "INSERT INTO notifications (user_id,type,category,title,message,priority,entity_type,entity_id,action_url,dedupe_key)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)";
    $stmt = Database::connection()->prepare($sql);
    $stmt->execute([$userId,$type,$category,$title,$message,$priority,$entityType,$entityId,$actionUrl,$dedupeKey]);
    return (int)Database::connection()->lastInsertId();
}

function notificationReviewerIds(int $bookingId): array
{
    $ids = [];
    foreach (Database::select("SELECT id FROM agents WHERE is_active=1 AND LOWER(role) IN ('admin','manager','administrator')") as $r) {
        $ids[] = (int)$r['id'];
    }
    $booking = Database::selectOne("SELECT agent_id FROM bookings WHERE id=?",[$bookingId]);
    if ($booking && (int)$booking['agent_id'] > 0) {
        $agentId=(int)$booking['agent_id'];
        $agent=Database::selectOne("SELECT team_lead_id,team_id FROM agents WHERE id=?",[$agentId]);
        if ($agent) {
            if (!empty($agent['team_lead_id'])) $ids[]=(int)$agent['team_lead_id'];
            if (!empty($agent['team_id'])) {
                $team=Database::selectOne("SELECT team_lead_id FROM teams WHERE id=?",[(int)$agent['team_id']]);
                if ($team && !empty($team['team_lead_id'])) $ids[]=(int)$team['team_lead_id'];
            }
        }
    }
    return array_values(array_unique(array_filter($ids,fn($v)=>$v>0)));
}

function notifyBookingApprovalRequested(int $bookingId, int $requestId, int $requesterId, string $kind): void
{
    notificationsEnsureSchema();
    $b=Database::selectOne("SELECT invoice_no,client_name FROM bookings WHERE id=?",[$bookingId]);
    $u=Database::selectOne("SELECT name FROM agents WHERE id=?",[$requesterId]);
    if (!$b) return;
    $invoice=(string)($b['invoice_no']??('Booking #'.$bookingId));
    $name=(string)($u['name']??'Agent');
    $isDelete=$kind==='delete';
    $title=$isDelete?'Booking deletion approval required':'Booking edit approval required';
    $message=$name.($isDelete?' requested deletion of ':' requested edit access for ').$invoice.' — '.(($b['client_name']??'')?:'Client').'.';
    $type=$isDelete?'booking_delete':'booking_edit';
    $priority=$isDelete?'critical':'high';
    foreach(notificationReviewerIds($bookingId) as $recipient) {
        if ($recipient===$requesterId) continue;
        notificationCreate($recipient,$type,'approvals',$title,$message,$priority,$isDelete?'booking_delete_request':'booking_edit_request',$requestId,'booking.php?id='.$bookingId,'approval:'.$kind.':'.$requestId.':'.$recipient);
    }
}

function notifyBookingApprovalReviewed(int $bookingId, int $requestId, int $requesterId, string $kind, string $status, int $reviewerId, string $reason=''): void
{
    notificationsEnsureSchema();
    $b=Database::selectOne("SELECT invoice_no,client_name FROM bookings WHERE id=?",[$bookingId]);
    $reviewer=Database::selectOne("SELECT name FROM agents WHERE id=?",[$reviewerId]);
    if (!$b) return;
    $invoice=(string)($b['invoice_no']??('Booking #'.$bookingId));
    $reviewerName=(string)($reviewer['name']??'Reviewer');
    $approved=$status==='Approved';
    $action=$kind==='delete'?'delete':'edit';
    $title=($kind==='delete'?'Booking deletion ':'Booking edit ').($approved?'approved':'rejected');
    $message=$reviewerName.' '.($approved?'approved ':'rejected ').'your '.$action.' request for '.$invoice.'.';
    if (!$approved && trim($reason)!=='') $message.=' Reason: '.trim($reason);
    notificationCreate($requesterId,'booking_'.$kind,'approvals',$title,$message,$approved?'high':'normal',$kind==='delete'?'booking_delete_request':'booking_edit_request',$requestId,'booking.php?id='.$bookingId,'review:'.$kind.':'.$requestId.':'.$status);
}

function notificationUserScopeWhere(int $uid, string $role, string $bookingAlias='b'): array
{
    if ($role==='agent') return [$bookingAlias.'.agent_id=?',[$uid]];
    if ($role==='teamlead') {
        $ids=array_values(array_unique(array_merge([$uid],teamAgentIds($uid))));
        if (!$ids) return ['0=1',[]];
        return [$bookingAlias.'.agent_id IN ('.implode(',',array_fill(0,count($ids),'?')).')',$ids];
    }
    return ['1=1',[]];
}

function syncSystemNotifications(int $uid, string $role): void
{
    notificationsEnsureSchema();
    if ($uid<=0) return;
    $pdo=Database::connection();

    // Approval queues and outcomes are generated here as a backstop for older requests.
    if (in_array($role,['admin','manager','administrator'],true)) {
        $editRows=Database::select("SELECT r.id,r.booking_id,r.requester_id,b.invoice_no,b.client_name,a.name requester FROM booking_edit_requests r JOIN bookings b ON b.id=r.booking_id JOIN agents a ON a.id=r.requester_id WHERE r.status='Pending' ORDER BY r.id DESC LIMIT 100");
        foreach($editRows as $r) notifyBookingApprovalRequested((int)$r['booking_id'],(int)$r['id'],(int)$r['requester_id'],'edit');
        $delRows=Database::select("SELECT r.id,r.booking_id,r.requester_id,b.invoice_no,b.client_name,a.name requester FROM booking_delete_requests r JOIN bookings b ON b.id=r.booking_id JOIN agents a ON a.id=r.requester_id WHERE r.status='Pending' ORDER BY r.id DESC LIMIT 100");
        foreach($delRows as $r) notifyBookingApprovalRequested((int)$r['booking_id'],(int)$r['id'],(int)$r['requester_id'],'delete');
    } elseif ($role==='teamlead') {
        $ids=array_values(array_unique(array_merge([$uid],teamAgentIds($uid))));
        if($ids){$ph=implode(',',array_fill(0,count($ids),'?'));
            $editRows=Database::select("SELECT r.id,r.booking_id,r.requester_id FROM booking_edit_requests r JOIN bookings b ON b.id=r.booking_id WHERE r.status='Pending' AND b.agent_id IN ($ph) ORDER BY r.id DESC LIMIT 100",$ids);
            foreach($editRows as $r) notifyBookingApprovalRequested((int)$r['booking_id'],(int)$r['id'],(int)$r['requester_id'],'edit');
            $delRows=Database::select("SELECT r.id,r.booking_id,r.requester_id FROM booking_delete_requests r JOIN bookings b ON b.id=r.booking_id WHERE r.status='Pending' AND b.agent_id IN ($ph) ORDER BY r.id DESC LIMIT 100",$ids);
            foreach($delRows as $r) notifyBookingApprovalRequested((int)$r['booking_id'],(int)$r['id'],(int)$r['requester_id'],'delete');
        }
    }

    // Agent-specific approval outcomes.
    if ($role==='agent') {
        $rows=Database::select("SELECT r.id,r.booking_id,r.status,r.reviewed_by,r.rejection_reason FROM booking_edit_requests r WHERE r.requester_id=? AND r.status IN ('Approved','Rejected') ORDER BY r.id DESC LIMIT 50",[$uid]);
        foreach($rows as $r) notifyBookingApprovalReviewed((int)$r['booking_id'],(int)$r['id'],$uid,'edit',(string)$r['status'],(int)($r['reviewed_by']??0),(string)($r['rejection_reason']??''));
        $rows=Database::select("SELECT r.id,r.booking_id,r.status,r.reviewed_by,r.rejection_reason FROM booking_delete_requests r WHERE r.requester_id=? AND r.status IN ('Approved','Rejected') ORDER BY r.id DESC LIMIT 50",[$uid]);
        foreach($rows as $r) notifyBookingApprovalReviewed((int)$r['booking_id'],(int)$r['id'],$uid,'delete',(string)$r['status'],(int)($r['reviewed_by']??0),(string)($r['rejection_reason']??''));
    }

    [$bWhere,$bp]=notificationUserScopeWhere($uid,$role);
    $today=date('Y-m-d'); $soon=date('Y-m-d',strtotime('+7 days'));
    foreach(Database::select("SELECT b.id,b.invoice_no,b.client_name,b.travel_date FROM bookings b WHERE $bWhere AND b.travel_date BETWEEN ? AND ? AND b.status NOT IN ('Completed','Cancelled') ORDER BY b.travel_date LIMIT 100",array_merge($bp,[$today,$soon])) as $r) {
        $days=max(0,(int)floor((strtotime((string)$r['travel_date'])-strtotime($today))/86400));
        $priority=$days<=1?'critical':($days<=3?'high':'normal');
        notificationCreate($uid,'departure','bookings','Upcoming departure',($r['invoice_no']??'Booking').' — '.(($r['client_name']??'')?:'Client').' travels on '.$r['travel_date'].'.',$priority,'booking',(int)$r['id'],'booking.php?id='.(int)$r['id'],'departure:'.$uid.':'.$r['id'].':'.$r['travel_date']);
    }
    foreach(Database::select("SELECT b.id,b.invoice_no,b.client_name,b.balance_due FROM bookings b WHERE $bWhere AND b.balance_due>0 AND b.status NOT IN ('Cancelled','Completed') ORDER BY b.balance_due DESC LIMIT 100",$bp) as $r) {
        notificationCreate($uid,'payment_due','finance','Payment pending',($r['invoice_no']??'Booking').' — '.(($r['client_name']??'')?:'Client').' has £'.number_format((float)$r['balance_due'],2).' outstanding.','high','booking',(int)$r['id'],'booking.php?id='.(int)$r['id'],'payment:'.$uid.':'.$r['id']);
    }
    if($role==='agent') {
        foreach(Database::select("SELECT l.id,l.lead_id,l.name,l.follow_up_date FROM leads l WHERE l.assigned_to=? AND l.follow_up_date IS NOT NULL AND l.follow_up_date<=CURDATE() AND l.status NOT IN ('Booked','Lost Lead','Duplicate') ORDER BY l.follow_up_date LIMIT 100",[$uid]) as $r) {
            notificationCreate($uid,'lead_followup','leads','Lead follow-up due',($r['lead_id']??'Lead').' — '.(($r['name']??'')?:'Lead').' requires follow-up dated '.$r['follow_up_date'].'.','high','lead',(int)$r['id'],'leads.php','followup:'.$uid.':'.$r['id'].':'.$r['follow_up_date']);
        }
    } elseif($role==='teamlead') {
        $ids=array_values(array_unique(array_merge([$uid],teamAgentIds($uid))));
        if($ids){$ph=implode(',',array_fill(0,count($ids),'?')); foreach(Database::select("SELECT l.id,l.lead_id,l.name,l.follow_up_date FROM leads l WHERE l.assigned_to IN ($ph) AND l.follow_up_date IS NOT NULL AND l.follow_up_date<=CURDATE() AND l.status NOT IN ('Booked','Lost Lead','Duplicate') ORDER BY l.follow_up_date LIMIT 100",$ids) as $r) notificationCreate($uid,'lead_followup','leads','Team follow-up due',($r['lead_id']??'Lead').' — '.(($r['name']??'')?:'Lead').' requires follow-up dated '.$r['follow_up_date'].'.','normal','lead',(int)$r['id'],'leads.php','followup-team:'.$uid.':'.$r['id'].':'.$r['follow_up_date']);}
    }

    foreach(Database::select("SELECT ba.id,ba.booking_id,b.invoice_no,b.client_name,ba.alert_date FROM booking_alerts ba JOIN bookings b ON b.id=ba.booking_id WHERE ba.created_by=? AND ba.alert_date<=CURDATE() AND ba.seen_at IS NULL ORDER BY ba.alert_date LIMIT 100",[$uid]) as $r) {
        notificationCreate($uid,'reminder','bookings','Booking reminder due',($r['invoice_no']??'Booking').' — '.(($r['client_name']??'')?:'Client').' reminder is due today.','high','booking_alert',(int)$r['id'],'alert_reminder.php','reminder:'.$uid.':'.$r['id']);
    }
}

function notificationsUnreadCount(int $uid): int
{
    notificationsEnsureSchema();
    return (int)(Database::selectOne("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0 AND archived_at IS NULL",[$uid])['c']??0);
}
