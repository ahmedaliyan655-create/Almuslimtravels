<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';


class Database
{
    private static ?PDO $instance = null;


    /*
    |--------------------------------------------------------------------------
    | GET PDO CONNECTION
    |--------------------------------------------------------------------------
    */

    public static function connection(): PDO
    {
        if (self::$instance === null) {

            self::$instance = new PDO(

                "mysql:host=" . DB_HOST .
                ";dbname=" . DB_NAME .
                ";charset=utf8mb4",

                DB_USER,

                DB_PASS,

                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false
                ]

            );
        }

        return self::$instance;
    }


    /*
    |--------------------------------------------------------------------------
    | SELECT ALL
    |--------------------------------------------------------------------------
    */

    public static function select(string $sql, array $params = []): array
    {
        $stmt = self::connection()->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll();
    }


    /*
    |--------------------------------------------------------------------------
    | SELECT ONE
    |--------------------------------------------------------------------------
    */

    public static function selectOne(string $sql, array $params = []): array|false
    {
        $stmt = self::connection()->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetch();
    }


    /*
    |--------------------------------------------------------------------------
    | INSERT
    |--------------------------------------------------------------------------
    */

    public static function insert(string $sql, array $params = []): string
    {
        $stmt = self::connection()->prepare($sql);

        $stmt->execute($params);

        return self::connection()->lastInsertId();
    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE
    |--------------------------------------------------------------------------
    */

    public static function update(string $sql, array $params = []): int
    {
        $stmt = self::connection()->prepare($sql);

        $stmt->execute($params);

        return $stmt->rowCount();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    public static function delete(string $sql, array $params = []): int
    {
        $stmt = self::connection()->prepare($sql);

        $stmt->execute($params);

        return $stmt->rowCount();
    }


    /*
    |--------------------------------------------------------------------------
    | RAW QUERY
    |--------------------------------------------------------------------------
    */

    public static function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::connection()->prepare($sql);

        $stmt->execute($params);

        return $stmt;
    }


    /*
    |--------------------------------------------------------------------------
    | TRANSACTIONS
    |--------------------------------------------------------------------------
    */

    public static function beginTransaction(): bool
    {
        return self::connection()->beginTransaction();
    }


    public static function commit(): bool
    {
        return self::connection()->commit();
    }


    public static function rollback(): bool
    {
        return self::connection()->rollBack();
    }
}


/*
|--------------------------------------------------------------------------
| PDO VARIABLE FOR LEGACY / DIRECT PDO CODE
|--------------------------------------------------------------------------
|
| Your save_booking.php uses:
|
|     $pdo->prepare()
|     $pdo->beginTransaction()
|     $pdo->commit()
|     $pdo->rollBack()
|
| Therefore expose the same PDO connection as $pdo.
|
*/

$pdo = Database::connection();