</div>
<!-- End Content Wrapper -->

</div>
<!-- End Main Container -->

</div>
<!-- End Wrapper -->

<!-- Footer -->
<footer class="main-footer">

    <div class="container-fluid">

        <div class="row align-items-center">

            <div class="col-md-6 text-center text-md-start">

                <strong>
                    &copy; <?php echo date('Y'); ?> CoreNex Solution.
                </strong>

                All Rights Reserved.

            </div>

            <div class="col-md-6 text-center text-md-end">

                Version 2.0.0

            </div>

        </div>

    </div>

</footer>

<!-- ================================= -->
<!-- Bootstrap JS -->
<!-- ================================= -->

<!-- FontAwesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js"></script>
<script src="../assets/js/notifications.js"></script>
<script>
(function(){
  const nEndpoint="../actions/notifications.php";
  const bell=document.getElementById("notificationBell");
  const dropdown=document.getElementById("notificationDropdown");
  const list=document.getElementById("headerNotificationList");
  const unreadText=document.getElementById("headerUnreadText");
  const esc=v=>String(v??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const ago=iso=>{const t=new Date(String(iso).replace(' ','T'));if(isNaN(t))return '';let s=Math.max(0,Math.floor((Date.now()-t.getTime())/1000));if(s<60)return 'just now';if(s<3600)return Math.floor(s/60)+' min ago';if(s<86400)return Math.floor(s/3600)+' hr ago';return Math.floor(s/86400)+' day(s) ago';};
  function render(items,unread){unreadText.textContent=(unread||0)+' unread';if(!items.length){list.innerHTML='<div class="notification-dropdown-empty"><i class="fa-regular fa-circle-check"></i>All caught up</div>';return;}list.innerHTML=items.slice(0,8).map(n=>`<a class="header-notification-item ${n.is_read?'':'unread'}" href="${esc(n.action_url||'alerts.php')}" data-notification-id="${n.id}"><div class="header-notification-mini-icon ${esc(n.priority)}"><i class="fa-solid fa-bell"></i></div><div class="header-notification-copy"><strong>${esc(n.title)}</strong><p>${esc(n.message)}</p><span>${esc(ago(n.created_at))}</span></div></a>`).join('');}
  async function loadHeader(){try{const r=await fetch(nEndpoint+'?action=list&per_page=8&page=1',{cache:'no-store',credentials:'same-origin'});const j=await r.json();if(!j.success)return;const d=j.data||{};render(d.notifications||[],d.unread||0);document.querySelectorAll('.notification-count').forEach(x=>{x.textContent=d.unread||0;x.style.display=(d.unread||0)>0?'inline-block':'none';});}catch(e){}}
  bell?.addEventListener('click',e=>{e.stopPropagation();dropdown?.classList.toggle('show');if(dropdown?.classList.contains('show'))loadHeader();});
  dropdown?.addEventListener('click',e=>{const a=e.target.closest('a[data-notification-id]');if(!a)return;const id=a.dataset.notificationId;const fd=new FormData();fd.append('action','read');fd.append('id',id);fetch(nEndpoint,{method:'POST',body:fd,credentials:'same-origin'});});
  document.getElementById('headerMarkRead')?.addEventListener('click',async e=>{e.stopPropagation();const fd=new FormData();fd.append('action','mark_all_read');await fetch(nEndpoint,{method:'POST',body:fd,credentials:'same-origin'});loadHeader();});
  document.addEventListener('click',e=>{if(dropdown?.classList.contains('show')&&!dropdown.contains(e.target)&&!bell?.contains(e.target))dropdown.classList.remove('show');});
  window.crmLoadNotificationHeader=loadHeader;
  loadHeader();
})();
</script>
<script>
(function(){
  const endpoint="../actions/realtime.php"; let lastAlerts=null,lastChange=null;
  async function pulse(){
    try{const r=await fetch(endpoint,{cache:"no-store",headers:{"X-Requested-With":"XMLHttpRequest"}});const j=await r.json();if(!j.success)return;const d=j.data||{};
      document.querySelectorAll(".notification-count").forEach(x=>{x.textContent=d.alerts||0;x.style.display=(d.alerts||0)>0?"inline-block":"none";});
      if(lastAlerts!==null && (d.new_leads||0)>0 && (d.last_change||0)!==lastChange && !location.pathname.endsWith("/leads.php")) toastr.info((d.new_leads||1)+" new lead activity received.","CRM Update");
      lastAlerts=d.alerts||0; lastChange=d.last_change||0;
      window.dispatchEvent(new CustomEvent("crm:realtime",{detail:d}));
      if(typeof window.loadBookings==="function" && (d.updated_bookings||0)>0) window.loadBookings();
      if(typeof window.loadLeads==="function" && (d.new_leads||0)>0) window.loadLeads();
    }catch(e){/* network failures are non-blocking */}
  }
  pulse(); setInterval(pulse,15000);
})();
</script>
<!-- Custom JS -->
<!-- <script src="assets/js/app.js"></script> -->

<script>

    /********************************************
     Sidebar Toggle / Mobile Drawer
    ********************************************/
    const sidebar = document.getElementById("sidebar");
    const content = document.querySelector(".content-wrapper");
    const header = document.querySelector(".main-header");
    const menuBtn = document.getElementById("sidebarToggle");

    if (sidebar && menuBtn) {
        let overlay = document.getElementById("sidebarOverlay");
        if (!overlay) {
            overlay = document.createElement("div");
            overlay.id = "sidebarOverlay";
            overlay.className = "sidebar-overlay";
            document.body.appendChild(overlay);
        }
        const toggleSidebar = () => {
            if (window.innerWidth <= 991) {
                sidebar.classList.toggle("show");
                overlay.classList.toggle("show");
                document.body.classList.toggle("sidebar-open");
            } else {
                sidebar.classList.toggle("collapsed");
                if (content) content.classList.toggle("expanded");
                if (header) header.classList.toggle("expanded");
            }
        };
        menuBtn.addEventListener("click", function(e){ e.stopPropagation(); toggleSidebar(); });
        overlay.addEventListener("click", function(){ sidebar.classList.remove("show"); overlay.classList.remove("show"); document.body.classList.remove("sidebar-open"); });
        document.addEventListener("click", function(e){
            if(window.innerWidth <= 991 && sidebar.classList.contains("show") && !sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
                sidebar.classList.remove("show"); overlay.classList.remove("show"); document.body.classList.remove("sidebar-open");
            }
        });
        window.addEventListener("resize", function(){
            if(window.innerWidth > 991){ sidebar.classList.remove("show"); overlay.classList.remove("show"); document.body.classList.remove("sidebar-open"); }
        });
    }

    /********************************************
     Active Sidebar Menu
    ********************************************/

    const currentPage = window.location.pathname.split("/").pop();
    const pageHeading = document.querySelector(".main-header .page-title");
    const activeLink = document.querySelector('.sidebar-menu ul li a[href="'+currentPage+'"]');
    if (pageHeading && activeLink) {
        const txt = activeLink.querySelector("span");
        if (txt) pageHeading.textContent = txt.textContent.trim();
    }

    document.querySelectorAll(".sidebar-menu ul li a").forEach(function (link) {

        const href = link.getAttribute("href");

        if (href === currentPage) {

            document.querySelectorAll(".sidebar-menu li").forEach(function (item) {

                item.classList.remove("active");

            });

            link.parentElement.classList.add("active");

        }

    });


    /********************************************
     Dropdown Hover (Desktop)
    ********************************************/

    if (window.innerWidth > 991) {

        document.querySelectorAll('.dropdown').forEach(function (drop) {

            drop.addEventListener('mouseenter', function () {

                bootstrap.Dropdown.getOrCreateInstance(
                    this.querySelector('.dropdown-toggle')
                ).show();

            });

            drop.addEventListener('mouseleave', function () {

                bootstrap.Dropdown.getOrCreateInstance(
                    this.querySelector('.dropdown-toggle')
                ).hide();

            });

        });

    }


    /********************************************
     Current Time
    ********************************************/

    function updateClock() {

        const now = new Date();

        const options = {

            weekday: 'long',
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'

        };

        const clock = document.getElementById("liveClock");

        if (clock) {

            clock.innerHTML = now.toLocaleString('en-GB', options);

        }

    }

    setInterval(updateClock, 1000);

    updateClock();

</script>

</body>

</html>