<?php

require_once __DIR__ . "/session.php";

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

function isLoggedIn()
{
    return isset($_SESSION['agent_id']);
}

function requireLogin()
{
    if (!isLoggedIn()) {

        header("Location: ../login.php");
        exit;

    }
}

function redirectIfLoggedIn()
{
    if (isLoggedIn()) {

        header("Location: modules/dashboard.php");
        exit;

    }
}

/*
|--------------------------------------------------------------------------
| Current User Helpers
|--------------------------------------------------------------------------
*/

function authId()
{
    return $_SESSION['agent_id'] ?? null;
}

function authName()
{
    return $_SESSION['agent_name'] ?? null;
}

function authCode()
{
    return $_SESSION['agent_code'] ?? null;
}

function authRole()
{
    return $_SESSION['role'] ?? null;
}

function authTeam()
{
    return $_SESSION['team_id'] ?? null;
}

function authProject()
{
    return $_SESSION['project_id'] ?? null;
}

/*
|--------------------------------------------------------------------------
| Role Helpers
|--------------------------------------------------------------------------
*/

function isManager()
{
    return authRole() === "manager";
}

function isAdmin()
{
    return authRole() === "admin";
}

function isTeamLead()
{
    return authRole() === "teamlead";
}

function isAgent()
{
    return authRole() === "agent";
}
function authImage()
{
    return $_SESSION['profile_image'] ?? "";
}