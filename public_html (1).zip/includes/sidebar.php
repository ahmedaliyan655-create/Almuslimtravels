<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/permissions.php';
require_once __DIR__ . '/../includes/db.php';

/*
|--------------------------------------------------------------------------
| SIDEBAR PROJECT / CRM LOGO
|--------------------------------------------------------------------------
|
| Agent / Team Lead:
|   1. Session project_id
|   2. agents.default_project_id
|   3. First project from agent_projects
|
| Manager / Admin:
|   Always use the main CRM logo.
|--------------------------------------------------------------------------
*/

$crmLogo = '../assets/images/logonew.jpeg';

$sidebarLogo = $crmLogo;
$sidebarProjectName = 'Al Muslim Travel';

if (isAgent() || isTeamLead()) {

    $project = null;

    /*
    |--------------------------------------------------------------------------
    | 1. Check project stored in login session
    |--------------------------------------------------------------------------
    */

    $sessionProjectId = (int) authProject();

    if ($sessionProjectId > 0) {

        $stmt = $pdo->prepare("
            SELECT id, project_name, logo
            FROM projects
            WHERE id = ?
              AND is_active = 1
            LIMIT 1
        ");

        $stmt->execute([$sessionProjectId]);

        $project = $stmt->fetch(PDO::FETCH_ASSOC);
    }


    /*
    |--------------------------------------------------------------------------
    | 2. If session project is not available,
    |    check agents.default_project_id
    |--------------------------------------------------------------------------
    */

    if (!$project) {

        $stmt = $pdo->prepare("
            SELECT
                p.id,
                p.project_name,
                p.logo
            FROM agents a
            INNER JOIN projects p
                ON p.id = a.default_project_id
            WHERE a.id = ?
              AND p.is_active = 1
            LIMIT 1
        ");

        $stmt->execute([(int) authId()]);

        $project = $stmt->fetch(PDO::FETCH_ASSOC);
    }


    /*
    |--------------------------------------------------------------------------
    | 3. If still no project, check agent_projects
    |--------------------------------------------------------------------------
    */

    if (!$project) {

        $stmt = $pdo->prepare("
            SELECT
                p.id,
                p.project_name,
                p.logo
            FROM agent_projects ap
            INNER JOIN projects p
                ON p.id = ap.project_id
            WHERE ap.agent_id = ?
              AND p.is_active = 1
            ORDER BY ap.id ASC
            LIMIT 1
        ");

        $stmt->execute([(int) authId()]);

        $project = $stmt->fetch(PDO::FETCH_ASSOC);
    }


    /*
    |--------------------------------------------------------------------------
    | 4. Use assigned project's logo
    |--------------------------------------------------------------------------
    */

    if ($project) {

        $sidebarProjectName = trim(
            (string) ($project['project_name'] ?? '')
        );

        if ($sidebarProjectName === '') {
            $sidebarProjectName = 'Al Muslim Travel';
        }

        $projectLogo = trim(
            (string) ($project['logo'] ?? '')
        );

        if ($projectLogo !== '') {

            /*
            | Only use the filename.
            | Prevent paths such as ../../something.
            */
            $projectLogoFile = basename($projectLogo);

            /*
            | Project logos are stored in:
            | CRM/modules/uploads/
            |
            | Since sidebar.php is inside modules/,
            | the browser path is simply:
            | uploads/logo.jpg
            */
            $projectLogoPath = __DIR__ . '/uploads/' . $projectLogoFile;

            if (
                is_file($projectLogoPath) &&
                is_readable($projectLogoPath)
            ) {

                $sidebarLogo = 'uploads/' . rawurlencode($projectLogoFile);
            }
        }
    }
}
?>

<aside class="sidebar" id="sidebar">

    <div class="sidebar-logo">

        <a href="dashboard.php" class="logo">

            <img
                src="<?= htmlspecialchars($sidebarLogo, ENT_QUOTES, 'UTF-8') ?>"
                alt="<?= htmlspecialchars($sidebarProjectName, ENT_QUOTES, 'UTF-8') ?>"
                class="logo-img"
            >

            <div class="logo-text">

                <h5>
                    <?= htmlspecialchars(
                        $sidebarProjectName,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h5>

                <span>CRM System</span>

            </div>

        </a>

    </div>


    <div class="sidebar-menu">

        <ul>

            <li class="menu-title">MAIN MENU</li>


            <li>
                <a href="dashboard.php">
                    <i class="fas fa-house"></i>
                    <span>Dashboard</span>
                </a>
            </li>


            <li>
                <a href="performance.php">
                    <i class="fas fa-chart-line"></i>
                    <span>Performance</span>
                </a>
            </li>


            <li>
                <a href="booking.php">
                    <i class="fas fa-suitcase"></i>
                    <span>Bookings</span>
                </a>
            </li>


            <li>
                <a href="leads.php">
                    <i class="fas fa-user-plus"></i>
                    <span>Leads CRM</span>
                </a>
            </li>


            <?php if (canViewTeams()): ?>

                <li>
                    <a href="team.php">
                        <i class="fas fa-user-group"></i>
                        <span>Teams</span>
                    </a>
                </li>

            <?php endif; ?>


            <?php if (canManageStaff()): ?>

                <li>
                    <a href="staff.php">
                        <i class="fas fa-user-tie"></i>
                        <span>Staff &amp; Roles</span>
                    </a>
                </li>

            <?php elseif (isTeamLead()): ?>

                <li>
                    <a href="myteam.php">
                        <i class="fas fa-user-group"></i>
                        <span>My Team</span>
                    </a>
                </li>

            <?php endif; ?>


            <li>
                <a href="integrations.php">
                    <i class="fas fa-link"></i>
                    <span>Integrations</span>
                </a>
            </li>


            <li>
                <a href="alerts.php">
                    <i class="fas fa-bell"></i>
                    <span>Alerts</span>
                </a>
            </li>

            <li>
                <a href="alert_reminder.php">
                    <i class="fas fa-calendar-check"></i>
                    <span>Alert Reminder</span>
                </a>
            </li>


            <li>
                <a href="brochure.php">
                    <i class="fas fa-book-open"></i>
                    <span>Brochure</span>
                </a>
            </li>


            <?php if (canViewProjects()): ?>

                <li>
                    <a href="projects.php">
                        <i class="fas fa-folder-open"></i>
                        <span>Projects</span>
                    </a>
                </li>

            <?php endif; ?>

        </ul>

    </div>


    <div class="sidebar-bottom">

        <a href="profile.php" class="bottom-link">
            <i class="fas fa-user-circle"></i>
            <span>My Profile</span>
        </a>


        <a href="../logout.php" class="bottom-link logout">
            <i class="fas fa-right-from-bracket"></i>
            <span>Logout</span>
        </a>

    </div>

</aside>

<div class="content-wrapper">