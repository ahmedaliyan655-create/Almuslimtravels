<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Regenerate long-lived sessions periodically to reduce session fixation risk.
if (isset($_SESSION['agent_id'])) {
    $lastRotation = (int)($_SESSION['_rotated_at'] ?? 0);
    if ($lastRotation === 0 || (time() - $lastRotation) > 1800) {
        session_regenerate_id(true);
        $_SESSION['_rotated_at'] = time();
    }
}
