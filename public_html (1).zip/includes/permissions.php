<?php

declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
function canManageAllStaff(): bool
{
    return isManager();
}
function canManageStaff(): bool
{
    return isManager() || isAdmin();
}
function isTeamLeadAgent(int $agentId, ?int $leadId = null): bool
{
    $leadId = $leadId ?? (int)authId();
    if ($leadId <= 0 || $agentId <= 0) return false;
    return (bool)Database::selectOne("SELECT a.id FROM agents a LEFT JOIN teams t ON t.id=a.team_id WHERE a.id=? AND a.role='agent' AND a.is_active=1 AND (a.team_lead_id=? OR t.team_lead_id=? OR EXISTS(SELECT 1 FROM team_members tm WHERE tm.agent_id=a.id AND tm.team_id=t.id AND t.team_lead_id=?)) LIMIT 1", [$agentId, $leadId, $leadId, $leadId]);
}
function teamAgentIds(?int $leadId = null): array
{
    $leadId = $leadId ?? (int)authId();
    if ($leadId <= 0) return [];
    $rows = Database::select("SELECT DISTINCT a.id FROM agents a LEFT JOIN teams t ON t.id=a.team_id WHERE a.role='agent' AND a.is_active=1 AND (a.team_lead_id=? OR t.team_lead_id=? OR a.id IN (SELECT tm.agent_id FROM team_members tm JOIN teams tt ON tt.id=tm.team_id WHERE tt.team_lead_id=?))", [$leadId, $leadId, $leadId]);
    return array_map(fn($r) => (int)$r['id'], $rows);
}
function canViewStaffMember(int $agentId): bool
{
    if ($agentId <= 0) return false;
    if (isManager() || isAdmin()) return true;
    if (isTeamLead()) return in_array($agentId, teamAgentIds(), true);
    return $agentId === (int)authId();
}
function canEditStaffMember(int $agentId): bool
{
    if ($agentId <= 0) return false;
    if (isManager()) return true;
    if (isAdmin()) {
        $t = Database::selectOne("SELECT role FROM agents WHERE id=?", [$agentId]);
        return $t && $t['role'] !== 'manager';
    }
    return isTeamLead() && isTeamLeadAgent($agentId);
}
function canDeleteStaffMember(int $agentId): bool
{
    if ($agentId <= 0) return false;
    if (isManager()) return $agentId !== (int)authId();
    if (isAdmin()) {
        $t = Database::selectOne("SELECT role FROM agents WHERE id=?", [$agentId]);
        return $t && !in_array($t['role'], ['manager', 'admin'], true);
    }
    return false;
}
function canAssignStaffRole(string $role): bool
{
    $role = strtolower(trim($role));
    if (isManager()) return in_array($role, ['manager', 'admin', 'teamlead', 'agent'], true);
    if (isAdmin()) return in_array($role, ['teamlead', 'agent'], true);
    return false;
}
function canViewProjects(): bool
{
    return isManager() || isAdmin();
}
function canViewTeams(): bool
{
    return isManager() || isAdmin();
}
function canViewIntegrations(): bool
{
    return true;
}
